import os
import json


def extract_py_files(file_path):
    py_files = []
    with open(file_path, 'r', encoding='utf-8') as file:
        for line in file:
            line = line.rstrip()
            if '── ' in line:
                parts = line.split('── ')
                candidate = parts[-1].strip()
                if candidate.endswith('.py'):
                    py_files.append(candidate)
    return py_files


def main():
    # 定义基础路径
    base_dir = r"C:\Users\cruzitodeng\Desktop\sys_gen\projs_filtered_uml"
    instruction_path = r"C:\Users\cruzitodeng\Desktop\sys_gen\projs_filtered_uml\model_gen\make_prompts_single\instruction_single.txt"
    prompts_output_file = r"C:\Users\cruzitodeng\Desktop\sys_gen\projs_filtered_uml\model_gen\make_prompts\prompts_single.jsonl"

    # 支持的层级目录
    LEVELS = ["level1", "level2", "level3", "level4"]

    # 读取提示模板
    try:
        with open(instruction_path, 'r', encoding='utf-8') as f:
            prompt_template = f.read()
    except FileNotFoundError:
        print(f"错误：指令文件 {instruction_path} 不存在")
        return

    # 创建输出文件
    with open(prompts_output_file, 'w', encoding='utf-8') as f_out:
        # 遍历每个层级
        for level in LEVELS:
            level_dir = os.path.join(base_dir, level)
            if not os.path.exists(level_dir):
                print(f"警告：层级目录不存在 - {level}")
                continue

            # 读取当前层级的描述文件
            des_file = os.path.join(level_dir, "des.jsonl")
            proj_desc_dict = {}

            if os.path.exists(des_file):
                with open(des_file, 'r', encoding='utf-8') as f:
                    for line in f:
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            data = json.loads(line)
                            proj_name = data.get('proj_name')
                            description = data.get('description', '') or data.get(',description', '')  # 兼容旧格式
                            if proj_name:
                                proj_desc_dict[proj_name] = description
                        except json.JSONDecodeError as e:
                            print(f"JSON解析失败（{des_file}）: {e} - 行内容: {line}")

            # 遍历当前层级的领域目录
            for domain in os.listdir(level_dir):
                domain_dir = os.path.join(level_dir, domain)

                # 跳过非目录项和des.jsonl文件
                if not os.path.isdir(domain_dir) or domain.endswith(".jsonl"):
                    continue

                # 遍历领域中的项目
                for project in os.listdir(domain_dir):
                    project_path = os.path.join(domain_dir, project)

                    if not os.path.isdir(project_path):
                        continue

                    # 检查uml_output目录是否存在
                    uml_output_dir = os.path.join(project_path, "uml_output")
                    if not os.path.exists(uml_output_dir):
                        print(f"缺少uml_output目录 - {project_path}")
                        continue

                    # 构建文件路径
                    json_file = os.path.join(uml_output_dir, f"{project}_uml.json")
                    txt_file = os.path.join(uml_output_dir, "tree.txt")

                    # 检查文件是否存在
                    if not (os.path.exists(json_file) and os.path.exists(txt_file)):
                        print(f"缺少必要文件 - {project}")
                        continue

                    # 获取项目描述
                    if project not in proj_desc_dict:
                        print(f"警告：未找到描述 - {level}.{domain}.{project}")
                        continue

                    # 读取文件内容
                    try:
                        with open(json_file, 'r', encoding='utf-8') as f:
                            uml_json_str = f.read()
                        with open(txt_file, 'r', encoding='utf-8') as f:
                            structure_tree = f.read()
                            py_files = extract_py_files(txt_file)
                    except Exception as e:
                        print(f"文件读取错误 - {project}: {str(e)}")
                        continue

                    # 生成prompt
                    try:
                        for py_file in py_files:
                            prompt = prompt_template.format(
                                code_generated=code_generated,
                                file_name=py_file,
                                proj_desc=proj_desc_dict[project],
                                uml_json_str=uml_json_str,
                                structure_tree=structure_tree
                            )
                            # 生成命名空间
                            namespace = f"{level}.{domain}.{project}.{py_file}"

                            # 写入结果
                            f_out.write(json.dumps({
                                "namespace": namespace,
                                "prompt": prompt
                            }, ensure_ascii=False) + '\n')
                    except KeyError as e:
                        print(f"提示模板变量缺失 - {project}: {str(e)}")
                        continue


if __name__ == "__main__":
    main()