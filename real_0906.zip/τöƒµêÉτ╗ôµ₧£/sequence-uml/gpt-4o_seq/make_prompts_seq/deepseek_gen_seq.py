import os
import json
import time
from openai import OpenAI
from tqdm import tqdm

# ---------- 参数区（与原脚本保持一致） ----------
BASE_DIR = r"C:\Users\cruzitodeng\Desktop\sys_gen\projs_filtered_uml"
INSTRUCTION_PATH = os.path.join(BASE_DIR, r"model_gen\make_prompts_seq\instruction_seq.txt")
PROMPTS_FILE = os.path.join(BASE_DIR, r"model_gen\make_prompts\prompts_seq.jsonl")
OUTPUT_DIR = r"C:\Users\cruzitodeng\Desktop\sys_gen\work12_new\sys_generation\generate_seq\deepseek-v3"
API_KEY_FILE = r"C:\Users\cruzitodeng\Desktop\sys_gen\work12_new\sys_generation\generate_single\api_key_deepseek.txt"
MODEL = "deepseek-chat"
MAX_TOKENS = 8192
T = 0               # greedy
TOP_P = None
N = 1
# -------------------------------------------------

def extract_py_files(tree_path: str):
    py_files = []
    with open(tree_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.rstrip()
            if "── " in line:
                candidate = line.split("── ")[-1].strip()
                if candidate.endswith(".py"):
                    py_files.append(candidate)
    return py_files


def load_instruction() -> str:
    with open(INSTRUCTION_PATH, "r", encoding="utf-8") as f:
        return f.read()


def load_api_key() -> str:
    with open(API_KEY_FILE, "r") as f:
        return f.readline().strip()


def ensure_dirs():
    os.makedirs(os.path.dirname(PROMPTS_FILE), exist_ok=True)
    os.makedirs(OUTPUT_DIR, exist_ok=True)


def main():
    ensure_dirs()
    instruction_tpl = load_instruction()
    api_key = load_api_key()
    client = OpenAI(api_key=api_key, base_url="https://api.deepseek.com/beta")

    f_prompt = open(PROMPTS_FILE, "w", encoding="utf-8")
    f_comp = open(os.path.join(OUTPUT_DIR, "completion_sequential.jsonl"),
                  "a", encoding="utf-8")

    LEVELS = ["level1", "level2", "level3", "level4"]

    for level in LEVELS:
        level_dir = os.path.join(BASE_DIR, level)
        if not os.path.isdir(level_dir):
            print(f"[WARN] {level} 不存在，跳过")
            continue

        proj_desc = {}
        des_path = os.path.join(level_dir, "des.jsonl")
        if os.path.exists(des_path):
            with open(des_path, "r", encoding="utf-8") as f:
                for ln in f:
                    ln = ln.strip()
                    if not ln:
                        continue
                    try:
                        d = json.loads(ln)
                        name = d.get("proj_name")
                        desc = d.get("description") or d.get(",description") or ""
                        if name:
                            proj_desc[name] = desc
                    except Exception as e:
                        print("JSON parse error in des:", e)

        for domain in os.listdir(level_dir):
            domain_dir = os.path.join(level_dir, domain)
            if not os.path.isdir(domain_dir):
                continue

            for project in os.listdir(domain_dir):
                project_dir = os.path.join(domain_dir, project)
                if not os.path.isdir(project_dir):
                    continue

                uml_out = os.path.join(project_dir, "uml_output")
                if not os.path.isdir(uml_out):
                    print(f"[WARN] 缺少 uml_output: {project_dir}")
                    continue

                uml_json_path = os.path.join(uml_out, f"{project}_uml.json")
                tree_path = os.path.join(uml_out, "tree.txt")
                if not (os.path.exists(uml_json_path) and os.path.exists(tree_path)):
                    print(f"[WARN] 缺少 uml 文件: {project}")
                    continue

                with open(uml_json_path, "r", encoding="utf-8") as fj:
                    uml_json_str = fj.read()
                with open(tree_path, "r", encoding="utf-8") as ft:
                    structure_tree = ft.read()

                py_files = extract_py_files(tree_path)

                if project not in proj_desc:
                    print(f"[WARN] 无描述: {level}.{domain}.{project}")
                    continue

                gen_dir = os.path.join(project_dir, "generated")
                os.makedirs(gen_dir, exist_ok=True)

                # 用于累计所有已生成代码
                accumulated_code = ""

                for py_file in py_files:
                    namespace = f"{level}.{domain}.{project}.{py_file}"
                    gen_file = os.path.join(gen_dir, py_file)

                    # 如果已生成，把它的内容追加到 accumulated_code
                    if os.path.exists(gen_file):
                        with open(gen_file, "r", encoding="utf-8") as gf:
                            file_content = gf.read()
                        accumulated_code += f"\n\n# ===== {py_file} =====\n{file_content}"

                    # 构造 prompt（使用累计代码）
                    prompt = instruction_tpl.format(
                        code_generated=accumulated_code,
                        file_name=py_file,
                        proj_desc=proj_desc[project],
                        uml_json_str=uml_json_str,
                        structure_tree=structure_tree
                    )

                    f_prompt.write(json.dumps({"namespace": namespace, "prompt": prompt},
                                              ensure_ascii=False) + "\n")
                    f_prompt.flush()

                    try:
                        resp = client.chat.completions.create(
                            model=MODEL,
                            messages=[{"role": "user", "content": prompt}],
                            temperature=T,
                            max_tokens=MAX_TOKENS,
                            n=N
                        )
                        code = resp.choices[0].message.content
                    except Exception as e:
                        print(f"[ERR] 请求失败 {namespace}: {e}")
                        time.sleep(2)
                        continue

                    with open(gen_file, "w", encoding="utf-8") as gf:
                        gf.write(code)

                    # 把刚生成的代码追加到累计区
                    accumulated_code += f"\n\n# ===== {py_file} =====\n{code}"

                    f_comp.write(json.dumps({"namespace": namespace, "completions": [code]},
                                            ensure_ascii=False) + "\n")
                    f_comp.flush()

    f_prompt.close()
    f_comp.close()
    print("全部完成！")


if __name__ == "__main__":
    main()