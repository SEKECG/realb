import requests
import pickle
import gspread
from oauth2client.service_account import ServiceAccountCredentials

class GarminExercisesCollector:
    def __init__(self):
        self.base_url = "https://connect.garmin.com"
        self.exercise_categories = ["general", "yoga", "pilates", "mobility"]
        self.data = {category: [] for category in self.exercise_categories}
        self.translations = {}
        self.google_sheets_id = None

    def fetch_exercise_data(self):
        for category in self.exercise_categories:
            url = f"{self.base_url}/exercise/{category}"
            response = requests.get(url)
            if response.status_code == 200:
                self.data[category] = response.json()
            else:
                print(f"Failed to fetch data for {category}")

    def fetch_translations(self):
        url = f"{self.base_url}/translations"
        response = requests.get(url)
        if response.status_code == 200:
            self.translations = response.json()
        else:
            print("Failed to fetch translations")

    def process_data(self):
        for category in self.exercise_categories:
            for exercise in self.data[category]:
                exercise['translated_name'] = self.translations.get(exercise['name'], exercise['name'])
                exercise['image_url'] = self.validate_image_url(exercise.get('image_url'))
                exercise['video_thumbnail_url'] = self.validate_image_url(exercise.get('video_thumbnail_url'))

    def validate_image_url(self, url):
        if url:
            response = requests.head(url)
            if response.status_code == 200:
                return url
        return None

    def save_data(self):
        with open('exercise_data.pkl', 'wb') as f:
            pickle.dump(self.data, f)

    def load_data(self):
        with open('exercise_data.pkl', 'rb') as f:
            self.data = pickle.load(f)

    def setup_google_sheets(self):
        scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
        creds = ServiceAccountCredentials.from_json_keyfile_name('credentials.json', scope)
        client = gspread.authorize(creds)
        if self.google_sheets_id:
            self.sheet = client.open_by_key(self.google_sheets_id)
        else:
            self.sheet = client.create("Garmin Exercises Data")
            self.google_sheets_id = self.sheet.id

    def update_google_sheets(self):
        for category in self.exercise_categories:
            worksheet = self.sheet.add_worksheet(title=category.capitalize(), rows="100", cols="20")
            worksheet.update([["Name", "Translated Name", "Description", "Difficulty", "Primary Muscles", "Secondary Muscles", "Equipment", "Image URL", "Video Thumbnail URL"]])
            for exercise in self.data[category]:
                worksheet.append_row([
                    exercise['name'],
                    exercise['translated_name'],
                    exercise.get('description', ''),
                    exercise.get('difficulty', ''),
                    ', '.join(exercise.get('primary_muscles', [])),
                    ', '.join(exercise.get('secondary_muscles', [])),
                    ', '.join(exercise.get('equipment', [])),
                    exercise.get('image_url', ''),
                    exercise.get('video_thumbnail_url', '')
                ])

    def run(self):
        self.fetch_exercise_data()
        self.fetch_translations()
        self.process_data()
        self.save_data()
        self.setup_google_sheets()
        self.update_google_sheets()

if __name__ == "__main__":
    collector = GarminExercisesCollector()
    collector.run()