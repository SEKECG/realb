import torch
from PIL import Image

def measure_gpu_speed():
    return torch.cuda.get_device_properties(0).total_memory

def resize_image_proportionally(image_path):
    image = Image.open(image_path)
    image.thumbnail((800, 800))
    return image