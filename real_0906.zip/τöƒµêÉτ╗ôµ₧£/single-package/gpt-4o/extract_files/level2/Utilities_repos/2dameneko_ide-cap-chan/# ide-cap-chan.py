import os
import torch
from arg_parser import parse_arguments
from image_processor import process_image_worker
from utils import measure_gpu_speed, resize_image_proportionally
from model_handlers import get_handler

def main():
    args = parse_arguments()
    model_handler = get_handler(args.model)
    input_dir = args.input_dir
    gpu_device = args.gpu_device

    images = [f for f in os.listdir(input_dir) if f.lower().endswith(('jpg', 'png', 'webp', 'jpeg'))]
    for image in images:
        image_path = os.path.join(input_dir, image)
        resized_image = resize_image_proportionally(image_path)
        process_image_worker(resized_image, model_handler, gpu_device, args)

if __name__ == "__main__":
    main()