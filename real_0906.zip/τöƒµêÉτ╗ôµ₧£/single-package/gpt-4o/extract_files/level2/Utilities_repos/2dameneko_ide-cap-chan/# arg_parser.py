import argparse

def check_mutually_exclusive(args):
    if args.model and args.generic_model:
        raise ValueError("Cannot specify both model and generic_model")

def parse_arguments():
    parser = argparse.ArgumentParser(description="Image Captioning System")
    parser.add_argument('--model', type=str, help='Specify the model to use')
    parser.add_argument('--generic_model', type=str, help='Specify a generic model for experimental use')
    parser.add_argument('--input_dir', type=str, required=True, help='Directory containing images')
    parser.add_argument('--gpu_device', type=int, default=0, help='GPU device to use')
    parser.add_argument('--output_extension', type=str, choices=['json', 'md', 'short', 'long', 'bbox'], help='Output file extension for captions')
    parser.add_argument('--use_tags', action='store_true', help='Incorporate existing tags to improve caption quality')
    parser.add_argument('--character_info', action='store_true', help='Include character information in captions')
    parser.add_argument('--character_traits', action='store_true', help='Include character traits in captions')
    parser.add_argument('--additional_info', action='store_true', help='Utilize additional image information')
    args = parser.parse_args()
    check_mutually_exclusive(args)
    return args