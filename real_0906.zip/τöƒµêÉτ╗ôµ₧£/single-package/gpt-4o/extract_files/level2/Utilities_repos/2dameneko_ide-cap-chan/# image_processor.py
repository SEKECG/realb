import torch
from utils import measure_gpu_speed

def process_image_worker(image, model_handler, gpu_device, args):
    device = torch.device(f'cuda:{gpu_device}' if torch.cuda.is_available() else 'cpu')
    model_handler.initialize(device)
    caption = model_handler.generate_caption(image, args)
    save_caption(image, caption, args.output_extension)

def get_handler(model_name):
    if model_name == 'JoyCaption':
        return JoyCaptionHandler()
    elif model_name == 'MoLMo':
        return MoLMoHandler()
    elif model_name == 'MoLMo72b':
        return MoLMo72bHandler()
    elif model_name == 'Qwen2VL':
        return Qwen2VLHandler()
    elif model_name == 'Pixtral':
        return PixtralHandler()
    elif model_name == 'Idefics3':
        return Idefics3Handler()
    elif model_name == 'ExLLaMA2':
        return ExLLaMA2Handler()
    elif model_name == 'Llava':
        return LlavaHandler()
    elif model_name == 'MiniCPMo':
        return MiniCPMoHandler()
    else:
        return GenericModelHandler()

def save_caption(image, caption, extension):
    output_file = f"{image}.{extension}"
    with open(output_file, 'w') as f:
        f.write(caption)