import emojichef

class EmojiChefCLI:
    def __init__(self):
        self.colors = emojichef.Colors()

    def run(self):
        emojichef.main()

def main():
    cli = EmojiChefCLI()
    cli.run()

if __name__ == "__main__":
    main()