import os
import glob
import sqlite3
import json
import math
import folium
from datetime import datetime
from collections import defaultdict
import logging
import argparse

logging.basicConfig(level=logging.DEBUG)

def haversine(lat1, lon1, lat2, lon2):
    R = 3958.8  # Earth radius in miles
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2) ** 2
    return 2 * R * math.atan2(math.sqrt(a), math.sqrt(1 - a))

def is_valid_lat_lon(lat, lon):
    return -90 <= lat <= 90 and -180 <= lon <= 180

def sanitize_string(s):
    return s.encode('ascii', 'ignore').decode('ascii')

def is_drone(device_name, mac_address):
    drone_ssid_patterns = ["drone", "DJI"]
    drone_mac_prefixes = ["60:60:1F", "90:3A:E6"]
    return any(pattern in device_name for pattern in drone_ssid_patterns) or any(mac_address.startswith(prefix) for prefix in drone_mac_prefixes)

def find_most_recent_kismet_file(directory):
    files = glob.glob(os.path.join(directory, '*.kismet'))
    if not files:
        return None
    return max(files, key=os.path.getctime)

def extract_device_detections(db_path):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM devices")
    devices = cursor.fetchall()
    conn.close()
    return devices

def detect_snoopers(devices, distance_threshold=0.05):
    snoopers = []
    for device in devices:
        if len(device['locations']) < 2:
            continue
        total_distance = 0
        for i in range(1, len(device['locations'])):
            lat1, lon1 = device['locations'][i-1]
            lat2, lon2 = device['locations'][i]
            distance = haversine(lat1, lon1, lat2, lon2)
            total_distance += distance
            if distance > distance_threshold:
                snoopers.append(device)
                break
    return snoopers

def extract_alerts_from_kismet(db_path):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM alerts")
    alerts = cursor.fetchall()
    conn.close()
    return alerts

def visualize_devices_snoopers_and_alerts(devices, snoopers, alerts, output_file):
    m = folium.Map(location=[0, 0], zoom_start=2)
    for device in devices:
        folium.Marker(
            location=[device['lat'], device['lon']],
            popup=f"{device['name']} ({device['mac']})",
            icon=folium.Icon(color='blue' if device['type'] == 'Wi-Fi AP' else 'green')
        ).add_to(m)
    for snooper in snoopers:
        folium.Marker(
            location=[snooper['lat'], snooper['lon']],
            popup=f"Snooper: {snooper['name']} ({snooper['mac']})",
            icon=folium.Icon(color='red')
        ).add_to(m)
    for alert in alerts:
        folium.Marker(
            location=[alert['lat'], alert['lon']],
            popup=f"Alert: {alert['type']}",
            icon=folium.Icon(color='orange')
        ).add_to(m)
    m.save(output_file)

def parse_arguments():
    parser = argparse.ArgumentParser(description="SnoopR - Kismet Device Visualization and Analysis Tool")
    parser.add_argument("directory", help="Directory containing Kismet database files")
    parser.add_argument("output_file", help="Output HTML file for the map")
    return parser.parse_args()

def main():
    args = parse_arguments()
    db_file = find_most_recent_kismet_file(args.directory)
    if not db_file:
        logging.error("No Kismet database file found in the specified directory.")
        return
    devices = extract_device_detections(db_file)
    snoopers = detect_snoopers(devices)
    alerts = extract_alerts_from_kismet(db_file)
    visualize_devices_snoopers_and_alerts(devices, snoopers, alerts, args.output_file)

if __name__ == "__main__":
    main()