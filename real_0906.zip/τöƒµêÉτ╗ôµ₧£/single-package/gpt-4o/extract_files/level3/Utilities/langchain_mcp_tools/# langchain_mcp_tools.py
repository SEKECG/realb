import subprocess
import os
import logging
import json
import asyncio
import websockets
import requests
from contextlib import contextmanager

class McpServerCommandBasedConfig:
    def __init__(self, command, args=None, env=None, cwd=None):
        self.command = command
        self.args = args or []
        self.env = env or {}
        self.cwd = cwd

class McpServerUrlBasedConfig:
    def __init__(self, url, protocol):
        self.url = url
        self.protocol = protocol

def init_logger(log_file=None):
    logger = logging.getLogger('langchain_mcp_tools')
    logger.setLevel(logging.DEBUG)
    handler = logging.FileHandler(log_file) if log_file else logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    return logger

logger = init_logger()

async def spawn_mcp_server_and_get_transport(config):
    if isinstance(config, McpServerCommandBasedConfig):
        process = await asyncio.create_subprocess_exec(
            config.command, *config.args,
            env=config.env, cwd=config.cwd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        return process
    elif isinstance(config, McpServerUrlBasedConfig):
        if config.protocol == 'ws':
            websocket = await websockets.connect(config.url)
            return websocket
        elif config.protocol in ['http', 'https']:
            response = requests.get(config.url, stream=True)
            return response
    else:
        raise ValueError("Unsupported server configuration")

def convert_mcp_to_langchain_tools(mcp_tools):
    langchain_tools = []
    for tool in mcp_tools:
        langchain_tool = {
            'name': tool['name'],
            'description': tool['description'],
            'input_schema': fix_schema(tool['input_schema']),
            'output_schema': fix_schema(tool['output_schema']),
            'execute': tool['execute']
        }
        langchain_tools.append(langchain_tool)
    return langchain_tools

def fix_schema(schema):
    # Implement schema fixing logic here
    return schema

async def get_mcp_server_tools(transport):
    if isinstance(transport, subprocess.Process):
        stdout, stderr = await transport.communicate()
        if stderr:
            logger.error(f"Server error: {stderr.decode()}")
        tools = json.loads(stdout.decode())
    elif isinstance(transport, websockets.WebSocketClientProtocol):
        async for message in transport:
            tools = json.loads(message)
            break
    elif isinstance(transport, requests.Response):
        tools = json.loads(transport.content.decode())
    else:
        raise ValueError("Unsupported transport type")
    return tools

@contextmanager
def lifecycle_management(transport):
    try:
        yield
    finally:
        if isinstance(transport, subprocess.Process):
            transport.terminate()
        elif isinstance(transport, websockets.WebSocketClientProtocol):
            asyncio.run(transport.close())
        elif isinstance(transport, requests.Response):
            transport.close()

def cleanup():
    # Implement cleanup logic here
    pass