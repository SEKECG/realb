from setuptools import setup, find_packages

setup(
    name='symeval',
    version='0.1',
    packages=find_packages(),
    install_requires=[
        'sympy',
        'pebble',
        'tqdm'
    ],
    entry_points={
        'console_scripts': [
            'symeval=symeval.core:main',
        ],
    },
)