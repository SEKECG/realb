import psycopg2
import geopandas as gpd
import sqlalchemy
from rich.console import Console
from rich.prompt import Prompt
import hashlib
import os
import sys
import argparse

console = Console()

def connect_db():
    try:
        dbname = Prompt.ask("Enter database name")
        user = Prompt.ask("Enter username")
        password = Prompt.ask("Enter password", password=True)
        host = Prompt.ask("Enter host", default="localhost")
        port = Prompt.ask("Enter port", default="5432")
        
        conn = psycopg2.connect(dbname=dbname, user=user, password=password, host=host, port=port)
        console.log("Database connection established", style="bold green")
        return conn
    except Exception as e:
        console.log(f"Error connecting to database: {e}", style="bold red")
        sys.exit(1)

def check_schema_exists(conn, schema):
    try:
        cur = conn.cursor()
        cur.execute(f"SELECT schema_name FROM information_schema.schemata WHERE schema_name = '{schema}'")
        exists = cur.fetchone() is not None
        cur.close()
        return exists
    except Exception as e:
        console.log(f"Error checking schema existence: {e}", style="bold red")
        return False

def check_table_exists(conn, schema, table):
    try:
        cur = conn.cursor()
        cur.execute(f"SELECT table_name FROM information_schema.tables WHERE table_schema = '{schema}' AND table_name = '{table}'")
        exists = cur.fetchone() is not None
        cur.close()
        return exists
    except Exception as e:
        console.log(f"Error checking table existence: {e}", style="bold red")
        return False

def get_existing_tables(conn, schema):
    try:
        cur = conn.cursor()
        cur.execute(f"SELECT table_name FROM information_schema.tables WHERE table_schema = '{schema}'")
        tables = [row[0] for row in cur.fetchall()]
        cur.close()
        return tables
    except Exception as e:
        console.log(f"Error retrieving existing tables: {e}", style="bold red")
        return []

def get_db_geometry_column(conn, schema, table):
    try:
        cur = conn.cursor()
        cur.execute(f"SELECT column_name FROM information_schema.columns WHERE table_schema = '{schema}' AND table_name = '{table}' AND udt_name = 'geometry'")
        column = cur.fetchone()
        cur.close()
        return column[0] if column else None
    except Exception as e:
        console.log(f"Error retrieving geometry column: {e}", style="bold red")
        return None

def get_non_essential_columns(conn, schema, table):
    try:
        cur = conn.cursor()
        cur.execute(f"SELECT column_name FROM information_schema.columns WHERE table_schema = '{schema}' AND table_name = '{table}' AND column_name NOT IN ('geom', 'geometry')")
        columns = [row[0] for row in cur.fetchall()]
        cur.close()
        return columns
    except Exception as e:
        console.log(f"Error retrieving non-essential columns: {e}", style="bold red")
        return []

def compute_geom_hash(geometry):
    return hashlib.sha256(geometry.wkb).hexdigest()

def compare_geometries(source_geom, db_geom):
    return compute_geom_hash(source_geom) == compute_geom_hash(db_geom)

def create_generic_geometry_table(conn, schema, table, geom_type, srid):
    try:
        cur = conn.cursor()
        cur.execute(f"""
            CREATE TABLE {schema}.{table} (
                id SERIAL PRIMARY KEY,
                geom geometry({geom_type}, {srid})
            )
        """)
        conn.commit()
        cur.close()
        console.log(f"Table {schema}.{table} created successfully", style="bold green")
    except Exception as e:
        console.log(f"Error creating table: {e}", style="bold red")

def create_spatial_index(conn, schema, table, column):
    try:
        cur = conn.cursor()
        cur.execute(f"CREATE INDEX {table}_{column}_idx ON {schema}.{table} USING GIST ({column})")
        conn.commit()
        cur.close()
        console.log(f"Spatial index on {schema}.{table}.{column} created successfully", style="bold green")
    except Exception as e:
        console.log(f"Error creating spatial index: {e}", style="bold red")

def append_geometries(conn, schema, table, geometries):
    try:
        cur = conn.cursor()
        for geom in geometries:
            cur.execute(f"INSERT INTO {schema}.{table} (geom) VALUES (ST_GeomFromText('{geom.wkt}', {geom.crs.to_epsg()}))")
        conn.commit()
        cur.close()
        console.log(f"Geometries appended to {schema}.{table} successfully", style="bold green")
    except Exception as e:
        console.log(f"Error appending geometries: {e}", style="bold red")

def update_geometries(conn, schema, table, updates):
    try:
        cur = conn.cursor()
        for id, geom in updates.items():
            cur.execute(f"UPDATE {schema}.{table} SET geom = ST_GeomFromText('{geom.wkt}', {geom.crs.to_epsg()}) WHERE id = {id}")
        conn.commit()
        cur.close()
        console.log(f"Geometries in {schema}.{table} updated successfully", style="bold green")
    except Exception as e:
        console.log(f"Error updating geometries: {e}", style="bold red")

def backup_tables(conn, schema, table):
    try:
        cur = conn.cursor()
        backup_table = f"{table}_backup"
        cur.execute(f"CREATE TABLE {schema}.{backup_table} AS TABLE {schema}.{table}")
        conn.commit()
        cur.close()
        console.log(f"Backup of {schema}.{table} created successfully", style="bold green")
    except Exception as e:
        console.log(f"Error creating backup: {e}", style="bold red")

def manage_old_backups(conn, schema, table):
    try:
        cur = conn.cursor()
        cur.execute(f"SELECT table_name FROM information_schema.tables WHERE table_schema = '{schema}' AND table_name LIKE '{table}_backup%' ORDER BY table_name DESC")
        backups = [row[0] for row in cur.fetchall()]
        if len(backups) > 3:
            for old_backup in backups[3:]:
                cur.execute(f"DROP TABLE {schema}.{old_backup}")
        conn.commit()
        cur.close()
        console.log(f"Old backups managed successfully", style="bold green")
    except Exception as e:
        console.log(f"Error managing old backups: {e}", style="bold red")

def check_crs_compatibility(source_crs, target_crs):
    return source_crs == target_crs

def check_geometry_type_constraint(source_geom_type, target_geom_type):
    return source_geom_type == target_geom_type

def identify_affected_tables(conn, schema, table, geometries):
    try:
        cur = conn.cursor()
        affected_tables = []
        for geom in geometries:
            cur.execute(f"SELECT id FROM {schema}.{table} WHERE ST_Equals(geom, ST_GeomFromText('{geom.wkt}', {geom.crs.to_epsg()}))")
            if cur.fetchone():
                affected_tables.append(table)
        cur.close()
        return affected_tables
    except Exception as e:
        console.log(f"Error identifying affected tables: {e}", style="bold red")
        return []

def build_update_statement(schema, table, updates):
    statements = []
    for id, geom in updates.items():
        statements.append(f"UPDATE {schema}.{table} SET geom = ST_GeomFromText('{geom.wkt}', {geom.crs.to_epsg()}) WHERE id = {id}")
    return statements

def quote_identifier(identifier):
    return f'"{identifier}"'

def print_geometry_details(geometry):
    console.log(f"Geometry: {geometry.wkt}, CRS: {geometry.crs.to_epsg()}", style="bold blue")

def process_files(files):
    geometries = []
    for file in files:
        gdf = gpd.read_file(file)
        for geom in gdf.geometry:
            geometries.append(geom)
    return geometries

def parse_arguments():
    parser = argparse.ArgumentParser(description="DBFriend - PostgreSQL Spatial Data Management Tool")
    parser.add_argument("--schema", required=True, help="Schema name")
    parser.add_argument("--table", required=True, help="Table name")
    parser.add_argument("--files", nargs="+", required=True, help="Spatial files to process")
    return parser.parse_args()

def main():
    args = parse_arguments()
    conn = connect_db()
    
    if not check_schema_exists(conn, args.schema):
        console.log(f"Schema {args.schema} does not exist", style="bold red")
        sys.exit(1)
    
    if not check_table_exists(conn, args.schema, args.table):
        console.log(f"Table {args.schema}.{args.table} does not exist", style="bold red")
        sys.exit(1)
    
    geometries = process_files(args.files)
    existing_tables = get_existing_tables(conn, args.schema)
    
    if args.table not in existing_tables:
        create_generic_geometry_table(conn, args.schema, args.table, "MULTIPOLYGON", 4326)
    
    append_geometries(conn, args.schema, args.table, geometries)
    create_spatial_index(conn, args.schema, args.table, "geom")
    
    conn.close()

if __name__ == "__main__":
    main()