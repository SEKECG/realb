import argparse
import torch
from inference import embed_camera_settings
from camera_embed import CameraSettingEmbedding

def parse_args():
    parser = argparse.ArgumentParser(description="Text to Image Generation with Camera Settings")
    parser.add_argument("--prompt", type=str, required=True, help="Text prompt for image generation")
    parser.add_argument("--focal_length", type=float, help="Focal length of the camera")
    parser.add_argument("--aperture", type=float, help="Aperture of the camera")
    parser.add_argument("--iso_speed", type=float, help="ISO speed of the camera")
    parser.add_argument("--exposure_time", type=float, help="Exposure time of the camera")
    return parser.parse_args()

def main():
    args = parse_args()
    embedding_model = CameraSettingEmbedding(embedding_dim=512, hidden_dim=256, activation='relu', layer_norm=True, zero_init=True)
    camera_embedding = embed_camera_settings(args.focal_length, args.aperture, args.iso_speed, args.exposure_time, embedding_model)
    # Placeholder for Stable Diffusion integration
    print(f"Generated camera embedding: {camera_embedding}")

if __name__ == "__main__":
    main()