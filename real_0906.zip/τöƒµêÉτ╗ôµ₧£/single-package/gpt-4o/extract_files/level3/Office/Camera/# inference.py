import torch
from camera_embed import CameraSettingEmbedding

def embed_camera_settings(focal_length, aperture, iso_speed, exposure_time, embedding_model):
    if focal_length is None:
        focal_length = torch.tensor(0.0)
    if aperture is None:
        aperture = torch.tensor(0.0)
    if iso_speed is None:
        iso_speed = torch.tensor(0.0)
    if exposure_time is None:
        exposure_time = torch.tensor(0.0)
    
    camera_embedding = embedding_model(focal_length, aperture, iso_speed, exposure_time)
    return camera_embedding