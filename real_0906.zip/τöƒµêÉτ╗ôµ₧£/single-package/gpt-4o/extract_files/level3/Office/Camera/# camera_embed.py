import torch
import torch.nn as nn
import torch.nn.functional as F

class CameraSettingEmbedding(nn.Module):
    def __init__(self, embedding_dim, hidden_dim, activation='relu', layer_norm=False, zero_init=False):
        super(CameraSettingEmbedding, self).__init__()
        self.embedding_dim = embedding_dim
        self.hidden_dim = hidden_dim
        self.activation = activation
        self.layer_norm = layer_norm
        self.zero_init = zero_init

        self.fc1 = nn.Linear(4, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, embedding_dim)
        if layer_norm:
            self.ln = nn.LayerNorm(embedding_dim)
        if zero_init:
            nn.init.zeros_(self.fc2.weight)
            nn.init.zeros_(self.fc2.bias)

    def forward(self, focal_length, aperture, iso_speed, exposure_time):
        x = torch.stack([focal_length, aperture, iso_speed, exposure_time], dim=-1)
        x = torch.log1p(x)
        x = self.fc1(x)
        if self.activation == 'relu':
            x = F.relu(x)
        elif self.activation == 'silu':
            x = F.silu(x)
        elif self.activation == 'gelu':
            x = F.gelu(x)
        x = self.fc2(x)
        if self.layer_norm:
            x = self.ln(x)
        return x