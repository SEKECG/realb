from src.Game import Game
from src.Player import Player
from agents.NaiveAgent import NaiveAgent

def main():
    player1 = Player("Player 1", "Red")
    player2 = NaiveAgent("AI", "Blue")
    game = Game(player1, player2)
    game.start()

if __name__ == "__main__":
    main()