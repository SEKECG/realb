import streamlit as st
from utils import load_css, init_watsonx, run_watson_granite, show_error, show_info, show_success, show_warning

def main():
    st.set_page_config(page_title="EduNexus 2.0", layout="wide")
    load_css()
    
    st.title("Welcome to EduNexus 2.0")
    st.markdown("### Empowering Education with Technology")
    
    # Personalized Learning
    st.header("Personalized Learning")
    st.write("Customized learning plans tailored to individual needs and goals.")
    
    # Smart Summaries
    st.header("Smart Summaries")
    document = st.text_area("Paste your document here:")
    if st.button("Generate Summary"):
        if document:
            summary = run_watson_granite(document)
            st.write(summary)
        else:
            show_warning("Please paste a document to summarize.")
    
    # AI Code Mentor
    st.header("AI Code Mentor")
    code_query = st.text_area("Enter your coding query:")
    if st.button("Get Assistance"):
        if code_query:
            response = run_watson_granite(code_query)
            st.write(response)
        else:
            show_warning("Please enter a coding query.")
    
    # Study Planner
    st.header("Study Planner")
    st.write("Create and manage effective study schedules.")
    
    # Real-time Support
    st.header("Real-time Support")
    st.write("Instant answers to academic questions.")
    
    # Multi-Language Support
    st.header("Multi-Language Support")
    st.write("Accommodates users from different linguistic backgrounds.")
    
    # Mental Wellness Resources
    st.header("Mental Wellness Resources")
    st.write("Support and materials for maintaining mental well-being during studies.")
    
    # AI-Generated Study Resources
    st.header("AI-Generated Study Resources")
    st.write("Automatically generated study materials to aid learning.")
    
    # Inspirational Quotes
    st.header("Inspirational Quotes")
    st.write("Random inspirational quotes to motivate users.")
    
    # Team Information
    st.header("Team Information")
    st.write("Developed by a diverse team of specialists:")
    st.write("- **M Ibrahim Qasmi** (Team Leader, Data Science Specialist)")
    st.write("- **TIJANI S. OLALEKAN** (Software Engineer, Development Specialist)")
    st.write("- **Maryam Sikander** (ML Engineer, Machine Learning Specialist)")
    st.write("- **Ahmad Fakhar** (Data Analyst)")
    st.write("- **M Jawad** (Data Analyst)")
    st.write("- **TAYYAB SAJJAD** (Web Expert, Web Development Specialist)")

if __name__ == "__main__":
    main()