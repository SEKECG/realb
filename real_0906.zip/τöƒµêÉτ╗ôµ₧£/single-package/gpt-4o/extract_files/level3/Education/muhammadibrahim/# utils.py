import streamlit as st
import requests
import os

def load_css():
    st.markdown(
        """
        <style>
        .main {
            background-color: #f0f2f6;
        }
        .stButton>button {
            background-color: #4CAF50;
            color: white;
        }
        </style>
        """,
        unsafe_allow_html=True
    )

def init_watsonx():
    api_key = os.getenv("WATSONX_API_KEY")
    if not api_key:
        show_error("IBM WatsonX API key is not set.")
    return api_key

def run_watson_granite(text):
    api_key = init_watsonx()
    if not api_key:
        return "Error: API key not found."
    
    url = "https://api.us-south.watsonx.com/v1/analyze"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}"
    }
    data = {
        "text": text,
        "features": {
            "summarize": {}
        }
    }
    
    response = requests.post(url, json=data, headers=headers)
    if response.status_code == 200:
        return response.json().get("summary", "No summary available.")
    else:
        show_error("Error in WatsonX API call.")
        return "Error: Unable to generate summary."

def show_error(message):
    st.error(message)

def show_info(message):
    st.info(message)

def show_success(message):
    st.success(message)

def show_warning(message):
    st.warning(message)