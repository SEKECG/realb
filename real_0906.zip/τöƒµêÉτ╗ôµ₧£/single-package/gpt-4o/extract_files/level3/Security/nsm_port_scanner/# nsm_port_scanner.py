import socket
import threading
import json
import os
import requests
import time
from datetime import datetime

# Utility functions
def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def clean_text(text):
    return ''.join(e for e in text if e.isalnum())

def connection_status():
    try:
        requests.get('https://www.google.com', timeout=5)
        return True
    except requests.ConnectionError:
        return False

def flush_dns():
    if os.name == 'nt':
        os.system('ipconfig /flushdns')
    else:
        os.system('sudo dscacheutil -flushcache; sudo killall -HUP mDNSResponder')

def show_help_menu():
    print("NSM Port Scanner Help Menu")
    print("Usage: python nsm_port_scanner.py [options]")
    print("Options:")
    print("  --help                Show this help message and exit")
    print("  --scan <target>       Perform a port scan on the target")
    print("  --resolve <domain>    Resolve the domain to an IP address")
    print("  --subdomains <domain> Enumerate subdomains for the domain")
    print("  --geoip <ip>          Perform a GeoIP lookup for the IP address")
    print("  --shodan <ip>         Retrieve Shodan information for the IP address")
    print("  --flushdns            Flush the DNS cache")
    print("  --status              Show connection status")
    print("  --config              Show configuration options")

def welcome():
    print("Welcome to NSM Port Scanner")
    print("For educational and testing purposes only")

def about_me():
    print("NSM Port Scanner developed by [Your Name]")
    print("Version 1.0.0")

def version_lookup():
    return "1.0.0"

def noty(message):
    print(f"Notification: {message}")

# Core functionalities
def port_scan(target, full_scan=False):
    open_ports = []
    ports = range(0, 65536) if full_scan else range(0, 1025)
    for port in ports:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1)
        result = sock.connect_ex((target, port))
        if result == 0:
            open_ports.append(port)
        sock.close()
    return open_ports

def domain_resolver(domain):
    try:
        return socket.gethostbyname(domain)
    except socket.gaierror:
        return None

def sub_resolver(domain, full=False):
    subdomains = ["www", "mail", "ftp"] if not full else ["www", "mail", "ftp", "blog", "dev", "test"]
    resolved_subdomains = []
    for sub in subdomains:
        subdomain = f"{sub}.{domain}"
        ip = domain_resolver(subdomain)
        if ip:
            resolved_subdomains.append((subdomain, ip))
    return resolved_subdomains

def geo_lookup(ip, api_key=None):
    url = f"https://ipinfo.io/{ip}/json"
    if api_key:
        url += f"?token={api_key}"
    response = requests.get(url)
    return response.json()

def shodan_lookup(ip, api_key):
    url = f"https://api.shodan.io/shodan/host/{ip}?key={api_key}"
    response = requests.get(url)
    return response.json()

def save_results(filename, data):
    with open(filename, 'w') as file:
        json.dump(data, file)

def load_config():
    with open('config.json', 'r') as file:
        return json.load(file)

def save_config(config):
    with open('config.json', 'w') as file:
        json.dump(config, file)

def main():
    welcome()
    config = load_config()
    while True:
        command = input("NSM> ").strip().lower()
        if command == "exit":
            break
        elif command.startswith("--scan"):
            target = command.split()[1]
            full_scan = "--full" in command
            open_ports = port_scan(target, full_scan)
            print(f"Open ports on {target}: {open_ports}")
        elif command.startswith("--resolve"):
            domain = command.split()[1]
            ip = domain_resolver(domain)
            print(f"IP address of {domain}: {ip}")
        elif command.startswith("--subdomains"):
            domain = command.split()[1]
            full = "--full" in command
            subdomains = sub_resolver(domain, full)
            print(f"Subdomains of {domain}: {subdomains}")
        elif command.startswith("--geoip"):
            ip = command.split()[1]
            api_key = config.get("ipinfo_api_key")
            geo_info = geo_lookup(ip, api_key)
            print(f"GeoIP information for {ip}: {geo_info}")
        elif command.startswith("--shodan"):
            ip = command.split()[1]
            api_key = config.get("shodan_api_key")
            shodan_info = shodan_lookup(ip, api_key)
            print(f"Shodan information for {ip}: {shodan_info}")
        elif command == "--flushdns":
            flush_dns()
            print("DNS cache flushed")
        elif command == "--status":
            status = connection_status()
            print(f"Internet connection status: {'Connected' if status else 'Disconnected'}")
        elif command == "--config":
            print("Configuration options:")
            print(json.dumps(config, indent=4))
        elif command == "--help":
            show_help_menu()
        else:
            print("Unknown command. Type --help for a list of commands.")

if __name__ == "__main__":
    main()