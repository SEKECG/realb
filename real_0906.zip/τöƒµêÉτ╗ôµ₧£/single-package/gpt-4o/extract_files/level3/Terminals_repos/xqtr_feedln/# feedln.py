import sqlite3
import csv
import os
import sys
import configparser
import threading
import subprocess
import logging
from espeak import espeak

CONFIG_FILE = 'feedln.cfg'
DEFAULT_FEED_FILE = 'default_feed.csv'

def check_feed_file():
    if not os.path.exists(DEFAULT_FEED_FILE):
        with open(DEFAULT_FEED_FILE, 'w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(['name', 'url', 'tags'])
            writer.writerow(['Sample Feed', 'http://example.com/rss', 'sample'])

def footer():
    print("\n--- End of Feedln ---")

def footerpop():
    print("\n--- End of Feedln ---")

def format_file_size(size):
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size < 1024:
            return f"{size:.2f} {unit}"
        size /= 1024

def header():
    print("\n--- Welcome to Feedln ---")

def is_program_installed(program):
    try:
        subprocess.call([program], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        return True
    except FileNotFoundError:
        return False

def load_config():
    config = configparser.ConfigParser()
    config.read(CONFIG_FILE)
    return config

def load_feeds_to_db(csv_file, db_file):
    conn = sqlite3.connect(db_file)
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS feeds
                      (name TEXT, url TEXT, tags TEXT)''')
    cursor.execute('''CREATE TABLE IF NOT EXISTS categories
                      (name TEXT)''')
    cursor.execute('''CREATE TABLE IF NOT EXISTS feed_items
                      (title TEXT, summary TEXT, content TEXT, read_status INTEGER)''')
    cursor.execute('''CREATE TABLE IF NOT EXISTS feed_category
                      (feed_id INTEGER, category_id INTEGER)''')
    with open(csv_file, 'r') as file:
        reader = csv.reader(file)
        next(reader)  # Skip header row
        for row in reader:
            cursor.execute('INSERT INTO feeds (name, url, tags) VALUES (?, ?, ?)', row)
    conn.commit()
    conn.close()

def log_event(event):
    logging.basicConfig(filename='feedln.log', level=logging.INFO)
    logging.info(event)

def parse_arguments():
    import argparse
    parser = argparse.ArgumentParser(description='Feedln - RSS Feed Reader')
    parser.add_argument('csv_file', help='CSV file containing RSS feed information')
    return parser.parse_args()

def run_program():
    args = parse_arguments()
    check_feed_file()
    load_feeds_to_db(args.csv_file, 'feedln.db')
    log_event('Program executed successfully')
    header()
    footer()

def setup_database(db_file):
    conn = sqlite3.connect(db_file)
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS feeds
                      (name TEXT, url TEXT, tags TEXT)''')
    cursor.execute('''CREATE TABLE IF NOT EXISTS categories
                      (name TEXT)''')
    cursor.execute('''CREATE TABLE IF NOT EXISTS feed_items
                      (title TEXT, summary TEXT, content TEXT, read_status INTEGER)''')
    cursor.execute('''CREATE TABLE IF NOT EXISTS feed_category
                      (feed_id INTEGER, category_id INTEGER)''')
    conn.commit()
    conn.close()

class InterruptibleTTS:
    def __init__(self):
        self.thread = None

    def speak(self, text):
        if self.thread and self.thread.is_alive():
            self.thread.join()
        self.thread = threading.Thread(target=espeak.synth, args=(text,))
        self.thread.start()

if __name__ == '__main__':
    run_program()