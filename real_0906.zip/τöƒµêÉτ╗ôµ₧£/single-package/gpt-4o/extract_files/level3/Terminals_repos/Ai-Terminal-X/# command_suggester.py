import os
import google.generativeai as gemini
from dotenv import load_dotenv

def configure_ai():
    load_dotenv()
    api_key = os.getenv('GEMINI_API_KEY')
    if not api_key:
        raise EnvironmentError("GEMINI_API_KEY not found in .env file.")
    gemini.configure(api_key)

def load_api_key():
    load_dotenv()
    return os.getenv('GEMINI_API_KEY')

def parse_suggestions(request):
    response = gemini.suggest(request)
    suggestions = response['suggestions']
    return suggestions