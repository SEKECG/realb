import os
import subprocess
import json
import google.generativeai as gemini
from dotenv import load_dotenv
from command_suggester import configure_ai as suggester_configure_ai, load_api_key as suggester_load_api_key, parse_suggestions

def check_external_tools():
    required_tools = ['tmux', 'xfce4-terminal']
    for tool in required_tools:
        if subprocess.call(['which', tool], stdout=subprocess.PIPE, stderr=subprocess.PIPE) != 0:
            raise EnvironmentError(f"{tool} is not installed.")

def check_tmux_session():
    result = subprocess.run(['tmux', 'ls'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if result.returncode != 0:
        subprocess.run(['tmux', 'new-session', '-d', '-s', 'ai_terminal_x'])

def configure_ai():
    load_dotenv()
    api_key = os.getenv('GEMINI_API_KEY')
    if not api_key:
        raise EnvironmentError("GEMINI_API_KEY not found in .env file.")
    gemini.configure(api_key)

def explain_command(command):
    explanation = gemini.explain(command)
    return explanation

def gemini_command_and_explanation(request):
    response = gemini.generate(request)
    command = response['command']
    explanation = response['explanation']
    return command, explanation

def get_user_input():
    return input("Enter your request: ")

def handle_command_execution(command, mode):
    if mode == 'persistent':
        send_command_to_tmux_viewer(command)
    elif mode == 'separate':
        run_visual_pause_window(command)

def launch_persistent_viewer_if_needed():
    check_tmux_session()
    subprocess.run(['xfce4-terminal', '--command', 'tmux attach -t ai_terminal_x'])

def load_api_key():
    load_dotenv()
    return os.getenv('GEMINI_API_KEY')

def run_main_loop():
    while True:
        user_input = get_user_input()
        command, explanation = gemini_command_and_explanation(user_input)
        print(f"Generated Command: {command}")
        print(f"Explanation: {explanation}")
        risk = validate_command_risk(command)
        if risk:
            print(f"Risk Assessment: {risk}")
        mode = select_execution_mode()
        handle_command_execution(command, mode)

def run_visual_pause_window(command):
    subprocess.run(['xfce4-terminal', '--command', f'bash -c "{command}; read -p \'Press Enter to close...\'"'])

def select_execution_mode():
    mode = input("Select execution mode (persistent/separate): ")
    if mode not in ['persistent', 'separate']:
        raise ValueError("Invalid mode selected.")
    return mode

def send_command_to_tmux_viewer(command):
    subprocess.run(['tmux', 'send-keys', '-t', 'ai_terminal_x', command, 'C-m'])

def send_interrupt_to_tmux_viewer():
    subprocess.run(['tmux', 'send-keys', '-t', 'ai_terminal_x', 'C-c'])

def validate_command_risk(command):
    risk_assessment = gemini.assess_risk(command)
    return risk_assessment

if __name__ == "__main__":
    check_external_tools()
    configure_ai()
    launch_persistent_viewer_if_needed()
    run_main_loop()