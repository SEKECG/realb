from configs.config import Config
from trading.earnings_calendar import EarningsCalendar
from trading.stock_screener import StockScreener
from trading.theta_analyzer import ThetaAnalyzer
from trading.trade_options import TradeOptions
from options.options import Options
from options.option_chains import OptionChains
from options.stocks import Stocks

def main():
    config = Config('config.json')
    earnings_calendar = EarningsCalendar(source='file', file_path='earnings.json')
    stock_screener = StockScreener(config.get_tickers_by_iv_range('50-70'))
    theta_analyzer = ThetaAnalyzer([])  # Placeholder for actual positions
    trade_options = TradeOptions(config.get_account_number(), config.get_trading_strategy('ROLL_OUT'))

    # Example usage
    upcoming_earnings = earnings_calendar.get_upcoming_earnings()
    screened_stocks = stock_screener.screen_stocks(5, 7)
    theta_analyzer.visualize_theta_decay()
    option = Options('AAPL', '2023-12-15', 150, 'call', 'buy_to_open')
    trade = trade_options.execute_trade(option)

if __name__ == '__main__':
    main()