import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import pandas as pd
import threading
import openai
import requests
import json

class AIColumnGenerator:
    def __init__(self, root):
        self.root = root
        self.root.title("AI Column Generator")
        self.root.geometry("800x600")
        
        self.api_key = ""
        self.ollama_url = ""
        self.filepath = ""
        self.data = None
        self.templates = {}
        
        self.create_widgets()
        
    def create_widgets(self):
        self.main_frame = ttk.Frame(self.root)
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        
        self.file_frame = ttk.LabelFrame(self.main_frame, text="File Processing")
        self.file_frame.pack(fill=tk.X, padx=10, pady=10)
        
        self.load_button = ttk.Button(self.file_frame, text="Load File", command=self.load_file)
        self.load_button.pack(side=tk.LEFT, padx=5, pady=5)
        
        self.preview_button = ttk.Button(self.file_frame, text="Preview File", command=self.preview_file)
        self.preview_button.pack(side=tk.LEFT, padx=5, pady=5)
        
        self.export_button = ttk.Button(self.file_frame, text="Export File", command=self.export_file)
        self.export_button.pack(side=tk.LEFT, padx=5, pady=5)
        
        self.ai_frame = ttk.LabelFrame(self.main_frame, text="AI Integration")
        self.ai_frame.pack(fill=tk.X, padx=10, pady=10)
        
        self.api_key_label = ttk.Label(self.ai_frame, text="OpenAI API Key:")
        self.api_key_label.pack(side=tk.LEFT, padx=5, pady=5)
        
        self.api_key_entry = ttk.Entry(self.ai_frame, show="*")
        self.api_key_entry.pack(side=tk.LEFT, padx=5, pady=5)
        
        self.api_key_button = ttk.Button(self.ai_frame, text="Show/Hide", command=self.toggle_api_key_visibility)
        self.api_key_button.pack(side=tk.LEFT, padx=5, pady=5)
        
        self.ollama_url_label = ttk.Label(self.ai_frame, text="Ollama URL:")
        self.ollama_url_label.pack(side=tk.LEFT, padx=5, pady=5)
        
        self.ollama_url_entry = ttk.Entry(self.ai_frame)
        self.ollama_url_entry.pack(side=tk.LEFT, padx=5, pady=5)
        
        self.test_connection_button = ttk.Button(self.ai_frame, text="Test Connection", command=self.test_ollama_connection)
        self.test_connection_button.pack(side=tk.LEFT, padx=5, pady=5)
        
        self.column_frame = ttk.LabelFrame(self.main_frame, text="Column Generation")
        self.column_frame.pack(fill=tk.X, padx=10, pady=10)
        
        self.source_column_label = ttk.Label(self.column_frame, text="Source Column:")
        self.source_column_label.pack(side=tk.LEFT, padx=5, pady=5)
        
        self.source_column_entry = ttk.Entry(self.column_frame)
        self.source_column_entry.pack(side=tk.LEFT, padx=5, pady=5)
        
        self.new_column_label = ttk.Label(self.column_frame, text="New Column:")
        self.new_column_label.pack(side=tk.LEFT, padx=5, pady=5)
        
        self.new_column_entry = ttk.Entry(self.column_frame)
        self.new_column_entry.pack(side=tk.LEFT, padx=5, pady=5)
        
        self.generate_button = ttk.Button(self.column_frame, text="Generate Column", command=self.generate_column)
        self.generate_button.pack(side=tk.LEFT, padx=5, pady=5)
        
        self.template_frame = ttk.LabelFrame(self.main_frame, text="Template Management")
        self.template_frame.pack(fill=tk.X, padx=10, pady=10)
        
        self.template_listbox = tk.Listbox(self.template_frame)
        self.template_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self.load_template_button = ttk.Button(self.template_frame, text="Load Template", command=self.load_template)
        self.load_template_button.pack(side=tk.LEFT, padx=5, pady=5)
        
        self.save_template_button = ttk.Button(self.template_frame, text="Save Template", command=self.save_template)
        self.save_template_button.pack(side=tk.LEFT, padx=5, pady=5)
        
        self.preview_template_button = ttk.Button(self.template_frame, text="Preview Template", command=self.preview_template)
        self.preview_template_button.pack(side=tk.LEFT, padx=5, pady=5)
        
        self.status_bar = ttk.Label(self.root, text="AI Column Generator - Developed by Dr. Yuankang Liu")
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)
        
    def load_file(self):
        self.filepath = filedialog.askopenfilename(filetypes=[("Excel files", "*.xlsx *.xls"), ("CSV files", "*.csv")])
        if self.filepath:
            if self.filepath.endswith(".csv"):
                self.data = pd.read_csv(self.filepath)
            else:
                self.data = pd.read_excel(self.filepath)
            messagebox.showinfo("File Loaded", f"File loaded successfully: {self.filepath}")
        
    def preview_file(self):
        if self.data is not None:
            preview_window = tk.Toplevel(self.root)
            preview_window.title("File Preview")
            preview_window.geometry("600x400")
            
            text = tk.Text(preview_window)
            text.pack(fill=tk.BOTH, expand=True)
            
            text.insert(tk.END, self.data.head().to_string())
        else:
            messagebox.showwarning("No File", "No file loaded. Please load a file first.")
        
    def export_file(self):
        if self.data is not None:
            export_path = filedialog.asksaveasfilename(defaultextension=".xlsx", filetypes=[("Excel files", "*.xlsx"), ("CSV files", "*.csv")])
            if export_path:
                if export_path.endswith(".csv"):
                    self.data.to_csv(export_path, index=False)
                else:
                    self.data.to_excel(export_path, index=False)
                messagebox.showinfo("File Exported", f"File exported successfully: {export_path}")
        else:
            messagebox.showwarning("No Data", "No data to export. Please load and process a file first.")
        
    def toggle_api_key_visibility(self):
        if self.api_key_entry.cget("show") == "*":
            self.api_key_entry.config(show="")
        else:
            self.api_key_entry.config(show="*")
        
    def test_ollama_connection(self):
        self.ollama_url = self.ollama_url_entry.get()
        try:
            response = requests.get(self.ollama_url)
            if response.status_code == 200:
                messagebox.showinfo("Connection Successful", "Successfully connected to Ollama server.")
            else:
                messagebox.showerror("Connection Failed", "Failed to connect to Ollama server.")
        except Exception as e:
            messagebox.showerror("Connection Error", str(e))
        
    def generate_column(self):
        source_column = self.source_column_entry.get()
        new_column = self.new_column_entry.get()
        
        if source_column and new_column and self.data is not None:
            threading.Thread(target=self.process_column, args=(source_column, new_column)).start()
        else:
            messagebox.showwarning("Missing Information", "Please provide source column, new column, and load a file first.")
        
    def process_column(self, source_column, new_column):
        self.api_key = self.api_key_entry.get()
        self.ollama_url = self.ollama_url_entry.get()
        
        if self.api_key:
            openai.api_key = self.api_key
            for index, row in self.data.iterrows():
                response = openai.Completion.create(
                    engine="davinci",
                    prompt=row[source_column],
                    max_tokens=50
                )
                self.data.at[index, new_column] = response.choices[0].text.strip()
        elif self.ollama_url:
            for index, row in self.data.iterrows():
                response = requests.post(self.ollama_url, json={"prompt": row[source_column]})
                self.data.at[index, new_column] = response.json().get("text", "").strip()
        
        messagebox.showinfo("Column Generated", f"Column '{new_column}' generated successfully.")
        
    def load_template(self):
        template_path = filedialog.askopenfilename(filetypes=[("JSON files", "*.json")])
        if template_path:
            with open(template_path, "r") as file:
                self.templates = json.load(file)
            self.template_listbox.delete(0, tk.END)
            for template_name in self.templates.keys():
                self.template_listbox.insert(tk.END, template_name)
            messagebox.showinfo("Templates Loaded", "Templates loaded successfully.")
        
    def save_template(self):
        template_path = filedialog.asksaveasfilename(defaultextension=".json", filetypes=[("JSON files", "*.json")])
        if template_path:
            with open(template_path, "w") as file:
                json.dump(self.templates, file)
            messagebox.showinfo("Templates Saved", "Templates saved successfully.")
        
    def preview_template(self):
        selected_template = self.template_listbox.get(tk.ACTIVE)
        if selected_template:
            preview_window = tk.Toplevel(self.root)
            preview_window.title("Template Preview")
            preview_window.geometry("600x400")
            
            text = tk.Text(preview_window)
            text.pack(fill=tk.BOTH, expand=True)
            
            text.insert(tk.END, json.dumps(self.templates[selected_template], indent=4))
        else:
            messagebox.showwarning("No Template", "No template selected. Please select a template first.")

if __name__ == "__main__":
    root = tk.Tk()
    app = AIColumnGenerator(root)
    root.mainloop()