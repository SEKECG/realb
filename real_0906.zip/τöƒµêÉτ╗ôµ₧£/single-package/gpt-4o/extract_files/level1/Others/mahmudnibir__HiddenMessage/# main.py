from Crypto.Cipher import AES
import os
from PIL import Image
import binascii

def generate_key(password):
    return password.ljust(32)[:32].encode('utf-8')

def encrypt_text(text, password):
    key = generate_key(password)
    cipher = AES.new(key, AES.MODE_ECB)
    padded_text = text.ljust(16 * ((len(text) + 15) // 16))
    encrypted_text = cipher.encrypt(padded_text.encode('utf-8'))
    return binascii.hexlify(encrypted_text).decode('utf-8')

def decrypt_text(encrypted_text, password):
    key = generate_key(password)
    cipher = AES.new(key, AES.MODE_ECB)
    decrypted_text = cipher.decrypt(binascii.unhexlify(encrypted_text)).decode('utf-8').strip()
    return decrypted_text

def text_to_bin(text):
    return ''.join(format(ord(char), '08b') for char in text)

def bin_to_text(binary):
    text = ''.join(chr(int(binary[i:i+8], 2)) for i in range(0, len(binary), 8))
    return text

def hide_text_in_image(image_path, text, password):
    image = Image.open(image_path)
    binary_text = text_to_bin(encrypt_text(text, password))
    binary_text += '1111111111111110'  # End of text marker

    pixels = list(image.getdata())
    new_pixels = []

    binary_index = 0
    for pixel in pixels:
        new_pixel = []
        for channel in pixel:
            if binary_index < len(binary_text):
                new_pixel.append(channel & ~1 | int(binary_text[binary_index]))
                binary_index += 1
            else:
                new_pixel.append(channel)
        new_pixels.append(tuple(new_pixel))

    new_image = Image.new(image.mode, image.size)
    new_image.putdata(new_pixels)
    new_image.save('hidden_' + os.path.basename(image_path))

def extract_text_from_image(image_path, password):
    image = Image.open(image_path)
    pixels = list(image.getdata())

    binary_text = ''
    for pixel in pixels:
        for channel in pixel:
            binary_text += str(channel & 1)

    end_marker = binary_text.find('1111111111111110')
    if end_marker != -1:
        binary_text = binary_text[:end_marker]

    encrypted_text = bin_to_text(binary_text)
    return decrypt_text(encrypted_text, password)

def print_AUTHOR_info():
    print("Author: Mahmud Nibir")

if __name__ == "__main__":
    print_AUTHOR_info()
    # Example usage:
    # hide_text_in_image('example.png', 'Hello World', 'password123')
    # print(extract_text_from_image('hidden_example.png', 'password123'))