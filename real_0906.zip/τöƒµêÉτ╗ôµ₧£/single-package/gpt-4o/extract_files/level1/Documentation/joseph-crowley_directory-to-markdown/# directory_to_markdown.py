import os
import logging

logging.basicConfig(level=logging.INFO)

IGNORED_DIRECTORIES = ['node_modules', '__pycache__', '.git', '.vscode', '.idea']

def is_ignored(directory):
    return any(ignored in directory for ignored in IGNORED_DIRECTORIES)

def read_file_safely(file_path, max_size):
    try:
        if os.path.getsize(file_path) > max_size:
            logging.warning(f"File {file_path} exceeds maximum size and will be skipped.")
            return None
        with open(file_path, 'r') as file:
            return file.read()
    except Exception as e:
        logging.error(f"Error reading file {file_path}: {e}")
        return None

def directory_to_markdown(directory, output_file, file_types, max_size):
    with open(output_file, 'w') as md_file:
        for root, dirs, files in os.walk(directory):
            if is_ignored(root):
                continue
            for file in files:
                if any(file.endswith(ext) for ext in file_types):
                    file_path = os.path.join(root, file)
                    content = read_file_safely(file_path, max_size)
                    if content:
                        md_file.write(f"## {file_path}\n\n```\n{content}\n```\n\n")

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Convert directory contents to Markdown.")
    parser.add_argument("directory", help="Directory to scan")
    parser.add_argument("output_file", help="Output Markdown file")
    parser.add_argument("--file_types", nargs='+', default=['.py', '.txt'], help="File types to include")
    parser.add_argument("--max_size", type=int, default=1024*1024, help="Maximum file size in bytes")

    args = parser.parse_args()

    directory_to_markdown(args.directory, args.output_file, args.file_types, args.max_size)