import time
import random
import logging

def clear_screen():
    print("\033[H\033[J")

def banner():
    print("""
    =========================================
    |            InfiNet Tool               |
    =========================================
    """)

def show_menu():
    print("""
    1. Network Scanning
    2. MITM Attack
    3. DNS Spoofing
    4. Automatic Attack Type Selection
    5. Performance Monitoring
    6. Dynamic Reporting
    7. Advanced Logging
    8. Help and Instructions
    9. Exit
    """)

def show_instructions():
    print("""
    Instructions:
    1. Network Scanning: Enter target IP address to scan the network.
    2. MITM Attack: Provide victim's IP address and gateway IP address.
    3. DNS Spoofing: Redirect DNS requests from a target IP address to a specified IP address.
    4. Automatic Attack Type Selection: Randomly selects an attack type.
    5. Performance Monitoring: Tracks the duration of attack processes.
    6. Dynamic Reporting: Generates a report after each attack.
    7. Advanced Logging: Logs user interactions and attack initiations.
    """)

def network_scan(target_ip):
    print(f"Scanning network for devices connected to {target_ip}...")
    time.sleep(2)
    print("Network scan complete.")

def mitm_attack(victim_ip, gateway_ip):
    print(f"Initiating MITM attack between {victim_ip} and {gateway_ip}...")
    time.sleep(2)
    print("MITM attack complete.")

def dns_spoofing(target_ip, redirect_ip):
    print(f"Redirecting DNS requests from {target_ip} to {redirect_ip}...")
    time.sleep(2)
    print("DNS spoofing complete.")

def advanced_attack_choice():
    choices = [network_scan, mitm_attack, dns_spoofing]
    choice = random.choice(choices)
    print(f"Automatically selected attack: {choice.__name__}")
    if choice == network_scan:
        target_ip = input("Enter target IP address: ")
        choice(target_ip)
    elif choice == mitm_attack:
        victim_ip = input("Enter victim's IP address: ")
        gateway_ip = input("Enter gateway IP address: ")
        choice(victim_ip, gateway_ip)
    elif choice == dns_spoofing:
        target_ip = input("Enter target IP address: ")
        redirect_ip = input("Enter redirect IP address: ")
        choice(target_ip, redirect_ip)

def performance_monitor(func):
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        duration = end_time - start_time
        print(f"Duration: {duration} seconds")
        return result
    return wrapper

@performance_monitor
def dynamic_report(attack_type, status):
    print(f"Attack Type: {attack_type}")
    print(f"Status: {status}")

def advanced_logging():
    logging.basicConfig(filename='infinet.log', level=logging.INFO)
    logging.info('User interaction logged.')

def main():
    clear_screen()
    banner()
    while True:
        show_menu()
        choice = input("Enter your choice: ")
        if choice == '1':
            target_ip = input("Enter target IP address: ")
            network_scan(target_ip)
        elif choice == '2':
            victim_ip = input("Enter victim's IP address: ")
            gateway_ip = input("Enter gateway IP address: ")
            mitm_attack(victim_ip, gateway_ip)
        elif choice == '3':
            target_ip = input("Enter target IP address: ")
            redirect_ip = input("Enter redirect IP address: ")
            dns_spoofing(target_ip, redirect_ip)
        elif choice == '4':
            advanced_attack_choice()
        elif choice == '5':
            print("Performance monitoring is enabled for all attacks.")
        elif choice == '6':
            attack_type = input("Enter attack type: ")
            status = input("Enter status (successful/failed): ")
            dynamic_report(attack_type, status)
        elif choice == '7':
            advanced_logging()
        elif choice == '8':
            show_instructions()
        elif choice == '9':
            print("Exiting InfiNet...")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()