#!/usr/bin/env python3
"""
EmojiChef - Emoji Encoding/Decoding Tool
Main module with interactive menu and core functionality
"""

import os
import sys
from typing import Dict, List, Optional

from emoji_codec import EmojiCodec, FileHandler, CompressionMethod, VerificationMethod

class Colors:
    """ANSI color codes for terminal output"""
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

def print_banner():
    """Print the EmojiChef banner"""
    banner = f"""
{Colors.HEADER}{Colors.BOLD}
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║                  🍳 {Colors.OKGREEN}E M O J I C H E F{Colors.HEADER} 🍳                 ║
║                                                              ║
║           Emoji Encoding/Decoding Tool - v1.0.0              ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
{Colors.ENDC}
"""
    print(banner)

def print_menu():
    """Print the main menu"""
    menu = f"""
{Colors.BOLD}Main Menu:{Colors.ENDC}
{Colors.OKCYAN}1.{Colors.ENDC} Quick Encode/Decode Text
{Colors.OKCYAN}2.{Colors.ENDC} File Operations
{Colors.OKCYAN}3.{Colors.ENDC} Batch Processing
{Colors.OKCYAN}4.{Colors.ENDC} File Analysis
{Colors.OKCYAN}5.{Colors.ENDC} View Recipe Book
{Colors.OKCYAN}6.{Colors.ENDC} Settings
{Colors.OKCYAN}7.{Colors.ENDC} Exit

{Colors.WARNING}Select an option (1-7): {Colors.ENDC}"""
    print(menu, end='')

def get_valid_input(prompt: str, valid_options: List[str] = None, input_type: type = str) -> str:
    """Get validated user input"""
    while True:
        try:
            user_input = input(prompt).strip()
            if not user_input:
                continue
                
            if valid_options and user_input not in valid_options:
                print(f"{Colors.FAIL}Invalid option. Please choose from {valid_options}{Colors.ENDC}")
                continue
                
            if input_type != str:
                return input_type(user_input)
            return user_input
            
        except (ValueError, KeyboardInterrupt):
            print(f"\n{Colors.FAIL}Invalid input. Please try again.{Colors.ENDC}")
            if KeyboardInterrupt:
                print()
                sys.exit(0)

def handle_quick_operation():
    """Handle quick text encoding/decoding operations"""
    print(f"\n{Colors.BOLD}Quick Text Operations{Colors.ENDC}")
    print(f"{Colors.OKCYAN}1.{Colors.ENDC} Encode Text")
    print(f"{Colors.OKCYAN}2.{Colors.ENDC} Decode Text")
    
    choice = get_valid_input("Select operation (1-2): ", ["1", "2"])
    
    recipe = get_valid_input("Enter recipe (quick/light/classic/gourmet): ", 
                           ["quick", "light", "classic", "gourmet"])
    
    codec = EmojiCodec(recipe=recipe)
    
    if choice == "1":
        text = get_valid_input("Enter text to encode: ")
        try:
            encoded = codec.encode_text(text)
            print(f"\n{Colors.OKGREEN}Encoded Result:{Colors.ENDC}")
            print(encoded)
            print(f"\n{Colors.OKBLUE}Length: {len(encoded)} emojis{Colors.ENDC}")
        except Exception as e:
            print(f"{Colors.FAIL}Error encoding text: {e}{Colors.ENDC}")
    else:
        emoji_seq = get_valid_input("Enter emoji sequence to decode: ")
        try:
            decoded = codec.decode_text(emoji_seq)
            print(f"\n{Colors.OKGREEN}Decoded Result:{Colors.ENDC}")
            print(decoded)
        except Exception as e:
            print(f"{Colors.FAIL}Error decoding text: {e}{Colors.ENDC}")

def handle_file_operations():
    """Handle single file operations"""
    print(f"\n{Colors.BOLD}File Operations{Colors.ENDC}")
    print(f"{Colors.OKCYAN}1.{Colors.ENDC} Encode File")
    print(f"{Colors.OKCYAN}2.{Colors.ENDC} Decode File")
    
    choice = get_valid_input("Select operation (1-2): ", ["1", "2"])
    
    input_file = get_valid_input("Enter input file path: ")
    
    if not os.path.exists(input_file):
        print(f"{Colors.FAIL}File not found: {input_file}{Colors.ENDC}")
        return
    
    output_file = get_valid_input("Enter output file path: ")
    
    recipe = get_valid_input("Enter recipe (quick/light/classic/gourmet): ", 
                           ["quick", "light", "classic", "gourmet"])
    
    # Ask for compression and verification
    use_compression = get_valid_input("Use compression? (y/n): ", ["y", "n"]) == "y"
    use_verification = get_valid_input("Use verification? (y/n): ", ["y", "n"]) == "y"
    
    compression = CompressionMethod.ZLIB if use_compression else CompressionMethod.NONE
    verification = VerificationMethod.SHA256 if use_verification else VerificationMethod.NONE
    
    codec = EmojiCodec(recipe=recipe, compression=compression, verification=verification)
    file_handler = FileHandler()
    
    if choice == "1":
        result = file_handler.encode_file(input_file, output_file, codec)
        if result["success"]:
            print(f"\n{Colors.OKGREEN}File encoded successfully!{Colors.ENDC}")
            print(f"{Colors.OKBLUE}Original size: {result['original_size']} bytes{Colors.ENDC}")
            print(f"{Colors.OKBLUE}Encoded size: {result['encoded_size']} emojis{Colors.ENDC}")
            print(f"{Colors.OKBLUE}Compression ratio: {result['compression_ratio']:.2f}{Colors.ENDC}")
            print(f"{Colors.OKBLUE}MIME type: {result['mime_type']}{Colors.ENDC}")
        else:
            print(f"{Colors.FAIL}Error encoding file: {result['error']}{Colors.ENDC}")
    else:
        result = file_handler.decode_file(input_file, output_file, codec)
        if result["success"]:
            print(f"\n{Colors.OKGREEN}File decoded successfully!{Colors.ENDC}")
            print(f"{Colors.OKBLUE}Decoded size: {result['decoded_size']} bytes{Colors.ENDC}")
        else:
            print(f"{Colors.FAIL}Error decoding file: {result['error']}{Colors.ENDC}")

def handle_batch_processing():
    """Handle batch processing of multiple files"""
    print(f"\n{Colors.BOLD}Batch Processing{Colors.ENDC}")
    
    input_dir = get_valid_input("Enter input directory: ")
    output_dir = get_valid_input("Enter output directory: ")
    
    if not os.path.exists(input_dir):
        print(f"{Colors.FAIL}Input directory not found: {input_dir}{Colors.ENDC}")
        return
    
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    operation = get_valid_input("Operation (encode/decode): ", ["encode", "decode"])
    recipe = get_valid_input("Enter recipe (quick/light/classic/gourmet): ", 
                           ["quick", "light", "classic", "gourmet"])
    
    codec = EmojiCodec(recipe=recipe)
    file_handler = FileHandler()
    
    processed = 0
    failed = 0
    
    for filename in os.listdir(input_dir):
        input_path = os.path.join(input_dir, filename)
        output_path = os.path.join(output_dir, filename)
        
        if operation == "encode":
            result = file_handler.encode_file(input_path, output_path, codec)
        else:
            result = file_handler.decode_file(input_path, output_path, codec)
        
        if result["success"]:
            print(f"{Colors.OKGREEN}✓{Colors.ENDC} Processed: {filename}")
            processed += 1
        else:
            print(f"{Colors.FAIL}✗{Colors.ENDC} Failed: {filename} - {result['error']}")
            failed += 1
    
    print(f"\n{Colors.BOLD}Batch processing complete!{Colors.ENDC}")
    print(f"{Colors.OKGREEN}Successfully processed: {processed}{Colors.ENDC}")
    print(f"{Colors.FAIL}Failed: {failed}{Colors.ENDC}")

def view_recipe_book():
    """Display information about available encoding recipes"""
    print(f"\n{Colors.BOLD}Recipe Book{Colors.ENDC}")
    print(f"{Colors.HEADER}Available encoding recipes:{Colors.ENDC}")
    
    recipes_info = [
        ("Quick", "Base-64", "Food emojis", "Small files, quick messages"),
        ("Light", "Base-128", "Activity emojis", "Medium files, balanced"),
        ("Classic", "Base-256", "Smiley emojis", "General purpose, most files"),
        ("Gourmet", "Base-1024", "Extended emoji set", "Large files, maximum efficiency")
    ]
    
    for i, (name, base, emojis, desc) in enumerate(recipes_info, 1):
        print(f"\n{Colors.OKCYAN}{i}. {name} ({base}){Colors.ENDC}")
        print(f"   {Colors.WARNING}Emojis: {emojis}{Colors.ENDC}")
        print(f"   {Colors.OKGREEN}Best for: {desc}{Colors.ENDC}")

def handle_settings():
    """Handle application settings"""
    print(f"\n{Colors.BOLD}Settings{Colors.ENDC}")
    print(f"{Colors.WARNING}Settings functionality not yet implemented.{Colors.ENDC}")
    print("Future versions will include configurable options.")

def main():
    """Main entry point for interactive mode"""
    print_banner()
    
    while True:
        print_menu()
        choice = get_valid_input("", ["1", "2", "3", "4", "5", "6", "7"])
        
        if choice == "1":
            handle_quick_operation()
        elif choice == "2":
            handle_file_operations()
        elif choice == "3":
            handle_batch_processing()
        elif choice == "4":
            # File analysis
            file_path = get_valid_input("Enter file path to analyze: ")
            file_handler = FileHandler()
            result = file_handler.analyze_file(file_path)
            
            if result["success"]:
                print(f"\n{Colors.BOLD}File Analysis Results:{Colors.ENDC}")
                print(f"{Colors.OKBLUE}Size: {result['size']} bytes{Colors.ENDC}")
                print(f"{Colors.OKBLUE}MIME type: {result['mime_type']}{Colors.ENDC}")
                print(f"{Colors.OKBLUE}Suggested recipe: {result['suggested_recipe']}{Colors.ENDC}")
                print(f"{Colors.OKBLUE}Appears to be text: {result['is_text']}{Colors.ENDC}")
            else:
                print(f"{Colors.FAIL}Error analyzing file: {result['error']}{Colors.ENDC}")
                
        elif choice == "5":
            view_recipe_book()
        elif choice == "6":
            handle_settings()
        elif choice == "7":
            print(f"\n{Colors.OKGREEN}Thank you for using EmojiChef! 👋{Colors.ENDC}")
            break
        
        print("\n" + "="*50 + "\n")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n\n{Colors.FAIL}Operation cancelled by user.{Colors.ENDC}")
        sys.exit(0)
    except Exception as e:
        print(f"\n{Colors.FAIL}Unexpected error: {e}{Colors.ENDC}")
        sys.exit(1)