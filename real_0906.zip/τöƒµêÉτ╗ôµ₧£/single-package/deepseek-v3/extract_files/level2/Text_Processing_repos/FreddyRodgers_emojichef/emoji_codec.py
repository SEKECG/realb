import base64
import zlib
import hashlib
from enum import Enum
from typing import Dict, List, Tuple, Optional, Union

class CompressionMethod(Enum):
    NONE = 0
    ZLIB = 1

class VerificationMethod(Enum):
    NONE = 0
    SHA256 = 1

class EmojiCodec:
    # Emoji sets for different recipes
    QUICK_EMOJIS = "🍅🍆🍇🍈🍉🍊🍋🍌🍍🍎🍏🍐🍑🍒🍓🥝🥥🥭🥑🥒🥬🥦🥔🥕🌽🌶️🍄🥜🌰🍞🥐🥖🥨🥯🥞🧀🍖🍗🥩🥓🍔🍟🍕🌭🥪🌮🌯🥙🥚🍳🥘🍲🥣🥗🍿🧂🥫🍱🍘🍙🍚🍛🍜🍝🍠🍢🍣🍤🍥🥮🍡🥟🥠🥡🦪🍦🍧🍨🍩🍪🎂🍰🧁🥧🍫🍬🍭🍮🍯🍼🥛☕🍵🍶🍾🍷🍸🍹🍺🍻🥂🥃🥤🥢🍽️🍴🥄"
    LIGHT_EMOJIS = "🎰🎱🎲🎳🎴🎵🎶🎷🎸🎹🎺🎻🥁🎬🎭🎮🎯🎱🎲🎳🎴🎵🎶🎷🎸🎹🎺🎻🥁🎬🎭🎮🎯🃏🀄🎠🎡🎢🎪🎫🎟️🎭🎨🎪🎤🎧🎼🎹🎷🎸🎺🎻🥁🪘🪕🎵🎶"
    CLASSIC_EMOJIS = "😀😃😄😁😆😅😂🤣☺️😊😇🙂🙃😉😌😍🥰😘😗😙😚😋😛😝😜🤪🤨🧐🤓😎🤩🥳😏😒😞😔😟😕🙁☹️😣😖😫😩🥺😢😭😤😠😡🤬🤯😳🥵🥶😱😨😰😥😓🤗🤔🤭🤫🤥😶😐😑😬🙄😯😦😧😮😲🥱😴🤤😪😵🤐🥴🤢🤮🤧😷🤒🤕🤑🤠😈👿👹👺🤡💩👻💀☠️👽👾🤖🎃😺😸😹😻😼😽🙀😿😾"
    GOURMET_EMOJIS = "🤠🤡🤢🤣🤤🤥🤦🤧🤨🤩🤪🤫🤬🤭🤮🤯🤰🤱🤲🤳🤴🤵🤶🤷🤸🤹🤺🤻🤼🤽🤾🤿🥀🥁🥂🥃🥄🥅🥇🥈🥉🥊🥋🥌🥍🥎🥏🥐🥑🥒🥓🥔🥕🥖🥗🥘🥙🥚🥛🥜🥝🥞🥟🥠🥡🥢🥣🥤🥥🥦🥧🥨🥩🥪🥫🥬🥭🥮🥯🥰🥱🥲🥳🥴🥵🥶🥷🥸🥺🥻🥼🥽🥾🥿🦀🦁🦂🦃🦄🦅🦆🦇🦈🦉🦊🦋🦌🦍🦎🦏🦐🦑🦒🦓🦔🦕🦖🦗🦘🦙🦚🦛🦜🦝🦞🦟🦠🦡🦢🦣🦤🦥🦦🦧🦨🦩🦪🦫🦬🦭🦮🦯🦰🦱🦲🦳🦴🦵🦶🦷🦸🦹🦺🦻🦼🦽🦾🦿🧀🧁🧂🧃🧄🧅🧆🧇🧈🧉🧊🧋🧌🧍🧎🧏"

    RECIPES = {
        "quick": (64, QUICK_EMOJIS),
        "light": (128, LIGHT_EMOJIS),
        "classic": (256, CLASSIC_EMOJIS),
        "gourmet": (1024, GOURMET_EMOJIS)
    }

    def __init__(self, recipe: str = "classic", compression: CompressionMethod = CompressionMethod.NONE, 
                 verification: VerificationMethod = VerificationMethod.NONE):
        if recipe not in self.RECIPES:
            raise ValueError(f"Invalid recipe: {recipe}. Available recipes: {list(self.RECIPES.keys())}")
        
        self.recipe = recipe
        self.base, self.emoji_set = self.RECIPES[recipe]
        self.compression = compression
        self.verification = verification
        self.emoji_to_index = {emoji: idx for idx, emoji in enumerate(self.emoji_set)}

    def encode_text(self, text: str) -> str:
        """Encode text string to emoji sequence"""
        data = text.encode('utf-8')
        return self._encode_data(data)

    def decode_text(self, emoji_sequence: str) -> str:
        """Decode emoji sequence back to text string"""
        data = self._decode_data(emoji_sequence)
        return data.decode('utf-8')

    def encode_binary(self, data: bytes) -> str:
        """Encode binary data to emoji sequence"""
        return self._encode_data(data)

    def decode_binary(self, emoji_sequence: str) -> bytes:
        """Decode emoji sequence back to binary data"""
        return self._decode_data(emoji_sequence)

    def _encode_data(self, data: bytes) -> str:
        """Internal method to encode bytes data"""
        # Apply compression if requested
        if self.compression == CompressionMethod.ZLIB:
            data = zlib.compress(data)
        
        # Add verification hash if requested
        if self.verification == VerificationMethod.SHA256:
            hash_digest = hashlib.sha256(data).digest()
            data = hash_digest + data
        
        # Convert to base64 for easier handling of binary data
        data_b64 = base64.b64encode(data)
        
        # Convert to target base using emoji set
        result = []
        num = int.from_bytes(data_b64, 'big')
        
        if num == 0:
            return self.emoji_set[0]
        
        while num > 0:
            num, remainder = divmod(num, self.base)
            result.append(self.emoji_set[remainder])
        
        return ''.join(reversed(result))

    def _decode_data(self, emoji_sequence: str) -> bytes:
        """Internal method to decode emoji sequence back to bytes"""
        # Convert from target base to decimal
        num = 0
        for emoji in emoji_sequence:
            if emoji not in self.emoji_to_index:
                raise ValueError(f"Invalid emoji in sequence: {emoji}")
            num = num * self.base + self.emoji_to_index[emoji]
        
        # Convert back to bytes
        data_b64 = num.to_bytes((num.bit_length() + 7) // 8, 'big')
        
        # Decode from base64
        try:
            data = base64.b64decode(data_b64)
        except Exception as e:
            raise ValueError("Invalid base64 data in emoji sequence") from e
        
        # Verify and extract hash if present
        if self.verification == VerificationMethod.SHA256:
            if len(data) < 32:
                raise ValueError("Data too short for SHA256 verification")
            
            hash_digest = data[:32]
            actual_data = data[32:]
            
            computed_hash = hashlib.sha256(actual_data).digest()
            if computed_hash != hash_digest:
                raise ValueError("SHA256 verification failed - data may be corrupted")
            
            data = actual_data
        
        # Decompress if compressed
        if self.compression == CompressionMethod.ZLIB:
            try:
                data = zlib.decompress(data)
            except zlib.error as e:
                raise ValueError("ZLIB decompression failed") from e
        
        return data

    def get_recipe_info(self) -> Dict:
        """Get information about the current recipe"""
        return {
            "name": self.recipe,
            "base": self.base,
            "emoji_count": len(self.emoji_set),
            "compression": self.compression.name,
            "verification": self.verification.name
        }

class FileHandler:
    def __init__(self):
        pass

    @staticmethod
    def detect_mime_type(data: bytes) -> str:
        """Detect MIME type from binary data"""
        # Simple MIME type detection based on magic numbers
        if data.startswith(b'\xff\xd8\xff'):
            return 'image/jpeg'
        elif data.startswith(b'\x89PNG\r\n\x1a\n'):
            return 'image/png'
        elif data.startswith(b'GIF87a') or data.startswith(b'GIF89a'):
            return 'image/gif'
        elif data.startswith(b'%PDF'):
            return 'application/pdf'
        elif data.startswith(b'PK') and len(data) > 30:
            # ZIP files (could be DOCX, XLSX, etc.)
            return 'application/zip'
        elif data.startswith(b'\x7fELF'):
            return 'application/x-executable'
        else:
            # Default to binary if unknown
            return 'application/octet-stream'

    def encode_file(self, input_path: str, output_path: str, codec: EmojiCodec) -> Dict:
        """Encode a file to emoji format"""
        try:
            with open(input_path, 'rb') as f:
                data = f.read()
            
            mime_type = self.detect_mime_type(data)
            encoded_data = codec.encode_binary(data)
            
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(encoded_data)
            
            return {
                "success": True,
                "original_size": len(data),
                "encoded_size": len(encoded_data),
                "compression_ratio": len(encoded_data) / len(data) if len(data) > 0 else 0,
                "mime_type": mime_type
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }

    def decode_file(self, input_path: str, output_path: str, codec: EmojiCodec) -> Dict:
        """Decode an emoji file back to original format"""
        try:
            with open(input_path, 'r', encoding='utf-8') as f:
                emoji_data = f.read()
            
            decoded_data = codec.decode_binary(emoji_data)
            
            with open(output_path, 'wb') as f:
                f.write(decoded_data)
            
            return {
                "success": True,
                "decoded_size": len(decoded_data)
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }

    def analyze_file(self, file_path: str) -> Dict:
        """Analyze file to suggest optimal encoding settings"""
        try:
            with open(file_path, 'rb') as f:
                data = f.read()
            
            mime_type = self.detect_mime_type(data)
            size = len(data)
            
            # Suggest recipe based on file size
            if size < 1024:  # < 1KB
                suggested_recipe = "quick"
            elif size < 10240:  # < 10KB
                suggested_recipe = "light"
            elif size < 102400:  # < 100KB
                suggested_recipe = "classic"
            else:
                suggested_recipe = "gourmet"
            
            return {
                "success": True,
                "size": size,
                "mime_type": mime_type,
                "suggested_recipe": suggested_recipe,
                "is_text": self._is_text_data(data)
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }

    def _is_text_data(self, data: bytes) -> bool:
        """Check if data appears to be text"""
        try:
            # Try to decode as UTF-8
            data.decode('utf-8')
            return True
        except UnicodeDecodeError:
            return False