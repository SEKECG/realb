#!/usr/bin/env python3
"""
Speedtester - A command-line tool to monitor and record internet speed at regular intervals.
"""

import speedtest
import time
import csv
import os
from datetime import datetime
from colorama import Fore, Style, init

# Initialize colorama for cross-platform colored terminal output
init(autoreset=True)

class SpeedTester:
    def __init__(self, high_threshold=100, low_threshold=50):
        """
        Initialize the SpeedTester with speed thresholds.
        
        Args:
            high_threshold: Download speed threshold (Mbps) for 'great' status
            low_threshold: Download speed threshold (Mbps) for 'okay' status
        """
        self.high_threshold = high_threshold
        self.low_threshold = low_threshold
        self.csv_file = "speed_log.csv"
        self.test_count = 0
        
        # Initialize CSV file with headers if it doesn't exist
        if not os.path.exists(self.csv_file):
            with open(self.csv_file, 'w', newline='') as file:
                writer = csv.writer(file)
                writer.writerow(["Serial", "Timestamp", "Download (Mbps)", "Upload (Mbps)", "Ping (ms)", "Status"])
    
    def get_status(self, download_speed):
        """
        Determine the status based on download speed and thresholds.
        
        Args:
            download_speed: The measured download speed in Mbps
            
        Returns:
            str: Status category ('great', 'okay', or 'bad')
        """
        if download_speed >= self.high_threshold:
            return "great"
        elif download_speed >= self.low_threshold:
            return "okay"
        else:
            return "bad"
    
    def get_status_color(self, status):
        """
        Get the color code for a given status.
        
        Args:
            status: The status category
            
        Returns:
            str: Color code for terminal output
        """
        if status == "great":
            return Fore.GREEN
        elif status == "okay":
            return Fore.YELLOW
        else:
            return Fore.RED
    
    def run_speed_test(self):
        """
        Perform a single internet speed test.
        
        Returns:
            tuple: (download_speed, upload_speed, ping, status)
        """
        try:
            print("Running speed test...")
            st = speedtest.Speedtest()
            st.get_best_server()
            
            # Measure ping
            ping = st.results.ping
            
            # Measure download and upload speeds
            download_speed = st.download() / 1_000_000  # Convert to Mbps
            upload_speed = st.upload() / 1_000_000  # Convert to Mbps
            
            # Determine status
            status = self.get_status(download_speed)
            
            return download_speed, upload_speed, ping, status
            
        except speedtest.SpeedtestException as e:
            print(f"{Fore.RED}Error during speed test: {e}")
            return None, None, None, "error"
        except Exception as e:
            print(f"{Fore.RED}Unexpected error: {e}")
            return None, None, None, "error"
    
    def display_results(self, download_speed, upload_speed, ping, status):
        """
        Display the speed test results with color-coded output.
        
        Args:
            download_speed: Download speed in Mbps
            upload_speed: Upload speed in Mbps
            ping: Ping in milliseconds
            status: Status category
        """
        status_color = self.get_status_color(status)
        
        print(f"\n{Fore.CYAN}=== Speed Test Results ===")
        print(f"{Fore.WHITE}Download: {download_speed:.2f} Mbps")
        print(f"{Fore.WHITE}Upload: {upload_speed:.2f} Mbps")
        print(f"{Fore.WHITE}Ping: {ping:.2f} ms")
        print(f"{Fore.WHITE}Status: {status_color}{status.upper()}{Style.RESET_ALL}")
        print(f"{Fore.CYAN}=========================\n")
    
    def log_results(self, download_speed, upload_speed, ping, status):
        """
        Log the speed test results to CSV file.
        
        Args:
            download_speed: Download speed in Mbps
            upload_speed: Upload speed in Mbps
            ping: Ping in milliseconds
            status: Status category
        """
        self.test_count += 1
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        with open(self.csv_file, 'a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([
                self.test_count,
                timestamp,
                f"{download_speed:.2f}",
                f"{upload_speed:.2f}",
                f"{ping:.2f}",
                status
            ])
    
    def run_continuous_tests(self, interval_minutes=5):
        """
        Run speed tests continuously at specified intervals.
        
        Args:
            interval_minutes: Time interval between tests in minutes
        """
        interval_seconds = interval_minutes * 60
        
        print(f"{Fore.CYAN}Speedtester started!")
        print(f"{Fore.WHITE}Testing every {interval_minutes} minutes")
        print(f"{Fore.WHITE}Logging to: {self.csv_file}")
        print(f"{Fore.WHITE}High threshold: {self.high_threshold} Mbps")
        print(f"{Fore.WHITE}Low threshold: {self.low_threshold} Mbps")
        print(f"{Fore.CYAN}Press Ctrl+C to stop\n")
        
        try:
            while True:
                download_speed, upload_speed, ping, status = self.run_speed_test()
                
                if download_speed is not None:  # Only process if test was successful
                    self.display_results(download_speed, upload_speed, ping, status)
                    self.log_results(download_speed, upload_speed, ping, status)
                
                # Wait for the next test
                print(f"{Fore.WHITE}Next test in {interval_minutes} minutes...")
                time.sleep(interval_seconds)
                
        except KeyboardInterrupt:
            print(f"\n{Fore.CYAN}Speedtester stopped.")
            print(f"{Fore.WHITE}Total tests performed: {self.test_count}")
            print(f"{Fore.WHITE}Results saved to: {self.csv_file}")

def main():
    """Main function to run the Speedtester application."""
    # Default thresholds (can be made configurable via command-line arguments)
    HIGH_THRESHOLD = 100  # Mbps
    LOW_THRESHOLD = 50    # Mbps
    TEST_INTERVAL = 5     # minutes
    
    # Create and run the speed tester
    tester = SpeedTester(high_threshold=HIGH_THRESHOLD, low_threshold=LOW_THRESHOLD)
    tester.run_continuous_tests(interval_minutes=TEST_INTERVAL)

if __name__ == "__main__":
    main()