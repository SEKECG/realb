import os
import streamlit as st
from dotenv import load_dotenv
import ibm_watsonx_ai
from ibm_watsonx_ai import APIClient
from ibm_watsonx_ai.metanames import GenTextParamsMetaNames as GenParams
from ibm_watsonx_ai.foundation_models import ModelInference

def load_css():
    """Load custom CSS styles for the application"""
    st.markdown("""
        <style>
            .header {
                text-align: center;
                padding: 2rem 0;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                border-radius: 10px;
                margin-bottom: 2rem;
            }
            
            .header h1 {
                font-size: 3rem;
                margin-bottom: 0.5rem;
            }
            
            .header p {
                font-size: 1.2rem;
                opacity: 0.9;
            }
            
            .quote {
                background-color: #f8f9fa;
                padding: 1rem;
                border-left: 4px solid #667eea;
                border-radius: 5px;
                margin-bottom: 2rem;
                font-style: italic;
                text-align: center;
            }
            
            .section {
                margin: 2rem 0;
                padding: 1rem 0;
                border-bottom: 2px solid #e9ecef;
            }
            
            .feature-card {
                background: white;
                padding: 1.5rem;
                border-radius: 10px;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                margin-bottom: 1rem;
                transition: transform 0.3s ease;
                border: 1px solid #e9ecef;
            }
            
            .feature-card:hover {
                transform: translateY(-5px);
                box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
            }
            
            .feature-card h3 {
                color: #667eea;
                margin-bottom: 0.5rem;
            }
            
            .team-card {
                background: white;
                padding: 1rem;
                border-radius: 10px;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
                margin-bottom: 1rem;
                text-align: center;
                border: 1px solid #e9ecef;
            }
            
            .team-card h3 {
                color: #495057;
                margin-bottom: 0.5rem;
            }
            
            .team-card p {
                color: #6c757d;
                font-size: 0.9rem;
            }
            
            .footer {
                text-align: center;
                margin-top: 3rem;
                padding: 2rem 0;
                color: #6c757d;
                border-top: 1px solid #e9ecef;
            }
            
            .stButton button {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                border: none;
                padding: 0.5rem 1rem;
                border-radius: 5px;
                cursor: pointer;
            }
            
            .stButton button:hover {
                background: linear-gradient(135deg, #5a67d8 0%, #6b46c1 100%);
            }
        </style>
    """, unsafe_allow_html=True)

def init_watsonx():
    """Initialize IBM WatsonX AI connection"""
    load_dotenv()
    
    api_key = os.getenv("WATSONX_API_KEY")
    project_id = os.getenv("WATSONX_PROJECT_ID")
    url = os.getenv("WATSONX_URL")
    
    if not all([api_key, project_id, url]):
        raise ValueError("Missing WatsonX API credentials. Please check your environment variables.")
    
    try:
        credentials = {
            "url": url,
            "apikey": api_key
        }
        
        client = APIClient(credentials)
        client.set.default_project(project_id)
        
        st.session_state.watsonx_client = client
        st.session_state.watsonx_initialized = True
        
        return client
    except Exception as e:
        raise Exception(f"Failed to initialize WatsonX: {str(e)}")

def run_watson_granite(prompt, model_id="ibm/granite-13b-instruct-v2", parameters=None):
    """Run text generation using WatsonX Granite model"""
    if not st.session_state.get("watsonx_initialized", False):
        raise Exception("WatsonX not initialized. Call init_watsonx() first.")
    
    try:
        if parameters is None:
            parameters = {
                GenParams.DECODING_METHOD: "greedy",
                GenParams.MAX_NEW_TOKENS: 1000,
                GenParams.MIN_NEW_TOKENS: 1,
                GenParams.TEMPERATURE: 0.7,
                GenParams.TOP_P: 1,
                GenParams.TOP_K: 50,
                GenParams.REPETITION_PENALTY: 1
            }
        
        model = ModelInference(
            model_id=model_id,
            params=parameters,
            credentials=st.session_state.watsonx_client.credentials,
            project_id=os.getenv("WATSONX_PROJECT_ID")
        )
        
        response = model.generate_text(prompt)
        return response
    except Exception as e:
        raise Exception(f"Text generation failed: {str(e)}")

def show_error(message):
    """Display an error message"""
    st.error(f"❌ {message}")

def show_info(message):
    """Display an info message"""
    st.info(f"ℹ️ {message}")

def show_success(message):
    """Display a success message"""
    st.success(f"✅ {message}")

def show_warning(message):
    """Display a warning message"""
    st.warning(f"⚠️ {message}")