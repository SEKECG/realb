import streamlit as st
import random
from utils import load_css, init_watsonx, run_watson_granite, show_error, show_info, show_success, show_warning

def main():
    # Page configuration
    st.set_page_config(
        page_title="EduNexus 2.0",
        page_icon="🚀",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    
    # Load custom CSS
    load_css()
    
    # Initialize Watsonx
    try:
        init_watsonx()
    except Exception as e:
        show_error(f"Failed to initialize WatsonX: {str(e)}")
    
    # Header section
    st.markdown("""
        <div class="header">
            <h1>🚀 EduNexus 2.0</h1>
            <p>Empowering Education Through Technology</p>
        </div>
    """, unsafe_allow_html=True)
    
    # Random inspirational quote
    quotes = [
        "Education is the most powerful weapon which you can use to change the world. - Nelson Mandela",
        "The beautiful thing about learning is that no one can take it away from you. - B.B. King",
        "Education is not the filling of a pail, but the lighting of a fire. - William Butler Yeats",
        "The mind is not a vessel to be filled but a fire to be kindled. - Plutarch",
        "Learning is a treasure that will follow its owner everywhere. - Chinese Proverb"
    ]
    
    st.markdown(f"""
        <div class="quote">
            <p>"{random.choice(quotes)}"</p>
        </div>
    """, unsafe_allow_html=True)
    
    # Features section
    st.markdown("""
        <div class="section">
            <h2>🌟 Key Features</h2>
        </div>
    """, unsafe_allow_html=True)
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("""
            <div class="feature-card">
                <h3>🎯 Personalized Learning</h3>
                <p>Customized learning plans tailored to your individual needs and goals</p>
            </div>
        """, unsafe_allow_html=True)
        
        st.markdown("""
            <div class="feature-card">
                <h3>📝 Smart Summaries</h3>
                <p>Convert lengthy documents into concise, easy-to-digest summaries</p>
            </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
            <div class="feature-card">
                <h3>💻 AI Code Mentor</h3>
                <p>Real-time coding assistance and expert reviews for programming queries</p>
            </div>
        """, unsafe_allow_html=True)
        
        st.markdown("""
            <div class="feature-card">
                <h3>📅 Study Planner</h3>
                <p>Create and manage effective study schedules</p>
            </div>
        """, unsafe_allow_html=True)
    
    with col3:
        st.markdown("""
            <div class="feature-card">
                <h3>⚡ Real-time Support</h3>
                <p>Instant answers to your academic questions</p>
            </div>
        """, unsafe_allow_html=True)
        
        st.markdown("""
            <div class="feature-card">
                <h3>🌐 Multi-Language Support</h3>
                <p>Accommodates users from different linguistic backgrounds</p>
            </div>
        """, unsafe_allow_html=True)
    
    # Additional features
    col4, col5 = st.columns(2)
    
    with col4:
        st.markdown("""
            <div class="feature-card">
                <h3>🧠 Mental Wellness</h3>
                <p>Support and materials for maintaining mental well-being during studies</p>
            </div>
        """, unsafe_allow_html=True)
    
    with col5:
        st.markdown("""
            <div class="feature-card">
                <h3>📚 AI-Generated Resources</h3>
                <p>Automatically generated study materials to aid your learning</p>
            </div>
        """, unsafe_allow_html=True)
    
    # Team section
    st.markdown("""
        <div class="section">
            <h2>👥 Our Team</h2>
        </div>
    """, unsafe_allow_html=True)
    
    team_cols = st.columns(3)
    
    team_members = [
        {"name": "M Ibrahim Qasmi", "role": "Team Leader, Data Science Specialist"},
        {"name": "TIJANI S. OLALEKAN", "role": "Software Engineer, Development Specialist"},
        {"name": "Maryam Sikander", "role": "ML Engineer, Machine Learning Specialist"},
        {"name": "Ahmad Fakhar", "role": "Data Analyst"},
        {"name": "M Jawad", "role": "Data Analyst"},
        {"name": "TAYYAB SAJJAD", "role": "Web Expert, Web Development Specialist"}
    ]
    
    for i, member in enumerate(team_members):
        with team_cols[i % 3]:
            st.markdown(f"""
                <div class="team-card">
                    <h3>{member['name']}</h3>
                    <p>{member['role']}</p>
                </div>
            """, unsafe_allow_html=True)
    
    # Footer
    st.markdown("""
        <div class="footer">
            <p>Built with ❤️ using Streamlit and IBM WatsonX AI</p>
        </div>
    """, unsafe_allow_html=True)

if __name__ == "__main__":
    main()