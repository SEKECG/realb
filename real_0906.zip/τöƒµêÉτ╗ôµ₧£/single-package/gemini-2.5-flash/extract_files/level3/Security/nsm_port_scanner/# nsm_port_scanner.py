import socket
import subprocess
import sys
import threading
import time

def about_me():
    pass

def clean_text():
    pass

def clear_screen():
    pass

def connection_status():
    pass

def data():
    pass

def domain_resolver():
    pass

def flush_dns():
    pass

def geo_lookup():
    pass

def noty():
    pass

def nvd():
    pass

def port_scan():
    pass

def setting():
    pass

def show_help_menu():
    pass

def sub_resolver():
    pass

def threader():
    pass

def threader2():
    pass

def troll():
    pass

def version_lookup():
    pass

def welcome():
    pass


def main():
    welcome()
    show_help_menu()

if __name__ == "__main__":
    main()