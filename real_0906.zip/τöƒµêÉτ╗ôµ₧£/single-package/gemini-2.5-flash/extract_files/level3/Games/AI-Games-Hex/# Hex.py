from src.Game import Game
from agents.NaiveAgent import NaiveAgent
from src.Player import Player
from src.Colour import Colour

def main():
    player1 = Player("Player 1", Colour.RED, NaiveAgent(Colour.RED))
    player2 = Player("Player 2", Colour.BLUE, NaiveAgent(Colour.BLUE))
    game = Game(player1, player2)
    result = game.play()
    print(result)

if __name__ == "__main__":
    main()