import os
import subprocess
import time
from dotenv import load_dotenv
from google.generativeai import Client

load_dotenv()

def load_api_key():
    return os.getenv("GEMINI_API_KEY")

def check_external_tools():
    pass

def check_tmux_session():
    pass

def configure_ai():
    client = Client(api_key=load_api_key())
    return client

def explain_command():
    pass

def gemini_command_and_explanation():
    pass

def get_user_input():
    pass

def handle_command_execution():
    pass

def launch_persistent_viewer_if_needed():
    pass

def run_main_loop():
    pass

def run_visual_pause_window():
    pass

def select_execution_mode():
    pass

def send_command_to_tmux_viewer():
    pass

def send_interrupt_to_tmux_viewer():
    pass

def validate_command_risk():
    pass

if __name__ == "__main__":
    run_main_loop()