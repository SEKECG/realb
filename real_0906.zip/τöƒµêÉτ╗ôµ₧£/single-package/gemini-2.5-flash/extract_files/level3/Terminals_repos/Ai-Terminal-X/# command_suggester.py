from google.generativeai import Client

def configure_ai():
    client = Client(api_key=os.getenv("GEMINI_API_KEY"))
    return client

def load_api_key():
    return os.getenv("GEMINI_API_KEY")

def parse_suggestions():
    pass