import typer
from apikeygenerator import ApiKeyGenerator
from client import APIClient
from models import *

app = typer.Typer()

@app.command()
def configure(api_key):
    pass

@app.command()
def raw_get(url):
    pass

@app.command()
def get_nodes():
    pass

@app.command()
def get_node_info(node_id):
    pass

@app.command()
def get_config_nodes():
    pass

@app.command()
def get_config_node(node_id):
    pass

@app.command()
def update_config_node(node_id, config):
    pass

@app.command()
def get_actions_node(node_id):
    pass

@app.command()
def change_action_node(node_id, action, value):
    pass

@app.command()
def get_action(action_id):
    pass

@app.command()
def get_api_info():
    pass

@app.command()
def get_logs():
    pass

@app.command()
def get_info():
    pass

@app.command()
def print_output(output, format):
    pass

@app.command()
def setup_logging(log_level):
    pass

@app.command()
def validate_url(url):
    pass

class URLModel:
    pass

def entry_point():
    pass