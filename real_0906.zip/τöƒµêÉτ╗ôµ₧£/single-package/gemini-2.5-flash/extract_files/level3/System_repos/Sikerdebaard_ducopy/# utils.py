import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry
from urllib3.util.ssl_ import create_urllib3_context

class CustomHostNameCheckingAdapter(HTTPAdapter):
    def init_poolmanager(self, *args, **kwargs):
        context = create_urllib3_context(cert_reqs='required')
        kwargs['ssl_context'] = context
        return super().init_poolmanager(*args, **kwargs)

class DucoUrlSession(requests.Session):
    def __init__(self):
        super().__init__()
        retries = Retry(total=5, backoff_factor=0.1, status_forcelist=[500, 502, 503, 504])
        adapter = CustomHostNameCheckingAdapter()
        adapter.max_retries = retries
        self.mount('https://', adapter)
        self.mount('http://', adapter)

def custom_host_mapping(host):
    pass