import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry
from utils import DucoUrlSession

class APIClient:
    def __init__(self, api_key, base_url):
        self.api_key = api_key
        self.base_url = base_url
        self.session = DucoUrlSession()

    def get(self, endpoint):
        url = f"{self.base_url}{endpoint}"
        headers = {"Authorization": f"Bearer {self.api_key}"}
        response = self.session.get(url, headers=headers)
        return response.json()

    def post(self, endpoint, data):
        url = f"{self.base_url}{endpoint}"
        headers = {"Authorization": f"Bearer {self.api_key}"}
        response = self.session.post(url, headers=headers, json=data)
        return response.json()

    def patch(self, endpoint, data):
        url = f"{self.base_url}{endpoint}"
        headers = {"Authorization": f"Bearer {self.api_key}"}
        response = self.session.patch(url, headers=headers, json=data)
        return response.json()