from pydantic import BaseModel, validator

class ParameterConfig(BaseModel):
    pass

class NodeConfig(BaseModel):
    pass

class NodeGeneralInfo(BaseModel):
    pass

class NetworkDucoInfo(BaseModel):
    pass

class VentilationInfo(BaseModel):
    pass

class SensorData(BaseModel):
    pass

class NodesResponse(BaseModel):
    pass

class ActionsResponse(BaseModel):
    pass

class ConfigNodeRequest(BaseModel):
    pass

class NodeInfo(BaseModel):
    pass

class NodesInfoResponse(BaseModel):
    pass

class ActionsChangeResponse(BaseModel):
    pass

class ActionInfo(BaseModel):
    pass

class FirmwareResponse(BaseModel):
    pass

class GeneralInfo(BaseModel):
    pass

class ConfigNodeResponse(BaseModel):
    pass


def extract_val(value):
    pass

def unified_validator(cls):
    pass