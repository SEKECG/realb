from client import APIClient
from apikeygenerator import ApiKeyGenerator

class DucoPy:
    def __init__(self, serial_number, mac_address, base_url):
        self.api_key_generator = ApiKeyGenerator()
        self.api_key = self.api_key_generator.generate_key(serial_number, mac_address)
        self.client = APIClient(self.api_key, base_url)