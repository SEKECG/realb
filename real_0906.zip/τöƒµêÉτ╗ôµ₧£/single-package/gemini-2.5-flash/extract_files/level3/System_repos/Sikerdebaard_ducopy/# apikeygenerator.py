import time

class ApiKeyGenerator:
    def generate_key(self, serial_number, mac_address):
        timestamp = str(int(time.time()))
        base_string = f"{serial_number}{mac_address}{timestamp}"
        key = ""
        for char in base_string:
            key += chr(ord(char) ^ 123)  # Example XOR operation
        return key[:64]