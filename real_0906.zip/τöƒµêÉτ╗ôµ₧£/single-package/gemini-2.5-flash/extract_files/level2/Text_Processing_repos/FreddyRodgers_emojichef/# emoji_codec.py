import zlib
import hashlib

class CompressionMethod:
    ZLIB = "zlib"

class VerificationMethod:
    SHA256 = "sha256"

class EmojiCodec:
    def __init__(self, recipe):
        self.recipe = recipe

    def encode(self, data):
        pass

    def decode(self, data):
        pass


class FileHandler:
    def __init__(self, filepath):
        self.filepath = filepath

    def process_file(self, codec):
        pass