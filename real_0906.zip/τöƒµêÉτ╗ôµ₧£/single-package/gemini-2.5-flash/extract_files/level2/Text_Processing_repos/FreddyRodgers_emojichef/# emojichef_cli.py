import emoji_codec

class Colors:
    pass

class EmojiChefCLI:
    pass

def main():
    pass