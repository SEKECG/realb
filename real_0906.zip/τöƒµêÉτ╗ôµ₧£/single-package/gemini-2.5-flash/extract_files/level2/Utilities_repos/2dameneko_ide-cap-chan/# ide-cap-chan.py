import argparse
import os
from image_processor import process_image_worker
from arg_parser import parse_arguments
from model_handlers import get_handler

def main():
    args = parse_arguments()
    model_handler = get_handler(args.model, args.model_path)
    for filename in os.listdir(args.input_dir):
        if filename.endswith(('.jpg', '.jpeg', '.png', '.webp')):
            filepath = os.path.join(args.input_dir, filename)
            process_image_worker(filepath, model_handler, args)

if __name__ == "__main__":
    main()

#