from PIL import Image

def measure_gpu_speed():
    #Implementation for GPU speed measurement
    pass

def resize_image_proportionally(image, max_size):
    width, height = image.size
    if width > height:
        new_width = max_size
        new_height = int(height * (max_size / width))
    else:
        new_height = max_size
        new_width = int(width * (max_size / height))
    return image.resize((new_width, new_height))

#