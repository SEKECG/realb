import os
from PIL import Image
from utils import resize_image_proportionally
from model_handlers import ModelHandler

def process_image_worker(filepath, model_handler, args):
    try:
        img = Image.open(filepath)
        img = resize_image_proportionally(img, 512)
        caption = model_handler.generate_caption(img)
        output_filename = os.path.splitext(filepath)[0] + '.' + args.output_ext
        with open(output_filename, 'w') as f:
            f.write(caption)
    except Exception as e:
        print(f"Error processing {filepath}: {e}")

def get_handler(model_name, model_path):
    if model_name == 'JoyCaption':
        from model_handlers import JoyCaptionHandler
        return JoyCaptionHandler(model_path)
    elif model_name == 'MoLMo':
        from model_handlers import MoLMoHandler
        return MoLMoHandler(model_path)
    # ... other model handlers ...
    else:
        from model_handlers import GenericModelHandler
        return GenericModelHandler(model_path)

def get_torii03_user_prompt():
    return "Generate a caption for this image:"

def get_torii04_system_prompt():
    return "You are a helpful and informative image captioning assistant."

def get_torii04_user_prompt():
    return "Generate a detailed caption for this image:"

#