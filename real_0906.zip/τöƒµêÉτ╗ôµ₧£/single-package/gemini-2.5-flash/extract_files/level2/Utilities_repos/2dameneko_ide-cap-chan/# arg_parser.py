import argparse

def check_mutually_exclusive(args, group):
    if sum(1 for v in group if getattr(args, v) is not None) > 1:
        raise argparse.ArgumentError(None, "mutually exclusive arguments")

def parse_arguments():
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--model', choices=['ExLLaMA2', 'JoyCaption', 'MoLMo', 'MoLMo72b', 'Qwen2VL', 'Pixtral', 'Idefics3', 'LLaVA', 'MiniCPMo', 'Generic'], help='Model to use')
    group.add_argument('--model_path', help='Path to custom model')
    parser.add_argument('--input_dir', help='Input directory for images')
    parser.add_argument('--output_ext', default='json', help='Output file extension')
    parser.add_argument('--gpu', default=0, type=int, help='GPU device to use')
    parser.add_argument('--format', choices=['json', 'markdown', 'short', 'long', 'bbox'], help='Caption format')
    args = parser.parse_args()
    check_mutually_exclusive(args, ['model', 'model_path'])
    return args

#