class ModelHandler:
    def __init__(self, model_path):
        self.model_path = model_path

    def generate_caption(self, image):
        raise NotImplementedError

class JoyCaptionHandler(ModelHandler):
    def generate_caption(self, image):
        #Implementation for JoyCaption
        return "JoyCaption caption"

class MoLMoHandler(ModelHandler):
    def generate_caption(self, image):
        #Implementation for MoLMo
        return "MoLMo caption"

class MoLMo72bHandler(ModelHandler):
    def generate_caption(self, image):
        #Implementation for MoLMo72b
        return "MoLMo72b caption"

class Qwen2VLHandler(ModelHandler):
    def generate_caption(self, image):
        #Implementation for Qwen2VL
        return "Qwen2VL caption"

class PixtralHandler(ModelHandler):
    def generate_caption(self, image):
        #Implementation for Pixtral
        return "Pixtral caption"

class Idefics3Handler(ModelHandler):
    def generate_caption(self, image):
        #Implementation for Idefics3
        return "Idefics3 caption"

class ExLLaMA2Handler(ModelHandler):
    def generate_caption(self, image):
        #Implementation for ExLLaMA2
        return "ExLLaMA2 caption"

class LlavaHandler(ModelHandler):
    def generate_caption(self, image):
        #Implementation for LLaVA
        return "LLaVA caption"

class MiniCPMoHandler(ModelHandler):
    def generate_caption(self, image):
        #Implementation for MiniCPMo
        return "MiniCPMo caption"

class GenericModelHandler(ModelHandler):
    def generate_caption(self, image):
        #Implementation for Generic Model
        return "Generic Model caption"

#