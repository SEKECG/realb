from core.analyzer import LlmAnalyzer, TokenSearcher
from core.processor import TwitterLinkProcessor
from core.trader import ChainTrader, EvmChain, SolanaChain
from monitor.webhook_monitor import WebhookMonitor
from monitor.telegram_monitor import TelegramMonitor
from notify.dingding import DingTalkRobot
from notify.telegram_bot import TgRobot
from config import load_config

def main():
    config = load_config()
    analyzer = LlmAnalyzer()
    token_searcher = TokenSearcher()
    twitter_processor = TwitterLinkProcessor()
    evm_trader = EvmChain()
    solana_trader = SolanaChain()
    webhook_monitor = WebhookMonitor()
    telegram_monitor = TelegramMonitor()
    dingtalk_robot = DingTalkRobot()
    telegram_robot = TgRobot()

    # Main logic here...

if __name__ == "__main__":
    main()