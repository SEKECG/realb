import time
import random
import os

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def banner():
    print("Welcome to InfiNet!")

def show_menu():
    print("\nMain Menu:")
    print("1. Network Scan")
    print("2. MITM Attack")
    print("3. DNS Spoofing")
    print("4. Automatic Attack")
    print("5. Show Instructions")
    print("6. Exit")

def show_instructions():
    print("\nInstructions:")
    print("Network Scan: Enter target IP.")
    print("MITM Attack: Enter victim IP and gateway IP.")
    print("DNS Spoofing: Enter target IP and redirect IP.")

def network_scan():
    target_ip = input("Enter target IP: ")
    print(f"Scanning network for devices connected to {target_ip}...")
    time.sleep(2)
    print("Scan complete.")

def mitm_attack():
    victim_ip = input("Enter victim IP: ")
    gateway_ip = input("Enter gateway IP: ")
    print(f"Performing MITM attack on {victim_ip} via {gateway_ip}...")
    time.sleep(3)
    print("Attack complete.")

def dns_spoofing():
    target_ip = input("Enter target IP: ")
    redirect_ip = input("Enter redirect IP: ")
    print(f"Redirecting DNS requests from {target_ip} to {redirect_ip}...")
    time.sleep(2)
    print("DNS spoofing complete.")

def advanced_attack_choice():
    attack_types = ["Network Scan", "MITM Attack", "DNS Spoofing"]
    choice = random.choice(attack_types)
    print(f"Automatically selected attack: {choice}")
    if choice == "Network Scan":
        network_scan()
    elif choice == "MITM Attack":
        mitm_attack()
    elif choice == "DNS Spoofing":
        dns_spoofing()

def performance_monitor(start_time):
    end_time = time.time()
    duration = end_time - start_time
    print(f"Attack duration: {duration:.2f} seconds")

def dynamic_report(attack_type, status, duration):
    print("\nAttack Report:")
    print(f"Attack Type: {attack_type}")
    print(f"Status: {status}")
    print(f"Duration: {duration:.2f} seconds")

def advanced_logging(action):
    with open("InfiNet_log.txt", "a") as f:
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        f.write(f"{timestamp}: {action}\n")

def main():
    banner()
    while True:
        show_menu()
        choice = input("Enter your choice: ")
        start_time = time.time()
        try:
            if choice == '1':
                network_scan()
            elif choice == '2':
                mitm_attack()
            elif choice == '3':
                dns_spoofing()
            elif choice == '4':
                advanced_attack_choice()
            elif choice == '5':
                show_instructions()
            elif choice == '6':
                break
            else:
                print("Invalid choice.")
            performance_monitor(start_time)
            advanced_logging(f"User selected option {choice}")

        except Exception as e:
            print(f"An error occurred: {e}")
            advanced_logging(f"Error: {e}")

        input("Press Enter to continue...")
        clear_screen()

if __name__ == "__main__":
    main()