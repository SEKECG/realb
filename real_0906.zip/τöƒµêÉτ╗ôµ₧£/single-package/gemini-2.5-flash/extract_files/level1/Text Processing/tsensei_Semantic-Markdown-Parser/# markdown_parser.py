from token_encoder import get_token_length
from text_splitter import split_text_into_sentences

class TreeElement:
    def __init__(self, header, content):
        self.header = header
        self.content = content
        self.children = []

class SemanticChunk:
    def __init__(self, header, content):
        self.header = header
        self.content = content

class SemanticMarkdownParser:
    def __init__(self, token_limit):
        self.token_limit = token_limit

    def combine_chunks(self, chunks):
        combined_chunk = ""
        combined_token_count = 0
        for chunk in chunks:
            token_count = get_token_length(chunk.content)
            if combined_token_count + token_count <= self.token_limit:
                combined_chunk += chunk.content
                combined_token_count += token_count
            else:
                break
        return SemanticChunk("", combined_chunk)

    def get_semantic_chunks(self, root):
        chunks = []
        def post_order_traversal(node):
            for child in node.children:
                post_order_traversal(child)
            text = node.header + " " + node.content
            sentences = split_text_into_sentences(text, self.token_limit)
            for sentence in sentences:
                chunks.append(SemanticChunk(node.header, sentence))

        post_order_traversal(root)
        return chunks