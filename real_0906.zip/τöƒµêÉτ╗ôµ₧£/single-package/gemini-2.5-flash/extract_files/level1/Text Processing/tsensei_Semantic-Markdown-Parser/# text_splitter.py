def split_text_into_sentences(text, token_limit):
    sentences = text.split('.')
    chunks = []
    current_chunk = ""
    current_token_count = 0
    for sentence in sentences:
        sentence_tokens = sentence.split()
        if current_token_count + len(sentence_tokens) <= token_limit:
            current_chunk += sentence + "."
            current_token_count += len(sentence_tokens)
        else:
            chunks.append(current_chunk)
            current_chunk = sentence + "."
            current_token_count = len(sentence_tokens)
    chunks.append(current_chunk)
    return chunks