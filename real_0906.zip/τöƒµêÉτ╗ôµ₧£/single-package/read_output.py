import os
import json
import re

# 输入 JSONL 文件路径
#input_jsonl = r"C:\Users\cruzitodeng\Desktop\sys_gen\work12\sys_generation\generate\deepseek-v3\completion_block0.jsonl"
#input_jsonl = r"C:\Users\cruzitodeng\Desktop\sys_gen\work12\sys_generation\generate\gemini-2.5-flash\completion_block0.jsonl"
#input_jsonl = r"C:\Users\cruzitodeng\Desktop\sys_gen\work12\sys_generation\generate\claude-sonnet-4\completion_block0.jsonl"
input_jsonl = r"C:\Users\cruzitodeng\Desktop\sys_gen\projs_filtered_uml\model_gen\make_prompts_package\total\qwen3-235b-a22b\completion_block0.jsonl"

# 输出根目录路径
#output_root = r"C:\Users\cruzitodeng\Desktop\sys_gen\work12\sys_generation\generate\deepseek-v3\extract_files"
#output_root = r"C:\Users\cruzitodeng\Desktop\sys_gen\work12\sys_generation\generate\gemini-2.5-flash\extract_files"
#output_root = r"C:\Users\cruzitodeng\Desktop\sys_gen\work12\sys_generation\generate\claude-sonnet-4\extract_files"
output_root = r"C:\Users\cruzitodeng\Desktop\sys_gen\projs_filtered_uml\model_gen\make_prompts_package\total\qwen3-235b-a22b\extract_files"

# 创建输出根目录（如果不存在）
os.makedirs(output_root, exist_ok=True)

# 更灵活的正则表达式，处理换行符数量不固定的情况
file_block_pattern = re.compile(
    r'<begin_file>(?:\s*[\r\n])*?([^\r\n]+)(?:\s*[\r\n])*?([\s\S]*?)<end_file>',
    re.DOTALL
)

# 读取 JSONL 文件并处理每一行
with open(input_jsonl, 'r', encoding='utf-8') as infile:
    for line in infile:
        # 解析 JSON 行
        data = json.loads(line.strip())
        namespace = data['namespace']
        code = data['completions'][0]
        #code = data["output"]

        # 提取所有文件块
        file_blocks = file_block_pattern.findall(code)

        # 处理每个文件块
        for rel_path, content in file_blocks:
            try:
                # 构建目标文件路径
                full_dir = os.path.join(output_root, *namespace.split('.'))
                file_path = os.path.join(full_dir, rel_path.strip())  # 去除路径两端空白

                # 创建父目录（如果不存在）
                os.makedirs(os.path.dirname(file_path), exist_ok=True)

                # 写入文件内容
                with open(file_path, 'w', encoding='utf-8') as outfile:
                    outfile.write(content.strip())  # 去除内容两端空白
            except:
                continue