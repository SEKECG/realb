from migration_lint.extractor.base import BaseExtractor


class DjangoManagementExtractor(BaseExtractor):
    """
    Migrations extractor for Django migrations for management command.
    """

    NAME = "django-management"

    def extract_sql(self, migration_path):
        """
        Extract raw SQL from the migration file.

        :param migration_path: Path to the migration file.
        :return: Raw SQL as a string.
        """
        # This method should implement logic to extract SQL from Django migration
        # For now, returning empty string as a placeholder
        return ""