import unittest
from migration_lint.sql.parser import classify_migration, classify_statement
from migration_lint.sql.constants import StatementType


class TestClassifyStatement(unittest.TestCase):
    def test_classify_migration(self, statement="SELECT 1", expected_type=StatementType.BACKWARD_COMPATIBLE):
        result = classify_migration(statement)
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0][1], expected_type)

    def test_conditionally_safe(self, sql="ALTER TABLE t ADD COLUMN x INT", expected_type=StatementType.BACKWARD_COMPATIBLE):
        result = classify_migration(sql)
        statement_type = result[-1][1]
        self.assertEqual(statement_type, expected_type)

    def test_ignore_order(self):
        sql = """
            ALTER TABLE t ADD COLUMN x INT NOT NULL DEFAULT 1;
            ALTER TABLE t ADD COLUMN y INT DEFAULT 1 NOT NULL;
        """
        result = classify_migration(sql)
        for _, statement_type in result:
            self.assertEqual(statement_type, StatementType.BACKWARD_COMPATIBLE)

    def test_ignore_statements(self, statement="CREATE INDEX CONCURRENTLY idx ON t(col)", expected_count=1):
        result = classify_migration(statement)
        self.assertEqual(len(result), expected_count)


if __name__ == "__main__":
    unittest.main()