import subprocess
from typing import Any, Optional

from migration_lint.extractor.base import BaseExtractor
from migration_lint.util.env import get_bool_env


class AlembicExtractor(BaseExtractor):
    NAME = "alembic"

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.command = kwargs.get("command", "make sqlmigrate")
        self.migration_path = kwargs.get("migration_path", "/migrations/versions/")

    def _get_migrations_sql(self) -> None:
        try:
            result = subprocess.run(
                ["alembic", self.command],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                check=True,
            )
            return result.stdout
        except subprocess.CalledProcessError as e:
            if not get_bool_env("IGNORE_EXTRACTOR_FAIL", False):
                raise RuntimeError(f"Alembic command failed: {e.stderr}") from e
            return ""

    def extract_sql(self, migration_path: str) -> str:
        # Implement logic to extract SQL from the specific migration file
        return self._get_migrations_sql()

    def is_allowed_with_backward_incompatible_migration(self, path: str) -> bool:
        # Implement logic to check if file changes are allowed with backward-incompatible migrations
        return path.startswith(self.migration_path)

    def is_migration(self, path: str) -> bool:
        # Implement logic to check if the file is a migration
        return path.startswith(self.migration_path) and path.endswith(".py")