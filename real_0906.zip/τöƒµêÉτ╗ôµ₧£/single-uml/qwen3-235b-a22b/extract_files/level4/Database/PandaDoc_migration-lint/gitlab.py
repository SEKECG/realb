import os
import requests
from typing import Sequence

from migration_lint.source_loader.model import SourceDiff


class GitlabBranchLoader:
    NAME = "gitlab-branch"
    base_url: str
    branch: str
    default_branch: str
    gitlab_api_key: str
    project_id: str

    def __init__(
        self,
        branch,
        project_id,
        gitlab_api_key,
        gitlab_instance,
        **kwargs
    ):
        if not all([branch, project_id, gitlab_api_key, gitlab_instance]):
            raise RuntimeError(
                "Missing required configuration for GitlabBranchLoader: "
                "branch, project_id, gitlab_api_key, gitlab_instance"
            )

        self.branch = branch
        self.project_id = project_id
        self.gitlab_api_key = gitlab_api_key
        self.base_url = f"{gitlab_instance}/api/v4/projects/{project_id}"
        self.default_branch = kwargs.get("default_branch", "master")

    def get_changed_files(self) -> Sequence[SourceDiff]:
        headers = {"PRIVATE-TOKEN": self.gitlab_api_key}
        url = f"{self.base_url}/repository/compare"

        params = {
            "from": self.default_branch,
            "to": self.branch,
        }

        response = requests.get(url, headers=headers, params=params)
        response.raise_for_status()

        changes = response.json().get("diffs", [])
        return [
            SourceDiff(
                path=change["new_path"] if change["new_file"] or change["renamed_file"] else change["old_path"],
                old_path=change["old_path"] if change["old_file"] or change["renamed_file"] else change["new_path"],
                diff=change.get("diff")
            )
            for change in changes
            if change.get("new_file") or change.get("modified_file") or change.get("renamed_file")
        ]


class GitlabMRLoader:
    NAME = "gitlab-mr"
    base_url: str
    gitlab_api_key: str
    mr_id: str
    project_id: str

    def __init__(
        self,
        mr_id,
        project_id,
        gitlab_api_key,
        gitlab_instance,
        **kwargs
    ):
        if not all([mr_id, project_id, gitlab_api_key, gitlab_instance]):
            raise RuntimeError(
                "Missing required configuration for GitlabMRLoader: "
                "mr_id, project_id, gitlab_api_key, gitlab_instance"
            )

        self.mr_id = mr_id
        self.project_id = project_id
        self.gitlab_api_key = gitlab_api_key
        self.base_url = f"{gitlab_instance}/api/v4/projects/{project_id}"

    def get_changed_files(self) -> Sequence[SourceDiff]:
        headers = {"PRIVATE-TOKEN": self.gitlab_api_key}
        url = f"{self.base_url}/merge_requests/{self.mr_id}/changes"

        response = requests.get(url, headers=headers)
        response.raise_for_status()

        changes = response.json().get("changes", [])
        return [
            SourceDiff(
                path=change["new_path"],
                old_path=change["old_path"],
                diff=change.get("diff")
            )
            for change in changes
            if not change.get("deleted_file")
        ]