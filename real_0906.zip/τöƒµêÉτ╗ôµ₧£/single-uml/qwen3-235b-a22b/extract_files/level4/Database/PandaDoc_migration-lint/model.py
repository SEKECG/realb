from dataclasses import dataclass
from typing import List, Optional


@dataclass
class SourceDiff:
    path: str
    old_path: Optional[str] = None
    diff: Optional[str] = None

    def __post_init__(self):
        if not self.old_path:
            self.old_path = self.path


@dataclass
class ExtendedSourceDiff:
    path: str
    allowed_with_backward_incompatible: bool

    @classmethod
    def of_source_diff(cls, source_diff, allowed_with_backward_incompatible):
        return cls(
            path=source_diff.path,
            old_path=source_diff.old_path,
            diff=source_diff.diff,
            allowed_with_backward_incompatible=allowed_with_backward_incompatible,
        )


@dataclass
class Migration:
    path: str
    raw_sql: str


@dataclass
class MigrationsMetadata:
    changed_files: List[ExtendedSourceDiff]
    migrations: List[Migration]