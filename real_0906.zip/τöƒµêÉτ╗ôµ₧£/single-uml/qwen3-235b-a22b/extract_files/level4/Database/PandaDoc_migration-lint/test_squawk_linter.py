import unittest
from unittest.mock import patch, MagicMock
import sys
import os

# Add the project root to the Python path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from migration_lint.analyzer.squawk import SquawkLinter


class TestSquawkLinter(unittest.TestCase):

    def test_platform(self, platform, result):
        with patch('platform.system', return_value=platform):
            with patch('shutil.which', return_value='/mock/path/to/squawk'):
                linter = SquawkLinter(config_path='/mock/config', pg_version='13')
                self.assertEqual(linter.squawk, result)

    def test_squawk_command(self, params, result_flags):
        linter = SquawkLinter(config_path='/mock/config', pg_version='13')
        migration_sql = 'SELECT * FROM test;'
        expected_command = f"/mock/squawk_binary -config /mock/config -pg_version 13 {result_flags} <<< '{migration_sql}'"
        with patch.object(linter, 'squawk', '/mock/squawk_binary'):
            self.assertEqual(linter.squawk_command(migration_sql), expected_command)

    def test_unsupported_platform(self):
        with patch('platform.system', return_value='win32'):
            with self.assertRaises(RuntimeError):
                SquawkLinter(config_path='/mock/config', pg_version='13')


if __name__ == '__main__':
    unittest.main()