from migration_lint.extractor.base import BaseExtractor


class FlywayExtractor(BaseExtractor):
    NAME = "flyway"

    def is_allowed_with_backward_incompatible_migration(self, path):
        return False

    def is_migration(self, path):
        return path.endswith(".sql") and path.startswith("V")