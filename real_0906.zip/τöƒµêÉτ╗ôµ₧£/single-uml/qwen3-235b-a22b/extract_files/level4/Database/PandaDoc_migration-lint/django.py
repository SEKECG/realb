from typing import Any, List, Optional

from migration_lint.extractor.base import BaseExtractor


class DjangoExtractor(BaseExtractor):
    NAME = "django"

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.command = "makemigrations"
        self.skip_lines = 0

    def extract_sql(self, migration_path: str) -> str:
        # Placeholder for actual implementation
        return ""

    def is_allowed_with_backward_incompatible_migration(self, path: str) -> bool:
        # Placeholder for actual implementation
        return False

    def is_migration(self, path: str) -> bool:
        # Placeholder for actual implementation
        return False


class DjangoManagementExtractor(DjangoExtractor):
    NAME = "django_management"

    def extract_sql(self, migration_path: str) -> str:
        # Placeholder for actual implementation
        return ""