import unittest
from unittest.mock import patch, MagicMock

from migration_lint.django.extractor.django_management import DjangoManagementExtractor


class TestDjangoManagementExtractor(unittest.TestCase):
    @patch("migration_lint.django.extractor.django_management.os")
    def test_django_extractor__ok(self, mock_os):
        # Mock os.path.exists to return True
        mock_os.path.exists.return_value = True

        # Create instance
        extractor = DjangoManagementExtractor()

        # Test extract_sql method
        migration_path = "path/to/migration.py"
        with patch("builtins.open", unittest.mock.mock_open(read_data="fake_sql")) as mock_file:
            result = extractor.extract_sql(migration_path)

        # Assert
        mock_os.path.exists.assert_called_once_with(migration_path)
        mock_file.assert_called_once_with(migration_path, "r")
        self.assertEqual(result, "fake_sql")


if __name__ == "__main__":
    unittest.main()