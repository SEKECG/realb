import unittest
from unittest.mock import MagicMock, patch

from migration_lint.analyzer.base import Analyzer
from migration_lint.source_loader.model import SourceDiff
from migration_lint.extractor.model import Migration


class TestAnalyzer(unittest.TestCase):
    FAKE_STATEMENT = "CREATE TABLE test_table (id INT);"

    def get_analyzer(self, changed_files, migrations):
        loader = MagicMock()
        extractor = MagicMock()
        linters = [MagicMock()]
        analyzer = Analyzer(loader, extractor, linters)
        analyzer.changed_files = changed_files
        analyzer.migrations = migrations
        return analyzer

    def test_analyze_data_migration(self):
        # Test that data migrations are not mixed with backward-incompatible changes
        changed_files = [
            SourceDiff(path="data_migration.py", old_path="data_migration.py")
        ]
        migrations = [
            Migration(path="data_migration.py", raw_sql=self.FAKE_STATEMENT)
        ]
        analyzer = self.get_analyzer(changed_files, migrations)
        analyzer.analyze()
        for linter in analyzer.linters:
            linter.lint.assert_called_once_with(self.FAKE_STATEMENT, changed_files)

    def test_analyze_ignore_migration(self):
        # Test that a migration marked with ignore is skipped
        changed_files = [
            SourceDiff(path="ignored_migration.py", old_path="ignored_migration.py")
        ]
        migrations = [
            Migration(path="ignored_migration.py", raw_sql="-- migration-lint: ignore\n" + self.FAKE_STATEMENT)
        ]
        analyzer = self.get_analyzer(changed_files, migrations)
        analyzer.analyze()
        for linter in analyzer.linters:
            linter.lint.assert_not_called()

    def test_analyze_incompatible(self):
        # Test detection of backward incompatible operations
        changed_files = [
            SourceDiff(path="incompatible_migration.py", old_path="incompatible_migration.py")
        ]
        migrations = [
            Migration(path="incompatible_migration.py", raw_sql="ALTER TABLE table_name DROP COLUMN column_name;")
        ]
        analyzer = self.get_analyzer(changed_files, migrations)
        with self.assertRaises(SystemExit):
            analyzer.analyze()

    def test_analyze_incompatible_with_allowed_files(self):
        # Test allowed files with backward-incompatible changes
        changed_files = [
            SourceDiff(path="allowed_file.py", old_path="allowed_file.py", allowed_with_backward_incompatible=True)
        ]
        migrations = []
        analyzer = self.get_analyzer(changed_files, migrations)
        analyzer.analyze()
        # Should not raise any error

    def test_analyze_no_errors(self):
        # Test when no errors are found
        changed_files = [
            SourceDiff(path="safe_migration.py", old_path="safe_migration.py")
        ]
        migrations = [
            Migration(path="safe_migration.py", raw_sql="CREATE INDEX idx_name ON table_name(column_name);")
        ]
        analyzer = self.get_analyzer(changed_files, migrations)
        analyzer.analyze()
        # Should not raise any error

    def test_analyze_no_migrations(self):
        # Test when no migrations are detected
        changed_files = [
            SourceDiff(path="non_migration_file.py", old_path="non_migration_file.py")
        ]
        migrations = []
        analyzer = self.get_analyzer(changed_files, migrations)
        analyzer.analyze()
        # Should not raise any error

    def test_analyze_restricted(self):
        # Test detection of restricted operations
        changed_files = [
            SourceDiff(path="restricted_migration.py", old_path="restricted_migration.py")
        ]
        migrations = [
            Migration(path="restricted_migration.py", raw_sql="LOCK TABLE table_name IN EXCLUSIVE MODE;")
        ]
        analyzer = self.get_analyzer(changed_files, migrations)
        with self.assertRaises(SystemExit):
            analyzer.analyze()

    def test_analyze_unsupported(self):
        # Test detection of unsupported operations
        changed_files = [
            SourceDiff(path="unsupported_migration.py", old_path="unsupported_migration.py")
        ]
        migrations = [
            Migration(path="unsupported_migration.py", raw_sql="UNKNOWN SQL STATEMENT;")
        ]
        analyzer = self.get_analyzer(changed_files, migrations)
        with self.assertRaises(SystemExit):
            analyzer.analyze()


if __name__ == '__main__':
    unittest.main()