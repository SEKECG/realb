# rules.py

from migration_lint.sql.constants import StatementType
from migration_lint.sql.model import SegmentLocator, ConditionalMatch, KeywordLocator

BACKWARD_INCOMPATIBLE_OPERATIONS = [
    SegmentLocator(raw="ALTER TABLE ... ADD COLUMN ... SERIAL"),
    SegmentLocator(raw="ALTER TABLE ... DROP COLUMN ..."),
    SegmentLocator(raw="ALTER TABLE ... DROP CONSTRAINT ..."),
    SegmentLocator(raw="ALTER TABLE ... RENAME COLUMN ..."),
    SegmentLocator(raw="DROP TABLE ..."),
    SegmentLocator(raw="CREATE INDEX ... ON ..."),
    SegmentLocator(raw="DROP INDEX ..."),
]

BACKWARD_COMPATIBLE_OPERATIONS = [
    SegmentLocator(raw="CREATE TABLE ..."),
    SegmentLocator(raw="ALTER TABLE ... ADD COLUMN ..."),
    SegmentLocator(raw="ALTER TABLE ... ADD CONSTRAINT ..."),
    SegmentLocator(raw="ALTER TABLE ... ALTER COLUMN ... TYPE ..."),
]

DATA_MIGRATION_OPERATIONS = None  # Placeholder for data migration rules

RESTRICTED_OPERATIONS = [
    SegmentLocator(raw="ALTER TABLE ... ALTER COLUMN ... TYPE ... USING ..."),
    SegmentLocator(raw="ALTER TABLE ... ALTER COLUMN ... SET STORAGE ..."),
    SegmentLocator(raw="ALTER TABLE ... ALTER COLUMN ... SET STATISTICS ..."),
    SegmentLocator(raw="ALTER TABLE ... CLUSTER ON ..."),
    SegmentLocator(raw="ALTER TABLE ... SET WITHOUT CLUSTER"),
    SegmentLocator(raw="ALTER TABLE ... OWNER TO ..."),
    SegmentLocator(raw="ALTER TABLE ... SET TABLESPACE ..."),
    SegmentLocator(raw="ALTER TABLE ... INHERIT ..."),
    SegmentLocator(raw="ALTER TABLE ... NO INHERIT ..."),
    SegmentLocator(raw="ALTER TABLE ... OF ..."),
    SegmentLocator(raw="ALTER TABLE ... NOT OF"),
    SegmentLocator(raw="ALTER TABLE ... REPLICA IDENTITY ..."),
    SegmentLocator(raw="ALTER TABLE ... SET LOGGED"),
    SegmentLocator(raw="ALTER TABLE ... SET UNLOGGED"),
    SegmentLocator(raw="ALTER TABLE ... ADD CONSTRAINT ... EXCLUDE ..."),
    SegmentLocator(raw="ALTER TABLE ... ADD CONSTRAINT ... UNIQUE ... WITH ..."),
    SegmentLocator(raw="ALTER TABLE ... ADD CONSTRAINT ... CHECK ... NOT VALID"),
    SegmentLocator(raw="ALTER TABLE ... VALIDATE CONSTRAINT ..."),
]

IGNORED_OPERATIONS = None  # Placeholder for ignored operations