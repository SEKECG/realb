import unittest
from unittest.mock import patch, MagicMock

from migration_lint.extractor.alembic import AlembicExtractor
from migration_lint.source_loader.model import SourceDiff
from migration_lint.extractor.model import ExtendedSourceDiff, MigrationsMetadata


class TestAlembicExtractor(unittest.TestCase):
    @patch("migration_lint.extractor.alembic.subprocess")
    def test_alembic_extractor__ok(self, mock_subprocess):
        extractor = AlembicExtractor()
        mock_subprocess.run.return_value.stdout = "CREATE TABLE test_table (id INT);"
        mock_subprocess.run.return_value.returncode = 0

        # Mock source diff
        source_diff = SourceDiff(path="migrations/versions/123_test.py")
        extended_diff = ExtendedSourceDiff.of_source_diff(
            source_diff, allowed_with_backward_incompatible=False
        )

        # Call extract_sql
        result = extractor.extract_sql("migrations/versions/123_test.py")
        self.assertIn("CREATE TABLE test_table", result)

    @patch("migration_lint.extractor.alembic.subprocess")
    def test_alembic_extractor__error(self, mock_subprocess):
        extractor = AlembicExtractor()
        mock_subprocess.run.side_effect = Exception("Subprocess failed")

        with self.assertRaises(Exception):
            extractor.extract_sql("invalid_migration.py")

    def test_alembic_extractor_command__ok(self):
        extractor = AlembicExtractor()
        extractor.command = "custom command"
        self.assertEqual(extractor.command, "custom command")

    def test_alembic_extractor_path__ok(self):
        extractor = AlembicExtractor()
        extractor.migration_path = "/custom/migrations/"
        self.assertEqual(extractor.migration_path, "/custom/migrations/")

    def test_is_migration(self):
        extractor = AlembicExtractor()
        self.assertTrue(extractor.is_migration("migrations/versions/123_test.py"))
        self.assertFalse(extractor.is_migration("migrations/not_version/test.py"))

    def test_is_allowed_with_backward_incompatible_migration(self):
        extractor = AlembicExtractor()
        self.assertFalse(extractor.is_allowed_with_backward_incompatible_migration("path"))


if __name__ == "__main__":
    unittest.main()