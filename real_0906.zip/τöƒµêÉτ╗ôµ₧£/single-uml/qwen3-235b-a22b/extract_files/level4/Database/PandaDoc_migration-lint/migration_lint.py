from django.core.management.base import BaseCommand
from migration_lint.analyzer.base import Analyzer
from migration_lint.extractor import Extractor
from migration_lint.source_loader import SourceLoader
from migration_lint.analyzer.squawk import SquawkLinter
from migration_lint.util.env import get_bool_env
import logging


class Command(BaseCommand):
    help = 'Analyze migrations to detect unsafe operations'

    def add_arguments(self, parser):
        parser.add_argument(
            '--loader',
            choices=SourceLoader.names(),
            default='local',
            help='Source loader to use'
        )
        parser.add_argument(
            '--extractor',
            choices=Extractor.names(),
            default='django',
            help='Migration extractor to use'
        )
        parser.add_argument(
            '--squawk-config',
            help='Path to squawk configuration file'
        )
        parser.add_argument(
            '--pg-version',
            type=int,
            default=12,
            help='PostgreSQL version to check against'
        )
        parser.add_argument(
            '--ignore-extractor-fail',
            action='store_true',
            default=get_bool_env('MIGRATION_LINT_IGNORE_EXTRACTOR_FAIL', False),
            help='Ignore extractor failures'
        )
        parser.add_argument(
            '--ignore-extractor-not-found',
            action='store_true',
            default=get_bool_env('MIGRATION_LINT_IGNORE_EXTRACTOR_NOT_FOUND', False),
            help='Ignore extractor not found'
        )
        parser.add_argument(
            '--only-new-files',
            action='store_true',
            default=get_bool_env('MIGRATION_LINT_ONLY_NEW_FILES', False),
            help='Only process new files'
        )

    def handle(self, *args, **options):
        # Set up logger
        logging.basicConfig(level=logging.INFO)

        # Get loader instance
        loader_class = SourceLoader.get(options['loader'])
        loader = loader_class(only_new_files=options['only_new_files'])

        # Get extractor instance
        extractor_class = Extractor.get(options['extractor'])
        extractor = extractor_class(
            ignore_extractor_fail=options['ignore_extractor_fail'],
            ignore_extractor_not_found=options['ignore_extractor_not_found']
        )

        # Create linters
        linters = []
        if options['squawk_config']:
            try:
                from migration_lint.analyzer.squawk import SquawkLinter
                linters.append(SquawkLinter(
                    config_path=options['squawk_config'],
                    pg_version=options['pg_version']
                ))
            except ImportError:
                logging.warning("SquawkLinter is not available. Install squawk to use it.")

        # Create analyzer
        analyzer = Analyzer(loader=loader, extractor=extractor, linters=linters)

        # Run analysis
        analyzer.analyze()