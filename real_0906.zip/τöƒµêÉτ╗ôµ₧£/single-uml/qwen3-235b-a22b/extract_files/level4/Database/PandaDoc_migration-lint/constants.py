# migration_lint/sql/constants.py

from enum import Enum


class StatementType(Enum):
    UNSUPPORTED = "unsupported"
    RESTRICTED = "restricted"
    BACKWARD_INCOMPATIBLE = "backward_incompatible"
    DATA_MIGRATION = "data_migration"
    BACKWARD_COMPATIBLE = "backward_compatible"
    IGNORED = "ignored"

    def colorized(self):
        from migration_lint.util.colors import red, yellow, green, blue, grey

        colors = {
            StatementType.BACKWARD_COMPATIBLE: green,
            StatementType.DATA_MIGRATION: blue,
            StatementType.IGNORED: grey,
            StatementType.BACKWARD_INCOMPATIBLE: yellow,
            StatementType.RESTRICTED: red,
            StatementType.UNSUPPORTED: red,
        }
        return colors.get(self, lambda x: x)(self.name.replace("_", " ").title())