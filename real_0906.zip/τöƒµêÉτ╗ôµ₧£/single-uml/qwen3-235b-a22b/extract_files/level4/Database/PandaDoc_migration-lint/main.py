import sys
from migration_lint.source_loader import LocalLoader
from migration_lint.extractor import RawSqlExtractor
from migration_lint.analyzer import Analyzer
from migration_lint.analyzer.squawk import SquawkLinter
from migration_lint.analyzer.compat import CompatibilityLinter


def main(loader_type='local', extractor_type='raw_sql', squawk_config_path=None,
         squawk_pg_version=None, **kwargs):
    """
    Analyze source code using specified loader and extractor types,
    applying compatibility and Squawk linters based on the given configuration
    and PostgreSQL version.
    """
    extractor_map = {
        'raw_sql': RawSqlExtractor,
        'alembic': None,  # Placeholder for future implementation
        'django': None,  # Placeholder for future implementation
        'flyway': None,  # Placeholder for future implementation
    }

    loader_map = {
        'local': LocalLoader,
        'gitlab_branch': None,  # Placeholder for future implementation
        'gitlab_mr': None,  # Placeholder for future implementation
    }

    extractor_class = extractor_map.get(extractor_type)
    loader_class = loader_map.get(loader_type)

    if extractor_class is None or loader_class is None:
        print(f"Unsupported extractor or loader: {extractor_type}, {loader_type}")
        sys.exit(1)

    extractor = extractor_class(**kwargs)
    loader = loader_class(**kwargs)

    linters = [CompatibilityLinter()]
    if squawk_config_path and squawk_pg_version:
        linters.append(
            SquawkLinter(
                config_path=squawk_config_path,
                pg_version=squawk_pg_version
            )
        )

    analyzer = Analyzer(loader=loader, extractor=extractor, linters=linters)
    analyzer.analyze()


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='Migration Lint Tool')
    parser.add_argument('--loader', choices=['local', 'gitlab_branch', 'gitlab_mr'],
                        default='local', help='Type of source loader')
    parser.add_argument('--extractor', choices=['raw_sql', 'alembic', 'django', 'flyway'],
                        default='raw_sql', help='Type of migration extractor')
    parser.add_argument('--squawk-config', help='Path to Squawk config file')
    parser.add_argument('--pg-version', help='PostgreSQL version')

    args = parser.parse_args()

    main(loader_type=args.loader, extractor_type=args.extractor,
         squawk_config_path=args.squawk_config, squawk_pg_version=args.pg_version)