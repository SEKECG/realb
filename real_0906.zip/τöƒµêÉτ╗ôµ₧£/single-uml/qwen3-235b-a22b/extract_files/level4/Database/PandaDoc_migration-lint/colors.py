# migration_lint/util/colors.py

class ColorCode:
    blue = "\033[94m"
    green = "\033[92m"
    grey = "\033[90m"
    red = "\033[91m"
    reset = "\033[0m"
    yellow = "\033[93m"


def colorize(color, msg):
    return f"{color}{msg}{ColorCode.reset}"


def green(msg):
    return colorize(ColorCode.green, msg)


def red(msg):
    return colorize(ColorCode.red, msg)


def yellow(msg):
    return colorize(ColorCode.yellow, msg)


def blue(msg):
    return colorize(ColorCode.blue, msg)


def grey(msg):
    return colorize(ColorCode.grey, msg)