import unittest
from unittest.mock import patch, MagicMock

from migration_lint.source_loader.gitlab import GitlabBranchLoader, GitlabMRLoader


class TestGitlabLoaders(unittest.TestCase):
    def test_gitlab_branch_loader_not_configured(self):
        with self.assertRaises(RuntimeError):
            GitlabBranchLoader(
                branch=None,
                project_id=None,
                gitlab_api_key=None,
                gitlab_instance=None
            )

    @patch("migration_lint.source_loader.gitlab.requests.get")
    def test_gitlab_branch_loader_on_changed_files(self, mock_get):
        mock_response = MagicMock()
        mock_response.json.return_value = [
            {"old_path": "old_file.py", "new_path": "new_file.py", "diff": "diff_data"}
        ]
        mock_get.return_value = mock_response

        loader = GitlabBranchLoader(
            branch="test-branch",
            project_id=123,
            gitlab_api_key="token",
            gitlab_instance="https://gitlab.example.com"
        )
        changed_files = loader.get_changed_files()

        self.assertEqual(len(changed_files), 1)
        self.assertEqual(changed_files[0].old_path, "old_file.py")
        self.assertEqual(changed_files[0].path, "new_file.py")

    @patch("migration_lint.source_loader.gitlab.requests.get")
    def test_gitlab_branch_loader_default_branch(self, mock_get):
        mock_response = MagicMock()
        mock_response.json.return_value = []
        mock_get.return_value = mock_response

        loader = GitlabBranchLoader(
            branch="test-branch",
            project_id=123,
            gitlab_api_key="token",
            gitlab_instance="https://gitlab.example.com",
            default_branch="main"
        )
        changed_files = loader.get_changed_files()

        self.assertEqual(len(changed_files), 0)

    @patch("migration_lint.source_loader.gitlab.requests.get")
    def test_gitlab_branch_loader(self, mock_get):
        mock_response = MagicMock()
        mock_response.json.return_value = [
            {"old_path": "file1.py", "new_path": "file1.py", "diff": "diff1"},
            {"old_path": "file2.py", "new_path": "file3.py", "diff": "diff2"}
        ]
        mock_get.return_value = mock_response

        loader = GitlabBranchLoader(
            branch="test-branch",
            project_id=123,
            gitlab_api_key="token",
            gitlab_instance="https://gitlab.example.com"
        )
        changed_files = loader.get_changed_files()

        self.assertEqual(len(changed_files), 2)
        self.assertEqual(changed_files[0].old_path, "file1.py")
        self.assertEqual(changed_files[0].path, "file1.py")
        self.assertEqual(changed_files[1].old_path, "file2.py")
        self.assertEqual(changed_files[1].path, "file3.py")

    def test_gitlab_mr_loader_not_configured(self):
        with self.assertRaises(RuntimeError):
            GitlabMRLoader(
                mr_id=None,
                project_id=None,
                gitlab_api_key=None,
                gitlab_instance=None
            )

    @patch("migration_lint.source_loader.gitlab.requests.get")
    def test_gitlab_mr_loader_on_changed_files(self, mock_get):
        mock_response = MagicMock()
        mock_response.json.return_value = [
            {"old_path": "added_file.py", "new_path": "added_file.py", "diff": "added_diff"},
            {"old_path": "modified_old.py", "new_path": "modified_new.py", "diff": "modified_diff"},
            {"old_path": "deleted_file.py", "new_path": None, "diff": None}
        ]
        mock_get.return_value = mock_response

        loader = GitlabMRLoader(
            mr_id=456,
            project_id=123,
            gitlab_api_key="token",
            gitlab_instance="https://gitlab.example.com"
        )
        changed_files = loader.get_changed_files()

        self.assertEqual(len(changed_files), 2)
        self.assertEqual(changed_files[0].old_path, "added_file.py")
        self.assertEqual(changed_files[0].path, "added_file.py")
        self.assertEqual(changed_files[1].old_path, "modified_old.py")
        self.assertEqual(changed_files[1].path, "modified_new.py")

    @patch("migration_lint.source_loader.gitlab.requests.get")
    def test_gitlab_mr_loader(self, mock_get):
        mock_response = MagicMock()
        mock_response.json.return_value = [
            {"old_path": "file1.py", "new_path": "file1.py", "diff": "diff1"},
            {"old_path": "file2.py", "new_path": "file3.py", "diff": "diff2"}
        ]
        mock_get.return_value = mock_response

        loader = GitlabMRLoader(
            mr_id=456,
            project_id=123,
            gitlab_api_key="token",
            gitlab_instance="https://gitlab.example.com"
        )
        changed_files = loader.get_changed_files()

        self.assertEqual(len(changed_files), 2)
        self.assertEqual(changed_files[0].old_path, "file1.py")
        self.assertEqual(changed_files[0].path, "file1.py")
        self.assertEqual(changed_files[1].old_path, "file2.py")
        self.assertEqual(changed_files[1].path, "file3.py")


if __name__ == "__main__":
    unittest.main()