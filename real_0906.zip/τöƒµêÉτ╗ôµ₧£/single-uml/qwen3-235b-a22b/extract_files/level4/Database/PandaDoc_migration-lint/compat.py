# migration_lint/analyzer/compat.py

DOCS_URL = "https://migration-lint.readthedocs.io/en/latest/"

class CompatibilityLinter:
    def lint(self, migration_sql, changed_files, report_restricted):
        """
        Perform SQL migration linting.

        :param migration_sql: Raw SQL of the migration.
        :param changed_files: List of changed files.
        :param report_restricted: Flag to report restricted statements.
        :return: List of linting errors.
        """
        # Placeholder implementation
        return []