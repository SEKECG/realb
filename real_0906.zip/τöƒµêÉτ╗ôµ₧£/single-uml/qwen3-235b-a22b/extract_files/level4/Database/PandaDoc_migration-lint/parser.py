import re
from typing import Sequence, Tuple

from migration_lint.sql.constants import StatementType
from migration_lint.sql.model import SegmentLocator
from migration_lint.sql.operations import find_matching_segment


def classify_migration(raw_sql: str) -> Sequence[Tuple[str, StatementType]]:
    """
    Classify migration statements.

    :param raw_sql: raw SQL to classify
    :return: list of statements with their types
    """
    pass


def classify_statement(statement: str, context: str) -> StatementType:
    """
    Classify an SQL statement using predefined locators.

    :param statement: statement to classify
    :param context: all statements in the same migration
    :return: statement type
    """
    pass