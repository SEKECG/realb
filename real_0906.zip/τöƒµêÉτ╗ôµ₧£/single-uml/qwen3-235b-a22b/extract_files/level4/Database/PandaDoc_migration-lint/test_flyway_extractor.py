import unittest
from unittest.mock import patch, MagicMock

from migration_lint.extractor.flyway import FlywayExtractor
from migration_lint.source_loader.model import SourceDiff
from migration_lint.util.colors import green, red


class TestFlywayExtractor(unittest.TestCase):
    def test_flyway_extractor__ok(self):
        extractor = FlywayExtractor()

        # Test is_migration with valid file
        self.assertTrue(extractor.is_migration("V1_1__create_table.sql"))

        # Test is_migration with invalid file
        self.assertFalse(extractor.is_migration("invalid_file.sql"))

        # Test is_allowed_with_backward_incompatible_migration
        path = "V1_1__create_table.sql"
        self.assertTrue(extractor.is_allowed_with_backward_incompatible_migration(path))

        # Test extract_sql
        migration_path = "test_migration.sql"
        sql_content = "CREATE TABLE test (id INT);"
        with patch("builtins.open", unittest.mock.mock_open(read_data=sql_content)):
            extracted_sql = extractor.extract_sql(migration_path)
            self.assertEqual(extracted_sql, sql_content)

    @patch("os.path.isfile")
    def test_is_migration_file_check(self, mock_isfile):
        extractor = FlywayExtractor()

        # Mock os.path.isfile to return True
        mock_isfile.return_value = True

        # Test valid migration file name
        self.assertTrue(extractor.is_migration("V2_0__add_column.sql"))

        # Test invalid file name format
        self.assertFalse(extractor.is_migration("invalid_name.sql"))

    @patch("builtins.open", new_callable=unittest.mock.mock_open)
    def test_extract_sql_file_read(self, mock_file):
        extractor = FlywayExtractor()
        test_sql = "CREATE TABLE example (id SERIAL PRIMARY KEY);"
        mock_file.return_value.read.return_value = test_sql

        result = extractor.extract_sql("test.sql")
        self.assertEqual(result, test_sql)
        mock_file.assert_called_once_with("test.sql", "r")


if __name__ == "__main__":
    unittest.main()