import os
import subprocess
import sys
from typing import List

from migration_lint.util.env import get_bool_env
from migration_lint.extractor.base import BaseExtractor
from migration_lint.source_loader.base import BaseSourceLoader
from migration_lint.analyzer.base import BaseLinter
from migration_lint.sql.parser import classify_migration


class SquawkLinter(BaseLinter):
    def __init__(self, config_path, pg_version):
        self.config_path = config_path
        self.pg_version = pg_version
        self.ignored_rules = []
        self.squawk = self._get_squawk_binary()

    def _get_squawk_binary(self):
        if sys.platform == "darwin":
            return os.path.join(os.path.dirname(__file__), "bin", "squawk-darwin")
        elif sys.platform == "linux":
            return os.path.join(os.path.dirname(__file__), "bin", "squawk-linux")
        else:
            raise RuntimeError(f"Unsupported platform: {sys.platform}")

    def lint(self, migration_sql, changed_files) -> List[str]:
        cmd = self.squawk_command(migration_sql)
        try:
            result = subprocess.run(
                cmd,
                shell=True,
                check=False,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
            )
            if result.returncode == 0:
                return []
            return result.stdout.strip().splitlines()
        except Exception as e:
            return [f"Error running squawk: {str(e)}"]

    def squawk_command(self, migration_sql) -> str:
        cmd = [self.squawk]
        if self.config_path:
            cmd.extend(["--config", self.config_path])
        if self.pg_version:
            cmd.extend(["--pg-version", str(self.pg_version)])
        if self.ignored_rules:
            for rule in self.ignored_rules:
                cmd.extend(["--ignore", rule])
        cmd.append(migration_sql)
        return " ".join(cmd)


if __name__ == "__main__":
    # Example usage
    pass