from migration_lint.source_loader.base import BaseSourceLoader
from migration_lint.source_loader.model import SourceDiff


class LocalLoader(BaseSourceLoader):
    NAME = "local"

    def get_changed_files(self):
        # Mock implementation for local loader
        # In real implementation, this would read from local stashed files
        return [
            SourceDiff(path="migrations/0001_initial.py"),
            SourceDiff(path="models.py"),
        ]


if __name__ == "__main__":
    loader = LocalLoader()
    for f in loader.get_changed_files():
        print(f.path)