# migration_lint/extractor/raw_sql.py

from migration_lint.source_loader.base import BaseSourceLoader
from migration_lint.extractor.base import BaseExtractor
from dataclasses import dataclass
from typing import List, Optional


class RawSqlExtractor(BaseExtractor):
    """Migrations extractor for SQL files migrations."""

    NAME = "raw_sql"

    def is_allowed_with_backward_incompatible_migration(self, path):
        """Check if the specified file changes are allowed with
        backward-incompatible migrations."""
        # Implementation logic here
        return True  # Placeholder

    def is_migration(self, path):
        """Check if the specified file is a migration."""
        # Implementation logic here
        return path.endswith(".sql")  # Example logic

    def extract_sql(self, migration_path):
        """Extract raw SQL from the migration file."""
        with open(migration_path, "r") as file:
            return file.read()