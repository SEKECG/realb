class Analyzer:
    def __init__(self, loader, extractor, linters):
        self.loader = loader
        self.extractor = extractor
        self.linters = linters

    def analyze(self):
        pass


class BaseLinter:
    def lint(self, migration_sql, changed_files):
        return []