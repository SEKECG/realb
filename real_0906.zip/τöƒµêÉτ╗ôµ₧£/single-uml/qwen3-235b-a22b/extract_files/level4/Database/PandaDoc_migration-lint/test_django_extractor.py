import unittest
from unittest.mock import patch, MagicMock

from migration_lint.extractor.django import DjangoExtractor


class TestDjangoExtractor(unittest.TestCase):
    @patch("migration_lint.extractor.django.os.path.exists")
    @patch("migration_lint.extractor.django.run_command")
    def test_django_extractor__ok(self, mock_run_command, mock_exists):
        # Mock file existence
        mock_exists.return_value = True

        # Mock run_command output
        mock_run_command.return_value = "CREATE TABLE test_table (id INT);"

        # Initialize extractor
        extractor = DjangoExtractor()

        # Test extract_sql
        migration_path = "path/to/migration.py"
        result = extractor.extract_sql(migration_path)

        # Assert SQL extraction
        self.assertIn("CREATE TABLE", result)

        # Test is_migration
        self.assertTrue(extractor.is_migration(migration_path))

        # Test is_allowed_with_backward_incompatible_migration
        self.assertFalse(
            extractor.is_allowed_with_backward_incompatible_migration(
                migration_path
            )
        )


if __name__ == "__main__":
    unittest.main()