import unittest
from unittest.mock import patch, Mock

from migration_lint.main import main
from migration_lint.source_loader.base import BaseSourceLoader
from migration_lint.extractor.base import BaseExtractor
from migration_lint.analyzer.squawk import SquawkLinter


class TestMain(unittest.TestCase):
    @patch("migration_lint.main.SourceLoader")
    @patch("migration_lint.main.Extractor")
    @patch("migration_lint.main.SquawkLinter")
    @patch("migration_lint.main.CompatibilityLinter")
    @patch("migration_lint.main.Analyzer")
    def test_main(
        self,
        mock_analyzer: Mock,
        mock_compatibility_linter: Mock,
        mock_squawk_linter: Mock,
        mock_extractor: Mock,
        mock_source_loader: Mock,
    ):
        # Mock the source loader
        mock_loader_instance = Mock(spec=BaseSourceLoader)
        mock_source_loader.get.return_value = mock_loader_instance

        # Mock the extractor
        mock_extractor_instance = Mock(spec=BaseExtractor)
        mock_extractor.get.return_value = mock_extractor_instance

        # Mock linters
        mock_squawk_instance = Mock(spec=SquawkLinter)
        mock_squawk_linter.return_value = mock_squawk_instance

        # Run main
        main(
            loader_type="local",
            extractor_type="raw_sql",
            squawk_config_path="/path/to/config",
            squawk_pg_version="13",
            kwargs={},
        )

        # Assert calls
        mock_source_loader.get.assert_called_once_with("local")
        mock_extractor.get.assert_called_once_with("raw_sql")

        mock_squawk_linter.assert_called_once_with("/path/to/config", "13")
        mock_compatibility_linter.assert_called_once()

        mock_analyzer.assert_called_once_with(
            loader=mock_loader_instance,
            extractor=mock_extractor_instance,
            linters=[mock_compatibility_linter(), mock_squawk_instance],
        )
        mock_analyzer().analyze.assert_called_once()


if __name__ == "__main__":
    unittest.main()