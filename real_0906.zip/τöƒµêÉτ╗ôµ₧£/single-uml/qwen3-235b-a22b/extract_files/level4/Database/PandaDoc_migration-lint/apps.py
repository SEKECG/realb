from django.apps import AppConfig


class MigrationLintDjangoConfig(AppConfig):
    label = "migration_lint.django"
    name = "migration_lint.django"