import os
import shutil
import pandas as pd
import chromadb
from chromadb.config import Settings
from typing import Any, Dict, List, Tuple, Optional
import gradio as gr
from uuid import uuid4
import requests
import json
import logging
import tempfile
from langchain_community.document_loaders import PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter

# Global variables
status = None
CHAT_FLOW_ID = ""
CHAT_INPUT_COMPONENT = ""
CHROMA_QUERY_COMPONENT = ""
CHROMA_STORE_COMPONENT = ""
CUSTOM_CSS = ""
DEFAULT_CHROMA_PATH = "./chroma_db"
DEFAULT_COLLECTION = "main_collection"
FILE_INPUT_COMPONENT = ""
INGESTION_FLOW_COLLECTION = ""
INGESTION_FLOW_ID = ""
LANGFLOW_API_URL = "http://localhost:7860"
basic_add_metadata_btn = None
basic_clear_selection_btn = None
basic_collection_data = None
basic_delete_entries_btn = None
basic_delete_metadata_btn = None
basic_delete_metadata_category = None
basic_delete_metadata_value = None
basic_export_btn = None
basic_export_file = None
basic_metadata_category = None
basic_metadata_value = None
basic_select_all_btn = None
basic_selected_indices = None
chat_state = None
chatbot = None
clear_btn = None
clear_selection_btn = None
collection_dropdown = None
collection_status = None
context_display = None
current_collection_display = None
current_collection_state = None
current_view_type = None
current_view_value = None
db_path = None
demo = None
existing_fileset_dropdown = None
file_dropdown = None
file_upload = None
fileset_choice = None
fileset_dropdown = None
load_collection_btn = None
load_db_btn = None
load_fileset_btn = None
msg = None
new_fileset_name = None
power_add_metadata_btn = None
power_chunk_display = None
power_chunks_status = None
power_clear_selection_btn = None
power_delete_entries_btn = None
power_delete_metadata_btn = None
power_delete_metadata_category = None
power_delete_metadata_value = None
power_export_btn = None
power_export_file = None
power_file_dropdown = None
power_fileset_dropdown = None
power_load_file_btn = None
power_metadata_category = None
power_metadata_value = None
power_select_all_btn = None
power_selected_indices = None
refresh_btn = None
send_btn = None
tabs = None
upload_btn = None
upload_status = None


def add_metadata(db_path, selected_indices, category, value, df, view_type, view_value, collection_name):
    """Adds metadata to selected chunks and reloads the correct view"""
    try:
        client = chromadb.PersistentClient(path=db_path)
        collection = client.get_collection(name=collection_name)
        
        # Get all documents in the collection
        all_docs = collection.get()
        
        # Create a mapping of document IDs to their index in the collection
        id_to_index = {doc_id: idx for idx, doc_id in enumerate(all_docs['ids'])}
        
        # Prepare metadata updates
        metadatas = []
        ids = []
        
        for idx in selected_indices:
            # Get the document ID from the DataFrame
            doc_id = df.iloc[idx]['id']
            
            if doc_id in id_to_index:
                # Get current metadata
                metadata = all_docs['metadatas'][id_to_index[doc_id]]
                
                # Update metadata
                metadata[category] = value
                
                metadatas.append(metadata)
                ids.append(doc_id)
        
        # Update the collection with new metadata
        if ids:
            collection.update(ids=ids, metadatas=metadatas)
            
        # Reload the view
        if view_type == "file":
            return load_file_chunks(db_path, view_value, collection_name, "source_file")
        elif view_type == "fileset":
            return load_fileset_documents(view_value, collection_name, db_path)
        else:
            return load_collection(collection_name, db_path)
            
    except Exception as e:
        print(f"Error adding metadata: {str(e)}")
        return df, "Error adding metadata"


def check_collection_for_files(db_path, collection_name):
    """Check if a collection has any files (chunks with source_file metadata)"""
    try:
        client = chromadb.PersistentClient(path=db_path)
        collection = client.get_collection(name=collection_name)
        
        # Query for any documents with source_file metadata
        results = collection.get(
            where={"source_file": {"$exists": True}},
            limit=1
        )
        
        if len(results['ids']) > 0:
            return True, None
        else:
            return False, f"Collection '{collection_name}' is empty or contains no files."
            
    except Exception as e:
        return False, f"Error checking collection: {str(e)}"


def delete_entries(db_path, collection_name, selected_indices, df, view_type, view_value):
    """Deletes selected entries and reloads the appropriate view"""
    try:
        client = chromadb.PersistentClient(path=db_path)
        collection = client.get_collection(name=collection_name)
        
        # Get all documents in the collection
        all_docs = collection.get()
        
        # Create a mapping of document IDs to their index in the collection
        id_to_index = {doc_id: idx for idx, doc_id in enumerate(all_docs['ids'])}
        
        # Get IDs of selected documents
        ids_to_delete = []
        for idx in selected_indices:
            # Get the document ID from the DataFrame
            doc_id = df.iloc[idx]['id']
            
            if doc_id in id_to_index:
                ids_to_delete.append(doc_id)
        
        # Delete the documents
        if ids_to_delete:
            collection.delete(ids=ids_to_delete)
            
        # If all documents are deleted, recreate the collection to ensure it's empty
        if len(ids_to_delete) == len(all_docs['ids']):
            client.delete_collection(name=collection_name)
            client.get_or_create_collection(name=collection_name)
            return load_collection(collection_name, db_path)
        
        # Reload the view
        if view_type == "file":
            return load_file_chunks(db_path, view_value, collection_name, "source_file")
        elif view_type == "fileset":
            return load_fileset_documents(view_value, collection_name, db_path)
        else:
            return load_collection(collection_name, db_path)
            
    except Exception as e:
        print(f"Error deleting entries: {str(e)}")
        return df, "Error deleting entries"


def delete_metadata(db_path, selected_indices, category, value, df, view_type, view_value, collection_name):
    """Deletes metadata from selected chunks and reloads the correct view"""
    try:
        client = chromadb.PersistentClient(path=db_path)
        collection = client.get_collection(name=collection_name)
        
        # Get all documents in the collection
        all_docs = collection.get()
        
        # Create a mapping of document IDs to their index in the collection
        id_to_index = {doc_id: idx for idx, doc_id in enumerate(all_docs['ids'])}
        
        # Prepare metadata updates
        metadatas = []
        ids = []
        
        for idx in selected_indices:
            # Get the document ID from the DataFrame
            doc_id = df.iloc[idx]['id']
            
            if doc_id in id_to_index:
                # Get current metadata
                metadata = all_docs['metadatas'][id_to_index[doc_id]]
                
                # Delete metadata category or specific value
                if category in metadata:
                    if value is None or metadata[category] == value:
                        del metadata[category]
                        metadatas.append(metadata)
                        ids.append(doc_id)
        
        # Update the collection with new metadata
        if ids:
            collection.update(ids=ids, metadatas=metadatas)
            
        # Reload the view
        if view_type == "file":
            return load_file_chunks(db_path, view_value, collection_name, "source_file")
        elif view_type == "fileset":
            return load_fileset_documents(view_value, collection_name, db_path)
        else:
            return load_collection(collection_name, db_path)
            
    except Exception as e:
        print(f"Error deleting metadata: {str(e)}")
        return df, "Error deleting metadata"


def export_selected_chunks(selected_indices, df):
    """Create file for download"""
    try:
        # Create a temporary directory
        temp_dir = tempfile.mkdtemp()
        temp_file = os.path.join(temp_dir, "selected_chunks.xlsx")
        
        # Filter the dataframe to selected rows
        selected_df = df.iloc[selected_indices]
        
        # Export to Excel
        selected_df.to_excel(temp_file, index=False)
        
        return temp_file
        
    except Exception as e:
        print(f"Error exporting chunks: {str(e)}")
        return None


def get_filesets(db_path, collection_name):
    """Get unique filesets from a specific collection"""
    try:
        client = chromadb.PersistentClient(path=db_path)
        collection = client.get_collection(name=collection_name)
        
        # Get all documents in the collection
        results = collection.get(where={"fileset": {"$exists": True}})
        
        # Extract unique filesets
        filesets = list(set([metadata["fileset"] for metadata in results["metadatas"]]))
        
        return sorted(filesets)
        
    except Exception as e:
        print(f"Error getting filesets: {str(e)}")
        return []


def get_unique_filenames(db_path, collection_name):
    """Get unique filenames from a specific collection"""
    try:
        client = chromadb.PersistentClient(path=db_path)
        collection = client.get_collection(name=collection_name)
        
        # Get all documents in the collection
        results = collection.get(where={"source_file": {"$exists": True}})
        
        # Extract unique filenames
        filenames = list(set([metadata["source_file"] for metadata in results["metadatas"]]))
        
        return sorted(filenames)
        
    except Exception as e:
        print(f"Error getting filenames: {str(e)}")
        return []


def handle_chat_with_selection(message, history, selected_file, selected_fileset):
    """Enhanced chat handler with improved logging and request tracking"""
    try:
        # Prepare request data
        data = {
            "input": {
                "message": message,
                "session_id": str(uuid4()),
                "selected_file": selected_file,
                "selected_fileset": selected_fileset
            }
        }
        
        # Send request to Langflow API
        response = requests.post(
            f"{LANGFLOW_API_URL}/run/{CHAT_FLOW_ID}",
            json=data,
            headers={"Content-Type": "application/json"}
        )
        
        # Process response
        if response.status_code == 200:
            result = response.json()
            answer = result.get("output", {}).get("message", "No response from the model")
            
            # Update chat history
            new_history = history + [(message, answer)]
            
            return answer, new_history, result.get("context", "")
        else:
            error_msg = f"Error: API returned status code {response.status_code}"
            print(error_msg)
            return error_msg, history, ""
            
    except Exception as e:
        error_msg = f"Error during chat: {str(e)}"
        print(error_msg)
        return error_msg, history, ""


def handle_clear_selection(df):
    """Clears all selections in the dataframe"""
    try:
        # Reset selection state
        if 'selected' in df.columns:
            df['selected'] = 'Not Selected'
        return df
    except Exception as e:
        print(f"Error clearing selection: {str(e)}")
        return df


def handle_collection_file_check(collection_name, db_path):
    """Secondary handler to check for files in collection and show warning if needed"""
    has_files, message = check_collection_for_files(db_path, collection_name)
    if message:
        show_toast(message)
    return has_files, message


def handle_export_with_notification(indices, df):
    """Handle export and show user-facing notification"""
    file_path = export_selected_chunks(indices, df)
    if file_path:
        show_toast(f"Exported {len(indices)} chunks to {file_path}")
        return file_path
    else:
        show_toast("Error exporting chunks")
        return None


def handle_file_clear():
    """Hide file component when cleared"""
    return gr.update(visible=False)


def handle_file_upload(file_obj, choice, new_name, existing_name):
    """Handle file upload to the main collection with optional fileset organization"""
    try:
        # Determine fileset name based on user choice
        if choice == "Create a New File Set":
            fileset_name = new_name
        elif choice == "Add to Existing File Set":
            fileset_name = existing_name
        else:  # No File Set
            fileset_name = None
            
        # Process the file
        result = process_file(file_obj, fileset_name)
        
        # Return updated file and fileset dropdowns
        return result
            
    except Exception as e:
        print(f"Error handling file upload: {str(e)}")
        return "Error uploading file", gr.update(), gr.update()


def handle_select(evt, state, df):
    """Handles individual row selection events"""
    try:
        # Get selected row index
        idx = evt["index"]
        
        # Toggle selection state
        if 'selected' not in df.columns:
            df['selected'] = 'Not Selected'
            
        df.at[idx, 'selected'] = 'Selected' if df.at[idx, 'selected'] == 'Not Selected' else 'Not Selected'
        
        return df
        
    except Exception as e:
        print(f"Error handling selection: {str(e)}")
        return df


def handle_select_all(df):
    """Selects all rows in the dataframe"""
    try:
        if 'selected' not in df.columns:
            df['selected'] = 'Not Selected'
            
        df['selected'] = 'Selected'
        return df
        
    except Exception as e:
        print(f"Error selecting all: {str(e)}")
        return df


def initialize_database(db_path):
    """Initialize the database with the main collection if it doesn't exist."""
    try:
        # Create database directory if it doesn't exist
        if not os.path.exists(db_path):
            os.makedirs(db_path)
            
        # Initialize database connection
        client = chromadb.PersistentClient(path=db_path)
        
        # Create default collection if it doesn't exist
        if DEFAULT_COLLECTION not in [col.name for col in client.list_collections()]:
            client.create_collection(name=DEFAULT_COLLECTION)
            
        return True, "Database initialized successfully"
        
    except Exception as e:
        return False, f"Error initializing database: {str(e)}"


def load_collection(collection_name, db_path):
    """Loads a collection and returns its contents as a DataFrame with complete metadata"""
    try:
        # Connect to database
        client = chromadb.PersistentClient(path=db_path)
        
        # Get collection
        collection = client.get_collection(name=collection_name)
        
        # Get all items in the collection
        results = collection.get(include=["metadatas", "documents"])
        
        # Create DataFrame
        df = pd.DataFrame({
            "id": results["ids"],
            "content": results["documents"],
            "metadata": results["metadatas"]
        })
        
        # Expand metadata into separate columns
        metadata_df = pd.json_normalize(df["metadata"])
        df = pd.concat([df.drop(columns=["metadata"]), metadata_df], axis=1)
        
        # Add selection column
        df["selected"] = "Not Selected"
        
        return df
        
    except Exception as e:
        print(f"Error loading collection: {str(e)}")
        return pd.DataFrame(columns=["id", "content", "selected"])


def load_database(db_path):
    """Initialize database connection with single toast notification"""
    try:
        # Check if database exists
        if not os.path.exists(db_path):
            os.makedirs(db_path)
            
        # Try to connect to the database
        client = chromadb.PersistentClient(path=db_path)
        
        # Test the connection by listing collections
        collections = client.list_collections()
        
        return True, f"Connected to database at {db_path}"
        
    except Exception as e:
        return False, f"Error connecting to database: {str(e)}"


def load_file_chunks(db_path, filename, collection_name, key):
    """Load chunks from a file with improved error handling and debugging"""
    try:
        # Connect to database
        client = chromadb.PersistentClient(path=db_path)
        
        # Get collection
        collection = client.get_collection(name=collection_name)
        
        # Query for chunks from the specified file
        results = collection.get(
            where={key: filename},
            include=["metadatas", "documents", "ids"]
        )
        
        if not results["ids"]:
            return pd.DataFrame(), f"No chunks found for {key}: {filename}"
            
        # Create DataFrame
        df = pd.DataFrame({
            "id": results["ids"],
            "content": results["documents"],
            "metadata": results["metadatas"]
        })
        
        # Expand metadata into separate columns
        metadata_df = pd.json_normalize(df["metadata"])
        df = pd.concat([df.drop(columns=["metadata"]), metadata_df], axis=1)
        
        # Add selection column
        df["selected"] = "Not Selected"
        
        return df, f"Loaded {len(results['ids'])} chunks from {filename}"
        
    except Exception as e:
        error_msg = f"Error loading chunks from {filename}: {str(e)}"
        print(error_msg)
        return pd.DataFrame(), error_msg


def load_fileset_documents(fileset_name, collection_name, db_path):
    """Load fileset documents using client-side filtering with pipe-separated format"""
    try:
        # Connect to database
        client = chromadb.PersistentClient(path=db_path)
        
        # Get collection
        collection = client.get_collection(name=collection_name)
        
        # Get all documents
        results = collection.get(include=["metadatas", "documents", "ids"])
        
        # Filter documents by fileset on the client side
        filtered_ids = []
        filtered_docs = []
        filtered_metadata = []
        
        for i, metadata in enumerate(results["metadatas"]):
            if metadata.get("fileset") == fileset_name:
                filtered_ids.append(results["ids"][i])
                filtered_docs.append(results["documents"][i])
                filtered_metadata.append(metadata)
        
        if not filtered_ids:
            return pd.DataFrame(), f"No documents found for fileset: {fileset_name}"
            
        # Create DataFrame
        df = pd.DataFrame({
            "id": filtered_ids,
            "content": filtered_docs,
            "metadata": filtered_metadata
        })
        
        # Expand metadata into separate columns
        metadata_df = pd.json_normalize(df["metadata"])
        df = pd.concat([df.drop(columns=["metadata"]), metadata_df], axis=1)
        
        # Add selection column
        df["selected"] = "Not Selected"
        
        return df, f"Loaded {len(filtered_ids)} documents from fileset {fileset_name}"
        
    except Exception as e:
        error_msg = f"Error loading fileset documents: {str(e)}"
        print(error_msg)
        return pd.DataFrame(), error_msg


def process_file(file_obj, fileset_name):
    """Send file to Langflow's ingestion pipeline"""
    try:
        # Create a temporary directory to store the uploaded file
        temp_dir = tempfile.mkdtemp()
        temp_file_path = os.path.join(temp_dir, os.path.basename(file_obj.name))
        
        # Save the uploaded file to the temporary directory
        with open(temp_file_path, "wb") as f:
            f.write(file_obj.read())
        
        # Prepare the request data
        data = {
            "flow_id": INGESTION_FLOW_ID,
            "inputs": [{
                FILE_INPUT_COMPONENT: temp_file_path
            }]
        }
        
        # If fileset name is provided, add it to the metadata
        if fileset_name:
            data["inputs"][0]["fileset"] = fileset_name
        
        # Send the request to Langflow
        response = requests.post(
            f"{LANGFLOW_API_URL}/run",
            json=data,
            headers={"Content-Type": "application/json"}
        )
        
        # Check the response
        if response.status_code == 200:
            result = response.json()
            message = result.get("message", "File processed successfully")
            
            # Update file and fileset dropdowns
            files = refresh_dropdowns()
            
            return message, gr.update(choices=files), gr.update(choices=get_filesets(DEFAULT_CHROMA_PATH, DEFAULT_COLLECTION))
        else:
            error_msg = f"Error processing file: {response.text}"
            return error_msg, gr.update(), gr.update()
            
    except Exception as e:
        error_msg = f"Error processing file: {str(e)}"
        return error_msg, gr.update(), gr.update()


def refresh_all_filesets(db_path, collection_name):
    """Refresh and update the available fileset choices in a ChromaDB collection"""
    try:
        # Get updated filesets
        filesets = get_filesets(db_path, collection_name)
        
        # Update the fileset dropdown
        return gr.update(choices=filesets)
        
    except Exception as e:
        print(f"Error refreshing filesets: {str(e)}")
        return gr.update()


def refresh_dropdowns():
    """Update the choices in dropdown menus with the latest unique filenames"""
    try:
        # Get updated filenames
        files = get_unique_filenames(DEFAULT_CHROMA_PATH, DEFAULT_COLLECTION)
        
        return files
        
    except Exception as e:
        print(f"Error refreshing dropdowns: {str(e)}")
        return []


def show_toast(message):
    """Convert status messages to appropriate toast notifications"""
    print(f"Toast: {message}")


def try_connect_db(path):
    """Attempt to connect to database with timeout"""
    try:
        # Try to connect to the database
        client = chromadb.PersistentClient(path=path)
        
        # Test the connection by listing collections
        collections = client.list_collections()
        
        return True, f"Connected to database at {path}"
        
    except Exception as e:
        return False, f"Error connecting to database: {str(e)}"


def update_collection_state(collection_name):
    """Update all components when collection selection changes"""
    try:
        # Load the collection data
        df = load_collection(collection_name, DEFAULT_CHROMA_PATH)
        
        # Update file and fileset dropdowns
        files = refresh_dropdowns()
        filesets = refresh_all_filesets(DEFAULT_CHROMA_PATH, collection_name)
        
        return df, gr.update(choices=files), gr.update(choices=filesets)
        
    except Exception as e:
        print(f"Error updating collection state: {str(e)}")
        return pd.DataFrame(), gr.update(), gr.update()


def update_file_dropdown(file_val, fileset_val):
    """Prevent circular updates between dropdowns"""
    return gr.update(), gr.update()


def update_fileset_inputs(choice):
    """Update the visibility and options of UI elements based on the user's choice regarding file set operations"""
    try:
        if choice == "Create a New File Set":
            return gr.update(visible=True), gr.update(visible=False)
        elif choice == "Add to Existing File Set":
            filesets = get_filesets(DEFAULT_CHROMA_PATH, DEFAULT_COLLECTION)
            return gr.update(visible=False), gr.update(visible=True, choices=filesets)
        else:  # No File Set
            return gr.update(visible=False), gr.update(visible=False)
            
    except Exception as e:
        print(f"Error updating fileset inputs: {str(e)}")
        return gr.update(), gr.update()


def update_selection_state(indices, df):
    """Updates the selection state in the dataframe with 'Selected' or 'Not Selected' instead of True/False"""
    try:
        if 'selected' not in df.columns:
            df['selected'] = 'Not Selected'
            
        # Reset all selections
        df['selected'] = 'Not Selected'
        
        # Set selected rows
        df.loc[indices, 'selected'] = 'Selected'
        
        return df
        
    except Exception as e:
        print(f"Error updating selection state: {str(e)}")
        return df


# Main application setup
if __name__ == "__main__":
    # Initialize the database
    initialize_database(DEFAULT_CHROMA_PATH)
    
    # Create Gradio interface
    with gr.Blocks(css=CUSTOM_CSS, title="Chroma Auditor") as demo:
        # Database path
        db_path = gr.State(DEFAULT_CHROMA_PATH)
        
        # Collection state
        current_collection_state = gr.State(DEFAULT_COLLECTION)
        current_view_type = gr.State("")
        current_view_value = gr.State("")
        
        # Main interface
        with gr.Tab("Chroma Auditor"):
            # Collection selection
            collection_dropdown = gr.Dropdown(
                choices=[col.name for col in chromadb.PersistentClient(path=DEFAULT_CHROMA_PATH).list_collections()],
                value=DEFAULT_COLLECTION,
                label="Select Collection"
            )
            
            # Status message
            collection_status = gr.Textbox(label="Status", interactive=False)
            
            # Dataframe display
            current_collection_display = gr.DataFrame(label="Collection Contents")
            
            # View type and value
            view_type = gr.State("")
            view_value = gr.State("")
            
            # Load collection button
            load_collection_btn = gr.Button("Load Collection")
            
            # Event handlers
            collection_dropdown.change(
                fn=update_collection_state,
                inputs=[collection_dropdown],
                outputs=[current_collection_display, file_dropdown, fileset_dropdown]
            )
            
            load_collection_btn.click(
                fn=load_collection,
                inputs=[collection_dropdown, db_path],
                outputs=[current_collection_display]
            )
    
    # Launch the app
    demo.launch()