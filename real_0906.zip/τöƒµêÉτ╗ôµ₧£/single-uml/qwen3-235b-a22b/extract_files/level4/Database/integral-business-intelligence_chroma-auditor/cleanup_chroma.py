import os
import shutil
import logging
import getpass
import chromadb
from chromadb.config import Settings
from typing import List, Dict, Tuple, Optional
import uuid


class ChromaCollectionManager:
    """Manage ChromaDB collections including creation, deletion, listing, and handling of associated UUID directories and orphaned data."""

    def __init__(self, persist_directory: str):
        """Initialize a persistent ChromaDB client with a specified storage directory and configure logging."""
        self.persist_directory = persist_directory
        self.logger = self._setup_logger()
        self.client = self._initialize_client()

    def _setup_logger(self):
        """Set up logging configuration"""
        logger = logging.getLogger('ChromaCollectionManager')
        logger.setLevel(logging.INFO)
        
        # Create console handler
        ch = logging.StreamHandler()
        ch.setLevel(logging.INFO)
        
        # Create formatter
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        ch.setFormatter(formatter)
        
        # Add handler to logger
        logger.addHandler(ch)
        return logger

    def _initialize_client(self):
        """Initialize the ChromaDB client with persistent settings"""
        try:
            self.logger.info(f"Initializing ChromaDB client with persistence directory: {self.persist_directory}")
            
            # Create the persistence directory if it doesn't exist
            os.makedirs(self.persist_directory, exist_ok=True)
            
            # Initialize the client with persistent settings
            client = chromadb.Client(Settings(
                chroma_db_impl="duckdb+parquet",
                persist_directory=self.persist_directory,
                anonymized_telemetry=False
            ))
            
            return client
        except Exception as e:
            self.logger.error(f"Failed to initialize ChromaDB client: {str(e)}")
            raise

    def _get_all_uuid_directories(self) -> List[str]:
        """Get all UUID-like directories in the persistence path."""
        if not os.path.exists(self.persist_directory):
            self.logger.warning(f"Persist directory does not exist: {self.persist_directory}")
            return []

        try:
            all_items = os.listdir(self.persist_directory)
            uuid_dirs = [item for item in all_items if self._is_uuid_directory(item)]
            self.logger.debug(f"Found {len(uuid_dirs)} UUID directories")
            return uuid_dirs
        except Exception as e:
            self.logger.error(f"Error listing UUID directories: {str(e)}")
            return []

    def _is_uuid_directory(self, directory_name: str) -> bool:
        """Check if a directory name matches UUID format"""
        try:
            # Try to parse as UUID
            uuid_obj = uuid.UUID(directory_name)
            # Check if it's a directory and matches UUID version 4
            full_path = os.path.join(self.persist_directory, directory_name)
            return os.path.isdir(full_path) and str(uuid_obj) == directory_name
        except ValueError:
            return False

    def _get_collection_uuid_mapping(self) -> Dict[str, str]:
        """Get mapping between collection names and their UUID directories."""
        try:
            collections = self.list_collections()
            uuid_dirs = self._get_all_uuid_directories()
            
            # Get all collection UUIDs
            collection_uuids = {}
            for collection_name in collections:
                try:
                    collection = self.client.get_collection(collection_name)
                    # Get the UUID from the collection (this is a workaround as ChromaDB doesn't directly expose UUIDs)
                    # In a real implementation, you might need to store this mapping separately
                    collection_uuids[collection_name] = self._find_matching_uuid_dir(collection_name, uuid_dirs)
                except Exception as e:
                    self.logger.warning(f"Error getting UUID for collection {collection_name}: {str(e)}")
            
            return collection_uuids
        except Exception as e:
            self.logger.error(f"Error creating collection-UUID mapping: {str(e)}")
            return {}

    def _find_matching_uuid_dir(self, collection_name: str, uuid_dirs: List[str]) -> Optional[str]:
        """Try to find the UUID directory that corresponds to a collection"""
        # This is a placeholder implementation
        # In a real scenario, you would need to implement logic to associate
        # collections with their UUID directories, perhaps by storing metadata
        # when creating collections
        self.logger.warning("Collection to UUID mapping is not fully implemented")
        return None

    def create_collection(self, collection_name: str) -> bool:
        """Create a new empty collection."""
        try:
            self.logger.info(f"Creating collection: {collection_name}")
            
            # Check if collection already exists
            existing_collections = self.list_collections()
            if collection_name in existing_collections:
                self.logger.warning(f"Collection '{collection_name}' already exists")
                return False
            
            # Create new collection
            self.client.create_collection(collection_name)
            
            self.logger.info(f"Successfully created collection: {collection_name}")
            return True
        except Exception as e:
            self.logger.error(f"Failed to create collection {collection_name}: {str(e)}")
            return False

    def delete_collection(self, collection_name: str) -> bool:
        """Delete a specific collection including its UUID directory."""
        try:
            self.logger.info(f"Deleting collection: {collection_name}")
            
            # Check if collection exists
            existing_collections = self.list_collections()
            if collection_name not in existing_collections:
                self.logger.warning(f"Collection '{collection_name}' does not exist")
                return False
            
            # Delete the collection
            self.client.delete_collection(collection_name)
            
            self.logger.info(f"Successfully deleted collection: {collection_name}")
            return True
        except Exception as e:
            self.logger.error(f"Failed to delete collection {collection_name}: {str(e)}")
            return False

    def delete_collections(self, collection_names: List[str]) -> dict:
        """Delete multiple collections and return results."""
        results = {
            "success": [],
            "failed": [],
            "total": len(collection_names)
        }
        
        for collection_name in collection_names:
            success = self.delete_collection(collection_name)
            if success:
                results["success"].append(collection_name)
            else:
                results["failed"].append(collection_name)
        
        return results

    def delete_orphaned_uuid_dirs(self) -> Tuple[int, List[str]]:
        """Delete orphaned UUID directories."""
        try:
            self.logger.info("Deleting orphaned UUID directories")
            
            # Get all UUID directories
            uuid_dirs = self._get_all_uuid_directories()
            if not uuid_dirs:
                self.logger.info("No UUID directories found")
                return 0, []
            
            # Get all collection names
            collection_names = self.list_collections()
            
            # Get mapping of collections to their UUIDs
            collection_uuids = self._get_collection_uuid_mapping()
            
            # Find orphaned directories
            orphaned_dirs = []
            for uuid_dir in uuid_dirs:
                # Check if this UUID is associated with any collection
                is_orphaned = True
                for collection_name, uuid in collection_uuids.items():
                    if uuid_dir == uuid:
                        is_orphaned = False
                        break
                
                if is_orphaned:
                    orphaned_dirs.append(uuid_dir)
            
            self.logger.info(f"Found {len(orphaned_dirs)} orphaned UUID directories")
            
            # Delete orphaned directories
            deleted_count = 0
            for dir_name in orphaned_dirs:
                dir_path = os.path.join(self.persist_directory, dir_name)
                try:
                    shutil.rmtree(dir_path)
                    self.logger.info(f"Deleted orphaned directory: {dir_path}")
                    deleted_count += 1
                except Exception as e:
                    self.logger.error(f"Failed to delete orphaned directory {dir_path}: {str(e)}")
            
            return deleted_count, orphaned_dirs
        except Exception as e:
            self.logger.error(f"Error deleting orphaned UUID directories: {str(e)}")
            return 0, []

    def get_collection_info(self, collection_name: str) -> dict:
        """Get detailed information about a specific collection."""
        try:
            self.logger.info(f"Getting info for collection: {collection_name}")
            
            # Check if collection exists
            existing_collections = self.list_collections()
            if collection_name not in existing_collections:
                self.logger.warning(f"Collection '{collection_name}' does not exist")
                return {"error": "Collection does not exist"}
            
            # Get collection
            collection = self.client.get_collection(collection_name)
            
            # Get collection metadata
            info = {
                "name": collection_name,
                "id": str(collection.id) if hasattr(collection, "id") else "N/A",
                "metadata": collection.metadata if hasattr(collection, "metadata") else {},
                "number_of_embeddings": collection.count() if hasattr(collection, "count") else 0,
                "uuid": self._get_collection_uuid(collection_name),
                "created_at": "N/A",  # Not directly available in ChromaDB API
                "last_modified": "N/A"  # Not directly available in ChromaDB API
            }
            
            return info
        except Exception as e:
            self.logger.error(f"Error getting info for collection {collection_name}: {str(e)}")
            return {"error": str(e)}

    def _get_collection_uuid(self, collection_name: str) -> Optional[str]:
        """Get the UUID for a collection"""
        # This is a placeholder implementation
        # In a real scenario, you would need to implement logic to associate
        # collections with their UUIDs, perhaps by storing metadata
        self.logger.warning("Collection UUID retrieval is not fully implemented")
        return None

    def list_collections(self) -> List[str]:
        """List all available collections."""
        try:
            self.logger.info("Listing all collections")
            
            # Get all collections from ChromaDB
            collections = self.client.list_collections()
            
            # Extract just the names
            collection_names = [collection.name for collection in collections]
            
            self.logger.info(f"Found {len(collection_names)} collections")
            return collection_names
        except Exception as e:
            self.logger.error(f"Error listing collections: {str(e)}")
            return []

    def list_collections_with_uuids(self) -> Tuple[List[Dict], List[str]]:
        """List all collections with their UUID directories.
        Also returns a list of orphaned UUID directories."""
        try:
            self.logger.info("Listing collections with UUIDs")
            
            # Get all collections
            collection_names = self.list_collections()
            
            # Get all UUID directories
            uuid_dirs = self._get_all_uuid_directories()
            
            # Get mapping of collections to UUIDs
            collection_uuids = self._get_collection_uuid_mapping()
            
            # Build collection info list
            collection_info_list = []
            for collection_name in collection_names:
                collection_info = {
                    "name": collection_name,
                    "uuid": collection_uuids.get(collection_name, "Unknown")
                }
                collection_info_list.append(collection_info)
            
            # Find orphaned directories
            orphaned_dirs = []
            for uuid_dir in uuid_dirs:
                is_orphaned = True
                for collection_info in collection_info_list:
                    if collection_info["uuid"] == uuid_dir:
                        is_orphaned = False
                        break
                
                if is_orphaned:
                    orphaned_dirs.append(uuid_dir)
            
            return collection_info_list, orphaned_dirs
        except Exception as e:
            self.logger.error(f"Error listing collections with UUIDs: {str(e)}")
            return [], []


def main():
    """Provide an interactive command-line interface for managing Chroma collections, including listing, creating, deleting collections, and cleaning up orphaned UUID directories."""
    print("Welcome to Chroma Collection Manager")
    print("------------------------------------")
    
    # Get persist directory from user input
    persist_directory = input("Enter the path to your ChromaDB persistence directory (default: ./chroma_data): ").strip()
    if not persist_directory:
        persist_directory = "./chroma_data"
    
    # Create manager instance
    manager = ChromaCollectionManager(persist_directory)
    
    while True:
        print("\nMenu:")
        print("1. List collections")
        print("2. Create collection")
        print("3. Delete collection")
        print("4. Delete multiple collections")
        print("5. Get collection info")
        print("6. List collections with UUIDs")
        print("7. Delete orphaned UUID directories")
        print("8. Exit")
        
        choice = input("\nEnter your choice (1-8): ").strip()
        
        if choice == "1":
            collections = manager.list_collections()
            print("\nAvailable collections:")
            for collection in collections:
                print(f"- {collection}")
                
        elif choice == "2":
            collection_name = input("Enter collection name: ").strip()
            if collection_name:
                success = manager.create_collection(collection_name)
                if success:
                    print(f"Collection '{collection_name}' created successfully")
                else:
                    print(f"Failed to create collection '{collection_name}'")
            else:
                print("Collection name cannot be empty")
                
        elif choice == "3":
            collection_name = input("Enter collection name to delete: ").strip()
            if collection_name:
                confirm = input(f"Are you sure you want to delete collection '{collection_name}'? (y/n): ").strip().lower()
                if confirm == "y":
                    success = manager.delete_collection(collection_name)
                    if success:
                        print(f"Collection '{collection_name}' deleted successfully")
                    else:
                        print(f"Failed to delete collection '{collection_name}'")
                else:
                    print("Deletion cancelled")
            else:
                print("Collection name cannot be empty")
                
        elif choice == "4":
            print("Enter collection names to delete (one per line, empty line to finish):")
            collection_names = []
            while True:
                name = input().strip()
                if not name:
                    break
                collection_names.append(name)
            
            if collection_names:
                confirm = input(f"Are you sure you want to delete {len(collection_names)} collections? (y/n): ").strip().lower()
                if confirm == "y":
                    results = manager.delete_collections(collection_names)
                    print(f"\nSuccessfully deleted {len(results['success'])} collections:")
                    for name in results['success']:
                        print(f"- {name}")
                    
                    if results['failed']:
                        print("\nFailed to delete the following collections:")
                        for name in results['failed']:
                            print(f"- {name}")
                else:
                    print("Deletion cancelled")
            else:
                print("No collection names entered")
                
        elif choice == "5":
            collection_name = input("Enter collection name: ").strip()
            if collection_name:
                info = manager.get_collection_info(collection_name)
                if "error" in info:
                    print(f"Error: {info['error']}")
                else:
                    print(f"\nInformation for collection '{collection_name}':")
                    for key, value in info.items():
                        print(f"{key}: {value}")
            else:
                print("Collection name cannot be empty")
                
        elif choice == "6":
            collections, orphaned = manager.list_collections_with_uuids()
            print("\nCollections with UUIDs:")
            for collection in collections:
                print(f"- {collection['name']} (UUID: {collection['uuid']})")
            
            if orphaned:
                print("\nOrphaned UUID directories:")
                for uuid_dir in orphaned:
                    print(f"- {uuid_dir}")
                
        elif choice == "7":
            confirm = input("Are you sure you want to delete orphaned UUID directories? (y/n): ").strip().lower()
            if confirm == "y":
                count, dirs = manager.delete_orphaned_uuid_dirs()
                print(f"\nDeleted {count} orphaned directories:")
                for dir_name in dirs:
                    print(f"- {dir_name}")
            else:
                print("Deletion cancelled")
                
        elif choice == "8":
            print("Exiting Chroma Collection Manager")
            break
            
        else:
            print("Invalid choice. Please enter a number between 1 and 8.")


if __name__ == "__main__":
    main()