import os

BASE_DIR = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
CURRENT_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.path.join(BASE_DIR, 'data', 'cpc.db')
MEXC_HOST = 'https://api.mexc.com'