import sqlite3
from typing import Optional, Dict, List

from cpc.common.config import DB_PATH
from cpc.database.dml.user import USER_SQL
from cpc.repositories.asset import ASSET_REPOSITORIES
from cpc.repositories.favorite import FAVORITE_REPOSITORIES


class USER_REPOSITORIES:
    def __init__(self, conn):
        self.conn = conn
        self.cursor = conn.cursor()

    def create_default_user(self):
        user_sql = USER_SQL()
        self.cursor.execute("INSERT INTO user (name, target) VALUES (?, ?)", ("default", 1))
        self.conn.commit()
        return self.cursor.lastrowid

    def create_user(self, name, target=0):
        user_sql = USER_SQL()
        self.cursor.execute("INSERT INTO user (name, target) VALUES (?, ?)", (name, target))
        self.conn.commit()
        return self.cursor.lastrowid

    def get_user(self):
        self.cursor.execute("SELECT * FROM user WHERE target = 1 LIMIT 1")
        user = self.cursor.fetchone()
        if not user:
            return None

        user_id = user['id']
        favorites = FAVORITE_REPOSITORIES(self.conn).get_favorites(user_id)
        assets = ASSET_REPOSITORIES(self.conn).get_assets(user_id)

        return {
            'id': user['id'],
            'name': user['name'],
            'favorites': favorites,
            'assets': assets
        }

    def get_users(self):
        self.cursor.execute("SELECT id, name, target FROM user")
        return self.cursor.fetchall()

    def remove_user(self, user_id):
        self.cursor.execute("DELETE FROM user WHERE id = ?", (user_id,))
        self.conn.commit()

    def switch_user(self, user_id):
        self._remove_all_target()
        self.cursor.execute("UPDATE user SET target = 1 WHERE id = ?", (user_id,))
        self.conn.commit()

    def update_user(self, user_id, name):
        if name:
            self.cursor.execute("UPDATE user SET name = ? WHERE id = ?", (name, user_id))
            self.conn.commit()

    def _auto_choose_user(self):
        self.cursor.execute("SELECT id FROM user LIMIT 1")
        result = self.cursor.fetchone()
        if result:
            self.cursor.execute("UPDATE user SET target = 1 WHERE id = ?", (result['id'],))
            self.conn.commit()

    def _auto_switch_user(self):
        self._remove_all_target()
        self._auto_choose_user()

    def _is_user_target(self):
        self.cursor.execute("SELECT COUNT(*) as count FROM user WHERE target = 1")
        result = self.cursor.fetchone()
        return result['count'] == 1

    def _remove_all_target(self):
        self.cursor.execute("UPDATE user SET target = 0 WHERE target = 1")
        self.conn.commit()


class USER_SERVICE:
    def __init__(self, conn):
        self.repository = USER_REPOSITORIES(conn)

    def create_default_user(self):
        return self.repository.create_default_user()

    def create_user(self, name):
        return self.repository.create_user(name)

    def get_position_ratio(self, sort, reverse, pie):
        pass  # Implementation would calculate asset ratios

    def get_user(self, print_table):
        return self.repository.get_user()

    def get_users(self):
        return self.repository.get_users()

    def remove_user(self, user_id):
        return self.repository.remove_user(user_id)

    def switch_user(self, user_id):
        return self.repository.switch_user(user_id)

    def update_user(self, user_id, name):
        return self.repository.update_user(user_id, name)