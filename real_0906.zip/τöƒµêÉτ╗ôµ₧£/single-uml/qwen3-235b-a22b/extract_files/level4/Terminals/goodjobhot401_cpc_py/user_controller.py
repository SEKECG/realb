from typing import Any, Optional
from src.cpc.services.user import USER_SERVICE
from src.cpc.repositories.user import USER_REPOSITORIES
from src.cpc.middlewares.db_connect import db_connection


class USER:
    def __init__(self):
        self.user_service = USER_SERVICE(self._get_user_repository())

    def _get_user_repository(self) -> USER_REPOSITORIES:
        """Get a new user repository instance."""
        return USER_REPOSITORIES(self._get_db_connection())

    def _get_db_connection(self):
        """Get a database connection."""
        @db_connection
        def connect(func):
            return func
        return connect

    def get_user(self, print_table: bool = True) -> Optional[dict]:
        """Get the current user's information."""
        return self.user_service.get_user(print_table)

    def get_users(self) -> list:
        """Get all users in the system."""
        return self.user_service.get_users()

    def create_user(self, name: str) -> dict:
        """Create a new user with the given name."""
        return self.user_service.create_user(name)

    def switch_user(self, user_id: int) -> bool:
        """Switch the current context to the specified user."""
        return self.user_service.switch_user(user_id)

    def update_user(self, user_id: int, name: str) -> bool:
        """Update the name of a user with the given ID."""
        return self.user_service.update_user(user_id, name)

    def remove_user(self, user_id: int) -> bool:
        """Remove a user with the specified ID."""
        return self.user_service.remove_user(user_id)

    def get_position_ratio(self, sort: str = 'value', reverse: bool = False) -> list:
        """Get the portfolio position ratio for the current user."""
        return self.user_service.get_position_ratio(sort, reverse)

    def create_default_user(self) -> dict:
        """Create a default user if one doesn't exist."""
        return self.user_service.create_default_user()