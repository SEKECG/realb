import os
import sys
from typing import Any

# Add the project root directory to the Python path
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
sys.path.append(project_root)

from src.cpc.services.price import PRICE_SERVICE
from src.cpc.middlewares.db_connect import db_connection
from src.cpc.repositories.user import USER_REPOSITORIES
from src.cpc.helpers.mexc import mexc_market


class PRICE:
    def __init__(self):
        self.price_service = PRICE_SERVICE()
        self.mexc_api = mexc_market()

    def get_price_detail(self, symbols: Any) -> None:
        """
        Retrieve detailed price information for the given stock symbols using a price service.
        
        Args:
            symbols: A list of cryptocurrency symbols to fetch price details for
            
        Returns:
            None
        """
        if not symbols:
            print("No symbols provided to fetch price details.")
            return

        # Fetch price details from the service
        try:
            price_details = self.price_service.get_price_detail(symbols)
            if price_details:
                self._display_price_details(price_details)
            else:
                print("Failed to retrieve price details.")
        except Exception as e:
            print(f"Error fetching price details: {e}")

    def _display_price_details(self, price_details: dict) -> None:
        """
        Display the retrieved price details in a user-friendly format.
        
        Args:
            price_details: A dictionary containing price information for symbols
            
        Returns:
            None
        """
        # Implementation for displaying price details
        # This would typically use rich or similar library for formatted output
        print("Price Details:")
        for symbol, details in price_details.items():
            print(f"{symbol}: {details}")


if __name__ == "__main__":
    # Example usage
    price_controller = PRICE()
    
    # Example: Get price details for BTCUSDT and ETHUSDT
    price_controller.get_price_detail(["BTCUSDT", "ETHUSDT"])