from src.cpc.services.kline import KLINE_SERVICE
from src.cpc.middlewares.db_connect import db_connection
from src.cpc.helpers.mexc import mexc_market


class KLINE:
    def __init__(self):
        self.kline_service = KLINE_SERVICE(mexc_market())

    def get_kline(self, symbol, interval, limit):
        """
        Retrieve and return k-line (candlestick) data for a specified cryptocurrency symbol, interval, and limit.
        """
        return self.kline_service.get_kline(symbol, interval, limit, test=False)


# If you need to run this standalone for testing
if __name__ == "__main__":
    kline = KLINE()
    data = kline.get_kline("BTCUSDT", "1h", 10)
    print(data)