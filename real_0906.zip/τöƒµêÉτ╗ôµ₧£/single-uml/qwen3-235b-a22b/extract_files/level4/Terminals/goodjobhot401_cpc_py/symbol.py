import requests
from rich.console import Console
from rich.table import Table
import plotext as plt

console = Console()


class SYMBOL_SERVICE:
    def __init__(self):
        from helpers.mexc import mexc_market
        self.mexc = mexc_market()

    def filter_symbols(self, query=None):
        """
        Filter and display cryptocurrency symbols from the MEXC market API,
        either alphabetically grouped or filtered by a query string, in a formatted table.
        """
        try:
            response = self.mexc.get_exchangeInfo({})
            if response.get("code") == 200:
                symbols_data = response.get("data", {}).get("symbols", [])
                filtered_symbols = symbols_data

                if query:
                    query = query.upper()
                    filtered_symbols = [s for s in symbols_data if query in s["symbol"]]

                # Display in a formatted table
                table = Table(title="Available Trading Pairs")
                table.add_column("Symbol", style="cyan")
                table.add_column("Status", style="green")
                table.add_column("Base", style="magenta")
                table.add_column("Quote", style="yellow")

                for symbol in filtered_symbols:
                    table.add_row(
                        symbol["symbol"],
                        symbol["status"],
                        symbol["baseAsset"],
                        symbol["quoteAsset"],
                    )

                console.print(table)
            else:
                console.print("[red]Failed to fetch symbols from MEXC API[/red]")
        except Exception as e:
            console.print(f"[red]Error fetching symbols: {str(e)}[/red]")


# Example usage
if __name__ == "__main__":
    service = SYMBOL_SERVICE()
    service.filter_symbols()