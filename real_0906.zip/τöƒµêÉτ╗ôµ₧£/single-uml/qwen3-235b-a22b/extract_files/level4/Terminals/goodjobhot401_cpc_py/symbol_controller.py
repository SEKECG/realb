from typing import Any

from cpc.services.symbol import SYMBOL_SERVICE
from cpc.middlewares.db_connect import db_connection


class SYMBOL:
    def __init__(self):
        self.symbol_service = SYMBOL_SERVICE()

    def filter_symbols(self, query: Any) -> None:
        """
        Filter and retrieve symbols based on a given query using a symbol service.
        """
        self.symbol_service.filter_symbols(query)


# Example of how to use the SYMBOL class
if __name__ == "__main__":
    symbol_controller = SYMBOL()
    search_query = "BTC"  # Example query
    symbol_controller.filter_symbols(search_query)