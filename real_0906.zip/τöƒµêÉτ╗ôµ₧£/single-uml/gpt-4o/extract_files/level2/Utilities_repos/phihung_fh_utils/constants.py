# constants.py

CACHE_DIR = "/path/to/cache"