# src/semgrep_mcp/__init__.py

__all__ = ['server']

def main():
    pass