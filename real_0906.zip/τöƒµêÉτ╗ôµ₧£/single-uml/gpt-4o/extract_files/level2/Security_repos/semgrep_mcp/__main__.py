# src/semgrep_mcp/__main__.py

from .server import main

if __name__ == "__main__":
    main()