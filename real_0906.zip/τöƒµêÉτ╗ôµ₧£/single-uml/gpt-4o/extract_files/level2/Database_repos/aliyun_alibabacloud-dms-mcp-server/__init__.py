# src/alibabacloud_dms_mcp_server/__init__.py

def main():
    print("Welcome to Alibaba Cloud DMS MCP Server")