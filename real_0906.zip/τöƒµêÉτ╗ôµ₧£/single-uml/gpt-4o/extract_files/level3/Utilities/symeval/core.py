import re
from sympy import sympify, Matrix, Interval, FiniteSet, Union, Intersection, Complement
from typing import List, Any, Optional, Tuple, Dict, Union as T_Union

BASIC_FN_NAMES = ["sin", "cos", "tan", "log", "exp", "sqrt"]
DATETIME_FMTS = ["%Y-%m-%d", "%d/%m/%Y", "%m/%d/%Y"]
DEF_ABS_TOL = 1e-9
DEF_N_PROC = 2
DEF_PERCENT_REL_TOL = 1e-2
DEF_REL_TOL = 1e-9
DEF_TIMEOUT = 5
GSM8K_ANS_PREFIX = "Answer:"
LATEX_CMDS = ["\\frac", "\\sqrt", "\\pm", "\\mp"]
LATEX_FMT_ENVS = ["align", "equation"]
LATEX_LIST_ENVS = ["itemize", "enumerate"]
NDAYS_PER_WEEK = 7
NO_PRECEDING_PUNCS = [",", ".", ";", ":"]
NO_TRAILING_STRS = ["\\end{document}", "\\end{align}"]
PAREN_MAP = {"(": ")", "[": "]", "{": "}"}
PRM800K_ANS_PRRFIX = "Answer:"
SIMPLE_REPLACE_MAP = {"\\pm": "+,-", "\\mp": "-,+", "\\cdot": "*"}
SIMPLE_RM_STRS = ["\\begin{document}", "\\end{document}"]
STR2NUM = {"one": 1, "two": 2, "three": 3}
STRIP_STRS = ["\\n", "\\t", " "]
UNITS = ["cm", "m", "kg", "s"]
WEEKDAY_ABBRS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
WEEKDAY_FULLS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]

class EvaluatorBase:
    def __init__(self, ans_extract_mode="boxed"):
        self.ans_extract_mode = ans_extract_mode

    def clean(self, ans):
        return ans.strip()

    def clean_preceding(self, s):
        return s.lstrip("".join(NO_PRECEDING_PUNCS))

    def clean_trailing(self, s):
        return s.rstrip("".join(NO_TRAILING_STRS))

    def eq(self, ref_ans, pred):
        return ref_ans == pred

    def extract_ans(self, resp_str):
        if self.ans_extract_mode == "boxed":
            return self.extract_boxed(resp_str)
        elif self.ans_extract_mode == "explicit":
            return self.extract_explicit_ans(resp_str)
        else:
            return self.speculate_ans(resp_str)

    def extract_explicit_ans(self, resp_str):
        for prefix in [GSM8K_ANS_PREFIX, PRM800K_ANS_PRRFIX]:
            if prefix in resp_str:
                return self.clean(resp_str.split(prefix)[-1])
        return None

    def get_maj_ans_from_votes(self, ans_vote):
        sorted_votes = sorted(ans_vote.items(), key=lambda x: x[1], reverse=True)
        return sorted_votes[0][0] if sorted_votes else ""

    def get_maj_answers(self, answers):
        ans_vote = {}
        for ans in answers:
            ans_vote[ans] = ans_vote.get(ans, 0) + 1
        return self.get_maj_ans_from_votes(ans_vote)

class EvaluatorMath(EvaluatorBase):
    def __init__(self, ans_extract_mode="boxed", include_percentage=True, rel_tol=DEF_REL_TOL, abs_tol=DEF_ABS_TOL, percent_rel_tol=DEF_PERCENT_REL_TOL, ascii_only=True):
        super().__init__(ans_extract_mode)
        self.include_percentage = include_percentage
        self.rel_tol = rel_tol
        self.abs_tol = abs_tol
        self.percent_rel_tol = percent_rel_tol
        self.ascii_only = ascii_only

    def could_be_percent(self, v):
        return "%" in v or "percent" in v.lower()

    def eq(self, ref_ans, pred, compare_sets=False):
        if ref_ans == pred:
            return True
        if self.is_num_eq(ref_ans, pred):
            return True
        if self.is_sym_eq(ref_ans, pred):
            return True
        return False

    def extract_ans(self, resp_str):
        ans = super().extract_ans(resp_str)
        return self.norm_ans_str(ans)

    def extract_set(self, norm_s):
        elements = set(norm_s.split(","))
        return sorted(elements)

    def index_first_paren_pair(self, s, l):
        stack = []
        for i, char in enumerate(s[l:], start=l):
            if char in PAREN_MAP:
                stack.append(char)
            elif stack and char == PAREN_MAP[stack[-1]]:
                stack.pop()
                if not stack:
                    return l, i
        return -1, -1

    def is_num_eq(self, ref_num, pred_num):
        try:
            ref_val = float(ref_num)
            pred_val = float(pred_num)
            return abs(ref_val - pred_val) <= max(self.abs_tol, self.rel_tol * abs(ref_val))
        except ValueError:
            return False

    def is_sym_eq(self, a, b):
        try:
            a_sym = sympify(a)
            b_sym = sympify(b)
            return a_sym.equals(b_sym)
        except:
            return False

    def latex2matrix(self, latex_mat_str):
        return Matrix(sympify(latex_mat_str))

    def norm_ans_str(self, ans):
        ans = self.clean(ans)
        ans = self.clean_preceding(ans)
        ans = self.clean_trailing(ans)
        return ans

    def norm_basic_fn(self, s):
        for fn in BASIC_FN_NAMES:
            s = re.sub(rf"\\{fn}\s*\^{{(\d+)}}", rf"\\{fn}^{{\1}}", s)
        return s

    def norm_math_str(self, string):
        string = string.lower()
        for choice in ["yes", "no"]:
            if string == choice or string == f"({choice})":
                return choice
        for old, new in SIMPLE_REPLACE_MAP.items():
            string = string.replace(old, new)
        return string

    def norm_pm(self, s):
        return re.sub(r"(.*?)\\pm(.+?)", r"\1-\2,\1+\2", s)

    def norm_str2date_time(self, string):
        for fmt in DATETIME_FMTS:
            try:
                return datetime.strptime(string, fmt).strftime(fmt)
            except ValueError:
                continue
        return None

    def remove_first_paren_pair(self, s, l):
        start, end = self.index_first_paren_pair(s, l)
        if start != -1 and end != -1:
            return s[:start] + s[end + 1:]
        return s

    def remove_latex_cmd(self, s, cmd):
        return re.sub(rf"\\{cmd}\s*\{{.*?\}}", "", s)

    def remove_out_paren(self, s):
        while True:
            start, end = self.index_first_paren_pair(s, 0)
            if start == -1 or end == -1:
                break
            s = s[:start] + s[end + 1:]
        return s

class EvaluatorMathBatch(EvaluatorMath):
    def __init__(self, ans_extract_mode="boxed", include_percentage=True, rel_tol=DEF_REL_TOL, abs_tol=DEF_ABS_TOL, percent_rel_tol=DEF_PERCENT_REL_TOL, ascii_only=True, timeout=DEF_TIMEOUT, n_procs=DEF_N_PROC, use_tqdm=True):
        super().__init__(ans_extract_mode, include_percentage, rel_tol, abs_tol, percent_rel_tol, ascii_only)
        self.timeout = timeout
        self.n_procs = n_procs
        self.use_tqdm = use_tqdm

    def batch_eq(self, ref_answers, pred_answers, problems):
        return [self.eq(ref, pred) for ref, pred in zip(ref_answers, pred_answers)]

    def batch_eval(self, ref_answers, resps, problems):
        pred_answers = self.batch_extract_ans(resps)
        eq_results = self.batch_eq(ref_answers, pred_answers, problems)
        return pred_answers, eq_results

    def batch_extract_ans(self, resps):
        return [self.extract_ans(resp) for resp in resps]

    def batch_get_eq_map(self, ref_answers, pred_answers, querying4set_flags):
        eq_map = {}
        for ref, pred, flag in zip(ref_answers, pred_answers, querying4set_flags):
            eq_map[(ref, pred, flag)] = self.eq(ref, pred, flag)
        return eq_map

    def batch_get_maj_answers(self, answers_list, problems):
        maj_answers = []
        for answers in answers_list:
            maj_answers.append(self.get_maj_answers(answers))
        return maj_answers, problems

def batch_exec(func, kwargs_list, n_procs=DEF_N_PROC, timeout=DEF_TIMEOUT, use_tqdm=True, desc="", def_val=None, max_tasks_per_proc=None):
    from pebble import ProcessPool
    from tqdm import tqdm

    results = []
    with ProcessPool(max_workers=n_procs, max_tasks=max_tasks_per_proc) as pool:
        future = pool.map(func, kwargs_list, timeout=timeout)
        if use_tqdm:
            future = tqdm(future, desc=desc, total=len(kwargs_list))
        for result in future.result():
            results.append(result if result is not None else def_val)
    return results

def extract_boxed(resp):
    return re.search(r"\{(.*?)\}", resp).group(1)

def fix_a_slash_b(s):
    return re.sub(r"(\d+)/(\d+)", r"\\frac{\1}{\2}", s)

def fix_fracs(s):
    return re.sub(r"(\d+)/(\d+)", r"\\frac{\1}{\2}", s)

def fix_sqrt(s):
    return re.sub(r"sqrt\((.*?)\)", r"\\sqrt{\1}", s)

def has_non_ascii(s):
    return any(ord(char) > 127 for char in s)

def is_querying4set(query):
    return "set" in query.lower()

def is_set(s):
    return re.match(r"\{.*?\}", s) is not None

def latex2sympy_fix(s):
    return sympify(s.split(",")[0])

def latex2sympy_interval(s):
    return Interval(*map(sympify, re.findall(r"[-\d]+", s)))

def norm_deg(s):
    return re.sub(r"(\d+)\\circ", r"\1 degrees", s)

def norm_str2bool(s):
    return s.lower() in ["true", "false"]

def norm_str2weekday(s):
    s = s.capitalize()
    if s in WEEKDAY_FULLS:
        return s
    if s in WEEKDAY_ABBRS:
        return WEEKDAY_FULLS[WEEKDAY_ABBRS.index(s)]
    return None

def parse(parser, s_to_parse, parse_errs):
    try:
        return parser(s_to_parse)
    except Exception as e:
        parse_errs.append(str(e))
        return None

def rm_latex_env(s, env):
    return re.sub(rf"\\begin{{{env}}}.*?\\end{{{env}}}", "", s, flags=re.DOTALL)

def run_with_timeout(func, kwargs, timeout):
    from pebble import ProcessPool
    with ProcessPool(max_workers=1) as pool:
        future = pool.schedule(func, kwargs=kwargs, timeout=timeout)
        return future.result()

def task_wrapper(func, kwargs):
    return func(**kwargs)