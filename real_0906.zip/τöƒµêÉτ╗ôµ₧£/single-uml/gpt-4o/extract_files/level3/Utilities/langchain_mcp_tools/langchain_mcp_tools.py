import asyncio
import logging
import json
import os
import subprocess
import websockets
from contextlib import AsyncExitStack

# Type aliases
McpServerCleanupFn = asyncio.coroutine
McpServersConfig = dict
SingleMcpServerConfig = dict
Transport = tuple

class McpServerCommandBasedConfig:
    def __init__(self, command, args=None, env=None, cwd=None, errlog=None):
        self.command = command
        self.args = args or []
        self.env = env or {}
        self.cwd = cwd
        self.errlog = errlog

class McpServerUrlBasedConfig:
    def __init__(self, url, headers=None):
        self.url = url
        self.headers = headers or {}

async def convert_mcp_to_langchain_tools(server_configs, logger=None):
    if logger is None:
        logger = init_logger()
    
    async def cleanup():
        await exit_stack.aclose()
    
    exit_stack = AsyncExitStack()
    tools = []
    
    for server_name, server_config in server_configs.items():
        transport = await spawn_mcp_server_and_get_transport(server_name, server_config, exit_stack, logger)
        server_tools = await get_mcp_server_tools(server_name, transport, exit_stack, logger)
        tools.extend(server_tools)
    
    return tools, cleanup

def fix_schema(schema):
    if "type" in schema and isinstance(schema["type"], list) and "null" in schema["type"]:
        schema["anyOf"] = [{"type": t} for t in schema["type"]]
        del schema["type"]
    return schema

async def get_mcp_server_tools(server_name, transport, exit_stack, logger):
    try:
        # Placeholder for actual tool conversion logic
        tools = []
        return tools
    except Exception as e:
        logger.error(f"Failed to convert tools for server {server_name}: {e}")
        raise

def init_logger():
    logger = logging.getLogger("langchain_mcp_tools")
    if not logger.hasHandlers():
        handler = logging.StreamHandler()
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
    return logger

async def spawn_mcp_server_and_get_transport(server_name, server_config, exit_stack, logger):
    if "command" in server_config:
        return await spawn_command_based_server(server_name, server_config, exit_stack, logger)
    elif "url" in server_config:
        return await spawn_url_based_server(server_name, server_config, exit_stack, logger)
    else:
        raise ValueError(f"Invalid server configuration for {server_name}")

async def spawn_command_based_server(server_name, server_config, exit_stack, logger):
    command = server_config["command"]
    args = server_config.get("args", [])
    env = server_config.get("env", os.environ)
    cwd = server_config.get("cwd", None)
    errlog = server_config.get("errlog", None)
    
    process = await asyncio.create_subprocess_exec(
        command, *args, env=env, cwd=cwd,
        stdout=asyncio.subprocess.PIPE,
        stderr=errlog or asyncio.subprocess.PIPE
    )
    
    exit_stack.push_async_callback(process.wait)
    logger.info(f"Started command-based MCP server {server_name} with PID {process.pid}")
    
    return process.stdout, process.stdin

async def spawn_url_based_server(server_name, server_config, exit_stack, logger):
    url = server_config["url"]
    headers = server_config.get("headers", {})
    
    async def connect():
        async with websockets.connect(url, extra_headers=headers) as websocket:
            exit_stack.push_async_callback(websocket.close)
            logger.info(f"Connected to URL-based MCP server {server_name} at {url}")
            return websocket.recv, websocket.send
    
    return await connect()