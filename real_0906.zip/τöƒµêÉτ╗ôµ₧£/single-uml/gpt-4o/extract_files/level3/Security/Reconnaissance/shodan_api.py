import shodan
import socket

def shodan_scan(domain, api_key):
    api = shodan.Shodan(api_key)
    results = []
    try:
        ip = get_ip_from_domain(domain)
        host = api.host(ip)
        results.append({
            'ip': host['ip_str'],
            'organization': host.get('org', 'N/A'),
            'hostnames': host.get('hostnames', []),
            'vulnerabilities': host.get('vulns', [])
        })
    except shodan.APIError as e:
        print(f"Shodan API error: {e}")
    return results

def host_info(domain, api_key):
    api = shodan.Shodan(api_key)
    try:
        ip = get_ip_from_domain(domain)
        host = api.host(ip)
        return {
            'ip': host['ip_str'],
            'organization': host.get('org', 'N/A'),
            'hostnames': host.get('hostnames', []),
            'vulnerabilities': host.get('vulns', [])
        }
    except shodan.APIError as e:
        print(f"Shodan API error: {e}")
        return {}

def get_api_key(api_key):
    return shodan.Shodan(api_key)

def get_ip_from_domain(domain):
    try:
        return socket.gethostbyname(domain)
    except socket.gaierror:
        return None

def scan_single_ip(ip, api_key):
    api = shodan.Shodan(api_key)
    try:
        host = api.host(ip)
        return {
            'ip': host['ip_str'],
            'organization': host.get('org', 'N/A'),
            'hostnames': host.get('hostnames', []),
            'vulnerabilities': host.get('vulns', [])
        }
    except shodan.APIError as e:
        print(f"Shodan API error: {e}")
        return {}