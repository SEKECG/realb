import os
import socket
import threading
import json
import requests
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.progress import Progress

console = Console()

base_directory = os.path.expanduser("~/.nsm_port_scanner")
file_path_setting = os.path.join(base_directory, "settings.json")
file_path_error_log = os.path.join(base_directory, "error.log")
file_path_clean = os.path.join(base_directory, "clean_results.txt")

lock = threading.Lock()
open_ports = []
closed_fit = []
results_open_ports = []
results_subs_ports = []
geo_info = {}
shodan_results = {}
yes_dns = []
scans = 0
timestamp = ""
time_took = 0
terminal_width = console.size.width

def about_me():
    console.print(Panel("NSM Port Scanner\nDeveloped by: [bold]Your Name[/bold]\nFor educational and testing purposes.\nStart Date: 2023-01-01\nEnd Date: 2023-12-31"))

def clean_text(type, clean_letter):
    try:
        with open(file_path_clean, type) as file:
            file.write(clean_letter)
    except FileNotFoundError:
        console.print("[red]File not found![/red]")
    except Exception as e:
        console.print(f"[red]An error occurred: {e}[/red]")

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def connection_status():
    try:
        socket.create_connection(("www.google.com", 80))
        console.print("[green]Online[/green]")
    except OSError:
        console.print("[red]Offline[/red]")

def data(type, letter):
    try:
        with open(file_path_setting, type) as file:
            if type == 'r':
                return json.load(file)
            else:
                json.dump(letter, file)
    except FileNotFoundError:
        console.print("[red]File not found![/red]")
    except Exception as e:
        console.print(f"[red]An error occurred: {e}[/red]")

def domain_resolver():
    domain_name = input("Enter domain name: ")
    try:
        ip_address = socket.gethostbyname(domain_name)
        table = Table(title="Domain Resolution")
        table.add_column("Domain", justify="right", style="cyan", no_wrap=True)
        table.add_column("IP Address", style="magenta")
        table.add_row(domain_name, ip_address)
        console.print(table)
    except socket.gaierror:
        console.print("[red]Error resolving domain[/red]")

def flush_dns():
    if os.name == 'posix':
        os.system('sudo systemd-resolve --flush-caches')
        os.system('sudo /etc/init.d/dns-clean restart')
        os.system('sudo /etc/init.d/networking force-reload')
    else:
        console.print("[red]This function is only for Linux/macOS systems[/red]")

def geo_lookup():
    ip_address = input("Enter IP address: ")
    response = requests.get(f"https://ipinfo.io/{ip_address}/json")
    geo_info = response.json()
    table = Table(title="GeoIP Lookup")
    for key, value in geo_info.items():
        table.add_row(key, value)
    console.print(table)

def noty(type, msg):
    if type == 1:
        console.print(f"[green]{msg}[/green]")
    elif type == 2:
        settings = data('r', None)
        if settings.get("notifications", True):
            console.print(f"[green]{msg}[/green]")

def nvd(vulns):
    response = requests.get(f"https://services.nvd.nist.gov/rest/json/cves/1.0?cpeMatchString={vulns}")
    nvd_data = response.json()
    table = Table(title="NVD CVE Lookup")
    for item in nvd_data['result']['CVE_Items']:
        table.add_row(item['cve']['CVE_data_meta']['ID'], item['cve']['description']['description_data'][0]['value'])
    console.print(table)

def port_scan(port, table):
    target = input("Enter target IP: ")
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1)
        result = sock.connect_ex((target, port))
        if result == 0:
            open_ports.append(port)
            table.add_row(str(port), "Open")
        else:
            closed_fit.append(port)
        sock.close()
    except Exception as e:
        console.print(f"[red]An error occurred: {e}[/red]")

def setting():
    settings = data('r', None)
    console.print(settings)

def show_help_menu():
    console.print(Panel("Help Menu\nCommon Scan: Scans ports 0-1024\nFull Scan: Scans ports 0-65535\nCustom Scan: User-defined port range"))

def sub_resolver(sub, table):
    try:
        ip_address = socket.gethostbyname(sub)
        results_subs_ports.append(sub)
        table.add_row(sub, ip_address)
    except socket.gaierror:
        console.print(f"[red]Error resolving subdomain: {sub}[/red]")

def threader(choice, target):
    if choice == 1:
        ports = range(0, 1025)
    else:
        ports = range(0, 65536)
    table = Table(title="Port Scan Results")
    table.add_column("Port", justify="right", style="cyan", no_wrap=True)
    table.add_column("Status", style="magenta")
    with Progress() as progress:
        task = progress.add_task("[cyan]Scanning...", total=len(ports))
        for port in ports:
            threading.Thread(target=port_scan, args=(port, table)).start()
            progress.update(task, advance=1)
    console.print(table)

def threader2(choice, target):
    subdomains = ["www", "mail", "ftp", "localhost"]
    table = Table(title="Subdomain Scan Results")
    table.add_column("Subdomain", justify="right", style="cyan", no_wrap=True)
    table.add_column("IP Address", style="magenta")
    with Progress() as progress:
        task = progress.add_task("[cyan]Scanning...", total=len(subdomains))
        for sub in subdomains:
            threading.Thread(target=sub_resolver, args=(sub, table)).start()
            progress.update(task, advance=1)
    console.print(table)

def troll():
    with Progress() as progress:
        task = progress.add_task("[cyan]Loading...", total=100)
        progress.update(task, advance=1)

def version_lookup():
    ip_address = input("Enter IP address: ")
    response = requests.get(f"https://api.shodan.io/shodan/host/{ip_address}?key=YOUR_API_KEY")
    shodan_results = response.json()
    table = Table(title="Shodan Lookup")
    for key, value in shodan_results.items():
        table.add_row(key, str(value))
    console.print(table)

def welcome():
    console.print(Panel("Welcome to NSM Port Scanner"))
    settings = data('r', None)
    if settings:
        console.print(f"Welcome back, {settings.get('display_name', 'User')}!")
    else:
        console.print("Welcome, new user!")