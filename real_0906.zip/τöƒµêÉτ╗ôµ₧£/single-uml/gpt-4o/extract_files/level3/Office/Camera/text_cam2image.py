import argparse
import torch
from diffusers import StableDiffusionPipeline
from camera_embed import CameraSettingEmbedding
from inference import embed_camera_settings

def parse_args():
    parser = argparse.ArgumentParser(description="Generate images using Stable Diffusion with embedded camera settings.")
    parser.add_argument("--model_path", type=str, required=True, help="Path to the Stable Diffusion model.")
    parser.add_argument("--output_dir", type=str, required=True, help="Directory to save generated images.")
    parser.add_argument("--prompt", type=str, required=True, help="Text prompt for image generation.")
    parser.add_argument("--focal_length", type=float, default=0.0, help="Focal length of the camera.")
    parser.add_argument("--aperture", type=float, default=0.0, help="Aperture (f-number) of the camera.")
    parser.add_argument("--iso_speed", type=int, default=0, help="ISO speed rating of the camera.")
    parser.add_argument("--exposure_time", type=float, default=0.0, help="Exposure time of the camera.")
    parser.add_argument("--negative_prompt", type=str, default="", help="Negative text prompt for image generation.")
    parser.add_argument("--negative_focal_length", type=float, default=0.0, help="Negative focal length of the camera.")
    parser.add_argument("--negative_aperture", type=float, default=0.0, help="Negative aperture (f-number) of the camera.")
    parser.add_argument("--negative_iso_speed", type=int, default=0, help="Negative ISO speed rating of the camera.")
    parser.add_argument("--negative_exposure_time", type=float, default=0.0, help="Negative exposure time of the camera.")
    return parser.parse_args()

def main():
    args = parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"

    # Load the Stable Diffusion model
    model = StableDiffusionPipeline.from_pretrained(args.model_path).to(device)

    # Initialize the camera setting embedding module
    cam_embed = CameraSettingEmbedding(
        embedding_dim=model.text_encoder.config.hidden_size,
        hidden_dim=512,
        num_layers=2,
        activation="relu",
        layer_norm=True,
        zero_init=True,
        logize_input=True
    ).to(device)

    # Embed camera settings into prompt embeddings
    prompt_embeds = model.text_encoder(args.prompt, return_tensors="pt").input_ids.to(device)
    negative_prompt_embeds = model.text_encoder(args.negative_prompt, return_tensors="pt").input_ids.to(device)

    prompt_embeds = embed_camera_settings(
        args.focal_length, args.aperture, args.iso_speed, args.exposure_time,
        prompt_embeds, args.negative_focal_length, args.negative_aperture,
        args.negative_iso_speed, args.negative_exposure_time, negative_prompt_embeds,
        cam_embed, device
    )

    # Generate the image
    with torch.no_grad():
        image = model(prompt_embeds=prompt_embeds).images[0]

    # Save the image
    image.save(f"{args.output_dir}/generated_image.png")

if __name__ == "__main__":
    main()