import argparse
import torch
from diffusers import StableDiffusionPipeline, ControlNetModel
from camera_embed import CameraSettingEmbedding
from inference import embed_camera_settings

def parse_args():
    parser = argparse.ArgumentParser(description="Generate images with Stable Diffusion and ControlNet using camera settings.")
    parser.add_argument("--model_path", type=str, required=True, help="Path to the Stable Diffusion model.")
    parser.add_argument("--controlnet_path", type=str, required=True, help="Path to the ControlNet model.")
    parser.add_argument("--output_dir", type=str, required=True, help="Directory to save generated images.")
    parser.add_argument("--prompt", type=str, required=True, help="Text prompt for image generation.")
    parser.add_argument("--negative_prompt", type=str, default="", help="Negative text prompt for image generation.")
    parser.add_argument("--focal_length", type=float, default=0.0, help="Focal length of the camera.")
    parser.add_argument("--aperture", type=float, default=0.0, help="Aperture (f-number) of the camera.")
    parser.add_argument("--iso_speed", type=int, default=0, help="ISO speed rating of the camera.")
    parser.add_argument("--exposure_time", type=float, default=0.0, help="Exposure time of the camera.")
    parser.add_argument("--negative_focal_length", type=float, default=0.0, help="Negative focal length of the camera.")
    parser.add_argument("--negative_aperture", type=float, default=0.0, help="Negative aperture (f-number) of the camera.")
    parser.add_argument("--negative_iso_speed", type=int, default=0, help="Negative ISO speed rating of the camera.")
    parser.add_argument("--negative_exposure_time", type=float, default=0.0, help="Negative exposure time of the camera.")
    return parser.parse_args()

def main():
    args = parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"

    # Load models
    sd_pipeline = StableDiffusionPipeline.from_pretrained(args.model_path).to(device)
    controlnet = ControlNetModel.from_pretrained(args.controlnet_path).to(device)

    # Initialize camera embedding module
    cam_embed = CameraSettingEmbedding(
        embedding_dim=768,
        hidden_dim=512,
        num_layers=2,
        activation="ReLU",
        layer_norm=True,
        zero_init=True,
        logize_input=True
    ).to(device)

    # Embed camera settings
    prompt_embeds = sd_pipeline.tokenizer(args.prompt, return_tensors="pt").input_ids.to(device)
    negative_prompt_embeds = sd_pipeline.tokenizer(args.negative_prompt, return_tensors="pt").input_ids.to(device)

    prompt_embeds = embed_camera_settings(
        args.focal_length, args.aperture, args.iso_speed, args.exposure_time,
        prompt_embeds, args.negative_focal_length, args.negative_aperture,
        args.negative_iso_speed, args.negative_exposure_time, negative_prompt_embeds,
        cam_embed, device
    )

    # Generate image
    with torch.no_grad():
        images = sd_pipeline(prompt_embeds=prompt_embeds, controlnet=controlnet).images

    # Save images
    for i, image in enumerate(images):
        image.save(f"{args.output_dir}/generated_image_{i}.png")

if __name__ == "__main__":
    main()