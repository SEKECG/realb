import torch
from camera_embed import CameraSettingEmbedding

def embed_camera_settings(
    focal_length, aperture, iso_speed, exposure_time,
    prompt_embeds, negative_focal_length, negative_aperture,
    negative_iso_speed, negative_exposure_time, negative_prompt_embeds,
    cam_embed, device
):
    # Handle missing or partial camera settings by defaulting to zero values
    focal_length = focal_length if focal_length is not None else 0.0
    aperture = aperture if aperture is not None else 0.0
    iso_speed = iso_speed if iso_speed is not None else 0.0
    exposure_time = exposure_time if exposure_time is not None else 0.0

    negative_focal_length = negative_focal_length if negative_focal_length is not None else 0.0
    negative_aperture = negative_aperture if negative_aperture is not None else 0.0
    negative_iso_speed = negative_iso_speed if negative_iso_speed is not None else 0.0
    negative_exposure_time = negative_exposure_time if negative_exposure_time is not None else 0.0

    # Convert to tensors and move to the specified device
    focal_length = torch.tensor(focal_length, device=device).unsqueeze(0)
    aperture = torch.tensor(aperture, device=device).unsqueeze(0)
    iso_speed = torch.tensor(iso_speed, device=device).unsqueeze(0)
    exposure_time = torch.tensor(exposure_time, device=device).unsqueeze(0)

    negative_focal_length = torch.tensor(negative_focal_length, device=device).unsqueeze(0)
    negative_aperture = torch.tensor(negative_aperture, device=device).unsqueeze(0)
    negative_iso_speed = torch.tensor(negative_iso_speed, device=device).unsqueeze(0)
    negative_exposure_time = torch.tensor(negative_exposure_time, device=device).unsqueeze(0)

    # Embed camera settings
    positive_camera_embeds = cam_embed(
        focal_length, aperture, iso_speed, exposure_time
    )
    negative_camera_embeds = cam_embed(
        negative_focal_length, negative_aperture, negative_iso_speed, negative_exposure_time
    )

    # Combine text embeddings and camera setting embeddings
    combined_positive_embeds = torch.cat([prompt_embeds, positive_camera_embeds], dim=-1)
    combined_negative_embeds = torch.cat([negative_prompt_embeds, negative_camera_embeds], dim=-1)

    return combined_positive_embeds, combined_negative_embeds