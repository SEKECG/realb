import argparse
import logging
import os
import torch
from torch.utils.data import DataLoader
from transformers import CLIPTextModel, CLIPTokenizer
from diffusers import StableDiffusionPipeline
from camera_embed import CameraSettingEmbedding

logger = logging.getLogger(__name__)

def parse_args(argv=None):
    parser = argparse.ArgumentParser(description="Fine-tune Stable Diffusion with LoRA and camera setting embeddings.")
    parser.add_argument("--train_data_dir", type=str, required=True, help="Directory containing training data.")
    parser.add_argument("--output_dir", type=str, required=True, help="Directory to save the fine-tuned model.")
    parser.add_argument("--embedding_dim", type=int, default=768, help="Dimension of the camera setting embeddings.")
    parser.add_argument("--hidden_dim", type=int, default=512, help="Hidden dimension of the embedding network.")
    parser.add_argument("--num_layers", type=int, default=2, help="Number of layers in the embedding network.")
    parser.add_argument("--activation", type=str, default="relu", choices=["relu", "silu", "gelu"], help="Activation function.")
    parser.add_argument("--layer_norm", action="store_true", help="Use layer normalization.")
    parser.add_argument("--zero_init", action="store_true", help="Initialize weights to zero.")
    parser.add_argument("--logize_input", action="store_true", help="Apply logarithmic transformation to input values.")
    parser.add_argument("--mixed_precision", action="store_true", help="Use mixed precision training.")
    parser.add_argument("--gradient_checkpointing", action="store_true", help="Use gradient checkpointing.")
    parser.add_argument("--distributed", action="store_true", help="Use distributed training.")
    return parser.parse_args(argv)

def main():
    args = parse_args()

    # Initialize camera setting embedding module
    cam_embed = CameraSettingEmbedding(
        embedding_dim=args.embedding_dim,
        hidden_dim=args.hidden_dim,
        num_layers=args.num_layers,
        activation=args.activation,
        layer_norm=args.layer_norm,
        zero_init=args.zero_init,
        logize_input=args.logize_input
    )

    # Load training data
    train_data = DataLoader(os.path.join(args.train_data_dir, "train"))
    val_data = DataLoader(os.path.join(args.train_data_dir, "val"))

    # Initialize Stable Diffusion pipeline
    model_id = "CompVis/stable-diffusion-v1-4"
    pipe = StableDiffusionPipeline.from_pretrained(model_id, torch_dtype=torch.float16 if args.mixed_precision else torch.float32)
    pipe.enable_attention_slicing()

    # Training loop
    for epoch in range(num_epochs):
        for batch in train_data:
            images, exif_data = batch
            focal_length = exif_data["FocalLength"]
            aperture = exif_data["Aperture"]
            iso_speed = exif_data["ISOSpeedRatings"]
            exposure_time = exif_data["ExposureTime"]

            # Embed camera settings
            cam_embeds = cam_embed(focal_length, aperture, iso_speed, exposure_time)

            # Combine text and camera embeddings
            prompt_embeds = pipe.tokenizer(images, return_tensors="pt").input_ids
            combined_embeds = torch.cat([prompt_embeds, cam_embeds], dim=-1)

            # Forward pass
            outputs = pipe.model(combined_embeds)
            loss = outputs.loss

            # Backward pass and optimization
            loss.backward()
            optimizer.step()
            optimizer.zero_grad()

        # Validation
        for batch in val_data:
            images, exif_data = batch
            focal_length = exif_data["FocalLength"]
            aperture = exif_data["Aperture"]
            iso_speed = exif_data["ISOSpeedRatings"]
            exposure_time = exif_data["ExposureTime"]

            # Embed camera settings
            cam_embeds = cam_embed(focal_length, aperture, iso_speed, exposure_time)

            # Combine text and camera embeddings
            prompt_embeds = pipe.tokenizer(images, return_tensors="pt").input_ids
            combined_embeds = torch.cat([prompt_embeds, cam_embeds], dim=-1)

            # Forward pass
            outputs = pipe.model(combined_embeds)
            val_loss = outputs.loss

            logger.info(f"Validation loss: {val_loss.item()}")

    # Save the fine-tuned model
    pipe.save_pretrained(args.output_dir)

if __name__ == "__main__":
    main()