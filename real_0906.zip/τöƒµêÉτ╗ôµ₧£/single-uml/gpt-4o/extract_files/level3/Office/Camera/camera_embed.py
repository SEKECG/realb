import torch
import torch.nn as nn
import torch.nn.functional as F

class CameraSettingEmbedding(nn.Module):
    '''
    Map camera settings (focal length, aperture, ISO speed, exposure time) from EXIF data to embeddings with the same dimension as CLIP token embeddings.
    '''
    def __init__(self, embedding_dim, hidden_dim, num_layers, activation, layer_norm, zero_init, logize_input):
        super(CameraSettingEmbedding, self).__init__()
        self.activation = activation
        self.logize_input = logize_input
        self.zero_init = zero_init

        self.embed_focal_length = self._create_embedding_layer(embedding_dim, hidden_dim, num_layers, layer_norm)
        self.embed_aperture = self._create_embedding_layer(embedding_dim, hidden_dim, num_layers, layer_norm)
        self.embed_iso_speed = self._create_embedding_layer(embedding_dim, hidden_dim, num_layers, layer_norm)
        self.embed_exposure_time = self._create_embedding_layer(embedding_dim, hidden_dim, num_layers, layer_norm)

    def _create_embedding_layer(self, embedding_dim, hidden_dim, num_layers, layer_norm):
        layers = []
        input_dim = 1
        for _ in range(num_layers):
            layers.append(nn.Linear(input_dim, hidden_dim))
            if layer_norm:
                layers.append(nn.LayerNorm(hidden_dim))
            layers.append(self._get_activation())
            input_dim = hidden_dim
        layers.append(nn.Linear(hidden_dim, embedding_dim))
        if self.zero_init:
            layers[-1].weight.data.fill_(0)
            layers[-1].bias.data.fill_(0)
        return nn.Sequential(*layers)

    def _get_activation(self):
        if self.activation == 'SiLU':
            return nn.SiLU()
        elif self.activation == 'ReLU':
            return nn.ReLU()
        elif self.activation == 'GELU':
            return nn.GELU()
        else:
            raise ValueError(f"Unsupported activation function: {self.activation}")

    def aperture_forward(self, x_aperture):
        if self.logize_input:
            x_aperture = torch.log(x_aperture + 1)
        return self.embed_aperture(x_aperture.unsqueeze(-1))

    def exposure_time_forward(self, x_exposure_time):
        if self.logize_input:
            x_exposure_time = torch.log(x_exposure_time + 1)
        return self.embed_exposure_time(x_exposure_time.unsqueeze(-1))

    def focal_length_forward(self, x_focal_length):
        if self.logize_input:
            x_focal_length = torch.log(x_focal_length + 1)
        return self.embed_focal_length(x_focal_length.unsqueeze(-1))

    def iso_speed_forward(self, x_iso_speed):
        if self.logize_input:
            x_iso_speed = torch.log(x_iso_speed + 1)
        return self.embed_iso_speed(x_iso_speed.unsqueeze(-1))

    def forward(self, x_focal_length, x_aperture, x_iso_speed, x_exposure_time):
        focal_length_embed = self.focal_length_forward(x_focal_length)
        aperture_embed = self.aperture_forward(x_aperture)
        iso_speed_embed = self.iso_speed_forward(x_iso_speed)
        exposure_time_embed = self.exposure_time_forward(x_exposure_time)
        return torch.cat([focal_length_embed, aperture_embed, iso_speed_embed, exposure_time_embed], dim=-1)