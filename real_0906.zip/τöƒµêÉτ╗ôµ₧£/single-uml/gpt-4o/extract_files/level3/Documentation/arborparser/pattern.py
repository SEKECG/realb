import re
from typing import Callable, List, Optional, Union, Dict

class LevelPattern:
    def __init__(self, regex: re.Pattern, converter: Callable[[re.Match], List[int]], description: str):
        self.regex = regex
        self.converter = converter
        self.description = description

class NumberType:
    ARABIC = "arabic"
    CHINESE = "chinese"
    CIRCLED = "circled"
    LETTER = "letter"
    ROMAN = "roman"

class NumberTypeInfo:
    def __init__(self, pattern: str, converter: Callable[[str], int], name: str):
        self.pattern = pattern
        self.converter = converter
        self.name = name

class PatternBuilder:
    def __init__(self, prefix_regex: str, number_type: NumberTypeInfo, suffix_regex: str, separator: str, min_level: int, max_level: int):
        self.prefix_regex = prefix_regex
        self.number_type = number_type
        self.suffix_regex = suffix_regex
        self.separator = separator
        self.min_level = min_level
        self.max_level = max_level
        self.__post_init__()

    def __post_init__(self):
        if not self.prefix_regex or not self.number_type or not self.suffix_regex or not self.separator:
            raise ValueError("Invalid PatternBuilder configuration")

    def build(self) -> LevelPattern:
        pattern_str = f"{self.prefix_regex}{self.number_type.pattern}{self.separator}{self.suffix_regex}"
        regex = re.compile(pattern_str)
        return LevelPattern(regex, self.number_type.converter, f"{self.number_type.name} pattern")

    def modify(self, **kwargs) -> 'PatternBuilder':
        new_attrs = {**self.__dict__, **kwargs}
        return PatternBuilder(**new_attrs)

CHINESE_CHAPTER_PATTERN_BUILDER = PatternBuilder(
    prefix_regex=r"第",
    number_type=NumberTypeInfo(pattern=r"[一二三四五六七八九十百千]+", converter=lambda x: int(x), name=NumberType.CHINESE),
    suffix_regex=r"章",
    separator=r"",
    min_level=1,
    max_level=10
)

CIRCLED_PATTERN_BUILDER = PatternBuilder(
    prefix_regex=r"",
    number_type=NumberTypeInfo(pattern=r"[①②③④⑤⑥⑦⑧⑨⑩]", converter=lambda x: int(x), name=NumberType.CIRCLED),
    suffix_regex=r"",
    separator=r"",
    min_level=1,
    max_level=10
)

ENGLISH_CHAPTER_PATTERN_BUILDER = PatternBuilder(
    prefix_regex=r"Chapter ",
    number_type=NumberTypeInfo(pattern=r"\d+", converter=lambda x: int(x), name=NumberType.ARABIC),
    suffix_regex=r"",
    separator=r"",
    min_level=1,
    max_level=10
)

NUMERIC_DASH_PATTERN_BUILDER = PatternBuilder(
    prefix_regex=r"",
    number_type=NumberTypeInfo(pattern=r"\d+", converter=lambda x: int(x), name=NumberType.ARABIC),
    suffix_regex=r"",
    separator=r"-",
    min_level=1,
    max_level=10
)

NUMERIC_DOT_PATTERN_BUILDER = PatternBuilder(
    prefix_regex=r"",
    number_type=NumberTypeInfo(pattern=r"\d+", converter=lambda x: int(x), name=NumberType.ARABIC),
    suffix_regex=r"",
    separator=r"\.",
    min_level=1,
    max_level=10
)

ROMAN_PATTERN_BUILDER = PatternBuilder(
    prefix_regex=r"",
    number_type=NumberTypeInfo(pattern=r"[IVXLCDM]+", converter=lambda x: int(x), name=NumberType.ROMAN),
    suffix_regex=r"",
    separator=r"",
    min_level=1,
    max_level=10
)