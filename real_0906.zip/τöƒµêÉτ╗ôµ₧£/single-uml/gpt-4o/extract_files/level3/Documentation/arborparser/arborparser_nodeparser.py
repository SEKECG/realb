import re
from typing import List, Tuple, Dict, Any, Optional

class ArborParserNodeParser:
    def __init__(self, chunk_size, chunk_overlap, merge_threshold, is_merge_small_node, level_patterns):
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.merge_threshold = merge_threshold
        self.is_merge_small_node = is_merge_small_node
        self.patterns = level_patterns
        self.sentence_splitter = None  # Placeholder for SentenceSplitter

    def collect_chunks_with_path(self, node, title_path):
        chunks = []
        if node.content:
            chunks.append((node.content, {"title_path": title_path}))
        for child in node.children:
            chunks.extend(self.collect_chunks_with_path(child, title_path + [child.title]))
        return chunks

    def get_nodes_from_documents(self, documents, show_progress):
        nodes = []
        for doc in documents:
            nodes.append(self.parse_text(doc))
        return nodes

    def merge_deep_nodes(self, node):
        for child in node.children:
            self.merge_deep_nodes(child)
        if len(node.content) < self.merge_threshold:
            node.merge_all_children()

    def parse_text(self, text):
        chain_nodes = self._parse_to_chain(text)
        tree_builder = TreeBuilder(strategy=AutoPruneStrategy() if self.is_merge_small_node else StrictStrategy())
        tree_root = tree_builder.build_tree(chain_nodes)
        return self.collect_chunks_with_path(tree_root, [])

    def split_node_content(self, node):
        return self.sentence_splitter.split(node.content)

    def _parse_to_chain(self, text):
        chain_parser = ChainParser(patterns=self.patterns)
        return chain_parser.parse_to_chain(text)