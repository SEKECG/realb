# node.py

from typing import List, Optional, Dict, Any, Tuple

class BaseNode:
    def __init__(self, level_seq: List[int], level_text: str, title: str, content: str):
        self.level_seq = level_seq
        self.level_text = level_text
        self.title = title
        self.content = content

    def concat_node(self, node: 'BaseNode') -> None:
        self.content += node.content


class ChainNode(BaseNode):
    def __init__(self, level_seq: List[int], level_text: str, title: str, content: str, pattern_priority: int):
        super().__init__(level_seq, level_text, title, content)
        self.pattern_priority = pattern_priority


class TreeNode(BaseNode):
    def __init__(self, level_seq: List[int], level_text: str, title: str, content: str, parent: Optional['TreeNode'] = None):
        super().__init__(level_seq, level_text, title, content)
        self.parent = parent
        self.children = []

    def add_child(self, child: 'TreeNode') -> None:
        self.children.append(child)
        child.parent = self

    @staticmethod
    def from_chain_node(chain_node: ChainNode) -> 'TreeNode':
        return TreeNode(chain_node.level_seq, chain_node.level_text, chain_node.title, chain_node.content)

    def get_full_content(self) -> str:
        full_content = self.content
        for child in self.children:
            full_content += child.get_full_content()
        return full_content

    def merge_all_children(self) -> None:
        for child in self.children:
            self.concat_node(child)
        self.children = []