import re
from typing import Optional

ALL_CHINESE_CHARS = "零一二三四五六七八九十百千万亿"
ALL_ROMAN_NUMERALS = "IVXLCDM"

chinese_patterns_test = [
    ("零", 0), ("一", 1), ("二", 2), ("三", 3), ("四", 4),
    ("五", 5), ("六", 6), ("七", 7), ("八", 8), ("九", 9),
    ("十", 10), ("百", 100), ("千", 1000), ("万", 10000), ("亿", 100000000)
]

roman_patterns_test = [
    ("I", 1), ("II", 2), ("III", 3), ("IV", 4), ("V", 5),
    ("VI", 6), ("VII", 7), ("VIII", 8), ("IX", 9), ("X", 10)
]

def chinese_to_int(chinese_str: str) -> Optional[int]:
    chinese_num_map = {char: num for char, num in chinese_patterns_test}
    result = 0
    unit = 1
    for char in reversed(chinese_str):
        if char in chinese_num_map:
            num = chinese_num_map[char]
            if num >= 10 and unit == 1:
                unit = num
            else:
                result += num * unit
                if unit > 1:
                    unit //= 10
        else:
            return None
    return result

def roman_to_int(roman_str: str) -> Optional[int]:
    roman_num_map = {'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000}
    result = 0
    prev_value = 0
    for char in reversed(roman_str):
        if char in roman_num_map:
            value = roman_num_map[char]
            if value < prev_value:
                result -= value
            else:
                result += value
            prev_value = value
        else:
            return None
    return result