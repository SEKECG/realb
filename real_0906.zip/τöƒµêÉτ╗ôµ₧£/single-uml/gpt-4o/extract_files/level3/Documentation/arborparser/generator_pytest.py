import requests

def build_messages(python_code):
    system_prompt = {
        "role": "system",
        "content": "You are a senior Python programmer. Generate pytest unit tests for the given Python code module."
    }
    user_prompt = {
        "role": "user",
        "content": f"Please generate pytest unit tests for the following Python code:\n\n{python_code}"
    }
    return [system_prompt], [user_prompt]

def call_deepseek_v3(messages, api_key, max_tokens, temperature, n):
    url = "https://api.deepseek.com/v3/chat/completion"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    payload = {
        "messages": messages,
        "max_tokens": max_tokens,
        "temperature": temperature,
        "n": n
    }
    response = requests.post(url, headers=headers, json=payload)
    response.raise_for_status()
    return response.json()["choices"]

def call_gpt_4o(messages, api_key, max_tokens, temperature, n):
    url = "https://api.openai.com/v1/engines/gpt-4o/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    payload = {
        "messages": messages,
        "max_tokens": max_tokens,
        "temperature": temperature,
        "n": n
    }
    response = requests.post(url, headers=headers, json=payload)
    response.raise_for_status()
    return response.json()["choices"]

def main():
    import sys
    if len(sys.argv) != 6:
        print("Usage: python generator_pytest.py <source_file> <api_key> <max_tokens> <temperature> <n>")
        sys.exit(1)

    source_file, api_key, max_tokens, temperature, n = sys.argv[1:]
    max_tokens = int(max_tokens)
    temperature = float(temperature)
    n = int(n)

    with open(source_file, "r") as f:
        python_code = f.read()

    system_messages, user_messages = build_messages(python_code)
    deepseek_responses = call_deepseek_v3(system_messages + user_messages, api_key, max_tokens, temperature, n)
    gpt_4o_responses = call_gpt_4o(system_messages + user_messages, api_key, max_tokens, temperature, n)

    print("Deepseek v3 responses:")
    for response in deepseek_responses:
        print(response["message"]["content"])

    print("\nGPT-4o responses:")
    for response in gpt_4o_responses:
        print(response["message"]["content"])

if __name__ == "__main__":
    main()