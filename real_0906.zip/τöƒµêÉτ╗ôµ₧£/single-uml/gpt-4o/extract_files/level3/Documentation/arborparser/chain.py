import re
from typing import List, Optional

class ChainNode:
    def __init__(self, level_seq, level_text, title, content, pattern_priority):
        self.level_seq = level_seq
        self.level_text = level_text
        self.title = title
        self.content = content
        self.pattern_priority = pattern_priority

class LevelPattern:
    def __init__(self, regex, converter, description):
        self.regex = regex
        self.converter = converter
        self.description = description

class ChainParser:
    def __init__(self, patterns: List[LevelPattern]):
        self.patterns = patterns

    def _detect_level(self, line: str) -> Optional[ChainNode]:
        for pattern in self.patterns:
            match = pattern.regex.match(line)
            if match:
                level_seq = pattern.converter(match)
                level_text = match.group(0)
                title = line[len(level_text):].strip()
                content = line
                return ChainNode(level_seq, level_text, title, content, pattern.priority)
        return None

    def parse_to_chain(self, text: str) -> List[ChainNode]:
        lines = text.split('\n')
        chain_nodes = []
        for line in lines:
            node = self._detect_level(line)
            if node:
                chain_nodes.append(node)
        return chain_nodes