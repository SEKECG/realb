# build_strategy.py

from typing import List, Dict, Any, Tuple
from node import TreeNode, ChainNode

def get_last_level(level_seq):
    return level_seq[-1] if level_seq else 0

def get_prefix(level_seq):
    return level_seq[:-1]

def is_imm_next(front_seq, back_seq):
    if len(front_seq) == len(back_seq):
        return get_prefix(front_seq) == get_prefix(back_seq) and get_last_level(front_seq) + 1 == get_last_level(back_seq)
    elif len(front_seq) + 1 == len(back_seq):
        return front_seq == get_prefix(back_seq)
    elif len(front_seq) > len(back_seq):
        truncated_front_seq = front_seq[:len(back_seq)]
        return is_imm_next(truncated_front_seq, back_seq)
    return False

def is_root(node):
    return node.parent is None

class TreeBuildingStrategy:
    def build_tree(self, chain):
        raise NotImplementedError("Subclasses should implement this method")

class AutoPruneStrategy(TreeBuildingStrategy):
    def build_tree(self, chain):
        root = TreeNode()
        current_node = root
        for chain_node in chain:
            tree_node = TreeNode.from_chain_node(chain_node)
            while not is_imm_next(current_node.level_seq, tree_node.level_seq):
                current_node = current_node.parent
            current_node.add_child(tree_node)
            current_node = tree_node
        return root

class StrictStrategy(TreeBuildingStrategy):
    def build_tree(self, chain):
        root = TreeNode()
        current_node = root
        for chain_node in chain:
            tree_node = TreeNode.from_chain_node(chain_node)
            while not is_imm_next(current_node.level_seq, tree_node.level_seq):
                current_node = current_node.parent
            current_node.add_child(tree_node)
            current_node = tree_node
        return root