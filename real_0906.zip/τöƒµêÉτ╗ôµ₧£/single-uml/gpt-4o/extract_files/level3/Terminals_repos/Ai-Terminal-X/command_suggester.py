import os
import re
from dotenv import load_dotenv
import google.generativeai as gemini

API_KEY_FILENAME = ".env"

def load_api_key():
    load_dotenv()
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        print("Error: API key not found in .env file.")
        exit(1)
    return api_key

def configure_ai(api_key):
    try:
        gemini.configure(api_key)
        model = gemini.Model("gemini-1.5-flash-latest")
        return model
    except Exception as e:
        print(f"Error: Failed to configure AI - {e}")
        exit(1)

def parse_suggestions(ai_text):
    try:
        suggestions = re.findall(r"Command: (.*?)\nExplanation: (.*?)\n", ai_text, re.DOTALL)
        recommended = re.search(r"Recommended: (.*?)\nExplanation: (.*?)\n", ai_text, re.DOTALL)
        if recommended:
            recommended = (recommended.group(1), recommended.group(2))
        else:
            recommended = None
        return suggestions, recommended, None
    except Exception as e:
        return None, None, f"Error parsing AI response: {e}"

if __name__ == "__main__":
    api_key = load_api_key()
    model = configure_ai(api_key)
    user_task_description = input("Describe your task: ")
    suggester_prompt = f"Suggest multiple Linux commands for the following task: {user_task_description}"
    response = model.chat(suggester_prompt)
    ai_response_text = response.text
    suggestions, recommended, parse_error_msg = parse_suggestions(ai_response_text)
    if parse_error_msg:
        print(parse_error_msg)
    else:
        print("Suggestions:")
        for sug in suggestions:
            print(f"Command: {sug[0]}\nExplanation: {sug[1]}\n")
        if recommended:
            print(f"Recommended Command: {recommended[0]}\nExplanation: {recommended[1]}\n")