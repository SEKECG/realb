import os
import subprocess
import google.generativeai as gemini
from dotenv import load_dotenv

API_KEY_FILENAME = ".env"
COMMAND_SUGGESTER_SCRIPT = "command_suggester.py"
TMUX_HISTORY_LIMIT = 1000
TMUX_VIEWER_SESSION_NAME = "ai_terminal_x_viewer"
VISUAL_TERMINAL = "xfce4-terminal"

ai_model = None
api_key = None
persistent_viewer_active = False

def check_external_tools():
    required_tools = ["tmux", VISUAL_TERMINAL, "xclip"]
    for tool in required_tools:
        if not shutil.which(tool):
            print(f"Error: {tool} is not installed or not in PATH.")
            exit(1)

def check_tmux_session(session_name):
    result = subprocess.run(["tmux", "has-session", "-t", session_name], capture_output=True)
    return result.returncode == 0

def configure_ai(api_key):
    try:
        gemini.configure(api_key)
        return gemini.Model("gemini-1.5-flash-latest")
    except Exception as e:
        print(f"Error configuring AI: {e}")
        exit(1)

def explain_command(model, command_input):
    prompt = f"Explain the following command: {command_input}"
    response = model.chat(prompt)
    return response.text

def gemini_command_and_explanation(model, user_input):
    if not user_input.strip():
        return None, None
    prompt = f"Generate a Linux command for: {user_input}"
    response = model.chat(prompt)
    return response.text, response.explanation

def get_user_input(prompt):
    return input(prompt)

def handle_command_execution(ai_generated_command, primary_mode, execution_mode, user_input_request):
    log_command(ai_generated_command, execution_mode)
    if primary_mode == "persistent":
        send_command_to_tmux_viewer(TMUX_VIEWER_SESSION_NAME, ai_generated_command)
    else:
        run_visual_pause_window(ai_generated_command)

def launch_persistent_viewer_if_needed():
    if not check_tmux_session(TMUX_VIEWER_SESSION_NAME):
        subprocess.run([VISUAL_TERMINAL, "-e", f"tmux new-session -s {TMUX_VIEWER_SESSION_NAME}"])

def load_api_key():
    load_dotenv()
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        api_key = get_user_input("Enter your Google Gemini API key: ")
    return api_key

def run_main_loop():
    while True:
        user_input = get_user_input("Enter your request: ")
        if user_input.lower() in ["quit", "exit"]:
            break
        ai_generated_command, explanation = gemini_command_and_explanation(ai_model, user_input)
        if ai_generated_command:
            print(f"Generated Command: {ai_generated_command}")
            print(f"Explanation: {explanation}")
            handle_command_execution(ai_generated_command, primary_mode, execution_mode, user_input)

def run_visual_pause_window(command_to_execute):
    subprocess.run([VISUAL_TERMINAL, "--hold", "-e", command_to_execute])

def select_execution_mode():
    mode = get_user_input("Select execution mode (persistent/separate): ").strip().lower()
    return mode

def send_command_to_tmux_viewer(session_name, command):
    try:
        subprocess.run(["tmux", "send-keys", "-t", session_name, command, "Enter"])
    except Exception as e:
        print(f"Error sending command to tmux viewer: {e}")
        persistent_viewer_active = False

def send_interrupt_to_tmux_viewer(session_name):
    try:
        subprocess.run(["tmux", "send-keys", "-t", session_name, "C-c"])
    except Exception as e:
        print(f"Error sending interrupt to tmux viewer: {e}")

def validate_command_risk(model, command_to_check):
    if not command_to_check.strip():
        return None
    prompt = f"Is the following command risky: {command_to_check}"
    response = model.chat(prompt)
    return response.text

if __name__ == "__main__":
    check_external_tools()
    api_key = load_api_key()
    ai_model = configure_ai(api_key)
    primary_mode = select_execution_mode()
    execution_mode = "persistent" if primary_mode == "persistent" else "separate"
    launch_persistent_viewer_if_needed()
    run_main_loop()