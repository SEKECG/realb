import os
import sqlite3
import csv
import configparser
import threading
import subprocess
import sys

SPEAK = "espeak.exe"
browser = "chrome"
cfgfile = "feedln.cfg"
database = "feeds.db"
editor = "notepad"
feedfile = "feeds.csv"
logfile = "feedln.log"
media = "vlc"
reqtimeout = 30
version = "1.0"

class InterruptibleTTS:
    def __init__(self):
        self.enabled = False
        self.speaking = False
        self.thread = None

    def speak(self, text):
        def run_speak():
            self.speaking = True
            subprocess.run([SPEAK, text])
            self.speaking = False

        if self.speaking:
            self.stop()
        self.thread = threading.Thread(target=run_speak)
        self.thread.start()

    def stop(self):
        if self.speaking:
            subprocess.run(["taskkill", "/IM", SPEAK, "/F"])
            self.speaking = False

def check_feed_file():
    if not os.path.exists(feedfile):
        with open(feedfile, 'w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(["Name", "URL", "Tags"])
            writer.writerow(["Sample Feed", "http://example.com/rss", "sample,example"])

def footer(text, color=None):
    print(f"\033[{color}m{text}\033[0m" if color else text)

def footerpop(text, delay, color=None):
    footer(text, color)
    time.sleep(delay)

def format_file_size(size_in_bytes):
    for unit in ['Bytes', 'KB', 'MB', 'GB']:
        if size_in_bytes < 1024.0:
            return f"{size_in_bytes:.2f} {unit}"
        size_in_bytes /= 1024.0

def header(text):
    print(f"Header: {text}")

def is_program_installed(program_name):
    result = subprocess.run(['where', program_name], capture_output=True, text=True)
    return result.returncode == 0

def load_config():
    config = configparser.ConfigParser()
    if os.path.exists(cfgfile):
        config.read(cfgfile)
        global media, browser, editor, reqtimeout
        media = config.get('Settings', 'media', fallback=media)
        browser = config.get('Settings', 'browser', fallback=browser)
        editor = config.get('Settings', 'editor', fallback=editor)
        reqtimeout = config.getint('Settings', 'reqtimeout', fallback=reqtimeout)

def load_feeds_to_db(csv_file, conn):
    with open(csv_file, 'r') as file:
        reader = csv.DictReader(file)
        cursor = conn.cursor()
        for row in reader:
            cursor.execute("INSERT OR IGNORE INTO feeds (name, url, tags) VALUES (?, ?, ?)", (row['Name'], row['URL'], row['Tags']))
        conn.commit()

def log_event(message):
    with open(logfile, 'a') as file:
        file.write(f"{message}\n")

def main():
    check_feed_file()
    load_config()
    conn = setup_database()
    args = parse_arguments()
    load_feeds_to_db(args.csv_file, conn)
    conn.close()

def parse_arguments():
    import argparse
    parser = argparse.ArgumentParser(description="Feedln - RSS Feed Reader")
    parser.add_argument('csv_file', help="CSV file containing RSS feed information")
    return parser.parse_args()

def run_program(param):
    try:
        subprocess.run(param, check=True)
    except subprocess.CalledProcessError as e:
        print(f"Error: {e}")

def setup_database():
    conn = sqlite3.connect(database)
    cursor = conn.cursor()
    cursor.execute("CREATE TABLE IF NOT EXISTS feeds (name TEXT, url TEXT, tags TEXT, PRIMARY KEY (name, url))")
    cursor.execute("CREATE TABLE IF NOT EXISTS categories (name TEXT PRIMARY KEY)")
    cursor.execute("CREATE TABLE IF NOT EXISTS feed_items (title TEXT, summary TEXT, content TEXT, read_status INTEGER, feed_name TEXT, FOREIGN KEY (feed_name) REFERENCES feeds (name))")
    cursor.execute("CREATE TABLE IF NOT EXISTS feed_category (feed_name TEXT, category_name TEXT, FOREIGN KEY (feed_name) REFERENCES feeds (name), FOREIGN KEY (category_name) REFERENCES categories (name))")
    conn.commit()
    return conn

if __name__ == "__main__":
    main()