import streamlit as st
from utils import load_css, init_watsonx, run_watson_granite, show_error, show_info, show_success, show_warning

# Initialize WatsonX credentials
watsonx_model = init_watsonx()

# Load custom CSS
load_css()

# Define columns for layout
col1, col2, col3, col4 = st.columns(4)

# Inspirational quotes
quotes = [
    "The best way to predict the future is to create it.",
    "Education is the most powerful weapon which you can use to change the world.",
    "The beautiful thing about learning is that no one can take it away from you.",
    "The mind is not a vessel to be filled, but a fire to be ignited."
]

# Display random inspirational quote
import random
quote = random.choice(quotes)
st.sidebar.markdown(f"**Inspirational Quote:** {quote}")

# Team information columns
team_col1, team_col2, team_col3, team_col4, team_col5, team_col6 = st.columns(6)

# Team information
team_info = [
    ("M Ibrahim Qasmi", "Team Leader, Data Science Specialist"),
    ("TIJANI S. OLALEKAN", "Software Engineer, Development Specialist"),
    ("Maryam Sikander", "ML Engineer, Machine Learning Specialist"),
    ("Ahmad Fakhar", "Data Analyst"),
    ("M Jawad", "Data Analyst"),
    ("TAYYAB SAJJAD", "Web Expert, Web Development Specialist")
]

# Display team information
for col, (name, role) in zip([team_col1, team_col2, team_col3, team_col4, team_col5, team_col6], team_info):
    col.markdown(f"**{name}**\n{role}")

# Main application functionality
st.title("EduNexus 2.0")

# Personalized Learning
st.header("Personalized Learning")
st.write("Offers customized learning plans tailored to individual needs and goals.")

# Smart Summaries
st.header("Smart Summaries")
st.write("Converts lengthy documents into concise, easy-to-digest summaries.")

# AI Code Mentor
st.header("AI Code Mentor")
st.write("Provides real-time coding assistance and expert reviews for programming-related queries.")

# Study Planner
st.header("Study Planner")
st.write("Helps users create and manage effective study schedules.")

# Real-time Support
st.header("Real-time Support")
st.write("Delivers instant answers to academic questions.")

# Multi-Language Support
st.header("Multi-Language Support")
st.write("Accommodates users from different linguistic backgrounds.")

# Mental Wellness Resources
st.header("Mental Wellness Resources")
st.write("Offers support and materials for maintaining mental well-being during studies.")

# AI-Generated Study Resources
st.header("AI-Generated Study Resources")
st.write("Provides automatically generated study materials to aid learning.")

# Error handling and user feedback
try:
    # Example usage of WatsonX model
    prompt = "Generate a summary for the following text..."
    system_prompt = "Summarize the text in a concise manner."
    summary = run_watson_granite(prompt, system_prompt)
    st.write(summary)
except Exception as e:
    show_error(f"An error occurred: {e}")

# Display success message
show_success("EduNexus 2.0 loaded successfully!")