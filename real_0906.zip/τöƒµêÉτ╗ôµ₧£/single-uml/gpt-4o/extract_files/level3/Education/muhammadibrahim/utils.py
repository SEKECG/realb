import streamlit as st
import requests
import os

def load_css():
    st.markdown(
        """
        <style>
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            transition: 0.3s;
        }
        .card:hover {
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }
        </style>
        """,
        unsafe_allow_html=True
    )

def init_watsonx():
    api_key = os.getenv("WATSONX_API_KEY")
    url = os.getenv("WATSONX_URL")
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}"
    }
    return {"url": url, "headers": headers}

def run_watson_granite(prompt, system_prompt):
    watsonx = init_watsonx()
    payload = {
        "prompt": prompt,
        "system_prompt": system_prompt
    }
    try:
        response = requests.post(watsonx["url"], headers=watsonx["headers"], json=payload)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        show_error(f"Error: {e}")
        return None

def show_error(message):
    st.error(f"⚠️ {message}")

def show_info(message):
    st.info(f"ℹ️ {message}")

def show_success(message):
    st.success(f"✅ {message}")

def show_warning(message):
    st.warning(f"⚠️ {message}")