import argparse
import importlib
import logging
import sys
from src.Game import Game
from src.Player import Player
from src.AgentBase import AgentBase
from src.NaiveAgent import NaiveAgent

def main():
    parser = argparse.ArgumentParser(description="Hex Game")
    parser.add_argument("--player1", type=str, default="NaiveAgent", help="Path to player 1 agent")
    parser.add_argument("--player2", type=str, default="NaiveAgent", help="Path to player 2 agent")
    parser.add_argument("--board_size", type=int, default=11, help="Size of the Hex board")
    parser.add_argument("--log", type=str, default=None, help="Log file destination")
    parser.add_argument("--verbose", action="store_true", help="Enable verbose logging")
    parser.add_argument("--silent", action="store_true", help="Disable all output")
    args = parser.parse_args()

    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO, filename=args.log, filemode='w')
    logger = logging.getLogger()

    try:
        p1_module = importlib.import_module(f"agents.{args.player1}")
        p1_class = getattr(p1_module, args.player1)
        p1 = p1_class()
    except (ImportError, AttributeError) as e:
        logger.error(f"Error loading player 1: {e}")
        sys.exit(1)

    try:
        p2_module = importlib.import_module(f"agents.{args.player2}")
        p2_class = getattr(p2_module, args.player2)
        p2 = p2_class()
    except (ImportError, AttributeError) as e:
        logger.error(f"Error loading player 2: {e}")
        sys.exit(1)

    player1 = Player(p1)
    player2 = Player(p2)

    game = Game(player1, player2, args.board_size, args.log, args.verbose, args.silent)
    game.run()

if __name__ == "__main__":
    main()