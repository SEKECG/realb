# Player.py

from src.AgentBase import AgentBase

class Player:
    def __init__(self, name, agent, move_time=0, turn=0):
        self.name = name
        self.agent = agent
        self.move_time = move_time
        self.turn = turn

    def __eq__(self, other):
        if isinstance(other, Player):
            return (self.agent.__hash__() == other.agent.__hash__() and
                    self.name == other.name and
                    self.move_time == other.move_time)
        return False

    def __str__(self):
        return f"Player(name={self.name}, agent={self.agent}, move_time={self.move_time}, turn={self.turn})"