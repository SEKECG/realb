# AgentBase.py

from src.Colour import Colour
from src.Move import Move

class AgentBase:
    def __init__(self, colour):
        self._colour = colour

    def make_move(self, turn, board, opp_move):
        raise NotImplementedError("Subclasses should implement this method")

    def __hash__(self):
        return hash(self.__class__.__name__)

    @property
    def colour(self):
        return self._colour

    @colour.setter
    def colour(self, colour):
        self._colour = colour

    def opp_colour(self):
        return Colour.opposite(self._colour)