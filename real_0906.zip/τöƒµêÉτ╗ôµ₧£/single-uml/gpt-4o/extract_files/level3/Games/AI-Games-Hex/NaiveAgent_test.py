import pytest
from src.Board import Board
from src.Move import Move
from agents.NaiveAgent import NaiveAgent
from src.Colour import Colour

@pytest.fixture
def mock_board():
    return Board(11)

@pytest.fixture
def naive_agent():
    return NaiveAgent(Colour.RED)

def test_naive_agent_initialization(naive_agent):
    assert naive_agent._board_size == 11
    assert naive_agent.colour == Colour.RED

def test_naive_agent_make_move_first_turn(naive_agent, mock_board):
    move = naive_agent.make_move(1, mock_board, None)
    assert isinstance(move, Move)
    assert 0 <= move.x < 11
    assert 0 <= move.y < 11

def test_naive_agent_make_move_swap_turn(naive_agent, mock_board):
    move = naive_agent.make_move(2, mock_board, Move(-1, -1))
    assert isinstance(move, Move)
    assert move.x == -1
    assert move.y == -1

def test_naive_agent_make_move_with_opponent_move(naive_agent, mock_board):
    opp_move = Move(5, 5)
    move = naive_agent.make_move(3, mock_board, opp_move)
    assert isinstance(move, Move)
    assert 0 <= move.x < 11
    assert 0 <= move.y < 11
    assert (move.x, move.y) != (5, 5)