# Board.py

from src.Tile import Tile
from src.Colour import Colour

class Board:
    def __init__(self, board_size):
        self.size = board_size
        self.tiles = [[Tile(x, y) for y in range(board_size)] for x in range(board_size)]
        self._winner = None

    def __str__(self):
        return self.print_board()

    def __eq__(self, value):
        if not isinstance(value, Board):
            return False
        return self.size == value.size and self.tiles == value.tiles

    def clear_tiles(self):
        for row in self.tiles:
            for tile in row:
                tile.clear_visit()

    @staticmethod
    def from_string(string_input, board_size):
        board = Board(board_size)
        lines = string_input.strip().split('\n')
        for x, line in enumerate(lines):
            for y, char in enumerate(line.strip()):
                board.set_tile_colour(x, y, Colour.from_char(char))
        return board

    def get_winner(self):
        return self._winner

    def has_ended(self, colour):
        self.clear_tiles()
        if colour == Colour.RED:
            for y in range(self.size):
                if self.DFS_colour(0, y, colour):
                    self._winner = colour
                    return True
        elif colour == Colour.BLUE:
            for x in range(self.size):
                if self.DFS_colour(x, 0, colour):
                    self._winner = colour
                    return True
        return False

    def print_board(self):
        board_str = ""
        for row in self.tiles:
            board_str += " ".join([tile.colour.get_char() for tile in row]) + "\n"
        return board_str

    def set_tile_colour(self, x, y, colour):
        self.tiles[x][y].colour = colour

    def DFS_colour(self, x, y, colour):
        if x < 0 or y < 0 or x >= self.size or y >= self.size:
            return False
        tile = self.tiles[x][y]
        if tile.is_visited() or tile.colour != colour:
            return False
        tile.visit()
        if colour == Colour.RED and x == self.size - 1:
            return True
        if colour == Colour.BLUE and y == self.size - 1:
            return True
        for dx, dy in zip(Tile.I_DISPLACEMENTS, Tile.J_DISPLACEMENTS):
            if self.DFS_colour(x + dx, y + dy, colour):
                return True
        return False

    @property
    def size(self):
        return self._size

    @property
    def tiles(self):
        return self._tiles