import random
from src.AgentBase import AgentBase
from src.Move import Move

class NaiveAgent(AgentBase):
    def __init__(self, colour):
        super().__init__(colour)
        self._board_size = 11
        self._choices = [(x, y) for x in range(self._board_size) for y in range(self._board_size)]

    def make_move(self, turn, board, opp_move):
        if turn == 2 and random.choice([True, False]):
            return Move(-1, -1)  # Swap move
        while True:
            move = random.choice(self._choices)
            if board.is_valid_move(move[0], move[1], self.colour):
                return Move(move[0], move[1])