import time
import logging
from src.Board import Board
from src.Player import Player
from src.Colour import Colour
from src.EndState import EndState

logger = logging.getLogger(__name__)

def format_result(player1_name, player2_name, winner, win_method, player_1_move_time, player_2_move_time, player_1_turn, player_2_turn, total_turns, total_time):
    return {
        "player1_name": player1_name,
        "player2_name": player2_name,
        "winner": winner,
        "win_method": win_method,
        "player_1_move_time": player_1_move_time,
        "player_2_move_time": player_2_move_time,
        "player_1_turn": player_1_turn,
        "player_2_turn": player_2_turn,
        "total_turns": total_turns,
        "total_time": total_time
    }

class Game:
    MAXIMUM_TIME = 60 * 60 * 1000000000  # 1 hour in nanoseconds

    def __init__(self, player1, player2, board_size=11, logDest=None, verbose=False, silent=False):
        self._board = Board(board_size)
        self._start_time = time.time_ns()
        self.board = self._board
        self.current_player = player1
        self.player1 = player1
        self.player2 = player2
        self.turn = 1
        if logDest:
            logging.basicConfig(filename=logDest, level=logging.DEBUG if verbose else logging.INFO)
        if silent:
            logging.disable(logging.CRITICAL)

    def _end_game(self, status):
        total_time = time.time_ns() - self._start_time
        result = format_result(
            self.player1.name, self.player2.name, status["winner"], status["win_method"],
            self.player1.move_time, self.player2.move_time, self.player1.turn, self.player2.turn,
            self.turn, total_time
        )
        logger.info(result)
        return result

    def _make_move(self, m):
        if self.is_valid_move(m, self.turn, self.board):
            self.board.set_tile_colour(m.x, m.y, self.current_player.colour)
            self.turn += 1
            self.current_player = self.player2 if self.current_player == self.player1 else self.player1
            logger.info(f"Move made: {m}")
        else:
            logger.error(f"Invalid move: {m}")
            raise ValueError("Invalid move")

    def _play(self):
        while not self.board.has_ended(self.current_player.colour):
            try:
                move = self.current_player.agent.make_move(self.turn, self.board, None)
                self._make_move(move)
            except Exception as e:
                logger.error(f"Error during move: {e}")
                return self._end_game({"winner": self.current_player.name, "win_method": EndState.BAD_MOVE})
        return self._end_game({"winner": self.current_player.name, "win_method": EndState.WIN})

    @property
    def board(self):
        return self._board

    @staticmethod
    def is_valid_move(move, turn, board):
        if move.x < 0 or move.x >= board.size or move.y < 0 or move.y >= board.size:
            return False
        return board.tiles[move.x][move.y].colour == Colour.NONE

    @staticmethod
    def ns_to_s(t):
        return t / 1000000000

    def run(self):
        return self._play()

    @property
    def turn(self):
        return self._turn