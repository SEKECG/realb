from enum import Enum

class Colour(Enum):
    RED = 'R'
    BLUE = 'B'

    @staticmethod
    def from_char(c):
        if c.upper() == 'R':
            return Colour.RED
        elif c.upper() == 'B':
            return Colour.BLUE
        else:
            raise ValueError(f"Invalid colour character: {c}")

    @staticmethod
    def get_char(colour):
        if colour == Colour.RED:
            return 'R'
        elif colour == Colour.BLUE:
            return 'B'
        else:
            raise ValueError(f"Invalid colour: {colour}")

    @staticmethod
    def opposite(colour):
        if colour == Colour.RED:
            return Colour.BLUE
        elif colour == Colour.BLUE:
            return Colour.RED
        else:
            raise ValueError(f"Invalid colour: {colour}")