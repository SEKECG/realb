from enum import Enum

class EndState(Enum):
    BAD_MOVE = "BAD_MOVE"
    FAILED_LOAD = "FAILED_LOAD"
    TIMEOUT = "TIMEOUT"
    WIN = "WIN"