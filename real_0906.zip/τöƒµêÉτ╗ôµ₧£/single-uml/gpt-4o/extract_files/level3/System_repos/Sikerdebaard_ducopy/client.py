import requests
import pkg_resources
from models import NodesResponse, ConfigNodeResponse, ActionsResponse, NodeInfo, NodesInfoResponse

class APIClient:
    def __init__(self, base_url, verify):
        self.base_url = base_url
        self.session = requests.Session()
        self.session.verify = verify
        if verify:
            self.session.mount('https://', CustomHostNameCheckingAdapter(ssl_context=self._duco_pem(), hostname_resolver=custom_host_mapping))

    def _duco_pem(self):
        return pkg_resources.resource_filename(__name__, 'duco.pem')

    def close(self):
        self.session.close()

    def get_action(self, action):
        url = f"{self.base_url}/actions/{action}"
        response = self.session.get(url)
        response.raise_for_status()
        return response.json()

    def get_actions_node(self, node_id, action=None):
        url = f"{self.base_url}/nodes/{node_id}/actions"
        if action:
            url += f"/{action}"
        response = self.session.get(url)
        response.raise_for_status()
        return ActionsResponse(**response.json())

    def get_api_info(self):
        url = f"{self.base_url}/api/info"
        response = self.session.get(url)
        response.raise_for_status()
        return response.json()

    def get_config_node(self, node_id):
        url = f"{self.base_url}/nodes/{node_id}/config"
        response = self.session.get(url)
        response.raise_for_status()
        return ConfigNodeResponse(**response.json())

    def get_config_nodes(self):
        url = f"{self.base_url}/nodes/config"
        response = self.session.get(url)
        response.raise_for_status()
        return NodesResponse(**response.json())

    def get_info(self, module, submodule=None, parameter=None):
        url = f"{self.base_url}/info/{module}"
        if submodule:
            url += f"/{submodule}"
        if parameter:
            url += f"/{parameter}"
        response = self.session.get(url)
        response.raise_for_status()
        return response.json()

    def get_logs(self):
        url = f"{self.base_url}/logs"
        response = self.session.get(url)
        response.raise_for_status()
        return response.json()

    def get_node_info(self, node_id):
        url = f"{self.base_url}/nodes/{node_id}/info"
        response = self.session.get(url)
        response.raise_for_status()
        return NodeInfo(**response.json())

    def get_nodes(self):
        url = f"{self.base_url}/nodes"
        response = self.session.get(url)
        response.raise_for_status()
        return NodesInfoResponse(**response.json())

    def patch_config_node(self, node_id, config):
        url = f"{self.base_url}/nodes/{node_id}/config"
        response = self.session.patch(url, json=config.dict())
        response.raise_for_status()
        return ConfigNodeResponse(**response.json())

    def post_action_node(self, action, value, node_id):
        url = f"{self.base_url}/nodes/{node_id}/actions"
        payload = {"action": action, "value": value}
        response = self.session.post(url, json=payload)
        response.raise_for_status()
        return ActionsChangeResponse(**response.json())

    def raw_get(self, endpoint, params=None):
        url = f"{self.base_url}{endpoint}"
        response = self.session.get(url, params=params)
        response.raise_for_status()
        return response.json()