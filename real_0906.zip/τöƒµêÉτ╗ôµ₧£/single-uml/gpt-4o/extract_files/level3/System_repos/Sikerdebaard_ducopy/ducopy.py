import requests
from client import APIClient
from models import ActionsChangeResponse, ActionsResponse, ConfigNodeResponse, NodesResponse, NodeInfo, NodesInfoResponse

class DucoPy:
    def __init__(self, base_url, verify=True):
        self.client = APIClient(base_url, verify)

    def change_action_node(self, action, value, node_id):
        return self.client.post_action_node(action, value, node_id)

    def close(self):
        self.client.close()

    def get_action(self, action):
        return self.client.get_action(action)

    def get_actions_node(self, node_id, action=None):
        return self.client.get_actions_node(node_id, action)

    def get_api_info(self):
        return self.client.get_api_info()

    def get_config_node(self, node_id):
        return self.client.get_config_node(node_id)

    def get_config_nodes(self):
        return self.client.get_config_nodes()

    def get_info(self, module, submodule=None, parameter=None):
        return self.client.get_info(module, submodule, parameter)

    def get_logs(self):
        return self.client.get_logs()

    def get_node_info(self, node_id):
        return self.client.get_node_info(node_id)

    def get_nodes(self):
        return self.client.get_nodes()

    def raw_get(self, endpoint, params=None):
        return self.client.raw_get(endpoint, params)

    def update_config_node(self, node_id, config):
        return self.client.patch_config_node(node_id, config)