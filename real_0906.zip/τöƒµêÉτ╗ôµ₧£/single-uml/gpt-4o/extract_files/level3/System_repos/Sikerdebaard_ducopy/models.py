```python
from typing import Optional, List, Dict, Any, Union
from pydantic import BaseModel, Field, validator

PYDANTIC_V2 = False

def extract_val(data: Any) -> Union[str, int, dict]:
    if isinstance(data, dict) and "Val" in data:
        return data["Val"]
    return data

def unified_validator(*uargs, **ukwargs):
    def decorator(func):
        return func
    return decorator

class ParameterConfig(BaseModel):
    Id: Optional[int] = None
    Inc: Optional[int] = None
    Max: Optional[int] = None
    Min: Optional[int] = None

    @classmethod
    def ensure_keys(cls, values: Dict[str, Any]) -> Dict[str, Any]:
        keys = ["Id", "Inc", "Max", "Min"]
        for key in keys:
            if key not in values:
                values[key] = None
        return values

class ConfigNodeRequest(BaseModel):
    Co2SetPoint: Optional[int] = None
    FlowLvlAutoMax: Optional[int] = None
    FlowLvlAutoMin: Optional[int] = None
    FlowLvlMan1: Optional[int] = None
    FlowLvlMan2: Optional[int] = None
    FlowLvlMan3: Optional[int] = None
    FlowLvlSwitch: Optional[int] = None
    FlowMax: Optional[int] = None
    Name: Optional[str] = None
    RhDetMode: Optional[int] = None
    RhSetPoint: Optional[int] = None
    ShowSensorLvl: Optional[int] = None
    SwitchMode: Optional[int] = None
    TempDepEnable: Optional[int] = None
    TimeMan: Optional[int] = None

class ConfigNodeResponse(BaseModel):
    Co2SetPoint: Optional[ParameterConfig] = None
    FlowLvlAutoMax: Optional[ParameterConfig] = None
    FlowLvlAutoMin: Optional[ParameterConfig] = None
    FlowLvlMan1: Optional[ParameterConfig] = None
    FlowLvlMan2: Optional[ParameterConfig] = None
    FlowLvlMan3: Optional[ParameterConfig] = None
    FlowLvlSwitch: Optional[ParameterConfig] = None
    FlowMax: Optional[ParameterConfig] = None
    Name: Optional[ParameterConfig] = None
    RhDetMode: Optional[ParameterConfig] = None
    RhSetPoint: Optional[ParameterConfig] = None
    SerialBoard: str
    SerialDuco: str
    ShowSensorLvl: Optional[ParameterConfig] = None
    SwitchMode: Optional[ParameterConfig] = None
    TempDepEnable: Optional[ParameterConfig] = None
    TimeMan: Optional[ParameterConfig] = None

class ActionInfo(BaseModel):
    @classmethod
    def set_optional_enum(cls, values: Dict[str, Any]) -> Dict[str, Any]:
        if values.get("ValType") != "Enum":
            values.pop("Enum", None)
        return values

class ActionsResponse(BaseModel):
    pass

class ActionsChangeResponse(BaseModel):
    pass

class NodeInfo(BaseModel):
    Sensor: Optional['SensorData'] = None

class NodesResponse(BaseModel):
    pass

class NodesInfoResponse(BaseModel):
    Nodes: Optional[List[NodeInfo]] = None

class GeneralInfo(BaseModel):
    Id: Optional[int] = None

class NetworkDucoInfo(BaseModel):
    CommErrorCtr: int

    @classmethod
    def validate_comm_error_ctr(cls, values: Dict[str, Any]) -> Dict[str, Any]:
        values["CommErrorCtr"] = extract_val(values.get("CommErrorCtr", {}))
        return values

class NodeConfig(BaseModel):
    Co2SetPoint: Optional[ParameterConfig] = None
    FlowLvlAutoMax: Optional[ParameterConfig] = None
    FlowLvlAutoMin: Optional[ParameterConfig] = None
    FlowLvlMan1: Optional[ParameterConfig] = None
    FlowLvlMan2: Optional[ParameterConfig] = None
    FlowLvlMan3: Optional[ParameterConfig] = None
    FlowLvlSwitch: Optional[ParameterConfig] = None
    FlowMax: Optional[ParameterConfig] = None
    Name: Optional[ParameterConfig] = None
    RhDetMode: Optional[ParameterConfig] = None
    RhSetPoint: Optional[ParameterConfig] = None
    SerialBoard: str
    SerialDuco: str
    ShowSensorLvl: Optional[ParameterConfig] = None
    SwitchMode: Optional[ParameterConfig] = None
    TempDepEnable: Optional[ParameterConfig] = None
    TimeMan: Optional[ParameterConfig] = None

class NodeGeneralInfo(BaseModel):
    Addr: int

    @classmethod
    def validate_addr(cls, values: Dict[str, Any]) -> Dict[str, Any]:
        values["Addr"] = extract_val(values.get("Addr", {}))
        return values

class SensorData(BaseModel):
    data: Optional[Dict[str, Union[int, float, str]]] = None

    @classmethod
    def extract_sensor_values(cls, values: Dict[str, Any]) -> Dict[str, Any]:
        if "data" in values:
            values["data"] = {k: extract_val(v) for k, v in values["data"].items()}
        return values

class VentilationInfo(BaseModel):
    FlowLvlOvrl: int
    FlowLvlTgt: Optional[int] = None
    Mode: Optional[str] = None
    State: Optional[str] = None
    TimeStateEnd: Optional[int] = None
    TimeStateRemain: Optional[int] = None

    @classmethod
    def validate_ventilation_fields(cls, values: Dict[str, Any]) -> Dict[str, Any]:
        for field in ["FlowLvlOvrl", "FlowLvlTgt", "Mode", "State", "TimeStateEnd", "TimeStateRemain"]:
            if field in values:
                values[field] = extract_val(values[field])
        return values

class FirmwareResponse(BaseModel):
    pass
```