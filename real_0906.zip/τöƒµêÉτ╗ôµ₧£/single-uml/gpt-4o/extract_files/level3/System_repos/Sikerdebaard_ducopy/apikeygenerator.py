import hashlib
import time

class ApiKeyGenerator:
    def generate_api_key(self, board_serial, mac_address, timestamp):
        combined_string = f"{board_serial}{mac_address}{timestamp}"
        hashed_string = hashlib.sha256(combined_string.encode()).hexdigest()
        transformed_key = ''.join([self.transform_char(hashed_string[i], hashed_string[i+1]) for i in range(0, len(hashed_string), 2)])
        return transformed_key

    def transform_char(self, c1, c2):
        xor_result = ord(c1) ^ ord(c2)
        adjusted_char = chr((xor_result % 94) + 33)
        return adjusted_char

if __name__ == "__main__":
    generator = ApiKeyGenerator()
    board_serial = "1234567890"
    mac_address = "00:1A:2B:3C:4D:5E"
    timestamp = int(time.time())
    api_key = generator.generate_api_key(board_serial, mac_address, timestamp)
    print(f"Generated API Key: {api_key}")