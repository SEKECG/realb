import requests
import typer
from loguru import logger
from pydantic import BaseModel, HttpUrl

from client import APIClient
from models import ActionsResponse, ConfigNodeResponse, NodesResponse, NodeInfo, NodesInfoResponse
from utils import custom_host_mapping

app = typer.Typer()

class URLModel(BaseModel):
    url: HttpUrl

def setup_logging(level):
    logger.remove()
    logger.add(sys.stderr, level=level)

@app.command()
def configure(logging_level: str):
    setup_logging(logging_level)

@app.command()
def entry_point():
    app()

@app.command()
def change_action_node(base_url: str, node_id: int, action: str, value: str, format: str):
    client = APIClient(base_url)
    response = client.post_action_node(action, value, node_id)
    print_output(response, format)
    client.close()

@app.command()
def get_action(base_url: str, action: str, format: str):
    client = APIClient(base_url)
    response = client.get_action(action)
    print_output(response, format)
    client.close()

@app.command()
def get_actions_node(base_url: str, node_id: int, action: str, format: str):
    client = APIClient(base_url)
    response = client.get_actions_node(node_id, action)
    print_output(response, format)
    client.close()

@app.command()
def get_api_info(base_url: str, format: str):
    client = APIClient(base_url)
    response = client.get_api_info()
    print_output(response, format)
    client.close()

@app.command()
def get_config_node(base_url: str, node_id: int, format: str):
    client = APIClient(base_url)
    response = client.get_config_node(node_id)
    print_output(response, format)
    client.close()

@app.command()
def get_config_nodes(base_url: str, format: str):
    client = APIClient(base_url)
    response = client.get_config_nodes()
    print_output(response, format)
    client.close()

@app.command()
def get_info(base_url: str, module: str, submodule: str, parameter: str, format: str):
    client = APIClient(base_url)
    response = client.get_info(module, submodule, parameter)
    print_output(response, format)
    client.close()

@app.command()
def get_logs(base_url: str, format: str):
    client = APIClient(base_url)
    response = client.get_logs()
    print_output(response, format)
    client.close()

@app.command()
def get_node_info(base_url: str, node_id: int, format: str):
    client = APIClient(base_url)
    response = client.get_node_info(node_id)
    print_output(response, format)
    client.close()

@app.command()
def get_nodes(base_url: str, format: str):
    client = APIClient(base_url)
    response = client.get_nodes()
    print_output(response, format)
    client.close()

@app.command()
def raw_get(url: str, params: str, format: str):
    client = APIClient("")
    response = client.raw_get(url, params)
    print_output(response, format)
    client.close()

@app.command()
def update_config_node(base_url: str, node_id: int, config_json: str, format: str):
    client = APIClient(base_url)
    config = ConfigNodeRequest.parse_raw(config_json)
    response = client.patch_config_node(node_id, config)
    print_output(response, format)
    client.close()

def print_output(data, format):
    if format == "pretty":
        print(data)
    elif format == "json":
        import json
        print(json.dumps(data, indent=4))
    else:
        raise ValueError("Invalid format specified")

if __name__ == "__main__":
    entry_point()