import json
import pandas as pd

class ExcelQuestionImporter:
    def __init__(self):
        pass

    def clean_non_standard_json(self, content):
        content = content.replace("'", '"')
        content = content.replace("True", "true").replace("False", "false")
        return content

    def recognize_tabular_questions(self, file_path):
        df = pd.read_excel(file_path)
        questions = []
        for index, row in df.iterrows():
            question = {
                "type": row["Type"],
                "content": row["Content"],
                "options": json.loads(self.clean_non_standard_json(row["Options"])),
                "answer": row["Answer"]
            }
            questions.append(question)
        return questions

client = ExcelQuestionImporter()