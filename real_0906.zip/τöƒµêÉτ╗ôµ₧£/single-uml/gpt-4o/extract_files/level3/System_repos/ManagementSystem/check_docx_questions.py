import json
from docx import Document

class DocxQuestionImporter:
    def __init__(self):
        pass

    def _read_from_word(self, file_path):
        document = Document(file_path)
        questions = []
        current_question = []
        for para in document.paragraphs:
            if para.text.strip() == "":
                if current_question:
                    questions.append("\n".join(current_question))
                    current_question = []
            else:
                current_question.append(para.text.strip())
        if current_question:
            questions.append("\n".join(current_question))
        return questions

    def clean_non_standard_json(self, content):
        content = content.replace("'", '"')
        content = content.replace("True", "true").replace("False", "false")
        return content

    def import_question_bank(self, file_path):
        questions = self._read_from_word(file_path)
        question_bank = []
        for question in questions:
            try:
                question_json = json.loads(self.clean_non_standard_json(question))
                question_bank.append(question_json)
            except json.JSONDecodeError:
                print(f"Error parsing question: {question}")
        return question_bank

if __name__ == "__main__":
    importer = DocxQuestionImporter()
    file_path = "path_to_your_docx_file.docx"
    question_bank = importer.import_question_bank(file_path)
    print(question_bank)