from flask import Flask, render_template, request, redirect, session
from models import db, Students, Teachers, Admins, Exams, QuestionBanks, Questions, StudentAnswers, StudentGrades, ExamQuestions, QuestionOptions
from methods import local_date, logger
from check_questions.check_docx_questions import DocxQuestionImporter
from check_questions.check_excel_questions import ExcelQuestionImporter

app = Flask(__name__)
app.secret_key = 'supersecretkey'

admin_module = AdminModule()
student_module = StudentModule()
teacher_module = TeacherModule()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        result = admin_module.login(username, password)
        if result:
            session['admin_id'] = result['admin_id']
            return redirect('/admin/dashboard')
        else:
            return render_template('admin_login.html', error="Invalid credentials")
    return render_template('admin_login.html')

@app.route('/admin/logout')
def admin_logout():
    session.pop('admin_id', None)
    return redirect('/')

@app.route('/admin/dashboard')
def admin_dashboard():
    if 'admin_id' not in session:
        return redirect('/admin/login')
    return render_template('admin_dashboard.html')

@app.route('/admin/add_student', methods=['GET', 'POST'])
def add_student():
    if request.method == 'POST':
        student_info = request.form.to_dict()
        admin_module.modify_student_account('create', student_info=student_info)
        return redirect('/admin/manage_students')
    return render_template('add_student.html')

@app.route('/admin/add_teacher', methods=['GET', 'POST'])
def add_teacher():
    if request.method == 'POST':
        teacher_info = request.form.to_dict()
        admin_module.modify_teacher_account('create', teacher_info=teacher_info)
        return redirect('/admin/manage_teachers')
    return render_template('add_teacher.html')

@app.route('/admin/manage_students')
def manage_students():
    if 'admin_id' not in session:
        return redirect('/admin/login')
    students = Students.query.all()
    return render_template('manage_students.html', students=students)

@app.route('/admin/manage_teachers')
def manage_teachers():
    if 'admin_id' not in session:
        return redirect('/admin/login')
    teachers = Teachers.query.all()
    return render_template('manage_teachers.html', teachers=teachers)

@app.route('/admin/delete_student/<student_id>')
def delete_student(student_id):
    admin_module.modify_student_account('delete', student_id=student_id)
    return redirect('/admin/manage_students')

@app.route('/admin/delete_teacher/<teacher_id>')
def delete_teacher(teacher_id):
    admin_module.modify_teacher_account('delete', teacher_id=teacher_id)
    return redirect('/admin/manage_teachers')

@app.route('/admin/update_student/<student_id>', methods=['GET', 'POST'])
def update_student(student_id):
    if request.method == 'POST':
        student_info = request.form.to_dict()
        admin_module.modify_student_account('update', student_id=student_id, student_info=student_info)
        return redirect('/admin/manage_students')
    student = Students.query.get(student_id)
    return render_template('update_student.html', student=student)

@app.route('/admin/update_teacher/<teacher_id>', methods=['GET', 'POST'])
def update_teacher(teacher_id):
    if request.method == 'POST':
        teacher_info = request.form.to_dict()
        admin_module.modify_teacher_account('update', teacher_id=teacher_id, teacher_info=teacher_info)
        return redirect('/admin/manage_teachers')
    teacher = Teachers.query.get(teacher_id)
    return render_template('update_teacher.html', teacher=teacher)

@app.route('/admin/view_logs')
def view_logs():
    if 'admin_id' not in session:
        return redirect('/admin/login')
    logs = logger.get_logs(local_date)
    return render_template('view_logs.html', logs=logs)

@app.route('/student/register', methods=['GET', 'POST'])
def student_register():
    if request.method == 'POST':
        student_info = request.form.to_dict()
        student_module.register(**student_info)
        return redirect('/student/login')
    return render_template('student_register.html')

@app.route('/student/login', methods=['GET', 'POST'])
def student_login():
    if request.method == 'POST':
        student_id = request.form['student_id']
        password = request.form['password']
        result = student_module.login(student_id, password)
        if result:
            session['student_id'] = result['student_id']
            return redirect('/student/dashboard')
        else:
            return render_template('student_login.html', error="Invalid credentials")
    return render_template('student_login.html')

@app.route('/student/logout')
def student_logout():
    session.pop('student_id', None)
    return redirect('/')

@app.route('/student/dashboard')
def student_dashboard():
    if 'student_id' not in session:
        return redirect('/student/login')
    exams = student_module.list_exams()
    return render_template('student_dashboard.html', exams=exams)

@app.route('/student/exam/<exam_id>', methods=['GET', 'POST'])
def take_exam(exam_id):
    if 'student_id' not in session:
        return redirect('/student/login')
    if request.method == 'POST':
        answers = request.form.to_dict()
        student_module.submit_exam_answers(session['student_id'], exam_id, answers)
        return redirect('/student/dashboard')
    exam = Exams.query.get(exam_id)
    questions = exam.questions
    return render_template('take_exam.html', exam=exam, questions=questions)

@app.route('/teacher/register', methods=['GET', 'POST'])
def teacher_register():
    if request.method == 'POST':
        teacher_info = request.form.to_dict()
        teacher_module.register(**teacher_info)
        return redirect('/teacher/login')
    return render_template('teacher_register.html')

@app.route('/teacher/login', methods=['GET', 'POST'])
def teacher_login():
    if request.method == 'POST':
        teacher_id = request.form['teacher_id']
        password = request.form['password']
        result = teacher_module.login(teacher_id, password)
        if result:
            session['teacher_id'] = result['teacher_id']
            return redirect('/teacher/dashboard')
        else:
            return render_template('teacher_login.html', error="Invalid credentials")
    return render_template('teacher_login.html')

@app.route('/teacher/logout')
def teacher_logout():
    session.pop('teacher_id', None)
    return redirect('/')

@app.route('/teacher/dashboard')
def teacher_dashboard():
    if 'teacher_id' not in session:
        return redirect('/teacher/login')
    exams = Exams.query.filter_by(teacher_id=session['teacher_id']).all()
    return render_template('teacher_dashboard.html', exams=exams)

@app.route('/teacher/create_exam', methods=['GET', 'POST'])
def create_exam():
    if 'teacher_id' not in session:
        return redirect('/teacher/login')
    if request.method == 'POST':
        exam_info = request.form.to_dict()
        teacher_module.create_exam(**exam_info)
        return redirect('/teacher/dashboard')
    question_banks = QuestionBanks.query.all()
    return render_template('create_exam.html', question_banks=question_banks)

@app.route('/teacher/edit_exam/<exam_id>', methods=['GET', 'POST'])
def edit_exam(exam_id):
    if 'teacher_id' not in session:
        return redirect('/teacher/login')
    if request.method == 'POST':
        exam_info = request.form.to_dict()
        teacher_module.edit_exam(exam_id, **exam_info)
        return redirect('/teacher/dashboard')
    exam = Exams.query.get(exam_id)
    return render_template('edit_exam.html', exam=exam)

@app.route('/teacher/delete_exam/<exam_id>')
def delete_exam(exam_id):
    if 'teacher_id' not in session:
        return redirect('/teacher/login')
    teacher_module.delete_exam(exam_id)
    return redirect('/teacher/dashboard')

@app.route('/teacher/grade_exam/<exam_id>', methods=['GET', 'POST'])
def grade_exam(exam_id):
    if 'teacher_id' not in session:
        return redirect('/teacher/login')
    if request.method == 'POST':
        grades = request.form.to_dict()
        teacher_module.grade_exam(exam_id, grades)
        return redirect('/teacher/dashboard')
    exam = Exams.query.get(exam_id)
    student_answers = StudentAnswers.query.filter_by(exam_id=exam_id).all()
    return render_template('grade_exam.html', exam=exam, student_answers=student_answers)

@app.route('/teacher/exam_report/<exam_id>')
def exam_report(exam_id):
    if 'teacher_id' not in session:
        return redirect('/teacher/login')
    report = teacher_module.generate_exam_report(exam_id)
    return render_template('exam_report.html', report=report)

if __name__ == '__main__':
    app.run(debug=True)