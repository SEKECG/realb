from datetime import datetime
from sqlalchemy import Column, Integer, String, ForeignKey, DateTime, Boolean, Text
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class BaseModel(Base):
    __abstract__ = True
    reserved1 = Column(String(50))
    reserved2 = Column(String(50))

class Students(BaseModel):
    __tablename__ = 'students'
    student_id = Column(Integer, primary_key=True)
    name = Column(String(100))
    password = Column(String(100))
    gender = Column(String(10))
    phone_number = Column(String(20))
    student_class = Column(String(50))
    answers = relationship("StudentAnswers", back_populates="student")
    grades = relationship("StudentGrades", back_populates="student")

class Teachers(BaseModel):
    __tablename__ = 'teachers'
    teacher_id = Column(Integer, primary_key=True)
    name = Column(String(100))
    password = Column(String(100))
    gender = Column(String(10))
    phone_number = Column(String(20))

class Admins(BaseModel):
    __tablename__ = 'admins'
    admin_id = Column(Integer, primary_key=True)
    name = Column(String(100))
    password = Column(String(100))
    phone_number = Column(String(20))

class QuestionBanks(BaseModel):
    __tablename__ = 'question_banks'
    id = Column(Integer, primary_key=True)
    name = Column(String(100))
    created_at = Column(DateTime, default=datetime.utcnow)
    questions = relationship("Questions", back_populates="question_bank")
    exams = relationship("Exams", back_populates="question_bank")

class Questions(BaseModel):
    __tablename__ = 'questions'
    id = Column(Integer, primary_key=True)
    question_bank_id = Column(Integer, ForeignKey('question_banks.id'))
    question_type = Column(String(50))
    content = Column(Text)
    answer = Column(Text)
    question_bank = relationship("QuestionBanks", back_populates="questions")
    options = relationship("QuestionOptions", back_populates="question")
    exam_questions = relationship("ExamQuestions", back_populates="question")
    student_answers = relationship("StudentAnswers", back_populates="question")

class QuestionOptions(BaseModel):
    __tablename__ = 'question_options'
    id = Column(Integer, primary_key=True)
    question_id = Column(Integer, ForeignKey('questions.id'))
    option_text = Column(Text)
    is_correct = Column(Boolean)
    question = relationship("Questions", back_populates="options")
    student_answers = relationship("StudentAnswers", back_populates="selected_option")

class Exams(BaseModel):
    __tablename__ = 'exams'
    id = Column(Integer, primary_key=True)
    name = Column(String(100))
    start_time = Column(DateTime)
    end_time = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)
    question_bank_id = Column(Integer, ForeignKey('question_banks.id'))
    question_bank = relationship("QuestionBanks", back_populates="exams")
    exam_questions = relationship("ExamQuestions", back_populates="exam")
    student_answers = relationship("StudentAnswers", back_populates="exam")
    student_grades = relationship("StudentGrades", back_populates="exam")

class ExamQuestions(BaseModel):
    __tablename__ = 'exam_questions'
    id = Column(Integer, primary_key=True)
    exam_id = Column(Integer, ForeignKey('exams.id'))
    question_id = Column(Integer, ForeignKey('questions.id'))
    score = Column(Integer)
    exam = relationship("Exams", back_populates="exam_questions")
    question = relationship("Questions", back_populates="exam_questions")

class StudentAnswers(BaseModel):
    __tablename__ = 'student_answers'
    id = Column(Integer, primary_key=True)
    student_id = Column(Integer, ForeignKey('students.student_id'))
    exam_id = Column(Integer, ForeignKey('exams.id'))
    question_id = Column(Integer, ForeignKey('questions.id'))
    answer_text = Column(Text)
    selected_option_id = Column(Integer, ForeignKey('question_options.id'))
    student = relationship("Students", back_populates="answers")
    exam = relationship("Exams", back_populates="student_answers")
    question = relationship("Questions", back_populates="student_answers")
    selected_option = relationship("QuestionOptions", back_populates="student_answers")

class StudentGrades(BaseModel):
    __tablename__ = 'student_grades'
    id = Column(Integer, primary_key=True)
    student_id = Column(Integer, ForeignKey('students.student_id'))
    exam_id = Column(Integer, ForeignKey('exams.id'))
    grade = Column(Integer)
    student = relationship("Students", back_populates="grades")
    exam = relationship("Exams", back_populates="student_grades")