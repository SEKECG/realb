import pandas as pd

EXISTING_OPTION_CHAINS_COLUMNS = ["symbol", "expirationDate", "strikePrice", "optionType", "bid", "ask", "totalVolume", "openInterest", "delta", "theta"]
OPTION_CHAINS_COLUMNS = ["symbol", "expirationDate", "strikePrice", "optionType", "bid", "ask", "totalVolume", "openInterest", "delta", "theta"]

class OptionChains:
    def __init__(self, option_chains_json):
        self.option_chains_json = option_chains_json
        self.call_option_chains_json = option_chains_json.get("callExpDateMap", {})
        self.put_option_chains_json = option_chains_json.get("putExpDateMap", {})
        self.option_chains_df = self._create_option_chains_df()

    def _create_option_chains_df(self):
        data = []
        for option_type, option_data in [("CALL", self.call_option_chains_json), ("PUT", self.put_option_chains_json)]:
            for exp_date, strikes in option_data.items():
                for strike, options in strikes.items():
                    for option in options:
                        data.append({
                            "symbol": option["symbol"],
                            "expirationDate": exp_date,
                            "strikePrice": float(strike),
                            "optionType": option_type,
                            "bid": option["bid"],
                            "ask": option["ask"],
                            "totalVolume": option["totalVolume"],
                            "openInterest": option["openInterest"],
                            "delta": option["delta"],
                            "theta": option["theta"]
                        })
        return pd.DataFrame(data, columns=OPTION_CHAINS_COLUMNS)

    def filter_option_candidates(self):
        df = self.option_chains_df.dropna(subset=["totalVolume", "openInterest", "bid", "ask"])
        df = df[(df["openInterest"] > 0) & ((df["ask"] - df["bid"]) <= 0.1)]
        return df

    def get_call_option_candidates_from_min_strike_price_and_min_premium_percentage(self, min_strike_price, min_premium, min_premium_percentage):
        df = self.filter_option_candidates()
        df = df[(df["optionType"] == "CALL") & (df["strikePrice"] >= min_strike_price)]
        df["premium"] = (df["bid"] + df["ask"]) / 2
        df["premium_percentage"] = df["premium"] / df["strikePrice"]
        df = df[(df["premium"] >= min_premium) & (df["premium_percentage"] >= min_premium_percentage)]
        return df.sort_values(by=["expirationDate", "premium", "delta"]).to_dict("records")

    def get_delta_from_option_symbol(self, option_symbol):
        df = self.option_chains_df
        return df[df["symbol"] == option_symbol]["delta"].values[0]

    def get_option_candidates_from_expiration_date_and_delta_range(self, min_expiration_date, min_delta, max_delta, min_premium_percentage, min_premium, option_type):
        df = self.filter_option_candidates()
        df = df[(df["expirationDate"] >= min_expiration_date) & (df["delta"] >= min_delta) & (df["delta"] <= max_delta) & (df["optionType"] == option_type)]
        df["premium"] = (df["bid"] + df["ask"]) / 2
        df["premium_percentage"] = df["premium"] / df["strikePrice"]
        df = df[(df["premium_percentage"] >= min_premium_percentage) & (df["premium"] >= min_premium)]
        return df.sort_values(by=["expirationDate", "premium", "delta"]).to_dict("records")

    def get_put_option_candidates_from_max_strike_price_and_min_premium(self, max_strike_price, min_premium):
        df = self.filter_option_candidates()
        df = df[(df["optionType"] == "PUT") & (df["strikePrice"] <= max_strike_price)]
        df["premium"] = (df["bid"] + df["ask"]) / 2
        df = df[df["premium"] >= min_premium]
        return df.sort_values(by=["expirationDate", "premium", "delta"]).to_dict("records")

    def get_theta_from_option_symbol(self, option_symbol):
        df = self.option_chains_df
        return df[df["symbol"] == option_symbol]["theta"].values[0]