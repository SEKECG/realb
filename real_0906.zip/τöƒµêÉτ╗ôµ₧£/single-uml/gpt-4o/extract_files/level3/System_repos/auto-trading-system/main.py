import pandas as pd
import matplotlib.pyplot as plt
from configs.config import Config
from configs.utils import sum_of_option_strike_prices, theta_scatter_plot, OptionInstruction, OptionType, StockInstruction, TradeReason
from options.options import Options
from options.option_chains import OptionChains
from options.stocks import Stocks
from trading.earnings_calendar import EarningsCalendar
from trading.stock_screener import StockScreener
from trading.theta_analyzer import ThetaAnalyzer
from trading.trade_options import TradeOptions

# Initialize necessary components
config = Config()
earnings_calendar = EarningsCalendar()
stock_screener = StockScreener(client=None, tickers_to_scan=[])
theta_analyzer = ThetaAnalyzer(client=None, options=[], ticker_to_stock_map={})
trade_options = TradeOptions()

# Example usage of the components
def main():
    # Example: Generate earnings calendar
    symbol_list = ["AAPL", "MSFT", "GOOGL"]
    earnings_calendar.generate_earnings_calendar_from_yahoo_finance(symbol_list)

    # Example: Screen stocks
    screened_stocks = stock_screener.run(day_change=5, week_change=10, month_change=15)
    print(screened_stocks)

    # Example: Analyze theta decay
    theta_analyzer.scatter_plot()

    # Example: Execute trades
    trade_options.trade_all_accounts()

if __name__ == "__main__":
    main()