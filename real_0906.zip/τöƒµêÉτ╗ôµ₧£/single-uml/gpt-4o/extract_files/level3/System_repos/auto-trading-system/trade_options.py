import pandas as pd
from options.options import Options
from options.option_chains import OptionChains
from options.stocks import Stocks
from configs.config import (
    ACCOUNT_TRADING_STRATEGY_MAP,
    BID_ASK_SPREAD_MAX,
    IRA_ACCOUNT_NUMBER,
    ROLLOUT_LOSING_TRADE_PREMIUM_INCREASE,
    ROLLOUT_LOSING_TRADE_STRIKE_PRICE_LOWER_PERCENTAGE,
    ROLLOUT_WINNING_TRADE_PREMIUM_INCREASE,
    STO_PUT_COUNT_MAX,
    STO_TRADE_SETTINGS,
    TICKERS_FOR_THE_WHEEL,
    TICKERS_OF_IV_100_and_above,
    TICKERS_OF_IV_50_70,
    TICKERS_OF_IV_70_100,
    TRUST_ACCOUNT_NUMBER,
    VOLUME_INTEREST_MIN
)
from configs.utils import OptionInstruction, OptionType, StockInstruction, TradeReason

ORDER_COLUMNS = ["account_number", "ticker", "expiration_date", "strike_price", "option_price", "quantity", "option_type", "instruction", "trade_reason"]

class TradeOptions:
    def __init__(self, client, linked_accounts, options_by_account, ticker_to_stock_map_by_account, available_funds_by_account, position_tracker):
        self.client = client
        self.linked_accounts = linked_accounts
        self.options_by_account = options_by_account
        self.ticker_to_stock_map_by_account = ticker_to_stock_map_by_account
        self.available_funds_by_account = available_funds_by_account
        self.position_tracker = position_tracker
        self.order_dict_list = []
        self.order_ids = []
        self.total_tickers = set()

    def constrain_to_current_positions(self, account_number, ticker_list):
        return [ticker for ticker in ticker_list if ticker in self.ticker_to_stock_map_by_account[account_number]]

    def display_all_orders(self):
        if self.order_dict_list:
            df = pd.DataFrame(self.order_dict_list, columns=ORDER_COLUMNS)
            print(df.sort_values(by=["account_number", "ticker"]))
        else:
            print("No orders available.")

    def get_existing_tickers(self):
        return self.total_tickers

    def process_losing_trades(self, account_number, options, ticker_to_stock_map):
        for option in options:
            if option.is_losing():
                new_expiration_date = option.expiration_date + pd.DateOffset(weeks=4)
                new_strike_price = option.strike_price * (1 - ROLLOUT_LOSING_TRADE_STRIKE_PRICE_LOWER_PERCENTAGE)
                new_option_price = option.option_market_price + ROLLOUT_LOSING_TRADE_PREMIUM_INCREASE
                order = option.create_a_rollout_order(new_expiration_date, new_strike_price, new_option_price)
                self.trade_an_order(account_number, order, option.profit, TradeReason.ROLLOUT_FROM_LOSING)

    def process_positions(self, account_number, positions):
        for position in positions:
            if isinstance(position, Options):
                self.options_by_account[account_number].append(position)
            elif isinstance(position, Stocks):
                self.ticker_to_stock_map_by_account[account_number][position.ticker] = position
            self.position_tracker[account_number].append(position)
        return self.options_by_account, self.ticker_to_stock_map_by_account

    def process_winning_trades(self, account_number, options, ticker_to_stock_map):
        for option in options:
            if option.is_winning():
                order = option.create_btc_order()
                self.trade_an_order(account_number, order, option.profit, TradeReason.BTC_FROM_WINNING)
                new_order = option.sto_after_a_win(option_chains, min_expiration_weeks, min_delta, max_delta, min_premium_percentage, min_premium)
                self.trade_an_order(account_number, new_order, option.profit, TradeReason.STO_FROM_WINNING)

    def selL_cc_and_csp(self, account_number, ticker_to_stock_map, trade_reason):
        for ticker in TICKERS_FOR_THE_WHEEL:
            if ticker in ticker_to_stock_map:
                stock = ticker_to_stock_map[ticker]
                if stock.quantity > 0:
                    order = stock.create_a_stock_order(ticker, stock.quantity, stock.stock_price, StockInstruction.SELL)
                    self.trade_an_order(account_number, order, stock.stock_price, trade_reason)
                else:
                    order = stock.create_a_stock_order(ticker, stock.quantity, stock.stock_price, StockInstruction.BUY)
                    self.trade_an_order(account_number, order, stock.stock_price, trade_reason)

    def sto_given_tickers(self, account_number, tickers_to_sell_dict, trade_reason):
        for ticker, settings in tickers_to_sell_dict.items():
            order = Options.sto_an_option_order(ticker, settings["option_chains"], settings["quantity"], settings["option_type"], settings["min_expiration_weeks"], settings["min_delta"], settings["max_delta"], settings["min_premium_percentage"], settings["min_premium"], settings["cost_basis"])
            self.trade_an_order(account_number, order, settings["option_price"], trade_reason)

    def trade_all_accounts(self):
        for account_number in self.linked_accounts:
            options = self.options_by_account[account_number]
            ticker_to_stock_map = self.ticker_to_stock_map_by_account[account_number]
            self.process_winning_trades(account_number, options, ticker_to_stock_map)
            self.process_losing_trades(account_number, options, ticker_to_stock_map)
            self.selL_cc_and_csp(account_number, ticker_to_stock_map, TradeReason.STO_FROM_THE_WHEEL)

    def trade_an_order(self, account_number, order, option_profit, trade_reason):
        order["option_price"] = round(order["option_price"], 2)
        self.order_dict_list.append(order)
        self.order_ids.append(order["order_id"])