import datetime

class Options:
    def __init__(self, position_json):
        self.position_json = position_json
        self.option_symbol = position_json.get("optionSymbol")
        self.ticker = position_json.get("ticker")
        self.expiration_date = position_json.get("expirationDate")
        self.option_type = position_json.get("optionType")
        self.strike_price = position_json.get("strikePrice")
        self.option_cost = position_json.get("optionCost")
        self.option_market_price = position_json.get("optionMarketPrice")
        self.profit = position_json.get("profit")
        self.short_quantity = position_json.get("shortQuantity")
        self.stock_price = None
        self.delta = None
        self.theta = None
        self.theta_decay_percentage = None

    def create_a_rollout_order(self, new_expiration_date, new_strike_price, new_option_price):
        order = {
            "ticker": self.ticker,
            "expirationDate": new_expiration_date,
            "strikePrice": new_strike_price,
            "optionPrice": new_option_price,
            "quantity": self.short_quantity,
            "optionType": self.option_type,
            "instruction": "ROLL_OUT"
        }
        return order

    def create_an_option_order(self, ticker, expiration_date, strike_price, option_price, quantity, option_type, instruction):
        order = {
            "ticker": ticker,
            "expirationDate": expiration_date,
            "strikePrice": strike_price,
            "optionPrice": option_price,
            "quantity": quantity,
            "optionType": option_type,
            "instruction": instruction
        }
        return order

    def create_btc_order(self):
        order = {
            "ticker": self.ticker,
            "expirationDate": self.expiration_date,
            "strikePrice": self.strike_price,
            "optionPrice": self.option_market_price,
            "quantity": self.short_quantity,
            "optionType": self.option_type,
            "instruction": "BUY_TO_CLOSE"
        }
        return order

    def form_an_option_symbol(self, ticker, expiration_date, strike_price, option_type):
        symbol = f"{ticker}  {expiration_date.strftime('%y%m%d')}{option_type[0]}{strike_price:08d}"
        return symbol

    def is_gain_larger_than_50_percent(self):
        return self.option_market_price < 0.5 * self.option_cost

    def is_losing(self):
        days_to_expiration = (self.expiration_date - datetime.datetime.now().date()).days
        extrinsic_value = self.option_market_price - max(0, self.stock_price - self.strike_price)
        return self.option_type == "PUT" and extrinsic_value < 0.005 * self.strike_price and days_to_expiration <= 14

    def is_winning(self, max_delta_for_btc):
        return self.option_market_price < 0.5 * self.option_cost and abs(self.delta) <= max_delta_for_btc

    def set_delta(self, delta):
        self.delta = delta

    def set_stock_price(self, stock_price):
        self.stock_price = stock_price

    def set_theta(self, theta):
        self.theta = theta

    def sto_after_a_win(self, option_chains, min_expiration_weeks, min_delta, max_delta, min_premium_percentage, min_premium):
        # Implementation for STO after a win
        pass

    def sto_after_btc_a_loss(self, option_chains):
        # Implementation for STO after BTC a loss
        pass

    def sto_an_option_order(self, ticker, option_chains, quantity, option_type, min_expiration_weeks, min_delta, max_delta, min_premium_percentage, min_premium, cost_basis):
        # Implementation for STO an option order
        pass