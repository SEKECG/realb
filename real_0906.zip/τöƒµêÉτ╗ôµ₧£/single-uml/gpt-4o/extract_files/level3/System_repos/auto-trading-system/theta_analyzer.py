```python
import matplotlib.pyplot as plt
import pandas as pd

class ThetaAnalyzer:
    def __init__(self, client, options, ticker_to_stock_map):
        self.client = client
        self.options = options
        self.ticker_to_stock_map = ticker_to_stock_map
        self.total_theta = 0
        self.total_principal = 0
        self.total_put_principal = 0
        self.total_theta_decay_percentage = 0
        self.predicted_return_per_year = 0
        self.calculate_metrics()

    def calculate_metrics(self):
        for option in self.options:
            self.total_theta += option.theta
            self.total_principal += option.option_cost
            if option.option_type == 'PUT':
                self.total_put_principal += option.option_cost
            self.total_theta_decay_percentage += option.theta_decay_percentage

        self.predicted_return_per_year = (self.total_theta / self.total_principal) * 365

    def scatter_plot(self):
        deltas = [option.delta for option in self.options]
        theta_decay_percentages = [option.theta_decay_percentage for option in self.options]
        expiration_dates = [option.expiration_date for option in self.options]
        strike_prices = [option.strike_price for option in self.options]
        tickers = [option.ticker for option in self.options]

        fig, ax = plt.subplots()
        scatter = ax.scatter(deltas, theta_decay_percentages, c=expiration_dates, s=strike_prices, alpha=0.5)
        legend1 = ax.legend(*scatter.legend_elements(), title="Expiration Dates")
        ax.add_artist(legend1)
        for i, ticker in enumerate(tickers):
            ax.annotate(ticker, (deltas[i], theta_decay_percentages[i]))
        plt.xlabel('Delta')
        plt.ylabel('Theta Decay Percentage')
        plt.title('Theta Decay Scatter Plot')
        plt.show()
```