import json
import requests
from datetime import datetime

class EarningsCalendar:
    def __init__(self):
        self.earning_tickers = []
        self.earnings_calendar_json = {}
        self.earnings_calendar_json_path = "earnings_calendar.json"
        self.earnings_json = {}
        self.headers = {"Content-Type": "application/json"}
        self.url = "https://api.example.com/earnings"

        # Load earnings calendar from JSON file if it exists
        try:
            with open(self.earnings_calendar_json_path, 'r') as file:
                self.earnings_calendar_json = json.load(file)
        except FileNotFoundError:
            self.earnings_calendar_json = {}

    def generate_earnings_calendar_from_yahoo_finance(self, symbol_list):
        earnings_data = {}
        for symbol in symbol_list:
            response = requests.get(f"https://finance.yahoo.com/quote/{symbol}/earnings", headers=self.headers)
            if response.status_code == 200:
                data = response.json()
                earnings_date = data.get("earningsDate")
                if earnings_date:
                    earnings_data[symbol] = earnings_date

        # Save to JSON file
        with open(self.earnings_calendar_json_path, 'w') as file:
            json.dump(earnings_data, file)
        self.earnings_calendar_json = earnings_data

    def get_earning_tickers(self, date):
        date_str = date.strftime("%Y-%m-%d")
        if date_str in self.earnings_calendar_json:
            return self.earnings_calendar_json[date_str]
        else:
            response = requests.get(f"{self.url}?date={date_str}", headers=self.headers)
            if response.status_code == 200:
                data = response.json()
                self.earnings_calendar_json[date_str] = data.get("tickers", [])
                return self.earnings_calendar_json[date_str]
            return []