import pandas as pd
from options.option_chains import OptionChains

PRICE_HISTORY_COLUMNS = ["date", "open", "high", "low", "close", "volume"]

class Stocks:
    def __init__(self, position_json):
        self.avg_cost_basis = None
        self.option_chains = None
        self.percent_day_change = None
        self.percent_month_change = None
        self.percent_week_change = None
        self.price_history = None
        self.price_history_df = None
        self.quantity = None
        self.stock_price = None
        self.ticker = None

        if "equity" in position_json:
            self.ticker = position_json["symbol"]
            self.stock_price = position_json["price"]
            self.quantity = position_json["quantity"]
            self.avg_cost_basis = position_json["cost_basis"]
            self.percent_day_change = position_json["percent_change"]

    def create_a_stock_order(self, ticker, quantity, price, instruction="BUY"):
        return {
            "ticker": ticker,
            "quantity": quantity,
            "price": price,
            "instruction": instruction
        }

    def get_option_chains(self, client):
        option_chains_json = client.get_option_chains(self.ticker)
        self.option_chains = OptionChains(option_chains_json)
        return self.option_chains

    def get_price_history(self, client, start_date, end_date):
        price_history_json = client.get_price_history(self.ticker, start_date, end_date)
        self.price_history_df = pd.DataFrame(price_history_json, columns=PRICE_HISTORY_COLUMNS)
        self.percent_week_change = self.calculate_percentage_change(self.price_history_df, "week")
        self.percent_month_change = self.calculate_percentage_change(self.price_history_df, "month")
        return price_history_json

    def initialize_from_quote_json(self, ticker, quote_json):
        self.ticker = ticker
        self.stock_price = quote_json["price"]
        self.quantity = quote_json.get("quantity", 0)
        self.percent_day_change = quote_json["percent_change"]

    @staticmethod
    def calculate_percentage_change(price_history_df, period):
        if period == "week":
            return (price_history_df["close"].iloc[-1] - price_history_df["close"].iloc[-5]) / price_history_df["close"].iloc[-5] * 100
        elif period == "month":
            return (price_history_df["close"].iloc[-1] - price_history_df["close"].iloc[-20]) / price_history_df["close"].iloc[-20] * 100
        return 0