import pandas as pd

class StockScreener:
    def __init__(self, client, tickers_to_scan):
        self.client = client
        self.tickers_to_scan = tickers_to_scan
        self.stocks = {}
        self.put_sell_candidates = []
        self.call_sell_candidates = []
        self._fetch_stock_data()

    def _fetch_stock_data(self):
        for ticker in self.tickers_to_scan:
            stock_data = self.client.get_stock_data(ticker)
            self.stocks[ticker] = stock_data

    def day_change_larger_than_x_percent(self, x_percent):
        candidates = {'put': [], 'call': []}
        for ticker, stock_data in self.stocks.items():
            day_change = stock_data['day_change']
            if day_change > x_percent:
                candidates['call'].append(ticker)
            elif day_change < -x_percent:
                candidates['put'].append(ticker)
        self.put_sell_candidates.extend(candidates['put'])
        self.call_sell_candidates.extend(candidates['call'])
        return candidates

    def week_change_larger_than_x_percent(self, x_percent):
        candidates = {'put': [], 'call': []}
        for ticker, stock_data in self.stocks.items():
            week_change = stock_data['week_change']
            if week_change > x_percent:
                candidates['call'].append(ticker)
            elif week_change < -x_percent:
                candidates['put'].append(ticker)
        self.put_sell_candidates.extend(candidates['put'])
        self.call_sell_candidates.extend(candidates['call'])
        return candidates

    def month_change_larger_than_x_percent(self, x_percent):
        candidates = {'put': [], 'call': []}
        for ticker, stock_data in self.stocks.items():
            month_change = stock_data['month_change']
            if month_change > x_percent:
                candidates['call'].append(ticker)
            elif month_change < -x_percent:
                candidates['put'].append(ticker)
        self.put_sell_candidates.extend(candidates['put'])
        self.call_sell_candidates.extend(candidates['call'])
        return candidates

    def run(self, day_change, week_change, month_change):
        day_candidates = self.day_change_larger_than_x_percent(day_change)
        week_candidates = self.week_change_larger_than_x_percent(week_change)
        month_candidates = self.month_change_larger_than_x_percent(month_change)
        return {
            'day_candidates': day_candidates,
            'week_candidates': week_candidates,
            'month_candidates': month_candidates
        }