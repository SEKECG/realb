# node.py

from typing import List, Optional

class BaseNode:
    def __init__(self, level_seq, level_text, title, content):
        self.level_seq = level_seq
        self.level_text = level_text
        self.title = title
        self.content = content

    def concat_node(self, node):
        self.content += node.content


class ChainNode(BaseNode):
    def __init__(self, level_seq, level_text, title, content, pattern_priority):
        super().__init__(level_seq, level_text, title, content)
        self.pattern_priority = pattern_priority


class TreeNode(BaseNode):
    def __init__(self, level_seq, level_text, title, content, parent=None):
        super().__init__(level_seq, level_text, title, content)
        self.parent = parent
        self.children = []

    def add_child(self, child):
        self.children.append(child)
        child.parent = self

    @staticmethod
    def from_chain_node(chain_node):
        return TreeNode(chain_node.level_seq, chain_node.level_text, chain_node.title, chain_node.content)

    def get_full_content(self):
        full_content = self.content
        for child in self.children:
            full_content += child.get_full_content()
        return full_content

    def merge_all_children(self):
        for child in self.children:
            self.concat_node(child)
        self.children = []