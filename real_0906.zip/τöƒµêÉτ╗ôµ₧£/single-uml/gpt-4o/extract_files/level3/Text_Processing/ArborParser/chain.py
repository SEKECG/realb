import re
from typing import List, Optional

from pattern import LevelPattern
from node import ChainNode

class ChainParser:
    """
    Parses text into a sequence of ChainNodes using predefined patterns.

    Attributes:
        patterns (List[LevelPattern]): A list of regex patterns, each with a conversion function
                                       to transform matches into hierarchy lists.
    """

    def __init__(self, patterns):
        """
        Initializes the ChainParser with the given patterns.

        Args:
            patterns (List[LevelPattern]): List of regex patterns and conversion functions.
        """
        self.patterns = patterns

    def _detect_level(self, line):
        """
        Apply all patterns to detect the title hierarchy.

        Args:
            line (str): Text line to analyze.

        Returns:
            Optional[ChainNode]: The detected ChainNode or None if no pattern matches.
        """
        for pattern in self.patterns:
            match = pattern.regex.match(line)
            if match:
                level_seq = pattern.converter(match)
                return ChainNode(level_seq=level_seq, content=line, pattern_priority=pattern.priority)
        return None

    def parse_to_chain(self, text):
        """
        Core parsing logic to convert text into a chain of nodes.

        Args:
            text (str): Input text to be parsed.

        Returns:
            List[ChainNode]: List of parsed ChainNodes.
        """
        lines = text.splitlines()
        chain = []
        for line in lines:
            node = self._detect_level(line)
            if node:
                chain.append(node)
        return chain