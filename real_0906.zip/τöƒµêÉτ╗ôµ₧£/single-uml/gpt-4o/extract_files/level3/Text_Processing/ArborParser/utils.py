import re
from typing import Optional

ALL_CHINESE_CHARS = "零一二三四五六七八九十百千万亿兆"
ALL_ROMAN_NUMERALS = "IVXLCDM"

chinese_patterns_test = [
    (r"零", 0),
    (r"一", 1),
    (r"二", 2),
    (r"三", 3),
    (r"四", 4),
    (r"五", 5),
    (r"六", 6),
    (r"七", 7),
    (r"八", 8),
    (r"九", 9),
    (r"十", 10),
]

roman_patterns_test = [
    (r"I", 1),
    (r"II", 2),
    (r"III", 3),
    (r"IV", 4),
    (r"V", 5),
    (r"VI", 6),
    (r"VII", 7),
    (r"VIII", 8),
    (r"IX", 9),
    (r"X", 10),
]

def chinese_to_int(chinese_str: str) -> Optional[int]:
    chinese_str = chinese_str.strip()
    if not chinese_str:
        return None

    result = 0
    pattern = re.compile(r"[零一二三四五六七八九十百千万亿兆]")
    matches = pattern.findall(chinese_str)
    if not matches:
        return None

    for match in matches:
        for pat, val in chinese_patterns_test:
            if re.fullmatch(pat, match):
                result += val
                break
    return result

def roman_to_int(roman_str: str) -> Optional[int]:
    roman_str = roman_str.strip().upper()
    if not roman_str:
        return None

    result = 0
    pattern = re.compile(r"[IVXLCDM]+")
    match = pattern.fullmatch(roman_str)
    if not match:
        return None

    roman_numerals = {
        'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000
    }
    prev_value = 0
    for char in roman_str:
        value = roman_numerals[char]
        if value > prev_value:
            result += value - 2 * prev_value
        else:
            result += value
        prev_value = value
    return result