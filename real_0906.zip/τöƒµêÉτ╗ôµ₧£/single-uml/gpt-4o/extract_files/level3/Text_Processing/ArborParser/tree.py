# src/tree.py

from typing import List, Optional, Union, Any, Dict
from pathlib import Path
from chain import ChainNode
from node import TreeNode
from build_strategy import TreeBuildingStrategy, StrictStrategy

class TreeBuilder:
    def __init__(self, strategy: Optional[TreeBuildingStrategy] = None):
        self.strategy = strategy if strategy else StrictStrategy()

    def build_tree(self, chain: List[ChainNode]) -> TreeNode:
        return self.strategy.build_tree(chain)

class TreeExporter:
    def _export_tree_internal(self, node: TreeNode, prefix: str, is_last: bool, is_root: bool) -> str:
        result = prefix + ("└── " if is_last else "├── ") + node.content + "\n"
        prefix += "    " if is_last else "│   "
        for i, child in enumerate(node.children):
            result += self._export_tree_internal(child, prefix, i == len(node.children) - 1, False)
        return result

    def _node_to_dict(self, node: TreeNode) -> Dict[str, Any]:
        return {
            "content": node.content,
            "children": [self._node_to_dict(child) for child in node.children]
        }

    def export_chain(self, chain: List[ChainNode]) -> str:
        return "\n".join(node.content for node in chain)

    def export_to_json(self, tree: TreeNode) -> str:
        import json
        return json.dumps(self._node_to_dict(tree), ensure_ascii=False, indent=4)

    def export_to_json_file(self, tree: TreeNode, file_path: Union[str, Path]) -> None:
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(self.export_to_json(tree))

    def export_tree(self, tree: TreeNode) -> str:
        return self._export_tree_internal(tree, "", True, True)