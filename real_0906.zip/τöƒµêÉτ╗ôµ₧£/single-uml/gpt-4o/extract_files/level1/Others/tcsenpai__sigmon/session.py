import datetime
import warnings
from typing import List

class SessionMetrics:
    def __init__(self):
        self.bitrate_readings = []
        self.signal_readings = []
        self.start_time = datetime.datetime.now()

    def add_metrics(self, metrics):
        if metrics.signal_strength is not None and metrics.bitrate is not None:
            self.signal_readings.append(metrics.signal_strength)
            self.bitrate_readings.append(metrics.bitrate)
        else:
            warnings.warn("Invalid metrics received, skipping...")

    def get_session_summary(self):
        avg_signal_strength = sum(self.signal_readings) / len(self.signal_readings) if self.signal_readings else 0
        avg_bitrate = sum(self.bitrate_readings) / len(self.bitrate_readings) if self.bitrate_readings else 0
        duration = datetime.datetime.now() - self.start_time
        num_samples = len(self.signal_readings)
        
        summary = (
            f"Session Summary:\n"
            f"Average Signal Strength: {avg_signal_strength:.2f} dBm\n"
            f"Average Bitrate: {avg_bitrate:.2f} Mb/s\n"
            f"Duration: {duration}\n"
            f"Number of Samples: {num_samples}"
        )
        return summary