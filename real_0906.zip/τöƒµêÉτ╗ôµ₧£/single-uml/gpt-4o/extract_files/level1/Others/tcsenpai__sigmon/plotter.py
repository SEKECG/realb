import os
import plotext as plt
from datetime import datetime
from session import SessionMetrics
from sigmod_metrics import Metrics

class MetricsPlotter:
    def __init__(self, max_points=100):
        self.max_points = max_points
        self.signal_strengths = []
        self.timestamps = []
        self.max_seen = float('-inf')
        self.min_seen = float('inf')
        self.session = SessionMetrics()
        if not os.path.exists('plots'):
            os.makedirs('plots')

    def save_plot(self):
        plt.plot(self.timestamps, self.signal_strengths)
        plt.title("WiFi Signal Strength Over Time")
        plt.xlabel("Time")
        plt.ylabel("Signal Strength (dBm)")
        plt.save(f"plots/plot_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png")
        plt.clear()

    def update_plot(self, metrics):
        signal_strength = float(metrics.signal_strength)
        if signal_strength > 0:
            signal_strength = -signal_strength
        self.signal_strengths.append(signal_strength)
        self.timestamps.append(datetime.now().strftime('%H:%M:%S'))
        if len(self.signal_strengths) > self.max_points:
            self.signal_strengths.pop(0)
            self.timestamps.pop(0)
        self.max_seen = max(self.max_seen, signal_strength)
        self.min_seen = min(self.min_seen, signal_strength)
        self.session.add_metrics(metrics)
        plt.plot(self.timestamps, self.signal_strengths)
        plt.title("WiFi Signal Strength Over Time")
        plt.xlabel("Time")
        plt.ylabel("Signal Strength (dBm)")
        plt.show()

def plot_metrics_live(get_metrics_func, adapter_name, interval):
    plotter = MetricsPlotter()
    while True:
        metrics = get_metrics_func(adapter_name)
        plotter.update_plot(metrics)
        time.sleep(interval)