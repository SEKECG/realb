import os
import subprocess
import time
import plotext as plt
from libs.plotter import plot_metrics_live
from libs.session import SessionMetrics
from libs.sigmod_metrics import Metrics

def get_active_interface():
    try:
        result = subprocess.run(['iwconfig'], capture_output=True, text=True)
        for line in result.stdout.split('\n'):
            if 'IEEE 802.11' in line:
                return line.split()[0]
    except Exception as e:
        print(f"Error getting active interface: {e}")
    return None

def get_metrics(adapter_name):
    try:
        result = subprocess.run(['iwconfig', adapter_name], capture_output=True, text=True)
        lines = result.stdout.split('\n')
        signal_strength = None
        bitrate = None
        is_power_save_enabled = None
        for line in lines:
            if 'Signal level' in line:
                signal_strength = float(line.split('Signal level=')[1].split()[0])
            if 'Bit Rate' in line:
                bitrate = float(line.split('Bit Rate=')[1].split()[0])
            if 'Power Management' in line:
                is_power_save_enabled = 'on' in line
        return Metrics(signal_strength, bitrate, is_power_save_enabled)
    except Exception as e:
        print(f"Error getting metrics: {e}")
    return None

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="WiFi Signal Monitor")
    parser.add_argument('--interface', type=str, help="Network interface name")
    parser.add_argument('--interval', type=int, default=5, help="Update interval in seconds")
    args = parser.parse_args()

    active_interface = args.interface if args.interface else get_active_interface()
    if not active_interface:
        print("No active interface found.")
        exit(1)

    plot_metrics_live(get_metrics, active_interface, args.interval)