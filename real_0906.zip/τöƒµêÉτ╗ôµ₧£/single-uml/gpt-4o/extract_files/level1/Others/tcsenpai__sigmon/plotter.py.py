import subprocess
import re
from typing import Optional
from sigmod_metrics import Metrics

def get_active_interface() -> Optional[str]:
    try:
        result = subprocess.run(['iwconfig'], capture_output=True, text=True)
        interfaces = re.findall(r'(\w+)\s+IEEE', result.stdout)
        if interfaces:
            return interfaces[0]
    except Exception as e:
        print(f"Error getting active interface: {e}")
    return None

def get_metrics(adapter_name) -> Metrics:
    try:
        result = subprocess.run(['iwconfig', adapter_name], capture_output=True, text=True)
        signal_strength = re.search(r'Signal level=(-\d+)', result.stdout)
        bitrate = re.search(r'Bit Rate=(\d+)', result.stdout)
        power_save = re.search(r'Power Management:(\w+)', result.stdout)
        
        return Metrics(
            signal_strength=int(signal_strength.group(1)) if signal_strength else None,
            bitrate=int(bitrate.group(1)) if bitrate else None,
            is_power_save_enabled=(power_save.group(1) == 'on') if power_save else None
        )
    except Exception as e:
        print(f"Error getting metrics: {e}")
        return Metrics(None, None, None)