import base64
import hashlib
from cryptography.fernet import Fernet
from PIL import Image
import binascii

AUTHOR_GITHUB = "https://github.com/mahmudnibir"
AUTHOR_NAME = "Mahmud Nibir"
AUTHOR_PROJECT = "HiddenMessage"
IMAGE_PATH = "input_image.png"
OUTPUT_IMAGE_PATH = "output_image.png"
PASSWORD = "your_password"

def animated_logo(text):
    for char in text:
        print(char, end='', flush=True)

def bin_to_text(binary_data):
    binary_int = int(binary_data, 2)
    byte_number = binary_int.bit_length() + 7 // 8
    binary_array = binary_int.to_bytes(byte_number, "big")
    ascii_text = binary_array.decode()
    return ascii_text

def decrypt_text(encrypted_text, password):
    key = generate_key(password)
    fernet = Fernet(key)
    decrypted_text = fernet.decrypt(encrypted_text.encode()).decode()
    return decrypted_text

def encrypt_text(text, password):
    key = generate_key(password)
    fernet = Fernet(key)
    encrypted_text = fernet.encrypt(text.encode()).decode()
    return encrypted_text

def extract_text_from_image(IMAGE_PATH, password):
    img = Image.open(IMAGE_PATH)
    binary_data = ""
    for pixel in img.getdata():
        for color in pixel[:3]:
            binary_data += bin(color)[-1]
    encrypted_text = bin_to_text(binary_data)
    return decrypt_text(encrypted_text, password)

def generate_key(password):
    key = hashlib.sha256(password.encode()).digest()
    return base64.urlsafe_b64encode(key)

def hide_text_in_image(IMAGE_PATH, text, OUTPUT_IMAGE_PATH, password):
    encrypted_text = encrypt_text(text, password)
    binary_data = text_to_bin(encrypted_text)
    img = Image.open(IMAGE_PATH)
    binary_index = 0
    img_data = list(img.getdata())
    for i in range(len(img_data)):
        pixel = list(img_data[i])
        for j in range(3):
            if binary_index < len(binary_data):
                pixel[j] = pixel[j] & ~1 | int(binary_data[binary_index])
                binary_index += 1
        img_data[i] = tuple(pixel)
    img.putdata(img_data)
    img.save(OUTPUT_IMAGE_PATH)

def print_AUTHOR_info():
    print(f"Author: {AUTHOR_NAME}")
    print(f"GitHub: {AUTHOR_GITHUB}")
    print(f"Project: {AUTHOR_PROJECT}")

def text_to_bin(text):
    binary_data = ''.join(format(ord(char), '08b') for char in text)
    return binary_data

if __name__ == "__main__":
    print_AUTHOR_info()
    animated_logo("Welcome to HiddenMessage Project")
    choice = input("\nDo you want to (1) hide text or (2) extract text? Enter 1 or 2: ")
    if choice == '1':
        text = input("Enter the text to hide: ")
        hide_text_in_image(IMAGE_PATH, text, OUTPUT_IMAGE_PATH, PASSWORD)
        print("Text hidden successfully in the image.")
    elif choice == '2':
        extracted_text = extract_text_from_image(IMAGE_PATH, PASSWORD)
        print(f"Extracted text: {extracted_text}")
    else:
        print("Invalid choice.")