import os
import logging
from pathlib import Path

DEFAULT_IGNORE_DIRS = {'node_modules', '__pycache__', '.git', '.vscode', '.idea'}

def is_ignored(path, ignore_dirs):
    for ignore_dir in ignore_dirs:
        if ignore_dir in path.parts:
            return True
    return False

def read_file_safely(file_path, max_size_mb):
    try:
        if os.path.getsize(file_path) > max_size_mb * 1024 * 1024:
            logging.warning(f"File {file_path} exceeds the maximum size limit.")
            return None
        with open(file_path, 'r', encoding='utf-8') as file:
            return file.read()
    except Exception as e:
        logging.error(f"Error reading file {file_path}: {e}")
        return None

def directory_to_markdown(directory_path, output_file, file_types, ignore_dirs=DEFAULT_IGNORE_DIRS, recursive=True, max_file_size_mb=5):
    directory_path = Path(directory_path)
    output_file = Path(output_file)
    
    with open(output_file, 'w', encoding='utf-8') as md_file:
        for root, dirs, files in os.walk(directory_path):
            if not recursive:
                dirs[:] = []
            dirs[:] = [d for d in dirs if d not in ignore_dirs]
            
            for file in files:
                file_path = Path(root) / file
                if file_path.suffix in file_types and not is_ignored(file_path, ignore_dirs):
                    content = read_file_safely(file_path, max_file_size_mb)
                    if content:
                        md_file.write(f"## {file_path}\n\n```\n{content}\n```\n\n")

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Convert directory contents to a markdown file.")
    parser.add_argument("directory_path", help="Directory to traverse.")
    parser.add_argument("output_file", help="Markdown file to generate.")
    parser.add_argument("--file_types", nargs='+', default=['.py', '.txt'], help="File extensions to include.")
    parser.add_argument("--ignore_dirs", nargs='+', default=list(DEFAULT_IGNORE_DIRS), help="Directory names to ignore.")
    parser.add_argument("--recursive", type=bool, default=True, help="Whether to traverse subdirectories.")
    parser.add_argument("--max_file_size_mb", type=int, default=5, help="Maximum file size to process in megabytes.")

    args = parser.parse_args()
    directory_to_markdown(args.directory_path, args.output_file, set(args.file_types), set(args.ignore_dirs), args.recursive, args.max_file_size_mb)