import json
import os
import re
import pyperclip
from cryptography.fernet import Fernet
import customtkinter as ctk

KEY_FILE = "key.key"
PACKAGE_FOLDER = "proj_clean/src/"
SAVE_FILE = os.path.join(PACKAGE_FOLDER, "clips.json")
SETTINGS_FILE = os.path.join(PACKAGE_FOLDER, "settings.json")

autosave = False
clipsObj = []
cryptKey = None
darkmode = False
lastClip = None
selected_color = "blue"
selected_type_filter = "All"

def UI():
    root = ctk.CTk()
    root.title("Clipboardy")
    root.geometry("800x600")

    frame = ctk.CTkFrame(root)
    frame.pack(fill="both", expand=True)

    search_bar = ctk.CTkEntry(frame, placeholder_text="Search...")
    search_bar.pack(pady=10)
    search_bar.bind("<KeyRelease>", search_clips)

    clips_table = ctk.CTkFrame(frame)
    clips_table.pack(fill="both", expand=True)

    populate_clips_table(clips_table, clipsObj)

    settings_button = ctk.CTkButton(frame, text="Settings", command=settings_UI)
    settings_button.pack(pady=10)

    root.mainloop()

def apply_color(choice):
    global selected_color
    selected_color = choice
    refresh_ui()

def apply_filter(choice):
    global selected_type_filter
    selected_type_filter = choice
    refresh_ui()

def decrypt_clip(encrypted_clip):
    fernet = Fernet(cryptKey)
    return fernet.decrypt(encrypted_clip).decode()

def delete_all_clips():
    global clipsObj
    clipsObj = []
    save_clips()
    refresh_ui()

def delete_clip_from_ui(index):
    global clipsObj
    del clipsObj[index]
    save_clips()
    refresh_ui()

def delete_key():
    if os.path.exists(KEY_FILE):
        os.remove(KEY_FILE)
    delete_all_clips()
    generate_key()
    load_key()

def determine_content_type(current_clip):
    if re.match(r'^https?://', current_clip):
        return "URL"
    elif re.match(r'^[\w\.-]+@[\w\.-]+\.\w+$', current_clip):
        return "Email"
    elif re.match(r'^\d{4}-\d{4}-\d{4}-\d{4}$', current_clip):
        return "Credit Card"
    elif re.match(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$', current_clip):
        return "IPv4"
    elif re.match(r'^[\da-fA-F:]+$', current_clip):
        return "IPv6"
    else:
        return "Text"

def encrypt_clip(clip):
    fernet = Fernet(cryptKey)
    return fernet.encrypt(clip.encode())

def generate_key():
    key = Fernet.generate_key()
    with open(KEY_FILE, 'wb') as key_file:
        key_file.write(key)

def load_clips():
    global clipsObj
    if os.path.exists(SAVE_FILE):
        with open(SAVE_FILE, 'r') as file:
            clipsObj = json.load(file)

def load_key():
    global cryptKey
    if os.path.exists(KEY_FILE):
        with open(KEY_FILE, 'rb') as key_file:
            cryptKey = key_file.read()
    else:
        generate_key()
        load_key()

def load_settings():
    global autosave, darkmode, selected_color
    if os.path.exists(SETTINGS_FILE):
        with open(SETTINGS_FILE, 'r') as file:
            settings = json.load(file)
            autosave = settings.get("autosave", False)
            darkmode = settings.get("darkmode", False)
            selected_color = settings.get("selected_color", "blue")

def main():
    load_key()
    load_clips()
    load_settings()
    UI()

def monitor_clipboard():
    global lastClip
    current_clip = pyperclip.paste()
    if current_clip != lastClip:
        lastClip = current_clip
        if autosave:
            save_clip()

def populate_clips_table(frame, clips_to_display):
    for widget in frame.winfo_children():
        widget.destroy()
    for index, clip in enumerate(clips_to_display):
        clip_type = determine_content_type(clip)
        clip_short = clip[:50] + "..." if len(clip) > 50 else clip
        clip_label = ctk.CTkLabel(frame, text=f"{clip_type}: {clip_short}")
        clip_label.pack(pady=5)
        delete_button = ctk.CTkButton(frame, text="Delete", command=lambda idx=index: delete_clip_from_ui(idx))
        delete_button.pack(pady=5)

def refresh_ui(component=None):
    if component:
        component.update()
    else:
        UI()

def save_clip():
    current_clip = pyperclip.paste()
    encrypted_clip = encrypt_clip(current_clip)
    clipsObj.append(encrypted_clip)
    save_clips()

def save_clips():
    with open(SAVE_FILE, 'w') as file:
        json.dump(clipsObj, file)

def save_settings():
    settings = {
        "autosave": autosave,
        "darkmode": darkmode,
        "selected_color": selected_color
    }
    with open(SETTINGS_FILE, 'w') as file:
        json.dump(settings, file)

def search_clips(event):
    search_term = event.widget.get()
    filtered_clips = [clip for clip in clipsObj if search_term.lower() in decrypt_clip(clip).lower()]
    populate_clips_table(event.widget.master, filtered_clips)

def settings_UI():
    settings_window = ctk.CTk()
    settings_window.title("Settings")
    settings_window.geometry("400x300")

    autosave_toggle = ctk.CTkSwitch(settings_window, text="Autosave", command=toggle_autosave)
    autosave_toggle.pack(pady=10)
    autosave_toggle.select() if autosave else autosave_toggle.deselect()

    darkmode_toggle = ctk.CTkSwitch(settings_window, text="Dark Mode", command=toggle_darkmode)
    darkmode_toggle.pack(pady=10)
    darkmode_toggle.select() if darkmode else darkmode_toggle.deselect()

    color_label = ctk.CTkLabel(settings_window, text="Select Color Theme")
    color_label.pack(pady=10)
    color_options = ["blue", "green", "red"]
    for color in color_options:
        color_button = ctk.CTkButton(settings_window, text=color.capitalize(), command=lambda c=color: apply_color(c))
        color_button.pack(pady=5)

    danger_zone_label = ctk.CTkLabel(settings_window, text="Danger Zone")
    danger_zone_label.pack(pady=10)
    reset_key_button = ctk.CTkButton(settings_window, text="Reset Encryption Key", command=delete_key)
    reset_key_button.pack(pady=5)

    settings_window.mainloop()

def toggle_autosave():
    global autosave
    autosave = not autosave
    save_settings()

def toggle_darkmode():
    global darkmode
    darkmode = not darkmode
    save_settings()
    refresh_ui()

if __name__ == "__main__":
    main()