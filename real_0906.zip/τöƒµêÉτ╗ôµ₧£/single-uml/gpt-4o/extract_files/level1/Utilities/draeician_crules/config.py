import yaml
import logging
from pathlib import Path

DEFAULT_CONFIG = {
    'cursor_dir': '.cursor',
    'rules_dir': '.cursor/rules',
    'global_rules': 'global_rules.yaml',
    'language_rules_dir': 'language_rules',
    'delimiter': '\n---\n'
}

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

def load_config():
    config_path = Path('config.yaml')
    if config_path.exists():
        with open(config_path, 'r') as file:
            config = yaml.safe_load(file)
            logger.info("Configuration loaded from config.yaml")
    else:
        config = DEFAULT_CONFIG
        logger.info("Using default configuration")
    return config