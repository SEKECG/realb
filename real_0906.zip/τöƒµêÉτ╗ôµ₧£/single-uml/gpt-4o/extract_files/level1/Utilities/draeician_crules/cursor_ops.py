import os
import shutil
from pathlib import Path
import logging

logger = logging.getLogger(__name__)

class CursorDirectoryManager:
    def __init__(self, config):
        self.config = config
        self.cursor_dir = Path(config.get('cursor_dir', '.cursor'))
        self.rules_dir = self.cursor_dir / 'rules'

    def create_rule_file(self, name, content, metadata=None):
        try:
            rule_file_path = self.rules_dir / f"{name}.mdc"
            with open(rule_file_path, 'w') as rule_file:
                rule_file.write(content)
                if metadata:
                    rule_file.write("\n\n# Metadata\n")
                    for key, value in metadata.items():
                        rule_file.write(f"# {key}: {value}\n")
            return True
        except Exception as e:
            logger.error(f"Failed to create rule file {name}: {e}")
            return False

    def ensure_cursor_structure(self):
        try:
            self.cursor_dir.mkdir(parents=True, exist_ok=True)
            self.rules_dir.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            logger.error(f"Failed to ensure .cursor directory structure: {e}")

    def list_rule_files(self):
        try:
            return list(self.rules_dir.glob("*.mdc"))
        except Exception as e:
            logger.error(f"Failed to list rule files: {e}")
            return []

    def update_gitignore(self):
        try:
            gitignore_path = Path('.gitignore')
            if gitignore_path.exists():
                with open(gitignore_path, 'a') as gitignore_file:
                    gitignore_file.write("\n# Ignore cursor rules\n")
                    gitignore_file.write(".cursor/rules/*.mdc\n")
        except Exception as e:
            logger.error(f"Failed to update .gitignore: {e}")