import os
import shutil
import logging
from pathlib import Path
from typing import Dict

logger = logging.getLogger(__name__)

def setup_directory_structure(verbose, force):
    cursor_dir = Path('.cursor')
    rules_dir = cursor_dir / 'rules'
    
    if not cursor_dir.exists():
        cursor_dir.mkdir()
        if verbose:
            logger.info(f"Created directory: {cursor_dir}")
    
    if not rules_dir.exists():
        rules_dir.mkdir()
        if verbose:
            logger.info(f"Created directory: {rules_dir}")
    
    return True

def list_available_languages(language_rules_dir):
    lang_files = [f for f in language_rules_dir.iterdir() if f.is_file()]
    for lang_file in lang_files:
        print(lang_file.name)

def check_files_exist(global_rules, language_rules_dir, languages):
    if not global_rules.exists():
        return False
    
    for lang in languages:
        lang_file = language_rules_dir / f"{lang}.mdc"
        if not lang_file.exists():
            return False
    
    return True

def backup_existing_rules(force):
    cursor_rules_file = Path('.cursorrules')
    backup_file = Path('.cursorrules.bak')
    
    if cursor_rules_file.exists():
        if force or not backup_file.exists():
            shutil.copy(cursor_rules_file, backup_file)
            logger.info(f"Backed up {cursor_rules_file} to {backup_file}")
            return True
    return False

def combine_rules(global_rules, language_rules_dir, languages, delimiter):
    combined_rules = global_rules.read_text()
    
    for lang in languages:
        lang_file = language_rules_dir / f"{lang}.mdc"
        combined_rules += delimiter + lang_file.read_text()
    
    return combined_rules

def write_rules_to_cursor_dir(cursor_manager, global_rules, lang_rules_dir, languages, force):
    combined_rules = combine_rules(global_rules, lang_rules_dir, languages, "\n")
    rule_file_path = cursor_manager.rules_dir / 'combined_rules.mdc'
    
    if rule_file_path.exists() and not force:
        logger.warning(f"File {rule_file_path} already exists. Use force to overwrite.")
        return False
    
    rule_file_path.write_text(combined_rules)
    return True

def copy_predefined_rules(lang_rules_dir, verbose, force):
    predefined_dir = Path('predefined_rules')
    
    for rule_file in predefined_dir.iterdir():
        dest_file = lang_rules_dir / rule_file.name
        if not dest_file.exists() or force:
            shutil.copy(rule_file, dest_file)
            if verbose:
                logger.info(f"Copied {rule_file} to {dest_file}")

def get_available_languages(language_rules_dir):
    lang_files = {f.stem: f for f in language_rules_dir.iterdir() if f.is_file()}
    return lang_files

def update_gitignore():
    gitignore_path = Path('.gitignore')
    if gitignore_path.exists():
        with gitignore_path.open('a') as gitignore:
            gitignore.write('\n.cursorrules\n.cursorrules.bak\n')