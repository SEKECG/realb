# src/crules/__init__.py

__version__ = "1.0.0"

# src/crules/cli.py

import logging
from src.crules.file_ops import setup_directory_structure, list_available_languages, write_rules_to_cursor_dir
from src.crules.config import load_config
from src.crules.cursor_ops import CursorDirectoryManager

logger = logging.getLogger(__name__)

def main(languages=None, force=False, verbose=False, show_list=False, setup_dirs=False, legacy=False):
    if verbose:
        logging.basicConfig(level=logging.DEBUG)
    else:
        logging.basicConfig(level=logging.INFO)

    config = load_config()
    cursor_manager = CursorDirectoryManager(config)

    if setup_dirs:
        setup_directory_structure(verbose, force)
        if force:
            cursor_manager.ensure_cursor_structure()
        return

    if show_list:
        list_available_languages(config['language_rules_dir'])
        return

    if legacy:
        write_rules_to_cursor_dir(cursor_manager, config['global_rules'], config['language_rules_dir'], languages, force)
    else:
        cursor_manager.create_rule_file("combined_rules", "Combined rules content", {"metadata": "example"})

# src/crules/config.py

import yaml
import logging

DEFAULT_CONFIG = {
    'global_rules': 'path/to/global_rules',
    'language_rules_dir': 'path/to/language_rules_dir',
    'cursor_dir': '.cursor',
    'rules_dir': '.cursor/rules'
}

logger = logging.getLogger(__name__)

def load_config():
    try:
        with open('config.yaml', 'r') as file:
            config = yaml.safe_load(file)
    except FileNotFoundError:
        logger.warning("Config file not found, using default settings.")
        config = DEFAULT_CONFIG
    return config

# src/crules/file_ops.py

import os
import shutil
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

def setup_directory_structure(verbose, force):
    cursor_dir = Path('.cursor')
    rules_dir = cursor_dir / 'rules'
    if not cursor_dir.exists():
        cursor_dir.mkdir()
    if not rules_dir.exists():
        rules_dir.mkdir()
    if verbose:
        logger.info(f"Created directory structure: {cursor_dir} and {rules_dir}")
    return True

def list_available_languages(language_rules_dir):
    languages = [f.stem for f in Path(language_rules_dir).glob('*.mdc')]
    for lang in languages:
        print(lang)

def write_rules_to_cursor_dir(cursor_manager, global_rules, lang_rules_dir, languages, force):
    cursor_manager.ensure_cursor_structure()
    combined_rules = "Combined rules content"
    cursor_manager.create_rule_file("combined_rules", combined_rules, {"metadata": "example"})
    return True

# src/crules/cursor_ops.py

import os
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

class CursorDirectoryManager:
    def __init__(self, config):
        self.config = config
        self.cursor_dir = Path(config['cursor_dir'])
        self.rules_dir = self.cursor_dir / 'rules'

    def create_rule_file(self, name, content, metadata=None):
        rule_file = self.rules_dir / f"{name}.mdc"
        with rule_file.open('w') as file:
            file.write(content)
        if metadata:
            metadata_file = self.rules_dir / f"{name}.meta"
            with metadata_file.open('w') as file:
                file.write(str(metadata))
        return True

    def ensure_cursor_structure(self):
        if not self.cursor_dir.exists():
            self.cursor_dir.mkdir()
        if not self.rules_dir.exists():
            self.rules_dir.mkdir()

    def list_rule_files(self):
        return list(self.rules_dir.glob('*.mdc'))

    def update_gitignore(self):
        gitignore_path = Path('.gitignore')
        if gitignore_path.exists():
            with gitignore_path.open('a') as file:
                file.write('\n.cursor/rules/*.mdc\n')