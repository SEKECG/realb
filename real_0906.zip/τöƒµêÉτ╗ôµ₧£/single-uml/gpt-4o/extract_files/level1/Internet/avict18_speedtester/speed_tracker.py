import csv
import time
import speedtest
from datetime import datetime

def run_speed_test(high, low, serial_number, record_file):
    st = speedtest.Speedtest()
    download_speed = st.download() / 1_000_000  # Convert to Mbps
    upload_speed = st.upload() / 1_000_000  # Convert to Mbps
    ping = st.results.ping

    if download_speed >= high:
        status = 'great'
    elif download_speed >= low:
        status = 'okay'
    else:
        status = 'bad'

    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    result = [serial_number, timestamp, download_speed, upload_speed, ping, status]

    with open(record_file, 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(result)

    print(f"Test #{serial_number} - {timestamp}")
    print(f"Download Speed: {download_speed:.2f} Mbps")
    print(f"Upload Speed: {upload_speed:.2f} Mbps")
    print(f"Ping: {ping:.2f} ms")
    print(f"Status: {status}\n")

def main():
    high_threshold = 50  # Mbps
    low_threshold = 10  # Mbps
    record_file = 'speedtest_results.csv'

    with open(record_file, 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['Serial Number', 'Timestamp', 'Download Speed (Mbps)', 'Upload Speed (Mbps)', 'Ping (ms)', 'Status'])

    serial_number = 1
    while True:
        run_speed_test(high_threshold, low_threshold, serial_number, record_file)
        serial_number += 1
        time.sleep(300)  # Wait for 5 minutes

if __name__ == "__main__":
    main()