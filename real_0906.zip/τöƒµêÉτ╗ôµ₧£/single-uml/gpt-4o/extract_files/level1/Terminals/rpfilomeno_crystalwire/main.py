import threading
import time
import pandas as pd
import plotille
import psutil
from scapy.all import sniff

# Global variables
all_macs = {}
connection2pid = {}
global_df = pd.DataFrame(columns=['PID', 'Process Name', 'Upload', 'Download', 'Upload Speed', 'Download Speed'])
global_graph_data = {}
is_program_running = True
pid2traffic = pd.DataFrame(columns=['PID', 'Process Name', 'Upload', 'Download'])
connections_thread = None
printing_thread = None

def get_connections():
    while is_program_running:
        for conn in psutil.net_connections(kind='inet'):
            if conn.laddr and conn.raddr:
                connection2pid[(conn.laddr.ip, conn.laddr.port, conn.raddr.ip, conn.raddr.port)] = conn.pid
        time.sleep(1)

def get_size(bytes):
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if bytes < 1024:
            return f"{bytes:.2f} {unit}"
        bytes /= 1024

def plot(df):
    fig = plotille.Figure()
    fig.width = 60
    fig.height = 20
    fig.color_mode = 'byte'
    for pid in df['PID'].unique():
        data = df[df['PID'] == pid]
        fig.plot(data.index, data['Upload Speed'], label=f"PID {pid} Upload")
        fig.plot(data.index, data['Download Speed'], label=f"PID {pid} Download")
    print(fig.show())

def print_pid2traffic():
    while is_program_running:
        global_df['Upload Speed'] = global_df['Upload'] - pid2traffic['Upload']
        global_df['Download Speed'] = global_df['Download'] - pid2traffic['Download']
        pid2traffic.update(global_df[['Upload', 'Download']])
        print(global_df)
        plot(global_df)
        time.sleep(1)

def print_stats():
    while is_program_running:
        print(global_df.head())
        time.sleep(1)

def process_packet(packet):
    if packet.haslayer('IP'):
        src_ip = packet['IP'].src
        dst_ip = packet['IP'].dst
        src_port = packet['IP'].sport
        dst_port = packet['IP'].dport
        if (src_ip, src_port, dst_ip, dst_port) in connection2pid:
            pid = connection2pid[(src_ip, src_port, dst_ip, dst_port)]
            process_name = psutil.Process(pid).name()
            if pid not in global_df['PID'].values:
                global_df = global_df.append({'PID': pid, 'Process Name': process_name, 'Upload': 0, 'Download': 0, 'Upload Speed': 0, 'Download Speed': 0}, ignore_index=True)
            if packet['IP'].src == src_ip:
                global_df.loc[global_df['PID'] == pid, 'Upload'] += len(packet)
            else:
                global_df.loc[global_df['PID'] == pid, 'Download'] += len(packet)

def stat(df):
    print(df.head().style.applymap(lambda x: 'color: red' if x > 1000 else 'color: black'))

if __name__ == "__main__":
    connections_thread = threading.Thread(target=get_connections)
    connections_thread.start()
    printing_thread = threading.Thread(target=print_pid2traffic)
    printing_thread.start()
    sniff(prn=process_packet, store=False)