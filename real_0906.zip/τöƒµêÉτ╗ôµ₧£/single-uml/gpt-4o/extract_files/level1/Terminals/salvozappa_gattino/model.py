def get_prompt(human_language_command):
    """
    Generate a prompt based on a human language command, instructing the user to create a single-line bash command
    that accomplishes the specified action. The prompt emphasizes requirements, the format of responses, and the action
    of human language commands.
    """
    prompt = (
        "Please create a single-line bash command that accomplishes the following action:\n"
        f"{human_language_command}\n"
        "Ensure the command is concise and follows best practices for bash scripting."
    )
    return prompt