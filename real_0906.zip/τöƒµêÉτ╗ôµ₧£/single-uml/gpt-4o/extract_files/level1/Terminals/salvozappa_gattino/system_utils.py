import subprocess
import time
from ui import show_spinner

def run_command(command, input=None):
    try:
        process = subprocess.Popen(command, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if input:
            process.stdin.write(input.encode())
            process.stdin.close()
        
        show_spinner(process)
        
        output, error = process.communicate()
        if process.returncode != 0:
            return f"Error: {error.decode()}"
        return output.decode()
    except Exception as e:
        return f"Exception: {str(e)}"

def write_file(path, content):
    try:
        with open(path, 'w') as file:
            file.write(content)
    except Exception as e:
        print(f"Failed to write to file {path}: {str(e)}")