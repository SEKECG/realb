import re

def extract_first_code_block(text):
    """
    Extract the first code block enclosed in triple backticks (```) from a given text string,
    removing any 'bash' specifier if present, and return the content of the code block as a stripped string.
    If no code block is found, return an empty string.
    """
    code_block_pattern = re.compile(r'```(?:bash)?\s*(.*?)\s*```', re.DOTALL)
    match = code_block_pattern.search(text)
    if match:
        return match.group(1).strip()
    return ""

if __name__ == "__main__":
    sample_text = """
    Here is some text.
    ```bash
    echo "Hello, World!"
    ```
    More text.
    """
    print(extract_first_code_block(sample_text))