import os

current_dir = os.path.dirname(os.path.abspath(__file__))
tokenizer_path = os.path.join(current_dir, 'tokenizer.json')

# Assuming a simple tokenizer for demonstration purposes
tokenizer = {
    "tokenize": lambda text: text.split(),
    "count_tokens": lambda text: len(text.split())
}

def get_token_length(content):
    """
    Calculate the number of tokens in a given string using a tokenizer.
    """
    return tokenizer["count_tokens"](content)

def get_tokens(content):
    """
    Tokenize the input string content into a list of tokens using a predefined tokenizer.
    """
    return tokenizer["tokenize"](content)