import re
from typing import List, Optional

def split_text_into_sentences(text, parent_text=None, chunk_size=500):
    """
    Split a given text into sentences or chunks of specified size, optionally prepending a parent text to each chunk,
    while ensuring minimal token overlap and handling short texts appropriately.
    """
    sentences = re.split(r'(?<=[.!?]) +', text)
    chunks = []
    current_chunk = []
    current_length = 0

    for sentence in sentences:
        sentence_length = len(sentence.split())
        if current_length + sentence_length > chunk_size:
            chunks.append(' '.join(current_chunk))
            current_chunk = []
            current_length = 0
        current_chunk.append(sentence)
        current_length += sentence_length

    if current_chunk:
        chunks.append(' '.join(current_chunk))

    if parent_text:
        chunks = [parent_text + ' ' + chunk for chunk in chunks]

    return chunks