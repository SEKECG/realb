# proj_clean/token_encoder/__init__.py

from .encode import get_token_length, get_tokens