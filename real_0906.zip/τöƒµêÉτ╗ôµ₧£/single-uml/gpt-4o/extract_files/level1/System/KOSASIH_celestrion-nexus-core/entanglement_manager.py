# entanglement_manager.py

from quantum_comm import QuantumComm

class EntanglementManager:
    def __init__(self):
        self.quantum_comm = QuantumComm()
        self.active_pairs = []

    def establish_connection(self):
        pair = self.quantum_comm.create_entangled_pair()
        self.active_pairs.append(pair)

    def list_active_pairs(self):
        return self.active_pairs

    def receive_message(self, pair_index):
        if pair_index < len(self.active_pairs):
            return self.quantum_comm.receive_message(pair_index)
        else:
            raise IndexError("Pair index out of range")

    def remove_pair(self, pair_index):
        if pair_index < len(self.active_pairs):
            self.active_pairs.pop(pair_index)
        else:
            raise IndexError("Pair index out of range")

    def send_message(self, message, pair_index):
        if pair_index < len(self.active_pairs):
            self.quantum_comm.transmit_message(message, pair_index)
        else:
            raise IndexError("Pair index out of range")