class MessageProtocol:
    @staticmethod
    def add_metadata(message_dict, key, value):
        if 'metadata' not in message_dict:
            message_dict['metadata'] = {}
        message_dict['metadata'][key] = value

    @staticmethod
    def format_message(recipient, message, metadata=None):
        formatted_message = {
            'recipient': recipient,
            'message': message,
            'metadata': metadata if metadata else {}
        }
        return formatted_message

    @staticmethod
    def get_metadata(message_dict, key):
        return message_dict.get('metadata', {}).get(key)

    @staticmethod
    def parse_message(raw_message):
        try:
            parsed_message = eval(raw_message)
            if isinstance(parsed_message, dict):
                return parsed_message
            else:
                raise ValueError("Parsed message is not a dictionary")
        except Exception as e:
            raise ValueError(f"Error parsing message: {e}")

    @staticmethod
    def remove_metadata(message_dict, key):
        if 'metadata' in message_dict and key in message_dict['metadata']:
            del message_dict['metadata'][key]

    @staticmethod
    def validate_message(message_dict):
        required_keys = ['recipient', 'message']
        for key in required_keys:
            if key not in message_dict:
                return False
        return True