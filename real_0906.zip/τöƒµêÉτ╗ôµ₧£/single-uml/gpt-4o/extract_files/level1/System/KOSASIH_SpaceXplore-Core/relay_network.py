import logging

class RelayNetwork:
    def __init__(self):
        self.relays = []
        logging.basicConfig(level=logging.INFO)

    def add_relay(self, relay_id):
        self.relays.append(relay_id)
        logging.info(f"Relay {relay_id} added to the network.")

    def transmit_via_relays(self, data):
        if not self.relays:
            logging.warning("No relays available for transmission.")
            return False
        for relay in self.relays:
            logging.info(f"Transmitting data via relay {relay}: {data}")
        return True

if __name__ == "__main__":
    network = RelayNetwork()
    network.add_relay("Relay1")
    network.add_relay("Relay2")
    success = network.transmit_via_relays("Sample Data")
    print(f"Transmission successful: {success}")