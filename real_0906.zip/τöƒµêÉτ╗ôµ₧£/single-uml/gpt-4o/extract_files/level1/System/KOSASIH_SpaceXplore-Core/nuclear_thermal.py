import logging

class NuclearThermal:
    def __init__(self, thrust, fuel_mass, specific_impulse):
        self.thrust = thrust
        self.fuel_mass = fuel_mass
        self.specific_impulse = specific_impulse
        self.is_active = False
        logging.basicConfig(level=logging.INFO)

    def activate(self):
        if self.fuel_mass > 0:
            self.is_active = True
            logging.info("Nuclear Thermal Propulsion activated.")
        else:
            logging.error("Insufficient fuel to activate Nuclear Thermal Propulsion.")

    def calculate_acceleration(self):
        if self.is_active:
            return self.thrust / self.fuel_mass
        return 0

    def consume_fuel(self, time):
        if self.is_active:
            fuel_consumed = self.thrust * time / self.specific_impulse
            self.fuel_mass -= fuel_consumed
            if self.fuel_mass <= 0:
                self.fuel_mass = 0
                self.deactivate()
            logging.info(f"Fuel consumed: {fuel_consumed}, Remaining fuel: {self.fuel_mass}")

    def deactivate(self):
        self.is_active = False
        logging.info("Nuclear Thermal Propulsion deactivated.")

    def simulate(self, duration):
        if self.is_active:
            for t in range(duration):
                self.consume_fuel(1)
                logging.info(f"Time: {t}, Status: {self.status()}")

    def status(self):
        return {
            "is_active": self.is_active,
            "thrust": self.thrust,
            "fuel_mass": self.fuel_mass,
            "acceleration": self.calculate_acceleration()
        }