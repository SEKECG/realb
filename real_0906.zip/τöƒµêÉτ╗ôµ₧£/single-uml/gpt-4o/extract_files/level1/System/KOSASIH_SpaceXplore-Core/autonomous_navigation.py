import logging
import numpy as np

class AutonomousNavigation:
    def __init__(self, initial_position, destination, speed):
        self.position = np.array(initial_position)
        self.destination = np.array(destination)
        self.speed = speed
        logging.basicConfig(level=logging.INFO)

    def calculate_direction(self):
        direction = self.destination - self.position
        norm = np.linalg.norm(direction)
        if norm == 0:
            return np.zeros_like(direction)
        return direction / norm

    def has_reached_destination(self):
        return np.allclose(self.position, self.destination, atol=1e-2)

    def move(self):
        direction = self.calculate_direction()
        self.position += direction * self.speed
        logging.info(f"New position: {self.position}")

    def navigate(self):
        while not self.has_reached_destination():
            self.move()
        logging.info("Destination reached.")