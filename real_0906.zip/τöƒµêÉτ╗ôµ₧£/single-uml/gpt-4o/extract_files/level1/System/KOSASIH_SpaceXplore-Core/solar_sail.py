import logging

class SolarSail:
    def __init__(self, area, reflectivity):
        self.area = area
        self.reflectivity = reflectivity
        self.is_deployed = False
        logging.basicConfig(level=logging.INFO)

    def calculate_thrust(self, solar_constant):
        if not self.is_deployed:
            return 0
        thrust = solar_constant * self.area * self.reflectivity
        logging.info(f"Calculated thrust: {thrust}")
        return thrust

    def deploy(self):
        self.is_deployed = True
        logging.info("Solar sail deployed.")

    def retract(self):
        self.is_deployed = False
        logging.info("Solar sail retracted.")

    def simulate(self, duration):
        if not self.is_deployed:
            logging.info("Solar sail is not deployed. Simulation aborted.")
            return
        for t in range(duration):
            thrust = self.calculate_thrust(1361)  # Solar constant in W/m^2
            logging.info(f"Time: {t}, Thrust: {thrust}")

    def status(self):
        status = {
            "is_deployed": self.is_deployed,
            "thrust": self.calculate_thrust(1361) if self.is_deployed else 0
        }
        logging.info(f"Status: {status}")
        return status