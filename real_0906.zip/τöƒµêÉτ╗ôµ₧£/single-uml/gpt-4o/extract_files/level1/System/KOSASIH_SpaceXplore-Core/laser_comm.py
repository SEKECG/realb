import logging

class LaserCommunication:
    def __init__(self, power, distance, efficiency=0.8):
        self.power = power
        self.distance = distance
        self.efficiency = efficiency
        logging.basicConfig(level=logging.INFO)

    def calculate_signal_strength(self):
        signal_strength = self.power * self.efficiency / (self.distance ** 2)
        logging.info(f"Calculated signal strength: {signal_strength}")
        return signal_strength

    def transmit_data(self, data):
        signal_strength = self.calculate_signal_strength()
        if signal_strength > 0.1:  # Assuming 0.1 is the threshold for successful transmission
            logging.info(f"Transmitting data: {data}")
            return True
        else:
            logging.error("Signal strength too low for transmission.")
            return False

if __name__ == "__main__":
    laser_comm = LaserCommunication(power=100, distance=10)
    laser_comm.transmit_data("Hello, SpaceXplore!")