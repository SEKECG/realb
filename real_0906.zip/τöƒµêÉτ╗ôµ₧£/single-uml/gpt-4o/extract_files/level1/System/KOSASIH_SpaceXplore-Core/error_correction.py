import numpy as np

class ErrorCorrection:
    def __init__(self):
        pass

    def detect_and_correct(self, received_data):
        # Calculate parity bits
        p1 = received_data[0] ^ received_data[2] ^ received_data[4] ^ received_data[6]
        p2 = received_data[1] ^ received_data[2] ^ received_data[5] ^ received_data[6]
        p3 = received_data[3] ^ received_data[4] ^ received_data[5] ^ received_data[6]

        # Calculate error position
        error_position = p1 + (p2 << 1) + (p3 << 2)

        # Correct the error if there is one
        if error_position != 0:
            received_data[error_position - 1] ^= 1

        # Extract the original 4-bit data
        corrected_data = np.array([received_data[2], received_data[4], received_data[5], received_data[6]])
        return corrected_data

    def hamming_code(self, data):
        # Convert data to numpy array
        data = np.array([int(bit) for bit in data])

        # Calculate parity bits
        p1 = data[0] ^ data[1] ^ data[3]
        p2 = data[0] ^ data[2] ^ data[3]
        p3 = data[1] ^ data[2] ^ data[3]

        # Create the 7-bit Hamming code
        hamming_code = np.array([p1, p2, data[0], p3, data[1], data[2], data[3]])
        return hamming_code