import random
import logging

class SensorIntegration:
    def __init__(self):
        self.sensors = {
            "temperature": self.read_temperature,
            "humidity": self.read_humidity,
            "pressure": self.read_pressure,
            "biosensor": self.read_biosensor
        }
        logging.basicConfig(level=logging.INFO)

    def collect_data(self):
        data = {}
        for sensor_name, sensor_method in self.sensors.items():
            data[sensor_name] = sensor_method()
        return data

    def read_temperature(self):
        temperature = random.uniform(-50, 50)
        logging.info(f"Temperature: {temperature} °C")
        return temperature

    def read_humidity(self):
        humidity = random.uniform(0, 100)
        logging.info(f"Humidity: {humidity} %")
        return humidity

    def read_pressure(self):
        pressure = random.uniform(900, 1100)
        logging.info(f"Pressure: {pressure} hPa")
        return pressure

    def read_biosensor(self):
        biosignal = random.choice([True, False])
        logging.info(f"Biosensor detected: {biosignal}")
        return biosignal

if __name__ == "__main__":
    sensor_integration = SensorIntegration()
    sensor_data = sensor_integration.collect_data()
    print(sensor_data)