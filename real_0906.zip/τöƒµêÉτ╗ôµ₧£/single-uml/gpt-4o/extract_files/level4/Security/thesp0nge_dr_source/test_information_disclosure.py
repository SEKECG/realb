import unittest
from dr_source.core.detectors.information_disclosure import InformationDisclosureDetector
from dr_source.core.codebase import FileObject

class TestInformationDisclosureDetector(unittest.TestCase):
    def test_information_disclosure_detector_regex(self):
        sample_code = """
        try {
            // Some code
        } catch (Exception e) {
            e.printStackTrace();
        }
        """
        file_obj = FileObject(path="sample.java", content=sample_code)
        detector = InformationDisclosureDetector()
        results = detector.detect(file_obj)
        
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]['vuln_type'], 'Information Disclosure')
        self.assertEqual(results[0]['file'], 'sample.java')
        self.assertEqual(results[0]['line'], 5)

if __name__ == '__main__':
    unittest.main()