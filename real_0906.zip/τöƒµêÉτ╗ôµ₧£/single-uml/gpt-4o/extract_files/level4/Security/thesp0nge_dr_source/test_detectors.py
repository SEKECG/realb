import unittest
from dr_source.core.detectors.command_injection import CommandInjectionDetector
from dr_source.core.detectors.crypto import CryptoDetector
from dr_source.core.detectors.ldap_injection import LDAPInjectionDetector
from dr_source.core.detectors.path_traversal import PathTraversalDetector
from dr_source.core.detectors.serialization import SerializationDetector
from dr_source.core.detectors.sql_injection import SQLInjectionDetector
from dr_source.core.detectors.ssrf import SSRFDetector
from dr_source.core.detectors.xss import XSSDetector
from dr_source.core.detectors.xxe import XXEDetector
from dr_source.core.codebase import FileObject

CMD_SAMPLE = """
public class Test {
    public void test() {
        Runtime.getRuntime().exec(request.getParameter("cmd"));
    }
}
"""

PATH_SAMPLE = """
public class Test {
    public void test() {
        String filePath = request.getParameter("file");
        File file = new File(filePath);
    }
}
"""

SERIAL_SAMPLE = """
public class Test {
    public void test() {
        ObjectInputStream ois = new ObjectInputStream(in);
        ois.readObject();
    }
}
"""

SQLI_SAMPLE = """
public class Test {
    public void test() {
        String query = "SELECT * FROM users WHERE id = " + request.getParameter("id");
        Statement stmt = connection.createStatement();
        stmt.executeQuery(query);
    }
}
"""

XSS_SAMPLE = """
public class Test {
    public void test() {
        out.println(request.getParameter("input"));
    }
}
"""

class TestDetectors(unittest.TestCase):

    def test_command_injection_detector(self):
        detector = CommandInjectionDetector()
        file_obj = FileObject(path="Test.java", content=CMD_SAMPLE)
        results = detector.detect(file_obj)
        self.assertTrue(len(results) > 0)
        self.assertEqual(results[0]['vuln_type'], 'Command Injection')

    def test_crypto_detector_cipher(self):
        detector = CryptoDetector()
        file_obj = FileObject(path="Test.java", content="Cipher.getInstance(\"DES\");")
        results = detector.detect(file_obj)
        self.assertTrue(len(results) > 0)
        self.assertEqual(results[0]['vuln_type'], 'Unsafe Crypto')

    def test_crypto_detector_md5(self):
        detector = CryptoDetector()
        file_obj = FileObject(path="Test.java", content="MessageDigest.getInstance(\"MD5\");")
        results = detector.detect(file_obj)
        self.assertTrue(len(results) > 0)
        self.assertEqual(results[0]['vuln_type'], 'Unsafe Hashing')

    def test_crypto_detector_no_issue(self):
        detector = CryptoDetector()
        file_obj = FileObject(path="Test.java", content="MessageDigest.getInstance(\"SHA-256\");")
        results = detector.detect(file_obj)
        self.assertTrue(len(results) == 0)

    def test_crypto_detector_sha1(self):
        detector = CryptoDetector()
        file_obj = FileObject(path="Test.java", content="MessageDigest.getInstance(\"SHA-1\");")
        results = detector.detect(file_obj)
        self.assertTrue(len(results) > 0)
        self.assertEqual(results[0]['vuln_type'], 'Unsafe Hashing')

    def test_ldap_injection_detector(self):
        detector = LDAPInjectionDetector()
        file_obj = FileObject(path="Test.java", content="String filter = \"(uid=\" + request.getParameter(\"user\") + \")\";")
        results = detector.detect(file_obj)
        self.assertTrue(len(results) > 0)
        self.assertEqual(results[0]['vuln_type'], 'LDAP Injection')

    def test_path_traversal_detector(self):
        detector = PathTraversalDetector()
        file_obj = FileObject(path="Test.java", content=PATH_SAMPLE)
        results = detector.detect(file_obj)
        self.assertTrue(len(results) > 0)
        self.assertEqual(results[0]['vuln_type'], 'Path Traversal')

    def test_serialization_detector(self):
        detector = SerializationDetector()
        file_obj = FileObject(path="Test.java", content=SERIAL_SAMPLE)
        results = detector.detect(file_obj)
        self.assertTrue(len(results) > 0)
        self.assertEqual(results[0]['vuln_type'], 'Serialization Issue')

    def test_sql_injection_detector(self):
        detector = SQLInjectionDetector()
        file_obj = FileObject(path="Test.java", content=SQLI_SAMPLE)
        results = detector.detect(file_obj)
        self.assertTrue(len(results) > 0)
        self.assertEqual(results[0]['vuln_type'], 'SQL Injection')

    def test_ssrf_detector(self):
        detector = SSRFDetector()
        file_obj = FileObject(path="Test.java", content="URL url = new URL(request.getParameter(\"url\"));")
        results = detector.detect(file_obj)
        self.assertTrue(len(results) > 0)
        self.assertEqual(results[0]['vuln_type'], 'SSRF')

    def test_xss_detector(self):
        detector = XSSDetector()
        file_obj = FileObject(path="Test.java", content=XSS_SAMPLE)
        results = detector.detect(file_obj)
        self.assertTrue(len(results) > 0)
        self.assertEqual(results[0]['vuln_type'], 'XSS')

    def test_xxe_detector(self):
        detector = XXEDetector()
        file_obj = FileObject(path="Test.xml", content="""<!DOCTYPE foo [<!ELEMENT foo ANY ><!ENTITY xxe SYSTEM "file:///etc/passwd" >]><foo>&xxe;</foo>""")
        results = detector.detect(file_obj)
        self.assertTrue(len(results) > 0)
        self.assertEqual(results[0]['vuln_type'], 'XXE')

if __name__ == '__main__':
    unittest.main()