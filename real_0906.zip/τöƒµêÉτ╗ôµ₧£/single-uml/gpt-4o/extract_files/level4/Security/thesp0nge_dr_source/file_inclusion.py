import re
import logging

logger = logging.getLogger(__name__)

class FileInclusionDetector:
    BUILTIN_REGEX_PATTERNS = [
        r'include\s*\(\s*[\'"][^\'"]+[\'"]\s*\)',
        r'require\s*\(\s*[\'"][^\'"]+[\'"]\s*\)',
        r'include_once\s*\(\s*[\'"][^\'"]+[\'"]\s*\)',
        r'require_once\s*\(\s*[\'"][^\'"]+[\'"]\s*\)'
    ]

    def __init__(self):
        self.regex_patterns = self.BUILTIN_REGEX_PATTERNS
        self.ast_mode = False

    def detect(self, file_object):
        vulnerabilities = []
        for pattern in self.regex_patterns:
            matches = re.finditer(pattern, file_object.content)
            for match in matches:
                vulnerabilities.append({
                    'file': file_object.path,
                    'vuln_type': 'File Inclusion',
                    'match': match.group(),
                    'line': file_object.content.count('\n', 0, match.start()) + 1
                })
        return vulnerabilities

    def detect_ast_from_tree(self, file_object, ast_tree):
        # Placeholder for AST-based detection logic
        return []