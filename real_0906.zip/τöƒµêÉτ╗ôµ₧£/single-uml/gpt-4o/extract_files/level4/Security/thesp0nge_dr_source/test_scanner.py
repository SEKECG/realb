import os
import tempfile
from dr_source.core.codebase import Codebase
from dr_source.core.scanner import Scanner
from dr_source.core.detectors.sql_injection import SQLInjectionDetector
from dr_source.core.detectors.xss import XSSDetector

def test_scanner_integration():
    # Create temporary test files
    with tempfile.TemporaryDirectory() as temp_dir:
        sql_injection_file_path = os.path.join(temp_dir, "sql_injection_test.java")
        xss_file_path = os.path.join(temp_dir, "xss_test.jsp")

        sql_injection_content = """
        public class Test {
            public void vulnerableMethod(String userInput) {
                String query = "SELECT * FROM users WHERE name = '" + userInput + "'";
                // Execute query
            }
        }
        """
        xss_content = """
        <%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
        <%
            String userInput = request.getParameter("input");
            out.println(userInput);
        %>
        """

        with open(sql_injection_file_path, "w") as f:
            f.write(sql_injection_content)
        with open(xss_file_path, "w") as f:
            f.write(xss_content)

        # Initialize codebase and scanner
        codebase = Codebase(temp_dir)
        codebase.load_files()
        scanner = Scanner(codebase, ast_mode=True)

        # Add detectors
        scanner.detectors.append(SQLInjectionDetector())
        scanner.detectors.append(XSSDetector())

        # Perform scan
        results = scanner.scan()

        # Check results
        assert len(results) > 0, "No vulnerabilities detected"
        sql_injection_found = any(result['vuln_type'] == 'SQL Injection' for result in results)
        xss_found = any(result['vuln_type'] == 'XSS' for result in results)

        assert sql_injection_found, "SQL Injection vulnerability not detected"
        assert xss_found, "XSS vulnerability not detected"

if __name__ == "__main__":
    test_scanner_integration()