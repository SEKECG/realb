import logging

logger = logging.getLogger(__name__)

class ASCIIReport:
    def generate(self, results):
        """
        Generates an ASCII table report as a string.
        Expects results to be a list of dictionaries with keys: vuln_type, file, line.
        """
        headers = ["Vulnerability Type", "File", "Line"]
        table = [headers]
        for result in results:
            row = [result["vuln_type"], result["file"], result["line"]]
            table.append(row)
        
        col_widths = [max(len(str(item)) for item in col) for col in zip(*table)]
        format_str = " | ".join(["{:<" + str(width) + "}" for width in col_widths])
        
        report_lines = [format_str.format(*row) for row in table]
        report = "\n".join(report_lines)
        
        return report