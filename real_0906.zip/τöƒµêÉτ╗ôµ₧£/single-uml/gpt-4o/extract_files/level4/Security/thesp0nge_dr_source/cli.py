import argparse
import logging
import os
import json
from dr_source.core.codebase import Codebase
from dr_source.core.scanner import Scanner
from dr_source.core.db import ScanDatabase
from dr_source.core.detection_rules import DetectionRules
from dr_source.reports.sarif import SARIFReport
from dr_source.reports.ascii import ASCIIReport
from dr_source.core.usage import where_is_it_used
from dr_source.logging import setup_logging

def get_version():
    return "DRSource 1.0.0"

def main(target_path, ast, init_db, history, compare, export, where_used, verbose, output, debug, show_trace, show_version):
    logger = setup_logging(debug)
    
    if show_version:
        print(get_version())
        return

    if init_db:
        db = ScanDatabase(target_path)
        db.initialize()
        logger.info("Database initialized.")
        return

    if history:
        db = ScanDatabase(target_path)
        history = db.get_scan_history()
        for record in history:
            print(record)
        return

    if compare:
        db = ScanDatabase(target_path)
        old_scan_id, new_scan_id = compare.split(',')
        comparison = db.compare_scans(old_scan_id, new_scan_id)
        print(json.dumps(comparison, indent=2))
        return

    if where_used:
        codebase = Codebase(target_path)
        codebase.load_files()
        usage = where_is_it_used(codebase, where_used)
        print(json.dumps(usage, indent=2))
        return

    codebase = Codebase(target_path)
    codebase.load_files()

    scanner = Scanner(codebase, ast_mode=ast)
    results = scanner.scan()

    if export:
        if export.lower() == 'sarif':
            report = SARIFReport()
            report_content = report.generate(results)
            with open(output, 'w') as f:
                f.write(report_content)
        elif export.lower() == 'json':
            with open(output, 'w') as f:
                json.dump(results, f, indent=2)
        elif export.lower() == 'html':
            # Placeholder for HTML report generation
            pass
        else:
            logger.error("Unsupported export format.")
    else:
        report = ASCIIReport()
        report_content = report.generate(results)
        print(report_content)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="DRSource - A static analysis tool for detecting vulnerabilities in Java/JSP projects.")
    parser.add_argument("target_path", help="Path of the codebase to analyze.")
    parser.add_argument("--ast", action="store_true", help="Enable AST-based detection.")
    parser.add_argument("--init-db", action="store_true", help="Initialize the database.")
    parser.add_argument("--history", action="store_true", help="View scan history.")
    parser.add_argument("--compare", help="Compare scans (old_scan_id,new_scan_id).")
    parser.add_argument("--export", choices=["sarif", "json", "html"], help="Export results in SARIF, JSON, or HTML formats.")
    parser.add_argument("--where-used", help="Find where a class is used.")
    parser.add_argument("--verbose", action="store_true", help="Enable verbose output.")
    parser.add_argument("--output", help="Output file for export.")
    parser.add_argument("--debug", action="store_true", help="Enable debug logging.")
    parser.add_argument("--show-trace", action="store_true", help="Show trace information.")
    parser.add_argument("--version", action="store_true", help="Display version information.")
    
    args = parser.parse_args()
    main(args.target_path, args.ast, args.init_db, args.history, args.compare, args.export, args.where_used, args.verbose, args.output, args.debug, args.show_trace, args.version)