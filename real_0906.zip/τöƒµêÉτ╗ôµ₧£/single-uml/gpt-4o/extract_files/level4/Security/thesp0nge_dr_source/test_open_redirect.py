import unittest
from dr_source.core.detectors.open_redirect import OpenRedirectDetector
from dr_source.core.codebase import FileObject

class TestOpenRedirectDetector(unittest.TestCase):
    def test_open_redirect_detector_regex(self):
        sample_code = """
        public class RedirectServlet extends HttpServlet {
            protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
                String url = request.getParameter("url");
                response.sendRedirect(url);
            }
        }
        """
        file_obj = FileObject(path="RedirectServlet.java", content=sample_code)
        detector = OpenRedirectDetector()
        vulnerabilities = detector.detect(file_obj)
        
        self.assertEqual(len(vulnerabilities), 1)
        self.assertEqual(vulnerabilities[0]['vuln_type'], 'Open Redirect')
        self.assertEqual(vulnerabilities[0]['line'], 5)

if __name__ == '__main__':
    unittest.main()