import javalang
import logging

logger = logging.getLogger(__name__)

def where_is_it_used(codebase, target_class):
    usage_records = []
    for file_obj in codebase.files:
        used, current_class = find_usage_in_file(file_obj, target_class)
        if used and current_class != target_class:
            usage_records.append({"class": current_class, "file": file_obj.path})
    return usage_records

def find_usage_in_file(file_obj, target_class):
    try:
        tree = javalang.parse.parse(file_obj.content)
    except javalang.parser.JavaSyntaxError as e:
        logger.error(f"Syntax error in file {file_obj.path}: {e}")
        return False, None

    current_class = None
    used = False

    for path, node in tree:
        if isinstance(node, javalang.tree.ClassDeclaration):
            current_class = node.name
        if isinstance(node, javalang.tree.MethodInvocation) and node.member == target_class:
            used = True

    return used, current_class