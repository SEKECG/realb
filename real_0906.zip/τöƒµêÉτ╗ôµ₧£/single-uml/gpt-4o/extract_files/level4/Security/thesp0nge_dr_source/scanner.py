import os
import concurrent.futures
from tqdm import tqdm
from dr_source.core.codebase import Codebase
from dr_source.core.detectors.sql_injection import SQLInjectionDetector
from dr_source.core.detectors.xss import XSSDetector
from dr_source.core.detectors.path_traversal import PathTraversalDetector
from dr_source.core.detectors.command_injection import CommandInjectionDetector
from dr_source.core.detectors.serialization import SerializationDetector
from dr_source.core.detectors.ldap_injection import LDAPInjectionDetector
from dr_source.core.detectors.xxe import XXEDetector
from dr_source.core.detectors.ssrf import SSRFDetector
from dr_source.core.detectors.crypto import CryptoDetector

class Scanner:
    def __init__(self, codebase, ast_mode=False):
        self.codebase = codebase
        self.ast_mode = ast_mode
        self.detectors = [
            SQLInjectionDetector(),
            XSSDetector(),
            PathTraversalDetector(),
            CommandInjectionDetector(),
            SerializationDetector(),
            LDAPInjectionDetector(),
            XXEDetector(),
            SSRFDetector(),
            CryptoDetector()
        ]

    def scan(self):
        results = []
        with concurrent.futures.ThreadPoolExecutor() as executor:
            futures = [executor.submit(self.scan_file, file_obj) for file_obj in self.codebase.files]
            for future in tqdm(concurrent.futures.as_completed(futures), total=len(futures), desc="Scanning files"):
                results.extend(future.result())
        return results

    def scan_file(self, file_obj):
        vulnerabilities = []
        for detector in self.detectors:
            vulnerabilities.extend(detector.detect(file_obj))
            if self.ast_mode:
                ast_tree = self._parse_ast(file_obj)
                vulnerabilities.extend(detector.detect_ast_from_tree(file_obj, ast_tree))
        return vulnerabilities

    def _parse_ast(self, file_obj):
        import javalang
        try:
            tree = javalang.parse.parse(file_obj.content)
            return tree
        except javalang.parser.JavaSyntaxError:
            return None