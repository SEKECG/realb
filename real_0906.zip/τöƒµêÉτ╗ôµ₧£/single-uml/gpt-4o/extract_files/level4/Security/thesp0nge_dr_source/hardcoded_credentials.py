import re
import logging

logger = logging.getLogger(__name__)

class HardcodedCredentialsDetector:
    BUILTIN_REGEX_PATTERNS = [
        r'password\s*=\s*["\'].*["\']',
        r'api_key\s*=\s*["\'].*["\']',
        r'username\s*=\s*["\'].*["\']',
        r'credential\s*=\s*["\'].*["\']',
    ]

    def __init__(self):
        self.regex_patterns = self.BUILTIN_REGEX_PATTERNS
        self.ast_mode = False

    def detect(self, file_object):
        vulnerabilities = []
        for pattern in self.regex_patterns:
            matches = re.finditer(pattern, file_object.content)
            for match in matches:
                vulnerabilities.append({
                    'file': file_object.path,
                    'vuln_type': 'Hardcoded Credentials',
                    'match': match.group(),
                    'line': file_object.content.count('\n', 0, match.start()) + 1
                })
        return vulnerabilities

    def detect_ast_from_tree(self, file_object, ast_tree):
        vulnerabilities = []
        for node in ast_tree:
            if isinstance(node, dict) and 'type' in node and node['type'] == 'VariableDeclarator':
                if any(keyword in node['name'] for keyword in ['password', 'api_key', 'username', 'credential']):
                    if 'initializer' in node and isinstance(node['initializer'], str):
                        vulnerabilities.append({
                            'file': file_object.path,
                            'vuln_type': 'Hardcoded Credentials',
                            'match': node['initializer'],
                            'line': node['line']
                        })
        return vulnerabilities