import re
import logging

logger = logging.getLogger(__name__)

class SessionFixationDetector:
    REGEX_GETSESSION = r'request\.getSession\(\)'
    REGEX_SAFE = r'\.(changeSessionId|invalidate)\(\)'

    def _collect_identifiers(self, expr):
        identifiers = set()
        if isinstance(expr, list):
            for item in expr:
                identifiers.update(self._collect_identifiers(item))
        elif isinstance(expr, dict):
            for key, value in expr.items():
                identifiers.update(self._collect_identifiers(value))
        elif isinstance(expr, str):
            identifiers.add(expr)
        return identifiers

    def detect(self, file_object):
        results = []
        lines = file_object.content.split('\n')
        for i, line in enumerate(lines):
            if re.search(self.REGEX_GETSESSION, line):
                session_var = re.search(r'(\w+)\s*=\s*request\.getSession\(\)', line)
                if session_var:
                    session_var_name = session_var.group(1)
                    safe_usage = False
                    for j in range(i + 1, len(lines)):
                        if re.search(self.REGEX_SAFE, lines[j]):
                            if session_var_name in self._collect_identifiers(lines[j]):
                                safe_usage = True
                                break
                    if not safe_usage:
                        results.append({
                            'file': file_object.path,
                            'vuln_type': 'Session Fixation',
                            'match': line.strip(),
                            'line': i + 1
                        })
        return results

    def detect_ast_from_tree(self, file_object, ast_tree):
        results = []
        for node in ast_tree:
            if isinstance(node, dict) and 'type' in node and node['type'] == 'MethodInvocation':
                if re.search(self.REGEX_GETSESSION, node['expression']):
                    session_var_name = node['expression'].split('=')[0].strip()
                    safe_usage = False
                    for sub_node in ast_tree:
                        if isinstance(sub_node, dict) and 'type' in sub_node and sub_node['type'] == 'MethodInvocation':
                            if re.search(self.REGEX_SAFE, sub_node['expression']):
                                if session_var_name in self._collect_identifiers(sub_node['expression']):
                                    safe_usage = True
                                    break
                    if not safe_usage:
                        results.append({
                            'file': file_object.path,
                            'vuln_type': 'Session Fixation',
                            'match': node['expression'],
                            'line': node['line']
                        })
        return results