import unittest
from dr_source.core.detectors.file_inclusion import FileInclusionDetector
from dr_source.core.codebase import FileObject

class TestFileInclusionDetector(unittest.TestCase):

    def test_file_inclusion_detector_regex(self):
        sample_code = """
        <%@ include file="header.jsp" %>
        <%@ include file="footer.jsp" %>
        """
        file_obj = FileObject(path="sample.jsp", content=sample_code)
        detector = FileInclusionDetector()
        vulnerabilities = detector.detect(file_obj)
        
        self.assertEqual(len(vulnerabilities), 2)
        self.assertEqual(vulnerabilities[0]['vuln_type'], 'File Inclusion')
        self.assertEqual(vulnerabilities[0]['file'], 'sample.jsp')
        self.assertEqual(vulnerabilities[0]['line'], 2)
        self.assertEqual(vulnerabilities[1]['vuln_type'], 'File Inclusion')
        self.assertEqual(vulnerabilities[1]['file'], 'sample.jsp')
        self.assertEqual(vulnerabilities[1]['line'], 3)

if __name__ == '__main__':
    unittest.main()