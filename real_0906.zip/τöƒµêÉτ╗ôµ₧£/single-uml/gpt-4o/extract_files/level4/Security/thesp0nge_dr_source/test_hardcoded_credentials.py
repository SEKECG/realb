import unittest
from dr_source.core.detectors.hardcoded_credentials import HardcodedCredentialsDetector
from dr_source.core.codebase import FileObject

class TestHardcodedCredentialsDetector(unittest.TestCase):
    def test_hardcoded_credentials_detector(self):
        sample_code = """
        public class Example {
            private String password = "hardcoded_password";
            private String apiKey = "hardcoded_api_key";
        }
        """
        file_obj = FileObject(path="Example.java", content=sample_code)
        detector = HardcodedCredentialsDetector()
        results = detector.detect(file_obj)
        
        self.assertEqual(len(results), 2)
        self.assertEqual(results[0]['vuln_type'], 'Hardcoded Credentials')
        self.assertEqual(results[0]['match'], 'hardcoded_password')
        self.assertEqual(results[1]['vuln_type'], 'Hardcoded Credentials')
        self.assertEqual(results[1]['match'], 'hardcoded_api_key')

if __name__ == '__main__':
    unittest.main()