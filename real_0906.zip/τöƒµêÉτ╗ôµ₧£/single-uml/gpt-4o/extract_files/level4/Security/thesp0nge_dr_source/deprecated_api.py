import re
import logging

logger = logging.getLogger(__name__)

class DeprecatedAPIDetector:
    BUILTIN_REGEX_PATTERNS = [
        r'\bThread\.stop\b',
        r'\bThread\.suspend\b',
        r'\bThread\.resume\b',
        r'\bSystem\.runFinalizersOnExit\b'
    ]

    def __init__(self):
        self.regex_patterns = self.BUILTIN_REGEX_PATTERNS
        self.ast_mode = False

    def detect(self, file_object):
        results = []
        for pattern in self.regex_patterns:
            for match in re.finditer(pattern, file_object.content):
                results.append({
                    'file': file_object.path,
                    'vuln_type': 'Deprecated API Usage',
                    'match': match.group(),
                    'line': file_object.content.count('\n', 0, match.start()) + 1
                })
        return results

    def detect_ast_from_tree(self, file_object, ast_tree):
        results = []
        deprecated_methods = ['stop', 'suspend', 'resume', 'runFinalizersOnExit']
        for node in ast_tree:
            if hasattr(node, 'member') and node.member in deprecated_methods:
                results.append({
                    'file': file_object.path,
                    'vuln_type': 'Deprecated API Usage',
                    'method': node.member,
                    'line': node.position.line
                })
        return results