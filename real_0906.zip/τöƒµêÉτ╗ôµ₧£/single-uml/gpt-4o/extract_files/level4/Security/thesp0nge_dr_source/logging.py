import logging

def setup_logging(debug):
    """
    Configure and return a logger with customizable log level (DEBUG or INFO) and formatted output to stdout.
    """
    logger = logging.getLogger('dr_source')
    logger.setLevel(logging.DEBUG if debug else logging.INFO)
    
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG if debug else logging.INFO)
    
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    ch.setFormatter(formatter)
    
    logger.addHandler(ch)
    
    return logger