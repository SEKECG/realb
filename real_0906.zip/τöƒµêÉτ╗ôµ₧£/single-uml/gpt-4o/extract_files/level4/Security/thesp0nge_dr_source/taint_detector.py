import logging
import ast

logger = logging.getLogger(__name__)

class TaintDetector:
    def detect_ast_taint(self, file_object, ast_tree, sink_list, vuln_prefix):
        tainted_vars = self._collect_tainted_vars(ast_tree)
        vulnerabilities = self._find_vulnerabilities(ast_tree, tainted_vars, sink_list, vuln_prefix)
        return vulnerabilities

    def _collect_tainted_vars(self, ast_tree):
        tainted_vars = set()
        for node in ast.walk(ast_tree):
            if isinstance(node, ast.Call) and self._is_taint_source(node):
                tainted_vars.update(self._extract_identifiers(node))
        return tainted_vars

    def _is_taint_source(self, node):
        if isinstance(node.func, ast.Attribute) and node.func.attr == 'getParameter':
            return True
        return False

    def _extract_identifiers(self, node):
        identifiers = set()
        for child in ast.walk(node):
            if isinstance(child, ast.Name):
                identifiers.add(child.id)
        return identifiers

    def _find_vulnerabilities(self, ast_tree, tainted_vars, sink_list, vuln_prefix):
        vulnerabilities = []
        for node in ast.walk(ast_tree):
            if isinstance(node, ast.Call) and self._is_sink(node, sink_list):
                if any(arg.id in tainted_vars for arg in node.args if isinstance(arg, ast.Name)):
                    vulnerabilities.append({
                        'file': file_object.path,
                        'vuln_type': vuln_prefix + 'Taint',
                        'line': node.lineno,
                        'match': ast.dump(node)
                    })
        return vulnerabilities

    def _is_sink(self, node, sink_list):
        if isinstance(node.func, ast.Name) and node.func.id in sink_list:
            return True
        return False