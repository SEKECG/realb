import re
import logging

logger = logging.getLogger(__name__)

class SerializationDetector:
    BUILTIN_AST_SINK = ["readObject"]
    BUILTIN_REGEX_PATTERNS = [
        r"new\s+ObjectInputStream\s*\(\s*.*\s*\)\s*\.readObject\s*\("
    ]

    def __init__(self):
        self.ast_mode = False
        self.ast_sink = self.BUILTIN_AST_SINK
        self.regex_patterns = self.BUILTIN_REGEX_PATTERNS

    def detect(self, file_object):
        vulnerabilities = []
        for pattern in self.regex_patterns:
            matches = re.finditer(pattern, file_object.content)
            for match in matches:
                vulnerabilities.append({
                    "file": file_object.path,
                    "vuln_type": "Serialization Issue",
                    "match": match.group(),
                    "line": file_object.content.count('\n', 0, match.start()) + 1
                })
        return vulnerabilities

    def detect_ast_from_tree(self, file_object, ast_tree):
        vulnerabilities = []
        for node in ast_tree:
            if isinstance(node, dict) and node.get("type") == "MethodInvocation":
                if node.get("name") in self.ast_sink:
                    vulnerabilities.append({
                        "file": file_object.path,
                        "vuln_type": "Serialization Issue",
                        "match": node.get("name"),
                        "line": node.get("line")
                    })
        return vulnerabilities