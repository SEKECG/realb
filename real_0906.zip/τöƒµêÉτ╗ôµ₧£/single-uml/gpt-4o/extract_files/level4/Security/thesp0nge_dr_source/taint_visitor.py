import logging

logger = logging.getLogger(__name__)

class TaintVisitor:
    def __init__(self):
        self.source_member = "getParameter"
        self.source_qualifier = "request"
        self.tainted = {}

    def collect_identifiers(self, expr):
        identifiers = set()
        if isinstance(expr, list):
            for item in expr:
                identifiers.update(self.collect_identifiers(item))
        elif hasattr(expr, 'name'):
            identifiers.add(expr.name)
        elif hasattr(expr, 'value'):
            identifiers.update(self.collect_identifiers(expr.value))
        return identifiers

    def get_vulnerabilities(self, ast_tree, sink_list):
        vulnerabilities = []
        for node in ast_tree:
            if self.is_tainted(node):
                for sink in sink_list:
                    if sink in node:
                        vulnerabilities.append({
                            "node": node,
                            "sink": sink,
                            "trace": self.tainted[node]
                        })
        return vulnerabilities

    def is_tainted(self, expr):
        identifiers = self.collect_identifiers(expr)
        for identifier in identifiers:
            if identifier in self.tainted:
                return True
        return False

    def visit(self, node):
        if hasattr(node, 'body'):
            for child in node.body:
                self.visit(child)
        if hasattr(node, 'value'):
            if self.source_qualifier in node.value and self.source_member in node.value:
                identifiers = self.collect_identifiers(node)
                for identifier in identifiers:
                    self.tainted[identifier] = node
        if hasattr(node, 'targets'):
            for target in node.targets:
                if self.is_tainted(target):
                    identifiers = self.collect_identifiers(target)
                    for identifier in identifiers:
                        self.tainted[identifier] = node