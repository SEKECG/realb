import unittest
from dr_source.core.codebase import Codebase
from dr_source.core.scanner import Scanner
from dr_source.core.detectors.sql_injection import SQLInjectionDetector
from dr_source.core.taint_detector import TaintDetector
from dr_source.core.taint_visitor import TaintVisitor
import javalang

class TestASTScanner(unittest.TestCase):

    def test_scanner_ast_mode(self):
        code_snippet = """
        public class Test {
            public void vulnerableMethod(HttpServletRequest request) {
                String userInput = request.getParameter("input");
                String query = "SELECT * FROM users WHERE name = '" + userInput + "'";
                Statement stmt = connection.createStatement();
                ResultSet rs = stmt.executeQuery(query);
            }
        }
        """
        file_obj = FileObject(path="Test.java", content=code_snippet)
        codebase = Codebase(root_path=".")
        codebase.files.append(file_obj)
        
        scanner = Scanner(codebase=codebase, ast_mode=True)
        results = scanner.scan()
        
        self.assertTrue(any(result['vuln_type'] == 'SQL Injection' for result in results))

if __name__ == '__main__':
    unittest.main()