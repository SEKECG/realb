import os
import sqlite3
import tempfile
import unittest
from dr_source.core.db import ScanDatabase

class TestScanDatabase(unittest.TestCase):

    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = os.path.join(self.temp_dir.name, 'test_project.db')
        self.db = ScanDatabase('test_project')
        self.db.db_path = self.db_path
        self.db.initialize()

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_database_initialization_and_store(self):
        scan_id = self.db.start_scan()
        vuln = {
            'file': 'test_file.java',
            'vuln_type': 'SQL Injection',
            'match': 'executeQuery("SELECT * FROM users WHERE id=" + userId)',
            'line': 42
        }
        self.db.store_vulnerability(scan_id, vuln)
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM vulnerabilities WHERE scan_id=?", (scan_id,))
        rows = cursor.fetchall()
        conn.close()
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0][1:], ('test_file.java', 'SQL Injection', 'executeQuery("SELECT * FROM users WHERE id=" + userId)', 42))

    def test_store_vulnerabilities_batch(self):
        scan_id = self.db.start_scan()
        vulns = [
            {
                'file': 'test_file1.java',
                'vuln_type': 'SQL Injection',
                'match': 'executeQuery("SELECT * FROM users WHERE id=" + userId)',
                'line': 42
            },
            {
                'file': 'test_file2.java',
                'vuln_type': 'XSS',
                'match': 'out.println(request.getParameter("userInput"))',
                'line': 27
            }
        ]
        self.db.store_vulnerabilities(scan_id, vulns)
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM vulnerabilities WHERE scan_id=?", (scan_id,))
        rows = cursor.fetchall()
        conn.close()
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0][1:], ('test_file1.java', 'SQL Injection', 'executeQuery("SELECT * FROM users WHERE id=" + userId)', 42))
        self.assertEqual(rows[1][1:], ('test_file2.java', 'XSS', 'out.println(request.getParameter("userInput"))', 27))

if __name__ == '__main__':
    unittest.main()