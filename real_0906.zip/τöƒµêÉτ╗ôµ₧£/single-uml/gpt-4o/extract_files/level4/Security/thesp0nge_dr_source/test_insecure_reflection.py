import unittest
from dr_source.core.detectors.insecure_reflection import InsecureReflectionDetector
from dr_source.core.codebase import FileObject

class TestInsecureReflectionDetector(unittest.TestCase):

    def test_insecure_reflection_detector_regex(self):
        sample_code = """
        public class Test {
            public void testMethod(String className) {
                Class<?> clazz = Class.forName(className);
                Object instance = clazz.newInstance();
            }
        }
        """
        file_obj = FileObject(path="Test.java", content=sample_code)
        detector = InsecureReflectionDetector()
        vulnerabilities = detector.detect(file_obj)
        
        self.assertEqual(len(vulnerabilities), 1)
        self.assertEqual(vulnerabilities[0]['vuln_type'], 'Insecure Reflection')
        self.assertIn('Class.forName', vulnerabilities[0]['match'])

if __name__ == '__main__':
    unittest.main()