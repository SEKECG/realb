import unittest
from dr_source.core.detectors.deprecated_api import DeprecatedAPIDetector
from dr_source.core.codebase import FileObject

class TestDeprecatedAPIDetector(unittest.TestCase):

    def test_deprecated_api_detector_regex(self):
        sample_code = """
        public class Test {
            public void testMethod() {
                Thread t = new Thread();
                t.stop();
                t.suspend();
                t.resume();
                Runtime.runFinalizersOnExit(true);
            }
        }
        """
        file_obj = FileObject(path="Test.java", content=sample_code)
        detector = DeprecatedAPIDetector()
        results = detector.detect(file_obj)
        
        expected_vulnerabilities = [
            {"file": "Test.java", "vuln_type": "Deprecated API", "match": "stop", "line": 5},
            {"file": "Test.java", "vuln_type": "Deprecated API", "match": "suspend", "line": 6},
            {"file": "Test.java", "vuln_type": "Deprecated API", "match": "resume", "line": 7},
            {"file": "Test.java", "vuln_type": "Deprecated API", "match": "runFinalizersOnExit", "line": 8},
        ]
        
        self.assertEqual(results, expected_vulnerabilities)

if __name__ == "__main__":
    unittest.main()