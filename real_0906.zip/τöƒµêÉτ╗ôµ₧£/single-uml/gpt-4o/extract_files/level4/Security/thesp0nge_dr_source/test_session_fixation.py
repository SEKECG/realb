import unittest
from dr_source.core.detectors.session_fixation import SessionFixationDetector
from dr_source.core.codebase import FileObject

class TestSessionFixationDetector(unittest.TestCase):

    def setUp(self):
        self.detector = SessionFixationDetector()

    def test_session_fixation_detector_ast(self):
        java_code = """
        public class Test {
            public void testMethod(HttpServletRequest request) {
                HttpSession session = request.getSession();
                // No call to changeSessionId() or invalidate()
            }
        }
        """
        file_obj = FileObject(path="Test.java", content=java_code)
        results = self.detector.detect_ast_from_tree(file_obj, None)  # Assuming None for AST tree for simplicity
        self.assertTrue(len(results) > 0)
        self.assertEqual(results[0]['vuln_type'], 'Session Fixation')

    def test_session_fixation_detector_regex(self):
        java_code = """
        public class Test {
            public void testMethod(HttpServletRequest request) {
                HttpSession session = request.getSession();
                // No call to changeSessionId() or invalidate()
            }
        }
        """
        file_obj = FileObject(path="Test.java", content=java_code)
        results = self.detector.detect(file_obj)
        self.assertTrue(len(results) > 0)
        self.assertEqual(results[0]['vuln_type'], 'Session Fixation')

if __name__ == '__main__':
    unittest.main()