import unittest
from dr_source.core.codebase import Codebase
from dr_source.core.taint_detector import TaintDetector
from dr_source.core.taint_visitor import TaintVisitor
from dr_source.core.detectors.sql_injection import SQLInjectionDetector

class TestTaintPropagation(unittest.TestCase):
    def test_taint_propagation(self):
        # Sample Java code snippet with SQL injection vulnerability
        java_code = """
        public class Test {
            public void vulnerableMethod(HttpServletRequest request) {
                String userInput = request.getParameter("input");
                String query = "SELECT * FROM users WHERE name = '" + userInput + "'";
                // Execute query
            }
        }
        """
        
        # Create a FileObject instance
        file_obj = Codebase.FileObject(path="Test.java", content=java_code)
        
        # Initialize the TaintVisitor
        taint_visitor = TaintVisitor()
        
        # Parse the Java code into an AST
        ast_tree = javalang.parse.parse(java_code)
        
        # Visit the AST to propagate taint
        taint_visitor.visit(ast_tree)
        
        # Define the sink list for SQL injection
        sink_list = ["executeQuery"]
        
        # Get vulnerabilities
        vulnerabilities = taint_visitor.get_vulnerabilities(ast_tree, sink_list)
        
        # Check if the vulnerability is detected
        self.assertTrue(any(vuln['vuln_type'] == 'SQL Injection' for vuln in vulnerabilities))

if __name__ == '__main__':
    unittest.main()