import unittest
from dr_source.core.codebase import Codebase
from dr_source.core.scanner import Scanner
from dr_source.core.detectors.sql_injection import SQLInjectionDetector
from javalang import parse

class TestScannerASTMode(unittest.TestCase):
    def test_scanner_ast_mode(self):
        # Sample Java code snippet with potential SQL Injection vulnerability
        java_code = """
        public class Test {
            public void vulnerableMethod(HttpServletRequest request) {
                String userInput = request.getParameter("input");
                String query = "SELECT * FROM users WHERE name = '" + userInput + "'";
                // Execute query
            }
        }
        """

        # Create a FileObject instance
        file_obj = Codebase.FileObject(path="Test.java", content=java_code)

        # Parse the Java code into an AST
        ast_tree = parse.parse(file_obj.content)

        # Initialize the SQLInjectionDetector with AST mode enabled
        sql_injection_detector = SQLInjectionDetector()
        sql_injection_detector.ast_mode = True

        # Detect vulnerabilities using AST
        vulnerabilities = sql_injection_detector.detect_ast_from_tree(file_obj, ast_tree)

        # Assert that vulnerabilities are detected
        self.assertGreater(len(vulnerabilities), 0)
        self.assertEqual(vulnerabilities[0]['vuln_type'], 'SQL Injection')

if __name__ == '__main__':
    unittest.main()