import json

class SARIFReport:
    def generate(self, results):
        sarif_report = {
            "version": "2.1.0",
            "runs": [
                {
                    "tool": {
                        "driver": {
                            "name": "DRSource",
                            "informationUri": "https://example.com/drsource",
                            "rules": []
                        }
                    },
                    "results": []
                }
            ]
        }

        for result in results:
            rule_id = result.get("vuln_type", "UNKNOWN")
            rule = {
                "id": rule_id,
                "name": rule_id,
                "shortDescription": {
                    "text": f"Detected {rule_id} vulnerability"
                },
                "fullDescription": {
                    "text": f"Detected {rule_id} vulnerability in the code"
                },
                "defaultConfiguration": {
                    "level": "error"
                }
            }
            sarif_report["runs"][0]["tool"]["driver"]["rules"].append(rule)

            sarif_result = {
                "ruleId": rule_id,
                "message": {
                    "text": result.get("match", "")
                },
                "locations": [
                    {
                        "physicalLocation": {
                            "artifactLocation": {
                                "uri": result.get("file", "")
                            },
                            "region": {
                                "startLine": result.get("line", 0)
                            }
                        }
                    }
                ]
            }
            sarif_report["runs"][0]["results"].append(sarif_result)

        return json.dumps(sarif_report, indent=2)