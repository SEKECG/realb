import unittest
from dr_source.core.detectors.insecure_cookie import InsecureCookieDetector
from dr_source.core.codebase import FileObject

class TestInsecureCookieDetector(unittest.TestCase):
    def test_insecure_cookie_detector_regex(self):
        sample_code = """
        Cookie cookie = new Cookie("name", "value");
        cookie.setSecure(false);
        cookie.setHttpOnly(false);
        """
        file_obj = FileObject(path="sample.java", content=sample_code)
        detector = InsecureCookieDetector()
        vulnerabilities = detector.detect(file_obj)
        
        self.assertEqual(len(vulnerabilities), 2)
        self.assertEqual(vulnerabilities[0]['vuln_type'], 'InsecureCookie')
        self.assertEqual(vulnerabilities[1]['vuln_type'], 'InsecureCookie')

if __name__ == '__main__':
    unittest.main()