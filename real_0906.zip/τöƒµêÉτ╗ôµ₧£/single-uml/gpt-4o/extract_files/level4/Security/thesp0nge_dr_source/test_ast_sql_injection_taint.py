import unittest
from dr_source.core.codebase import Codebase
from dr_source.core.scanner import Scanner
from dr_source.core.sql_injection import SQLInjectionDetector
from dr_source.core.taint_detector import TaintDetector
from dr_source.core.taint_visitor import TaintVisitor

class TestASTSQLInjectionTaint(unittest.TestCase):
    def test_sql_injection_ast_taint(self):
        # Sample Java code with potential SQL injection vulnerability
        java_code = """
        public class Test {
            public void vulnerableMethod(HttpServletRequest request) {
                String userInput = request.getParameter("input");
                String query = "SELECT * FROM users WHERE name = '" + userInput + "'";
                Statement stmt = connection.createStatement();
                ResultSet rs = stmt.executeQuery(query);
            }
        }
        """
        
        # Create a FileObject instance
        file_obj = Codebase.FileObject(path="Test.java", content=java_code)
        
        # Initialize the SQLInjectionDetector with AST mode enabled
        sql_injection_detector = SQLInjectionDetector()
        sql_injection_detector.ast_mode = True
        
        # Parse the Java code into an AST
        ast_tree = TaintVisitor().visit(file_obj.content)
        
        # Detect SQL injection vulnerabilities using AST taint analysis
        vulnerabilities = sql_injection_detector.detect_ast_from_tree(file_obj, ast_tree)
        
        # Assert that vulnerabilities are detected
        self.assertGreater(len(vulnerabilities), 0)
        self.assertEqual(vulnerabilities[0]['vuln_type'], 'SQL Injection')

if __name__ == '__main__':
    unittest.main()