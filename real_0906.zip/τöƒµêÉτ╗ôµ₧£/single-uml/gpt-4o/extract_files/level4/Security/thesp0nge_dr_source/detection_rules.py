import yaml
import os
import logging

logger = logging.getLogger(__name__)

class DetectionRules:
    _instance = None

    def __init__(self):
        self.rules = {}
        config_path = os.path.join(os.path.dirname(__file__), '../config/detection_rules.yaml')
        if os.path.exists(config_path):
            try:
                with open(config_path, 'r') as file:
                    self.rules = yaml.safe_load(file)
                    logger.info("Detection rules loaded successfully.")
            except yaml.YAMLError as e:
                logger.error(f"Error loading detection rules: {e}")
        else:
            logger.warning(f"Detection rules file not found at {config_path}")

    def get_rules(self, detector_key):
        return self.rules.get(detector_key, {})

    @classmethod
    def instance(cls):
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance