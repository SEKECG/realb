import os
import sqlite3
import re

class ScanDatabase:
    def __init__(self, project_name):
        self.project_name = self._sanitize_project_name(project_name)
        self.db_directory = os.path.join(os.getcwd(), 'db')
        self.db_path = os.path.join(self.db_directory, f"{self.project_name}.db")
        os.makedirs(self.db_directory, exist_ok=True)
        self._create_tables()

    def _create_tables(self):
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS scans (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    num_vulnerabilities INTEGER,
                    num_files_analyzed INTEGER,
                    scan_duration REAL
                )
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS vulnerabilities (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    scan_id INTEGER,
                    file TEXT,
                    vuln_type TEXT,
                    match TEXT,
                    line INTEGER,
                    FOREIGN KEY(scan_id) REFERENCES scans(id)
                )
            ''')
            conn.commit()

    def _sanitize_project_name(self, name):
        if name in [".", "..", ""]:
            return "default_project"
        return re.sub(r'[^a-zA-Z0-9_-]', '_', name)

    def compare_scans(self, old_scan_id, new_scan_id):
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT file, vuln_type, match, line FROM vulnerabilities WHERE scan_id = ?
            ''', (old_scan_id,))
            old_vulns = cursor.fetchall()
            cursor.execute('''
                SELECT file, vuln_type, match, line FROM vulnerabilities WHERE scan_id = ?
            ''', (new_scan_id,))
            new_vulns = cursor.fetchall()

            old_set = set(old_vulns)
            new_set = set(new_vulns)

            return {
                'new': list(new_set - old_set),
                'resolved': list(old_set - new_set),
                'persistent': list(new_set & old_set)
            }

    def get_latest_scan_id(self):
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT id FROM scans ORDER BY timestamp DESC LIMIT 1
            ''')
            result = cursor.fetchone()
            return result[0] if result else None

    def get_scan_history(self):
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT id, timestamp, num_vulnerabilities FROM scans ORDER BY timestamp DESC
            ''')
            return cursor.fetchall()

    def initialize(self):
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('DROP TABLE IF EXISTS scans')
            cursor.execute('DROP TABLE IF EXISTS vulnerabilities')
            self._create_tables()

    def start_scan(self):
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('INSERT INTO scans (num_vulnerabilities, num_files_analyzed, scan_duration) VALUES (0, 0, 0)')
            conn.commit()
            return cursor.lastrowid

    def store_vulnerabilities(self, scan_id, vulns):
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.executemany('''
                INSERT INTO vulnerabilities (scan_id, file, vuln_type, match, line) VALUES (?, ?, ?, ?, ?)
            ''', [(scan_id, v['file'], v['vuln_type'], v['match'], v['line']) for v in vulns])
            conn.commit()

    def store_vulnerability(self, scan_id, vuln):
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO vulnerabilities (scan_id, file, vuln_type, match, line) VALUES (?, ?, ?, ?, ?)
            ''', (scan_id, vuln['file'], vuln['vuln_type'], vuln['match'], vuln['line']))
            conn.commit()

    def update_scan_summary(self, scan_id, num_vulnerabilities, num_files_analyzed, scan_duration):
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE scans SET num_vulnerabilities = ?, num_files_analyzed = ?, scan_duration = ? WHERE id = ?
            ''', (num_vulnerabilities, num_files_analyzed, scan_duration, scan_id))
            conn.commit()