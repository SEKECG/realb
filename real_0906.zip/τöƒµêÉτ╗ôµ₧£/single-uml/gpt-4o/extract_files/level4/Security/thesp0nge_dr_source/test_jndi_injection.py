import unittest
from dr_source.core.detectors.jndi_injection import JNDIInjectionDetector
from dr_source.core.codebase import FileObject

class TestJNDIInjectionDetector(unittest.TestCase):
    def setUp(self):
        self.detector = JNDIInjectionDetector()

    def test_jndi_injection_detector_regex(self):
        sample_code = """
        import javax.naming.InitialContext;
        import javax.naming.NamingException;

        public class Test {
            public void vulnerableMethod(String input) {
                try {
                    InitialContext ctx = new InitialContext();
                    ctx.lookup(input);
                } catch (NamingException e) {
                    e.printStackTrace();
                }
            }
        }
        """
        file_obj = FileObject(path="Test.java", content=sample_code)
        vulnerabilities = self.detector.detect(file_obj)
        self.assertEqual(len(vulnerabilities), 1)
        self.assertEqual(vulnerabilities[0]['vuln_type'], 'JNDI Injection')
        self.assertEqual(vulnerabilities[0]['line'], 9)

if __name__ == '__main__':
    unittest.main()