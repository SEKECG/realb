import re
import logging

logger = logging.getLogger(__name__)

class InsecureCookieDetector:
    REGEX_PATTERNS = [
        re.compile(r'\.setSecure\s*\(\s*false\s*\)', re.IGNORECASE),
        re.compile(r'\.setHttpOnly\s*\(\s*false\s*\)', re.IGNORECASE)
    ]

    def detect(self, file_object):
        vulnerabilities = []
        for pattern in self.REGEX_PATTERNS:
            for match in pattern.finditer(file_object.content):
                vulnerabilities.append({
                    'file': file_object.path,
                    'vuln_type': 'Insecure Cookie Setting',
                    'match': match.group(),
                    'line': file_object.content.count('\n', 0, match.start()) + 1
                })
        return vulnerabilities

    def detect_ast_from_tree(self, file_object, ast_tree):
        # Placeholder for AST-based detection, fallback to regex
        return self.detect(file_object)