import os
import json
import requests
from typing import Tuple, Dict, Any
from io import BytesIO
from pyquist.audio import Audio

_CACHE_DIR = os.path.join(os.path.expanduser("~"), ".pyquist_cache")
_ROOT_CACHE_DIR = os.path.join(_CACHE_DIR, "freesound")

def fetch_from_freesound(*args, **kwargs) -> Audio:
    return fetch(*args, **kwargs)[0]

def _get_client_credentials(reauthenticate=False) -> Tuple[str, str]:
    credentials_path = os.path.join(_CACHE_DIR, "freesound_credentials.json")
    if not reauthenticate and os.path.exists(credentials_path):
        with open(credentials_path, "r") as f:
            credentials = json.load(f)
        return credentials["client_id"], credentials["client_secret"]
    client_id = input("Enter your Freesound client ID: ")
    client_secret = input("Enter your Freesound client secret: ")
    with open(credentials_path, "w") as f:
        json.dump({"client_id": client_id, "client_secret": client_secret}, f)
    return client_id, client_secret

def _get_oauthv2_token(reauthenticate=False) -> str:
    token_path = os.path.join(_CACHE_DIR, "freesound_token.json")
    if not reauthenticate and os.path.exists(token_path):
        with open(token_path, "r") as f:
            token_data = json.load(f)
        return token_data["access_token"]
    client_id, client_secret = _get_client_credentials(reauthenticate)
    response = requests.post(
        "https://freesound.org/apiv2/oauth2/access_token/",
        data={
            "client_id": client_id,
            "client_secret": client_secret,
            "grant_type": "client_credentials",
        },
    )
    response.raise_for_status()
    token_data = response.json()
    with open(token_path, "w") as f:
        json.dump(token_data, f)
    return token_data["access_token"]

def fetch(id_or_url, preview_okay=True, preview_tag="preview-hq-mp3", reauthenticate=False, cache_dir=_ROOT_CACHE_DIR) -> Tuple[Audio, Dict[str, Any]]:
    sound_id = url_to_id(id_or_url)
    audio_data, metadata = fetch_audio(sound_id, preview_okay, preview_tag, reauthenticate, cache_dir)
    audio = Audio.from_array(audio_data, sample_rate=metadata["sample_rate"])
    return audio, metadata

def fetch_audio(sound_id, preview_okay=True, preview_tag="preview-hq-mp3", reauthenticate=False, cache_dir=_ROOT_CACHE_DIR) -> Tuple[BytesIO, Dict[str, Any]]:
    metadata = fetch_metadata(sound_id, reauthenticate, cache_dir)
    if preview_okay and preview_tag in metadata["previews"]:
        url = metadata["previews"][preview_tag]
    else:
        url = metadata["download"]["preview-hq-mp3"]
    response = requests.get(url)
    response.raise_for_status()
    return BytesIO(response.content), metadata

def fetch_metadata(sound_id, reauthenticate=False, cache_dir=_ROOT_CACHE_DIR) -> Dict[str, Any]:
    metadata_path = os.path.join(cache_dir, f"{sound_id}.json")
    if not reauthenticate and os.path.exists(metadata_path):
        with open(metadata_path, "r") as f:
            return json.load(f)
    token = _get_oauthv2_token(reauthenticate)
    response = requests.get(
        f"https://freesound.org/apiv2/sounds/{sound_id}/",
        headers={"Authorization": f"Bearer {token}"},
    )
    response.raise_for_status()
    metadata = response.json()
    os.makedirs(cache_dir, exist_ok=True)
    with open(metadata_path, "w") as f:
        json.dump(metadata, f)
    return metadata

def url_to_id(id_or_url) -> int:
    if isinstance(id_or_url, int):
        return id_or_url
    if id_or_url.isdigit():
        return int(id_or_url)
    return int(id_or_url.rstrip("/").split("/")[-1])

audio = None
metadata = None