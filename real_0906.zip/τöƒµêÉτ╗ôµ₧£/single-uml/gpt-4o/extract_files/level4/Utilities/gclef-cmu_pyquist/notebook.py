import sounddevice as sd
import numpy as np
from pyquist.audio import Audio

def play(audio, safe=True, normalize=True):
    if normalize:
        audio = audio.normalize()
    if safe:
        audio = audio.clip(1.0)
    sd.play(audio, audio.sample_rate)
    sd.wait()