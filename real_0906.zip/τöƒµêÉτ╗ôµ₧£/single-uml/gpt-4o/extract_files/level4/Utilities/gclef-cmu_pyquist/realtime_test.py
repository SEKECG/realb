import numpy as np
from pyquist.realtime import AudioProcessor
from pyquist.realtime import AudioProcessorStream
from pyquist.realtime import BlockMessage
from pyquist.realtime import Message
from pyquist.audio import AudioBuffer

class MessageAudioProcessor(AudioProcessor):
    def __init__(self):
        super().__init__(num_input_channels=1, num_output_channels=1)
        self.current_value = 0.0

    def process_block(self, buffer, messages):
        for message in messages:
            self.current_value = message.data
        buffer[:] = self.current_value

class SineAudioProcessor(AudioProcessor):
    def __init__(self):
        super().__init__(num_input_channels=1, num_output_channels=1)

    def process_block(self, buffer, messages):
        t = np.arange(buffer.shape[1]) / self.sample_rate
        buffer[:] = np.sin(2 * np.pi * 440 * t)

class TestAudioProcessing:
    def test_audio_processor(self):
        processor = AudioProcessor(num_input_channels=1, num_output_channels=1)
        assert processor.num_input_channels == 1
        assert processor.num_output_channels == 1
        assert not processor.ready
        try:
            processor.sample_rate
        except AttributeError:
            pass
        try:
            processor.block_size
        except AttributeError:
            pass

    def test_prepare_to_play(self):
        processor = SineAudioProcessor()
        processor.prepare(sample_rate=44100, block_size=512)
        assert processor.ready
        assert processor.sample_rate == 44100
        assert processor.block_size == 512

    def test_process(self):
        processor = SineAudioProcessor()
        processor.prepare(sample_rate=44100, block_size=512)
        buffer = AudioBuffer(num_samples=512, num_channels=1)
        processor.process_block(buffer, [])
        assert np.allclose(buffer, np.sin(2 * np.pi * 440 * np.arange(512) / 44100))

    def test_process_messages(self):
        processor = MessageAudioProcessor()
        processor.prepare(sample_rate=44100, block_size=512)
        buffer = AudioBuffer(num_samples=512, num_channels=1)
        messages = [BlockMessage(offset=0, data=0.5)]
        processor.process_block(buffer, messages)
        assert np.all(buffer == 0.5)

    def test_release_resources(self):
        processor = SineAudioProcessor()
        processor.prepare(sample_rate=44100, block_size=512)
        processor.release()
        assert not processor.ready
        try:
            processor.sample_rate
        except AttributeError:
            pass
        try:
            processor.block_size
        except AttributeError:
            pass