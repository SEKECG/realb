import sounddevice as sd
import numpy as np
import json
from pathlib import Path
from typing import Dict, Any
from audio import Audio

_SD_DEFAULTS_PATH = Path.home() / ".pyquist_sd_defaults.json"
_SD_DEFAULTS: Dict[str, Any] = {}

def play(audio, safe=True, normalize=True):
    if normalize:
        audio = audio.normalize()
    if safe:
        _restore_sd_defaults()
    sd.play(audio, samplerate=audio.sample_rate)
    sd.wait()

def _restore_sd_defaults():
    try:
        with open(_SD_DEFAULTS_PATH, "r") as f:
            defaults = json.load(f)
        for name, value in defaults.items():
            _set_sd_default(name, value, write=False)
    except Exception as e:
        print(f"Error restoring sounddevice defaults: {e}")

def _set_sd_default(name, value, write=True):
    try:
        setattr(sd.default, name, value)
        if write:
            _SD_DEFAULTS[name] = value
            with open(_SD_DEFAULTS_PATH, "w") as f:
                json.dump(_SD_DEFAULTS, f)
    except Exception as e:
        print(f"Error setting sounddevice default {name}: {e}")

def record(duration, progress_bar=True, **kwargs):
    if progress_bar:
        print("Recording...")
    audio_data = sd.rec(int(duration * sd.default.samplerate), **kwargs)
    sd.wait()
    if progress_bar:
        print("Recording complete.")
    return Audio.from_array(audio_data, sample_rate=sd.default.samplerate)

def set_sd_defaults(**kwargs):
    for name, value in kwargs.items():
        _set_sd_default(name, value)