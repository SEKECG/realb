import unittest
import numpy as np
from pyquist.audio import Audio, AudioBuffer

class TestAudioBuffer(unittest.TestCase):
    def test_audio(self):
        # Test loading from file
        audio = Audio.from_file("test.wav")
        self.assertIsInstance(audio, Audio)
        
        # Test normalization
        normalized_audio = audio.normalize(peak_dbfs=-1.0)
        self.assertIsInstance(normalized_audio, Audio)
        
        # Test clipping
        clipped_audio = audio.clip(peak_gain=0.5)
        self.assertIsInstance(clipped_audio, Audio)
        
        # Test resampling
        resampled_audio = audio.resample(new_sample_rate=22050)
        self.assertIsInstance(resampled_audio, Audio)
        
        # Test array initialization
        array_audio = Audio.from_array(np.array([0.1, 0.2, 0.3]), sample_rate=44100)
        self.assertIsInstance(array_audio, Audio)
        
        # Test slicing
        sliced_audio = array_audio[:2]
        self.assertIsInstance(sliced_audio, Audio)
        
        # Test various array manipulations
        self.assertEqual(audio.duration, len(audio) / audio.sample_rate)
        self.assertEqual(audio.peak_gain, np.max(np.abs(audio)))
        self.assertEqual(audio.sample_rate, 44100)

    def test_audio_buffer(self):
        # Valid initialization
        buffer = AudioBuffer(num_samples=1000, num_channels=2)
        self.assertIsInstance(buffer, AudioBuffer)
        
        # Test slicing behavior
        sliced_buffer = buffer[:, :500]
        self.assertIsInstance(sliced_buffer, np.ndarray)
        
        # Test arithmetic operations
        buffer += 0.1
        self.assertTrue(np.all(buffer >= 0.1))
        
        # Test error handling
        with self.assertRaises(ValueError):
            AudioBuffer(num_samples=1000, num_channels=2, array=np.array([0.1, 0.2]))

if __name__ == "__main__":
    unittest.main()