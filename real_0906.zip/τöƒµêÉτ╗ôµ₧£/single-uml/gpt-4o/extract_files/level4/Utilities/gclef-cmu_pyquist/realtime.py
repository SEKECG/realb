import numpy as np
from collections import deque
from typing import Optional, Iterator, Tuple, List

class AudioProcessor:
    def __init__(self, num_input_channels, num_output_channels):
        self._num_input_channels = num_input_channels
        self._num_output_channels = num_output_channels
        self._sample_rate = None
        self._block_size = None
        self._ready = False

    @property
    def block_size(self):
        if self._ready:
            return self._block_size
        raise ValueError("Processor not ready")

    @property
    def num_input_channels(self):
        return self._num_input_channels

    @property
    def num_output_channels(self):
        return self._num_output_channels

    @property
    def ready(self):
        return self._ready

    @property
    def sample_rate(self):
        if self._ready:
            return self._sample_rate
        raise ValueError("Processor not ready")

    def prepare(self, sample_rate, block_size):
        self._sample_rate = sample_rate
        self._block_size = block_size
        self._ready = True

    def release(self):
        self._ready = False

    def process_block(self, buffer, messages):
        raise NotImplementedError("Subclasses should implement this method")

class AudioProcessorStream:
    def __init__(self, processor, block_size, sample_rate, gain_dbfs):
        self._processor = processor
        self._block_size = block_size
        self._sample_rate = sample_rate
        self._gain_dbfs = gain_dbfs
        self._message_queue = deque()
        self._blocks_elapsed = 0
        self._seconds_per_block = block_size / sample_rate

    @property
    def message_queue(self):
        return self._message_queue

    def start(self, *args, **kwargs):
        self._blocks_elapsed = 0
        self._message_queue.clear()
        self._processor.prepare(self._sample_rate, self._block_size)

    def stop(self, *args, **kwargs):
        self._processor.release()

    def abort(self, *args, **kwargs):
        self.stop(*args, **kwargs)

    def close(self, *args, **kwargs):
        self.stop(*args, **kwargs)

    def callback(self, outdata, *args):
        messages = []
        while self._message_queue and self._message_queue[0].time <= self._blocks_elapsed * self._seconds_per_block:
            messages.append(self._message_queue.popleft())
        self._processor.process_block(outdata, messages)
        self._blocks_elapsed += 1

    def sleep(self, duration):
        time.sleep(duration)

class BlockMessage:
    def __init__(self, offset, data):
        self.offset = offset
        self.data = data

class Message:
    def __init__(self, time, data):
        self.time = time
        self.data = data

def iter_process(processor, duration, input_audio, messages, pad_end, block_size, sample_rate):
    num_blocks = int(np.ceil(duration * sample_rate / block_size))
    for block_index in range(num_blocks):
        buffer = np.zeros((processor.num_output_channels, block_size), dtype=np.float32)
        block_messages = [msg for msg in messages if msg.offset >= block_index * block_size and msg.offset < (block_index + 1) * block_size]
        processor.process_block(buffer, block_messages)
        yield block_index, buffer, block_messages

def process(processor, duration, input_audio, messages, block_size, sample_rate):
    output_audio = np.zeros((processor.num_output_channels, int(duration * sample_rate)), dtype=np.float32)
    for block_index, buffer, block_messages in iter_process(processor, duration, input_audio, messages, False, block_size, sample_rate):
        output_audio[:, block_index * block_size:(block_index + 1) * block_size] = buffer
    return output_audio