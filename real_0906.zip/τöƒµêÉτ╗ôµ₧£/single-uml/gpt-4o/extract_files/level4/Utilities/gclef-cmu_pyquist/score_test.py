import unittest
from pyquist.score import BasicMetronome, render_score

class TestScore(unittest.TestCase):
    def test_basic_metronome(self):
        bpm = 120
        metronome = BasicMetronome(bpm)
        self.assertEqual(metronome.bpm, bpm)
        self.assertAlmostEqual(metronome.beat_duration, 0.5)
        self.assertAlmostEqual(metronome.beat_to_time(1), 0.5)
        self.assertAlmostEqual(metronome.time_to_beat(0.5), 1)

    def test_metronome(self):
        bpm = 60
        metronome = BasicMetronome(bpm)
        self.assertEqual(metronome.bpm, bpm)
        self.assertAlmostEqual(metronome.beat_duration, 1.0)
        self.assertAlmostEqual(metronome.beat_to_time(1), 1.0)
        self.assertAlmostEqual(metronome.time_to_beat(1.0), 1)

    def test_render_score(self):
        score = "dummy_score"
        metronome = BasicMetronome(120)
        audio = render_score(score, metronome)
        self.assertIsInstance(audio, Audio)

if __name__ == '__main__':
    unittest.main()