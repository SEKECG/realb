import numpy as np

ACCIDENTALS = {
    'b': -1,
    '#': 1,
    '': 0
}

PITCHES = {
    'C': 0,
    'D': 2,
    'E': 4,
    'F': 5,
    'G': 7,
    'A': 9,
    'B': 11
}

def dbfs_to_gain(dbfs):
    return 10 ** (dbfs / 20)

def _scientific_pitch_name_to_pitch(pitch_name):
    note = pitch_name[:-1]
    octave = int(pitch_name[-1])
    accidental = note[-1] if note[-1] in ACCIDENTALS else ''
    note = note[:-1] if accidental else note
    pitch = PITCHES[note] + ACCIDENTALS[accidental]
    return pitch + (octave + 1) * 12

def frequency_to_pitch(frequency):
    return 69 + 12 * np.log2(frequency / 440.0)

def gain_to_dbfs(gain):
    return 20 * np.log10(gain)

def pitch_name_to_pitch(pitch):
    return _scientific_pitch_name_to_pitch(pitch)

def pitch_to_frequency(pitch):
    return 440.0 * 2 ** ((pitch - 69) / 12)