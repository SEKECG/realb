import unittest
import numpy as np
from pyquist.helper import dbfs_to_gain, frequency_to_pitch, gain_to_dbfs, pitch_name_to_pitch, pitch_to_frequency

class TestHelper(unittest.TestCase):

    def test_dbfs_gain_conversion(self):
        dbfs_values = np.array([-20, -10, 0])
        expected_gains = np.array([0.1, 0.316, 1.0])
        np.testing.assert_almost_equal(dbfs_to_gain(dbfs_values), expected_gains, decimal=3)
        np.testing.assert_almost_equal(gain_to_dbfs(expected_gains), dbfs_values, decimal=3)

    def test_frequency_pitch_conversion(self):
        frequencies = np.array([440.0, 880.0, 1760.0])
        expected_pitches = np.array([69, 81, 93])
        np.testing.assert_almost_equal(frequency_to_pitch(frequencies), expected_pitches, decimal=1)
        np.testing.assert_almost_equal(pitch_to_frequency(expected_pitches), frequencies, decimal=1)

    def test_pitch_name_to_pitch(self):
        pitch_names = ["C4", "A4", "G#4"]
        expected_pitches = [60, 69, 68]
        for pitch_name, expected_pitch in zip(pitch_names, expected_pitches):
            self.assertEqual(pitch_name_to_pitch(pitch_name), expected_pitch)

if __name__ == '__main__':
    unittest.main()