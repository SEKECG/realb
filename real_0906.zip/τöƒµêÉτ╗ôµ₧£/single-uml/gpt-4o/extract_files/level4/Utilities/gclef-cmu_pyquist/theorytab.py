import os
import json
import requests
from typing import List, Tuple, Dict
from .score import Metronome, Score
from .audio import Audio

_CACHE_DIR = os.path.join(os.path.expanduser("~"), ".cache", "pyquist", "theorytab")
_CHORD_DEGREES_TO_LILY_NAME = {
    # Add mapping here
}
_ROOT_CACHE_DIR = os.path.join(os.path.expanduser("~"), ".cache", "pyquist")
_THEORYTAB_SCALE_NAME_TO_PITCH_INTERVALS = {
    # Add mapping here
}

def fetch_from_theorytab(id_or_url, **kwargs) -> Tuple[Metronome, Score, Score]:
    """
    Fetches a pop song from TheoryTab and returns a score.

    To get an `id_or_url` input:
        1. Find a song on TheoryTab, e.g., https://www.hooktheory.com/theorytab/view/the-beatles/a-hard-days-night
        2. Right click on "Open in Hookpad", and click "Copy Link Address."
        3. Paste the link address into the `id_or_url` input.

    Args:
        id_or_url: The TheoryTab ID or URL.
        **kwargs: Additional keyword arguments to `theorytab_json_to_score`.
    """
    song_data = fetch_theorytab_json(id_or_url)
    return theorytab_json_to_score(song_data, **kwargs)

def _cumulative_intervals(intervals) -> List[int]:
    """
    Compute the cumulative sum of a tuple of six integers and return it as a list with an initial zero.
    """
    cumulative = [0]
    for interval in intervals:
        cumulative.append(cumulative[-1] + interval)
    return cumulative

def _harmony(*args, **kwargs):
    pass

def _melody(*args, **kwargs):
    pass

def _osc(duration, pitch, dbfs, sample_rate) -> Audio:
    """
    Basic instrument functions
    TODO: add something similar to library?
    """
    pass

def _theorytab_chord_to_pitches(chord, key) -> List[int]:
    """
    Convert a chord representation from Theorytab format into a list of MIDI pitch values based on the given key and chord attributes.
    """
    pass

def _theorytab_chord_to_symbol(chord, key) -> str:
    """
    Convert a theorytab JSON chord and key into a chord symbol string (e.g., "Cmaj7").
    """
    pass

def _theorytab_note_to_pitch(note, key) -> int:
    """
    Convert a musical note from TheoryTab notation to a MIDI pitch number based on the specified key and scale.
    """
    pass

def fetch_theorytab_json(id_or_url, ignore_cache=False) -> Dict:
    """
    Fetch and return JSON data for a song from the Hooktheory TheoryTab API, either from cache or by making an API request, using a provided TheoryTab ID or URL.
    """
    if not os.path.exists(_CACHE_DIR):
        os.makedirs(_CACHE_DIR)
    
    cache_path = os.path.join(_CACHE_DIR, f"{id_or_url}.json")
    
    if not ignore_cache and os.path.exists(cache_path):
        with open(cache_path, 'r') as f:
            return json.load(f)
    
    response = requests.get(f"https://api.hooktheory.com/v1/theorytab/{id_or_url}")
    response.raise_for_status()
    data = response.json()
    
    with open(cache_path, 'w') as f:
        json.dump(data, f)
    
    return data

def theorytab_json_to_score(song_data, durations_in_beats=True, harmony_type="SYMBOL", melody_octave=4, harmony_octave=4) -> Tuple[Metronome, Score, Score]:
    """
    Convert a song's data from TheoryTab JSON format into musical scores for melody and harmony, with configurable parameters for durations, harmony representation, and octave settings.
    """
    pass

class HarmonyType:
    ROOT_POSITION_NOTES = "ROOT_POSITION_NOTES"
    SYMBOL = "SYMBOL"