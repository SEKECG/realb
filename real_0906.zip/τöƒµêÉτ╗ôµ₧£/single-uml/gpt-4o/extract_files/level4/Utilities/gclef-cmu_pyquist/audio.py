import numpy as np

class Audio(np.ndarray):
    def __new__(cls, *args, sample_rate=None, **kwargs):
        obj = super().__new__(cls, *args, **kwargs)
        obj._sample_rate = sample_rate
        return obj

    def __array_finalize__(self, obj):
        if obj is None: return
        self._sample_rate = getattr(obj, '_sample_rate', None)

    def __array_function__(self, func, types, args, kwargs):
        if func not in {np.concatenate}:
            return NotImplemented
        return super().__array_function__(func, types, args, kwargs)

    @property
    def sample_rate(self):
        return self._sample_rate

    @property
    def duration(self):
        return self.shape[-1] / self._sample_rate

    @property
    def num_channels(self):
        return self.shape[0]

    @property
    def peak_gain(self):
        return np.max(np.abs(self))

    def clip(self, peak_gain, in_place=False):
        if in_place:
            np.clip(self, -peak_gain, peak_gain, out=self)
            return self
        else:
            return np.clip(self, -peak_gain, peak_gain)

    def normalize(self, peak_dbfs, in_place=False):
        gain = 10 ** (peak_dbfs / 20)
        if in_place:
            self *= gain / self.peak_gain
            return self
        else:
            return self * (gain / self.peak_gain)

    def resample(self, new_sample_rate, **kwargs):
        duration = self.duration
        num_samples = int(duration * new_sample_rate)
        resampled = np.interp(
            np.linspace(0, duration, num_samples),
            np.linspace(0, duration, self.shape[-1]),
            self
        )
        return Audio(resampled, sample_rate=new_sample_rate)

    @classmethod
    def from_array(cls, array, sample_rate):
        return cls(array, sample_rate=sample_rate)

    @classmethod
    def from_file(cls, file):
        # Placeholder for actual file reading logic
        data = np.load(file)
        sample_rate = 44100  # Placeholder for actual sample rate extraction
        return cls(data, sample_rate=sample_rate)

    @classmethod
    def from_url(cls, url):
        # Placeholder for actual URL fetching logic
        data = np.load(url)
        sample_rate = 44100  # Placeholder for actual sample rate extraction
        return cls(data, sample_rate=sample_rate)

    def write(self, file, **kwargs):
        np.save(file, self)

class AudioBuffer(np.ndarray):
    def __new__(cls, num_samples, num_channels, array=None):
        if array is None:
            array = np.zeros((num_channels, num_samples), dtype=np.float32)
        obj = super().__new__(cls, shape=array.shape, dtype=array.dtype, buffer=array)
        return obj

    def __array_finalize__(self, obj):
        if obj is None: return

    def __array_function__(self, func, types, args, kwargs):
        if func not in {np.sum}:
            return NotImplemented
        return super().__array_function__(func, types, args, kwargs)

    def __array_wrap__(self, result, *args, **kwargs):
        if result.ndim != 2:
            return result
        return super().__array_wrap__(result, *args, **kwargs)

    def __getitem__(self, *args, **kwargs):
        result = super().__getitem__(*args, **kwargs)
        if result.ndim != 2:
            return result
        return result.view(type(self))

    @property
    def num_channels(self):
        return self.shape[0]

    @property
    def num_samples(self):
        return self.shape[1]

    def clear(self):
        self.fill(0)