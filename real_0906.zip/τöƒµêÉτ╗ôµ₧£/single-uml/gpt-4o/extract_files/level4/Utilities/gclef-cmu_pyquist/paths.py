import os

LIB_DIR = os.path.join(os.path.dirname(__file__), 'lib')
TEST_DATA_DIR = os.path.join(os.path.dirname(__file__), 'test_data')
CACHE_DIR = os.path.join(os.path.dirname(__file__), 'cache')