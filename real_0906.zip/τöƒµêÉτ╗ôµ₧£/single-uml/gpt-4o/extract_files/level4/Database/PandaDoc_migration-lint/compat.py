# compat.py

from typing import List

DOCS_URL = "https://docs.example.com"

class CompatibilityLinter:
    def lint(self, migration_sql, changed_files, report_restricted):
        """
        Perform SQL migration linting.
        :param migration_sql: SQL migration content
        :param changed_files: List of changed files
        :param report_restricted: Flag to report restricted operations
        :return: List of linting issues
        """
        issues = []
        # Implement linting logic here
        return issues