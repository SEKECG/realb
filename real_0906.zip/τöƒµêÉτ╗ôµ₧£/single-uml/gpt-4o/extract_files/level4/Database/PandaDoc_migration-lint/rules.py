# rules.py

from migration_lint.sql.model import SegmentLocator

BACKWARD_INCOMPATIBLE_OPERATIONS = [
    SegmentLocator(type="ALTER TABLE", raw="DROP COLUMN"),
    SegmentLocator(type="ALTER TABLE", raw="RENAME COLUMN"),
    SegmentLocator(type="ALTER TABLE", raw="DROP CONSTRAINT"),
    SegmentLocator(type="ALTER TABLE", raw="RENAME CONSTRAINT"),
]

BACKWARD_COMPATIBLE_OPERATIONS = [
    SegmentLocator(type="ALTER TABLE", raw="ADD COLUMN"),
    SegmentLocator(type="ALTER TABLE", raw="ADD CONSTRAINT"),
    SegmentLocator(type="ALTER TABLE", raw="RENAME TABLE"),
]

DATA_MIGRATION_OPERATIONS = [
    SegmentLocator(type="INSERT"),
    SegmentLocator(type="UPDATE"),
    SegmentLocator(type="DELETE"),
]

RESTRICTED_OPERATIONS = [
    SegmentLocator(type="ALTER TABLE", raw="SET NOT NULL"),
    SegmentLocator(type="ALTER TABLE", raw="DROP NOT NULL"),
]

IGNORED_OPERATIONS = [
    SegmentLocator(type="COMMENT"),
    SegmentLocator(type="SET"),
]