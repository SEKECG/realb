# flyway.py

class FlywayExtractor:
    NAME = "flyway"

    def is_allowed_with_backward_incompatible_migration(self, path):
        # Check if the specified file changes are allowed with backward-incompatible migrations.
        return False

    def is_migration(self, path):
        # Check if the specified file is a migration.
        return path.endswith(".sql")