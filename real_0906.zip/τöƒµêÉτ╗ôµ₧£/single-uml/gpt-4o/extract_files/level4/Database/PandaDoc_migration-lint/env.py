import os

def get_bool_env(var_name, default):
    value = os.getenv(var_name, str(default)).lower()
    if value in ['true', '1']:
        return True
    elif value in ['false', '0']:
        return False
    return default