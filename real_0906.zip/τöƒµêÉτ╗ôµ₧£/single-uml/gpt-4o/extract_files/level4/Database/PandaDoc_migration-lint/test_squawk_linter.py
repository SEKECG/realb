import unittest
from unittest.mock import patch, Mock
from migration_lint.analyzer.squawk import SquawkLinter

class TestSquawkLinter(unittest.TestCase):

    @patch('migration_lint.analyzer.squawk.platform.system')
    def test_platform(self, mock_platform):
        mock_platform.return_value = 'Linux'
        linter = SquawkLinter(config_path='/path/to/config', pg_version='12')
        self.assertEqual(linter.squawk, '/path/to/squawk')

    def test_squawk_command(self):
        linter = SquawkLinter(config_path='/path/to/config', pg_version='12')
        migration_sql = 'CREATE TABLE test (id INT);'
        expected_command = '/path/to/squawk --config /path/to/config --pg-version 12'
        self.assertEqual(linter.squawk_command(migration_sql), expected_command)

    @patch('migration_lint.analyzer.squawk.platform.system')
    def test_unsupported_platform(self, mock_platform):
        mock_platform.return_value = 'win32'
        with self.assertRaises(RuntimeError):
            SquawkLinter(config_path='/path/to/config', pg_version='12')

if __name__ == '__main__':
    unittest.main()