# raw_sql.py

class RawSqlExtractor:
    NAME = "raw_sql"

    def is_allowed_with_backward_incompatible_migration(self, path):
        # Check if the specified file changes are allowed with backward-incompatible migrations.
        return True

    def is_migration(self, path):
        # Check if the specified file is a migration.
        return path.endswith(".sql")

    def extract_sql(self, migration_path):
        # Extract raw SQL from the migration file.
        with open(migration_path, 'r') as file:
            return file.read()