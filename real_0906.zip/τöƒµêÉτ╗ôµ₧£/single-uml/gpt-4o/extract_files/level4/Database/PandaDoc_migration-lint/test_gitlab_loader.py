import pytest
from migration_lint.source_loader.gitlab import GitlabBranchLoader, GitlabMRLoader
from migration_lint.source_loader.model import SourceDiff

def test_gitlab_branch_loader():
    loader = GitlabBranchLoader(
        branch="feature-branch",
        project_id="123",
        gitlab_api_key="fake_api_key",
        gitlab_instance="https://gitlab.com"
    )
    changed_files = loader.get_changed_files()
    assert isinstance(changed_files, list)
    assert all(isinstance(file, SourceDiff) for file in changed_files)

def test_gitlab_branch_loader_default_branch():
    loader = GitlabBranchLoader(
        branch="feature-branch",
        project_id="123",
        gitlab_api_key="fake_api_key",
        gitlab_instance="https://gitlab.com"
    )
    changed_files = loader.get_changed_files()
    assert isinstance(changed_files, list)
    assert all(isinstance(file, SourceDiff) for file in changed_files)

def test_gitlab_branch_loader_not_configured():
    with pytest.raises(RuntimeError):
        GitlabBranchLoader(
            branch=None,
            project_id=None,
            gitlab_api_key=None,
            gitlab_instance=None
        )

def test_gitlab_branch_loader_on_changed_files():
    loader = GitlabBranchLoader(
        branch="feature-branch",
        project_id="123",
        gitlab_api_key="fake_api_key",
        gitlab_instance="https://gitlab.com"
    )
    changed_files = loader.get_changed_files()
    assert isinstance(changed_files, list)
    assert all(isinstance(file, SourceDiff) for file in changed_files)

def test_gitlab_mr_loader():
    loader = GitlabMRLoader(
        mr_id="1",
        project_id="123",
        gitlab_api_key="fake_api_key",
        gitlab_instance="https://gitlab.com"
    )
    changed_files = loader.get_changed_files()
    assert isinstance(changed_files, list)
    assert all(isinstance(file, SourceDiff) for file in changed_files)

def test_gitlab_mr_loader_not_configured():
    with pytest.raises(RuntimeError):
        GitlabMRLoader(
            mr_id=None,
            project_id=None,
            gitlab_api_key=None,
            gitlab_instance=None
        )

def test_gitlab_mr_loader_on_changed_files():
    loader = GitlabMRLoader(
        mr_id="1",
        project_id="123",
        gitlab_api_key="fake_api_key",
        gitlab_instance="https://gitlab.com"
    )
    changed_files = loader.get_changed_files()
    assert isinstance(changed_files, list)
    assert all(isinstance(file, SourceDiff) for file in changed_files)