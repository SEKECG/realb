# proj_clean/migration_lint/sql/constants.py

class StatementType:
    UNSUPPORTED = "UNSUPPORTED"
    RESTRICTED = "RESTRICTED"
    BACKWARD_INCOMPATIBLE = "BACKWARD_INCOMPATIBLE"
    DATA_MIGRATION = "DATA_MIGRATION"
    BACKWARD_COMPATIBLE = "BACKWARD_COMPATIBLE"
    IGNORED = "IGNORED"

    @property
    def colorized(self):
        # Assuming colorize is a function from util.colors module
        from migration_lint.util.colors import colorize, ColorCode
        if self == StatementType.UNSUPPORTED:
            return colorize(ColorCode.red, self)
        elif self == StatementType.RESTRICTED:
            return colorize(ColorCode.yellow, self)
        elif self == StatementType.BACKWARD_INCOMPATIBLE:
            return colorize(ColorCode.red, self)
        elif self == StatementType.DATA_MIGRATION:
            return colorize(ColorCode.blue, self)
        elif self == StatementType.BACKWARD_COMPATIBLE:
            return colorize(ColorCode.green, self)
        elif self == StatementType.IGNORED:
            return colorize(ColorCode.grey, self)
        else:
            return self