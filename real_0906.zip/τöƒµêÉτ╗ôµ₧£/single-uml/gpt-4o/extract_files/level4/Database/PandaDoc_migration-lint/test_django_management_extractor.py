import unittest
from migration_lint.django.extractor.django_management import DjangoManagementExtractor

class TestDjangoManagementExtractor(unittest.TestCase):

    def test_django_extractor__ok(self):
        extractor = DjangoManagementExtractor()
        migration_path = "path/to/migration"
        sql = extractor.extract_sql(migration_path)
        self.assertIsInstance(sql, str)
        self.assertTrue(sql.startswith("SELECT"))

if __name__ == "__main__":
    unittest.main()