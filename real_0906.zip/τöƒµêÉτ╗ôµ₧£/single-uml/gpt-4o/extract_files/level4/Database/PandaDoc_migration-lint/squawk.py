import os
import subprocess
from typing import List

class SquawkLinter:
    def __init__(self, config_path, pg_version):
        self.config_path = config_path
        self.pg_version = pg_version
        self.ignored_rules = []
        self.squawk = self._get_squawk_path()

    def lint(self, migration_sql, changed_files) -> List[str]:
        command = self.squawk_command(migration_sql)
        result = subprocess.run(command, shell=True, capture_output=True, text=True)
        if result.returncode != 0:
            raise RuntimeError(f"Squawk linter failed: {result.stderr}")
        return result.stdout.splitlines()

    def squawk_command(self, migration_sql) -> str:
        command = f"{self.squawk} --config {self.config_path} --pg-version {self.pg_version}"
        if self.ignored_rules:
            command += f" --ignore-rules {','.join(self.ignored_rules)}"
        command += f" {migration_sql}"
        return command

    def _get_squawk_path(self) -> str:
        platform = os.uname().sysname.lower()
        if platform == 'linux':
            return '/usr/local/bin/squawk'
        elif platform == 'darwin':
            return '/usr/local/bin/squawk'
        else:
            raise RuntimeError(f"Unsupported platform: {platform}")