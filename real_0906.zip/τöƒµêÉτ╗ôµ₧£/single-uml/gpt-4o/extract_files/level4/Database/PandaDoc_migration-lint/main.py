import sys
from migration_lint.analyzer.base import Analyzer
from migration_lint.extractor.base import BaseExtractor
from migration_lint.extractor.alembic import AlembicExtractor
from migration_lint.extractor.django import DjangoExtractor
from migration_lint.extractor.flyway import FlywayExtractor
from migration_lint.extractor.raw_sql import RawSqlExtractor
from migration_lint.source_loader.base import BaseSourceLoader
from migration_lint.source_loader.gitlab import GitlabBranchLoader, GitlabMRLoader
from migration_lint.source_loader.local import LocalLoader
from migration_lint.analyzer.compat import CompatibilityLinter
from migration_lint.analyzer.squawk import SquawkLinter

def main(loader_type, extractor_type, squawk_config_path, squawk_pg_version, **kwargs):
    loader_classes = {
        'local': LocalLoader,
        'gitlab_branch': GitlabBranchLoader,
        'gitlab_mr': GitlabMRLoader
    }
    
    extractor_classes = {
        'alembic': AlembicExtractor,
        'django': DjangoExtractor,
        'flyway': FlywayExtractor,
        'raw_sql': RawSqlExtractor
    }
    
    loader = loader_classes[loader_type](**kwargs)
    extractor = extractor_classes[extractor_type](**kwargs)
    
    linters = [
        CompatibilityLinter(),
        SquawkLinter(squawk_config_path, squawk_pg_version)
    ]
    
    analyzer = Analyzer(loader, extractor, linters)
    analyzer.analyze()

if __name__ == "__main__":
    loader_type = sys.argv[1]
    extractor_type = sys.argv[2]
    squawk_config_path = sys.argv[3]
    squawk_pg_version = sys.argv[4]
    kwargs = dict(arg.split('=') for arg in sys.argv[5:])
    main(loader_type, extractor_type, squawk_config_path, squawk_pg_version, **kwargs)