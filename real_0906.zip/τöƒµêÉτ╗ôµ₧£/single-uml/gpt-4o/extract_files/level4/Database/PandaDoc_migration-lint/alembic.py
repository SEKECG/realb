import subprocess

class AlembicExtractor:
    NAME = "alembic"
    command = "make sqlmigrate"
    migration_path = "/migrations/versions/"

    def __init__(self, **kwargs):
        self.command = kwargs.get("command", self.command)
        self.migration_path = kwargs.get("migration_path", self.migration_path)

    def _get_migrations_sql(self):
        try:
            result = subprocess.run(
                [self.command],
                capture_output=True,
                text=True,
                check=True
            )
            return result.stdout
        except subprocess.CalledProcessError as e:
            raise RuntimeError(f"Error running command {self.command}: {e}")

    def extract_sql(self, migration_path):
        return self._get_migrations_sql()

    def is_allowed_with_backward_incompatible_migration(self, path):
        # Implement logic to check if the file changes are allowed with backward-incompatible migrations
        return True

    def is_migration(self, path):
        # Implement logic to check if the specified file is a migration
        return path.endswith(".sql")