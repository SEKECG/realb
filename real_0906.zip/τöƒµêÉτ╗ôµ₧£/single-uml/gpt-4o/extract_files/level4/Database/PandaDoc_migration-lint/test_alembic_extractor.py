import unittest
from unittest.mock import patch, MagicMock
from migration_lint.extractor.alembic import AlembicExtractor

class TestAlembicExtractor(unittest.TestCase):

    @patch('migration_lint.extractor.alembic.subprocess')
    def test_alembic_extractor__error(self, mock_subprocess):
        mock_subprocess.run.side_effect = Exception("Subprocess error")
        extractor = AlembicExtractor()
        with self.assertRaises(Exception):
            extractor._get_migrations_sql()

    @patch('migration_lint.extractor.alembic.subprocess')
    def test_alembic_extractor__ok(self, mock_subprocess):
        mock_subprocess.run.return_value.stdout = "SQL command"
        extractor = AlembicExtractor()
        sql = extractor._get_migrations_sql()
        self.assertEqual(sql, "SQL command")

    def test_alembic_extractor_command__ok(self):
        command = "alembic upgrade head"
        expected_command = "alembic upgrade head"
        extractor = AlembicExtractor()
        with patch.object(extractor, 'squawk_command', return_value=command):
            result_command = extractor.squawk_command("migration.sql")
            self.assertEqual(result_command, expected_command)

    @patch('migration_lint.extractor.alembic.os.path')
    def test_alembic_extractor_path__ok(self, mock_path):
        mock_path.exists.return_value = True
        extractor = AlembicExtractor()
        self.assertTrue(extractor.is_migration("valid/path"))

if __name__ == '__main__':
    unittest.main()