from typing import Sequence, Tuple
from migration_lint.sql.constants import StatementType
from migration_lint.sql.model import SegmentLocator
from migration_lint.sql.operations import find_matching_segment

def classify_migration(raw_sql) -> Sequence[Tuple[str, StatementType]]:
    statements = raw_sql.split(';')
    classifications = []
    for statement in statements:
        if statement.strip():
            classification = classify_statement(statement, statements)
            classifications.append((statement, classification))
    return classifications

def classify_statement(statement, context) -> StatementType:
    for locator in BACKWARD_INCOMPATIBLE_OPERATIONS:
        if find_matching_segment(statement, locator, 0, context):
            return StatementType.BACKWARD_INCOMPATIBLE
    for locator in RESTRICTED_OPERATIONS:
        if find_matching_segment(statement, locator, 0, context):
            return StatementType.RESTRICTED
    for locator in BACKWARD_COMPATIBLE_OPERATIONS:
        if find_matching_segment(statement, locator, 0, context):
            return StatementType.BACKWARD_COMPATIBLE
    for locator in DATA_MIGRATION_OPERATIONS:
        if find_matching_segment(statement, locator, 0, context):
            return StatementType.DATA_MIGRATION
    return StatementType.UNSUPPORTED

# Constants for operations
BACKWARD_INCOMPATIBLE_OPERATIONS = [
    SegmentLocator(type="ALTER", raw="DROP COLUMN"),
    SegmentLocator(type="ALTER", raw="RENAME COLUMN"),
    SegmentLocator(type="ALTER", raw="DROP CONSTRAINT"),
]

RESTRICTED_OPERATIONS = [
    SegmentLocator(type="ALTER", raw="ADD CONSTRAINT"),
    SegmentLocator(type="ALTER", raw="SET NOT NULL"),
]

BACKWARD_COMPATIBLE_OPERATIONS = [
    SegmentLocator(type="CREATE", raw="TABLE"),
    SegmentLocator(type="ALTER", raw="ADD COLUMN"),
]

DATA_MIGRATION_OPERATIONS = [
    SegmentLocator(type="INSERT"),
    SegmentLocator(type="UPDATE"),
    SegmentLocator(type="DELETE"),
]