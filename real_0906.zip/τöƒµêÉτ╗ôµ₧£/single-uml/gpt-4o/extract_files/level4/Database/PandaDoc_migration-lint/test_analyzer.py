import unittest
from unittest.mock import Mock, patch
from migration_lint.analyzer.base import Analyzer
from migration_lint.extractor.model import Migration, MigrationsMetadata
from migration_lint.extractor.base import BaseExtractor
from migration_lint.source_loader.base import BaseSourceLoader
from migration_lint.analyzer.compat import CompatibilityLinter
from migration_lint.analyzer.squawk import SquawkLinter

FAKE_STATEMENT = "SELECT * FROM fake_table;"

def get_analyzer(changed_files, migrations):
    loader = Mock(spec=BaseSourceLoader)
    loader.get_changed_files.return_value = changed_files

    extractor = Mock(spec=BaseExtractor)
    extractor.create_metadata.return_value = MigrationsMetadata(changed_files=changed_files, migrations=migrations)

    linters = [CompatibilityLinter(), SquawkLinter(config_path="fake_path", pg_version="12")]

    return Analyzer(loader=loader, extractor=extractor, linters=linters)

class TestAnalyzer(unittest.TestCase):

    def test_analyze_data_migration(self):
        changed_files = [Mock()]
        migrations = [Migration(path="migration.sql", raw_sql="INSERT INTO table VALUES (1);")]
        analyzer = get_analyzer(changed_files, migrations)
        with patch.object(analyzer, 'analyze') as mock_analyze:
            analyzer.analyze()
            mock_analyze.assert_called_once()

    def test_analyze_ignore_migration(self):
        changed_files = [Mock()]
        migrations = [Migration(path="migration.sql", raw_sql="-- migration-lint: ignore\nALTER TABLE table ADD COLUMN new_column INT;")]
        analyzer = get_analyzer(changed_files, migrations)
        with patch.object(analyzer, 'analyze') as mock_analyze:
            analyzer.analyze()
            mock_analyze.assert_called_once()

    def test_analyze_incompatible(self):
        changed_files = [Mock()]
        migrations = [Migration(path="migration.sql", raw_sql="ALTER TABLE table DROP COLUMN old_column;")]
        analyzer = get_analyzer(changed_files, migrations)
        with patch.object(analyzer, 'analyze') as mock_analyze:
            analyzer.analyze()
            mock_analyze.assert_called_once()

    def test_analyze_incompatible_with_allowed_files(self):
        changed_files = [Mock()]
        migrations = [Migration(path="migration.sql", raw_sql="ALTER TABLE table DROP COLUMN old_column;")]
        analyzer = get_analyzer(changed_files, migrations)
        with patch.object(analyzer, 'analyze') as mock_analyze:
            analyzer.analyze()
            mock_analyze.assert_called_once()

    def test_analyze_no_errors(self):
        changed_files = [Mock()]
        migrations = [Migration(path="migration.sql", raw_sql="SELECT * FROM table;")]
        analyzer = get_analyzer(changed_files, migrations)
        with patch.object(analyzer, 'analyze') as mock_analyze:
            analyzer.analyze()
            mock_analyze.assert_called_once()

    def test_analyze_no_migrations(self):
        changed_files = [Mock()]
        migrations = []
        analyzer = get_analyzer(changed_files, migrations)
        with patch.object(analyzer, 'analyze') as mock_analyze:
            analyzer.analyze()
            mock_analyze.assert_called_once()

    def test_analyze_restricted(self):
        changed_files = [Mock()]
        migrations = [Migration(path="migration.sql", raw_sql="ALTER TABLE table ADD COLUMN new_column INT;")]
        analyzer = get_analyzer(changed_files, migrations)
        with patch.object(analyzer, 'analyze') as mock_analyze:
            analyzer.analyze()
            mock_analyze.assert_called_once()

    def test_analyze_unsupported(self):
        changed_files = [Mock()]
        migrations = [Migration(path="migration.sql", raw_sql="CREATE INDEX idx ON table (column);")]
        analyzer = get_analyzer(changed_files, migrations)
        with patch.object(analyzer, 'analyze') as mock_analyze:
            analyzer.analyze()
            mock_analyze.assert_called_once()

if __name__ == '__main__':
    unittest.main()