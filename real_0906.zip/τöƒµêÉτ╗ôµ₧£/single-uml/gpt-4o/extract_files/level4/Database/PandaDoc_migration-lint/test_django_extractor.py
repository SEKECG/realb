import unittest
from migration_lint.extractor.django import DjangoExtractor
from migration_lint.extractor.model import MigrationsMetadata

class TestDjangoExtractor(unittest.TestCase):

    def test_django_extractor__ok(self):
        extractor = DjangoExtractor()
        migration_path = "path/to/migration/file"
        sql = extractor.extract_sql(migration_path)
        self.assertIsInstance(sql, str)
        self.assertGreater(len(sql), 0)

        changed_files = ["file1.py", "file2.py"]
        metadata = extractor.create_metadata(changed_files)
        self.assertIsInstance(metadata, MigrationsMetadata)
        self.assertGreater(len(metadata.changed_files), 0)
        self.assertGreater(len(metadata.migrations), 0)

if __name__ == "__main__":
    unittest.main()