# local.py

from typing import Sequence
from migration_lint.source_loader.model import SourceDiff

class LocalLoader:
    NAME = "local"

    def get_changed_files(self) -> Sequence[SourceDiff]:
        # Implementation to return a list of changed files
        pass