import unittest
from migration_lint.sql.parser import classify_migration, classify_statement
from migration_lint.sql.constants import StatementType

class TestClassifyStatement(unittest.TestCase):

    def test_classify_migration(self):
        statement = "CREATE TABLE test (id INT PRIMARY KEY);"
        expected_type = StatementType.BACKWARD_COMPATIBLE
        result = classify_migration(statement)
        self.assertEqual(result[0][1], expected_type)

    def test_conditionally_safe(self):
        sql = "CREATE TABLE test (id INT PRIMARY KEY); ALTER TABLE test ADD COLUMN name VARCHAR(255);"
        expected_type = StatementType.BACKWARD_COMPATIBLE
        result = classify_migration(sql)
        self.assertEqual(result[-1][1], expected_type)

    def test_ignore_order(self):
        sql = "ALTER TABLE test ADD COLUMN name VARCHAR(255) NOT NULL DEFAULT 'unknown';"
        result = classify_migration(sql)
        self.assertIn(result[0][1], [StatementType.BACKWARD_COMPATIBLE, StatementType.RESTRICTED])

    def test_ignore_statements(self):
        statement = "CREATE TABLE test (id INT PRIMARY KEY);"
        expected_count = 1
        result = classify_migration(statement)
        self.assertEqual(len(result), expected_count)

if __name__ == '__main__':
    unittest.main()