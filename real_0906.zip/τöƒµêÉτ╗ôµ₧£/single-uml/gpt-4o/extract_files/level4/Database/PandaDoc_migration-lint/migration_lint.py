import argparse
from migration_lint.analyzer.base import Analyzer
from migration_lint.analyzer.compat import CompatibilityLinter
from migration_lint.analyzer.squawk import SquawkLinter
from migration_lint.extractor.base import BaseExtractor
from migration_lint.extractor.model import MigrationsMetadata
from migration_lint.source_loader.base import BaseSourceLoader
from migration_lint.source_loader.gitlab import GitlabBranchLoader, GitlabMRLoader
from migration_lint.source_loader.local import LocalLoader

class Command:
    def add_arguments(self, parser):
        parser.add_argument('--loader-type', type=str, required=True, help='Type of source loader to use')
        parser.add_argument('--squawk-config-path', type=str, required=False, help='Path to Squawk configuration file')
        parser.add_argument('--squawk-pg-version', type=str, required=False, help='PostgreSQL version for Squawk checks')
        parser.add_argument('--options', type=str, required=False, help='Additional options for the linter')

    def handle(self, loader_type, squawk_config_path, squawk_pg_version, options):
        loader = self.get_loader(loader_type)
        extractor = self.get_extractor(loader_type)
        linters = [CompatibilityLinter(), SquawkLinter(squawk_config_path, squawk_pg_version)]
        analyzer = Analyzer(loader, extractor, linters)
        analyzer.analyze()

    def get_loader(self, loader_type):
        if loader_type == 'gitlab_branch':
            return GitlabBranchLoader()
        elif loader_type == 'gitlab_mr':
            return GitlabMRLoader()
        elif loader_type == 'local':
            return LocalLoader()
        else:
            raise ValueError(f'Unknown loader type: {loader_type}')

    def get_extractor(self, loader_type):
        if loader_type in ['gitlab_branch', 'gitlab_mr', 'local']:
            return BaseExtractor()
        else:
            raise ValueError(f'Unknown extractor type for loader: {loader_type}')

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Migration Lint Command Line Tool')
    command = Command()
    command.add_arguments(parser)
    args = parser.parse_args()
    command.handle(args.loader_type, args.squawk_config_path, args.squawk_pg_version, args.options)