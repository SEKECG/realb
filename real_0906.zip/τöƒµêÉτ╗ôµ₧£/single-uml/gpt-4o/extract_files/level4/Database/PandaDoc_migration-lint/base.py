# base.py

from typing import List

CLASSIFICATION_LINK = "classification_link"
IGNORE_LINK = "ignore_link"
MANUALLY_IGNORE_ANNOTATION = "migration-lint: ignore"

class Analyzer:
    def __init__(self, loader, extractor, linters):
        self.loader = loader
        self.extractor = extractor
        self.linters = linters

    def analyze(self):
        changed_files = self.loader.get_changed_files()
        migrations_metadata = self.extractor.create_metadata(changed_files)
        for migration in migrations_metadata.migrations:
            raw_sql = self.extractor.extract_sql(migration.path)
            for linter in self.linters:
                linter.lint(raw_sql, changed_files)

class BaseLinter:
    def lint(self, migration_sql, changed_files) -> List[str]:
        raise NotImplementedError("Subclasses should implement this method")