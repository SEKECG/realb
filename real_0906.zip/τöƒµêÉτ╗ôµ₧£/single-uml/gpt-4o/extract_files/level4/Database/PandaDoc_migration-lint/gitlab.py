import requests
from typing import Sequence
from migration_lint.source_loader.model import SourceDiff

class GitlabBranchLoader:
    NAME = "gitlab_branch_loader"

    def __init__(self, branch, project_id, gitlab_api_key, gitlab_instance, **kwargs):
        self.branch = branch
        self.project_id = project_id
        self.gitlab_api_key = gitlab_api_key
        self.base_url = f"{gitlab_instance}/api/v4"
        self.default_branch = kwargs.get("default_branch", "master")

    def get_changed_files(self) -> Sequence[SourceDiff]:
        url = f"{self.base_url}/projects/{self.project_id}/repository/compare"
        params = {
            "from": self.default_branch,
            "to": self.branch
        }
        headers = {
            "PRIVATE-TOKEN": self.gitlab_api_key
        }
        response = requests.get(url, params=params, headers=headers)
        response.raise_for_status()
        changes = response.json()["diffs"]
        return [SourceDiff(path=change["new_path"], old_path=change["old_path"], diff=change["diff"]) for change in changes]

class GitlabMRLoader:
    NAME = "gitlab_mr_loader"

    def __init__(self, mr_id, project_id, gitlab_api_key, gitlab_instance, **kwargs):
        self.mr_id = mr_id
        self.project_id = project_id
        self.gitlab_api_key = gitlab_api_key
        self.base_url = f"{gitlab_instance}/api/v4"

    def get_changed_files(self) -> Sequence[SourceDiff]:
        url = f"{self.base_url}/projects/{self.project_id}/merge_requests/{self.mr_id}/changes"
        headers = {
            "PRIVATE-TOKEN": self.gitlab_api_key
        }
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        changes = response.json()["changes"]
        return [SourceDiff(path=change["new_path"], old_path=change["old_path"], diff=change["diff"]) for change in changes]