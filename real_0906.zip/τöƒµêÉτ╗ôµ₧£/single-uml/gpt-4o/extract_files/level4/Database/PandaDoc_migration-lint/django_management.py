from migration_lint.extractor.base import BaseExtractor

class DjangoManagementExtractor(BaseExtractor):
    NAME = "django_management"

    def extract_sql(self, migration_path):
        # Implement the logic to extract raw SQL from the migration file
        with open(migration_path, 'r') as file:
            return file.read()