from typing import List, Optional, Any

class SourceDiff:
    def __init__(self, path, old_path=None, diff=None):
        self.path = path
        self.old_path = old_path if old_path else path
        self.diff = diff

    def __post_init__(self):
        if not self.old_path:
            self.old_path = self.path

class ExtendedSourceDiff(SourceDiff):
    def __init__(self, path, old_path=None, diff=None, allowed_with_backward_incompatible=False):
        super().__init__(path, old_path, diff)
        self.allowed_with_backward_incompatible = allowed_with_backward_incompatible

    @classmethod
    def of_source_diff(cls, source_diff, allowed_with_backward_incompatible):
        return cls(
            path=source_diff.path,
            old_path=source_diff.old_path,
            diff=source_diff.diff,
            allowed_with_backward_incompatible=allowed_with_backward_incompatible
        )

class Migration:
    def __init__(self, path, raw_sql):
        self.path = path
        self.raw_sql = raw_sql

class MigrationsMetadata:
    def __init__(self, changed_files: List[ExtendedSourceDiff], migrations: List[Migration]):
        self.changed_files = changed_files
        self.migrations = migrations

class ConditionalMatch:
    def __init__(self, locator, match_by):
        self.locator = locator
        self.match_by = match_by

class KeywordLocator:
    def __init__(self, type):
        self.type = type

class SegmentLocator:
    def __init__(self, type, raw=None, children=None, inverted=False, ignore_order=False, only_with=None):
        self.type = type
        self.raw = raw
        self.children = children if children else []
        self.inverted = inverted
        self.ignore_order = ignore_order
        self.only_with = only_with