import unittest
from migration_lint.extractor.flyway import FlywayExtractor
from migration_lint.extractor.model import Migration, MigrationsMetadata

class TestFlywayExtractor(unittest.TestCase):

    def test_flyway_extractor__ok(self):
        extractor = FlywayExtractor()
        migration_path = "path/to/migration.sql"
        migration_sql = "CREATE TABLE test (id INT PRIMARY KEY);"
        
        # Mocking the extract_sql method
        extractor.extract_sql = lambda path: migration_sql if path == migration_path else ""
        
        # Mocking the is_migration method
        extractor.is_migration = lambda path: path == migration_path
        
        # Mocking the is_allowed_with_backward_incompatible_migration method
        extractor.is_allowed_with_backward_incompatible_migration = lambda path: False
        
        # Creating a mock changed file
        changed_files = [migration_path]
        
        # Extracting SQL
        extracted_sql = extractor.extract_sql(migration_path)
        self.assertEqual(extracted_sql, migration_sql)
        
        # Checking if the file is a migration
        is_migration = extractor.is_migration(migration_path)
        self.assertTrue(is_migration)
        
        # Checking if the migration is allowed with backward incompatible changes
        is_allowed = extractor.is_allowed_with_backward_incompatible_migration(migration_path)
        self.assertFalse(is_allowed)
        
        # Creating migration metadata
        migrations_metadata = MigrationsMetadata(
            changed_files=[migration_path],
            migrations=[Migration(path=migration_path, raw_sql=migration_sql)]
        )
        
        self.assertEqual(len(migrations_metadata.changed_files), 1)
        self.assertEqual(len(migrations_metadata.migrations), 1)
        self.assertEqual(migrations_metadata.migrations[0].raw_sql, migration_sql)

if __name__ == "__main__":
    unittest.main()