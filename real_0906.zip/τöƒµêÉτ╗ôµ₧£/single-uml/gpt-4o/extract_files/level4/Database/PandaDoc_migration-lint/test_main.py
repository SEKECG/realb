import pytest
from migration_lint.main import main
from migration_lint.extractor.squawk import SquawkLinter
from migration_lint.source_loader.local import LocalLoader
from migration_lint.extractor.base import BaseExtractor

def test_main():
    loader_type = LocalLoader
    extractor_type = BaseExtractor
    squawk_config_path = "path/to/squawk/config"
    squawk_pg_version = "12.0"
    kwargs = {}

    main(loader_type, extractor_type, squawk_config_path, squawk_pg_version, **kwargs)

if __name__ == "__main__":
    pytest.main()