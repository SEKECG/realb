# django.py

from migration_lint.extractor.base import BaseExtractor

class DjangoExtractor(BaseExtractor):
    NAME = "django"

    def __init__(self, **kwargs):
        self.command = kwargs.get("command", "make sqlmigrate")
        self.skip_lines = kwargs.get("skip_lines", 0)
        super().__init__(**kwargs)

    def extract_sql(self, migration_path):
        # Implementation for extracting SQL from Django migration file
        pass

    def is_allowed_with_backward_incompatible_migration(self, path):
        # Implementation for checking if the file changes are allowed with backward-incompatible migrations
        pass

    def is_migration(self, path):
        # Implementation for checking if the file is a migration
        pass