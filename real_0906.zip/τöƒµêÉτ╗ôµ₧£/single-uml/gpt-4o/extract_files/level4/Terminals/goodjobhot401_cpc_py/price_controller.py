import requests
from rich.console import Console
from rich.table import Table
from src.cpc.services.price import PRICE_SERVICE

class PRICE:
    def __init__(self):
        self.price_service = PRICE_SERVICE()

    def get_price_detail(self, symbols):
        try:
            price_details = self.price_service.get_price_detail(symbols)
            console = Console()
            table = Table(show_header=True, header_style="bold magenta")
            table.add_column("Symbol", style="dim", width=12)
            table.add_column("Current Price", justify="right")
            table.add_column("24h Change", justify="right")
            table.add_column("24h Change (%)", justify="right")
            table.add_column("Bid Price", justify="right")
            table.add_column("Ask Price", justify="right")
            table.add_column("24h High", justify="right")
            table.add_column("24h Low", justify="right")
            table.add_column("Volume", justify="right")

            for detail in price_details:
                table.add_row(
                    detail["symbol"],
                    f'{detail["current_price"]:.2f}',
                    f'{detail["price_change"]:.2f}',
                    f'{detail["price_change_percent"]:.2f}%',
                    f'{detail["bid_price"]:.2f}',
                    f'{detail["ask_price"]:.2f}',
                    f'{detail["high_price"]:.2f}',
                    f'{detail["low_price"]:.2f}',
                    f'{detail["volume"]:.2f}'
                )

            console.print(table)
        except Exception as e:
            console.print(f"[bold red]Error:[/bold red] {str(e)}")

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Get price details for specified symbols.")
    parser.add_argument("symbols", nargs="+", help="List of symbols to get price details for.")
    args = parser.parse_args()

    price_controller = PRICE()
    price_controller.get_price_detail(args.symbols)