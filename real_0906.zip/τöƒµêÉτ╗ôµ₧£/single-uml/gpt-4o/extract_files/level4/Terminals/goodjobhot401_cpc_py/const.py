# const.py

INIT_USER_DATA = {
    "name": "default_user",
    "target": 1,
    "favorites": [],
    "assets": []
}

PRICE_DETAIL_ROW_MAP = {
    "symbol": "Symbol",
    "priceChange": "Price Change",
    "priceChangePercent": "Price Change Percent",
    "weightedAvgPrice": "Weighted Avg Price",
    "prevClosePrice": "Previous Close Price",
    "lastPrice": "Last Price",
    "bidPrice": "Bid Price",
    "askPrice": "Ask Price",
    "openPrice": "Open Price",
    "highPrice": "High Price",
    "lowPrice": "Low Price",
    "volume": "Volume",
    "quoteVolume": "Quote Volume"
}

VALID_INTERVAL = [
    "1m", "5m", "15m", "30m", "1h", "4h", "8h", "1d", "1W", "1M"
]