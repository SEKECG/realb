import requests
from src.cpc.services.symbol import SYMBOL_SERVICE

class SYMBOL:
    def filter_symbols(self, query):
        symbol_service = SYMBOL_SERVICE()
        return symbol_service.filter_symbols(query)

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Filter and retrieve symbols based on a given query.")
    parser.add_argument("query", type=str, help="Query to filter symbols")
    args = parser.parse_args()

    symbol_controller = SYMBOL()
    symbols = symbol_controller.filter_symbols(args.query)
    for symbol in symbols:
        print(symbol)