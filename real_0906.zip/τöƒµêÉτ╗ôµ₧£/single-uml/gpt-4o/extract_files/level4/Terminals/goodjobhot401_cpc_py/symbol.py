import requests
from rich.table import Table
from rich.console import Console

class SYMBOL_SERVICE:
    def filter_symbols(self, query):
        url = "https://api.mexc.com/api/v3/exchangeInfo"
        response = requests.get(url)
        data = response.json()
        
        symbols = data['symbols']
        filtered_symbols = [symbol for symbol in symbols if query.lower() in symbol['symbol'].lower()]
        
        table = Table(title="Filtered Symbols")
        table.add_column("Symbol", justify="center", style="cyan", no_wrap=True)
        table.add_column("Base Asset", justify="center", style="magenta")
        table.add_column("Quote Asset", justify="center", style="green")
        
        for symbol in filtered_symbols:
            table.add_row(symbol['symbol'], symbol['baseAsset'], symbol['quoteAsset'])
        
        console = Console()
        console.print(table)