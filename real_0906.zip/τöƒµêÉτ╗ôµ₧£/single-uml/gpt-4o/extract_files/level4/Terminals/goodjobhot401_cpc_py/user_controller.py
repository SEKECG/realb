import sqlite3
from rich.console import Console
from rich.table import Table
from src.cpc.repositories.user import USER_REPOSITORIES
from src.cpc.services.user import USER_SERVICE

console = Console()

class USER:
    def __init__(self, conn):
        self.user_service = USER_SERVICE(conn)

    def get_user(self, print_table=True):
        user = self.user_service.get_user(print_table)
        if print_table and user:
            table = Table(title="User Information")
            table.add_column("ID", justify="right", style="cyan", no_wrap=True)
            table.add_column("Name", style="magenta")
            table.add_column("Target", justify="right", style="green")
            table.add_row(str(user["id"]), user["name"], str(user["target"]))
            console.print(table)
        return user

    def get_users(self):
        users = self.user_service.get_users()
        table = Table(title="Users List")
        table.add_column("ID", justify="right", style="cyan", no_wrap=True)
        table.add_column("Name", style="magenta")
        table.add_column("Target", justify="right", style="green")
        for user in users:
            table.add_row(str(user["id"]), user["name"], str(user["target"]))
        console.print(table)
        return users

    def create_user(self, name):
        self.user_service.create_user(name)
        console.print(f"User '{name}' created successfully.", style="bold green")

    def switch_user(self, user_id):
        try:
            self.user_service.switch_user(user_id)
            console.print(f"Switched to user ID {user_id}.", style="bold green")
        except Exception as e:
            console.print(f"Error switching user: {e}", style="bold red")

    def update_user(self, user_id, name):
        self.user_service.update_user(user_id, name)
        console.print(f"User ID {user_id} updated to '{name}'.", style="bold green")

    def remove_user(self, user_id):
        self.user_service.remove_user(user_id)
        console.print(f"User ID {user_id} removed successfully.", style="bold green")

    def get_position_ratio(self, sort=None, reverse=False):
        try:
            ratios = self.user_service.get_position_ratio(sort, reverse)
            table = Table(title="Position Ratios")
            table.add_column("Symbol", style="cyan")
            table.add_column("Amount", style="magenta")
            table.add_column("Value", style="green")
            for ratio in ratios:
                table.add_row(ratio["symbol"], str(ratio["amount"]), str(ratio["value"]))
            console.print(table)
        except Exception as e:
            console.print(f"Error retrieving position ratios: {e}", style="bold red")

    def create_default_user(self):
        try:
            self.user_service.create_default_user()
            console.print("Default user created successfully.", style="bold green")
        except Exception as e:
            console.print(f"Error creating default user: {e}", style="bold red")