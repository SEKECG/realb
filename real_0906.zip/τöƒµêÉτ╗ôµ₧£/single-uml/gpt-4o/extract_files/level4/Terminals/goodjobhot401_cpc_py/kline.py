import requests
import plotext as plt
from src.cpc.helpers.mexc import mexc_market

class KLINE_SERVICE:
    def __init__(self):
        self.market_api = mexc_market()

    def _plot_candlesticks(self, klines_data, symbol, interval, test=False):
        timestamps = [data[0] for data in klines_data]
        opens = [data[1] for data in klines_data]
        highs = [data[2] for data in klines_data]
        lows = [data[3] for data in klines_data]
        closes = [data[4] for data in klines_data]

        plt.candlestick(timestamps, opens, highs, lows, closes)
        plt.title(f"{symbol} - {interval}")
        plt.show()

    def get_kline(self, symbol, interval, limit, test=False):
        params = {
            "symbol": symbol,
            "interval": interval,
            "limit": limit
        }
        response = self.market_api.get_kline(params)
        if response.status_code == 200:
            klines_data = response.json()
            self._plot_candlesticks(klines_data, symbol, interval, test)
        else:
            print(f"Failed to fetch k-line data: {response.text}")

if __name__ == "__main__":
    kline_service = KLINE_SERVICE()
    kline_service.get_kline("BTCUSDT", "4h", 30)