import sqlite3
from src.cpc.common.config import DB_PATH
from src.cpc.database.dml.init.init import USER_TABLE_SQL, ASSET_TABLE_SQL, FAVORITE_TABLE_SQL

def db_connection(func):
    def wrapper(*args, **kwargs):
        conn = sqlite3.connect(DB_PATH)
        try:
            result = func(conn, *args, **kwargs)
            conn.commit()
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()
        return result
    return wrapper

@db_connection
def init_tables(conn):
    cursor = conn.cursor()
    cursor.execute(USER_TABLE_SQL)
    cursor.execute(ASSET_TABLE_SQL)
    cursor.execute(FAVORITE_TABLE_SQL)
    conn.commit()