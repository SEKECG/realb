import sys
sys.path.append('..')

from services.asset import ASSET_SERVICE
from middlewares.db_connect import db_connection

class ASSET:
    def __init__(self, conn):
        self.asset_service = ASSET_SERVICE(conn)

    @db_connection
    def add_asset(self, asset_list):
        try:
            result = self.asset_service.add_asset(asset_list)
            return result
        except Exception as e:
            print(f"Error adding asset: {e}")

    @db_connection
    def update_asset(self, asset_list):
        try:
            result = self.asset_service.update_asset(asset_list)
            return result
        except Exception as e:
            print(f"Error updating asset: {e}")

    @db_connection
    def remove_asset(self, asset_list):
        try:
            result = self.asset_service.remove_asset(asset_list)
            return result
        except Exception as e:
            print(f"Error removing asset: {e}")

if __name__ == "__main__":
    import sqlite3
    conn = sqlite3.connect('../database/cpc.db')
    asset_controller = ASSET(conn)
    # Example usage
    asset_controller.add_asset([("BTCUSDT", 0.5), ("ETHUSDT", 2.5)])
    asset_controller.update_asset([("BTCUSDT", 1.0), ("ETHUSDT", 3.0)])
    asset_controller.remove_asset(["BTCUSDT", "ETHUSDT"])