import requests
from rich.console import Console
from rich.table import Table
from src.cpc.common.const import PRICE_DETAIL_ROW_MAP
from src.cpc.helpers.mexc import mexc_market

class PRICE_SERVICE:
    def __init__(self):
        self.market = mexc_market()

    def get_price_detail(self, symbols):
        console = Console()
        table = Table(show_header=True, header_style="bold magenta")
        for header in PRICE_DETAIL_ROW_MAP.values():
            table.add_column(header)

        for symbol in symbols:
            params = {"symbol": symbol}
            response = self.market.get_24hr_ticker(params)
            if response.status_code == 200:
                data = response.json()
                row = [
                    data["symbol"],
                    data["lastPrice"],
                    data["priceChange"],
                    data["priceChangePercent"],
                    data["bidPrice"],
                    data["bidQty"],
                    data["askPrice"],
                    data["askQty"],
                    data["highPrice"],
                    data["lowPrice"],
                    data["volume"]
                ]
                table.add_row(*row)
            else:
                console.print(f"Failed to fetch data for {symbol}", style="bold red")

        console.print(table)

mapping = PRICE_SERVICE()