import argparse
import sqlite3
import requests
from rich.console import Console
from rich.table import Table
from plotext import plot

from common.config import DB_PATH, MEXC_HOST
from common.const import INIT_USER_DATA, PRICE_DETAIL_ROW_MAP, VALID_INTERVAL
from middlewares.db_connect import db_connection, init_tables
from handlers.asset_controller import ASSET
from handlers.favorite_controller import FAVORITE
from handlers.kline_controller import KLINE
from handlers.price_controller import PRICE
from handlers.symbol_controller import SYMBOL
from handlers.user_controller import USER

console = Console()

@db_connection
def main(conn):
    parser = argparse.ArgumentParser(description="Cryptocurrency Portfolio Tracker")
    subparsers = parser.add_subparsers(dest="command")

    # Symbols command
    symbols_parser = subparsers.add_parser("symbols", help="List/filter available trading pairs")
    symbols_parser.add_argument("query", nargs="?", default="", help="Query to filter symbols")

    # Price command
    price_parser = subparsers.add_parser("price", help="Get price details for specified pairs")
    price_parser.add_argument("symbols", nargs="+", help="Symbols to get price details for")

    # Kline command
    kline_parser = subparsers.add_parser("kline", help="Display candlestick charts")
    kline_parser.add_argument("symbol", help="Symbol to get kline data for")
    kline_parser.add_argument("--interval", default="1d", choices=VALID_INTERVAL, help="Time interval for kline data")
    kline_parser.add_argument("--limit", type=int, default=30, help="Data point limit for kline data")

    # User command
    user_parser = subparsers.add_parser("user", help="Manage user profiles")
    user_subparsers = user_parser.add_subparsers(dest="action")
    user_subparsers.add_parser("create", help="Create a new user")
    user_subparsers.add_parser("update", help="Update an existing user")
    user_subparsers.add_parser("delete", help="Delete a user")
    user_subparsers.add_parser("switch", help="Switch between users")
    user_subparsers.add_parser("list", help="List all users")

    # Favorite command
    favorite_parser = subparsers.add_parser("favorite", help="Manage watchlist")
    favorite_subparsers = favorite_parser.add_subparsers(dest="action")
    favorite_subparsers.add_parser("add", help="Add symbols to watchlist")
    favorite_subparsers.add_parser("remove", help="Remove symbols from watchlist")
    favorite_subparsers.add_parser("list", help="List all favorite symbols")

    # Asset command
    asset_parser = subparsers.add_parser("asset", help="Manage cryptocurrency holdings")
    asset_subparsers = asset_parser.add_subparsers(dest="action")
    asset_subparsers.add_parser("add", help="Add assets")
    asset_subparsers.add_parser("remove", help="Remove assets")
    asset_subparsers.add_parser("update", help="Update asset quantities")
    asset_subparsers.add_parser("list", help="List all assets")

    args = parser.parse_args()

    if args.command == "symbols":
        SYMBOL().filter_symbols(args.query)
    elif args.command == "price":
        PRICE().get_price_detail(args.symbols)
    elif args.command == "kline":
        KLINE().get_kline(args.symbol, args.interval, args.limit)
    elif args.command == "user":
        user_controller = USER()
        if args.action == "create":
            user_controller.create_user()
        elif args.action == "update":
            user_controller.update_user()
        elif args.action == "delete":
            user_controller.remove_user()
        elif args.action == "switch":
            user_controller.switch_user()
        elif args.action == "list":
            user_controller.get_users()
    elif args.command == "favorite":
        favorite_controller = FAVORITE()
        if args.action == "add":
            favorite_controller.add_favorite()
        elif args.action == "remove":
            favorite_controller.remove_favorite()
        elif args.action == "list":
            favorite_controller.get_favorites()
    elif args.command == "asset":
        asset_controller = ASSET()
        if args.action == "add":
            asset_controller.add_asset()
        elif args.action == "remove":
            asset_controller.remove_asset()
        elif args.action == "update":
            asset_controller.update_asset()
        elif args.action == "list":
            asset_controller.get_assets()

if __name__ == "__main__":
    main()