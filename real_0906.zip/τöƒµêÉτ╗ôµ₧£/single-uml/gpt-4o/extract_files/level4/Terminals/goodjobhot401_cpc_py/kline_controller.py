# kline_controller.py

import sys
from src.cpc.services.kline import KLINE_SERVICE
from src.cpc.helpers.mexc import TOOL
from src.cpc.common.config import MEXC_HOST

class KLINE:
    def __init__(self):
        self.kline_service = KLINE_SERVICE(TOOL(MEXC_HOST))

    def get_kline(self, symbol, interval, limit):
        try:
            return self.kline_service.get_kline(symbol, interval, limit)
        except Exception as e:
            print(f"Error fetching k-line data: {e}", file=sys.stderr)
            return None

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Fetch k-line data for a given symbol.")
    parser.add_argument("symbol", help="The symbol to fetch k-line data for.")
    parser.add_argument("interval", help="The interval for k-line data.")
    parser.add_argument("limit", type=int, help="The limit for k-line data points.")
    args = parser.parse_args()

    kline = KLINE()
    data = kline.get_kline(args.symbol, args.interval, args.limit)
    if data:
        print(data)