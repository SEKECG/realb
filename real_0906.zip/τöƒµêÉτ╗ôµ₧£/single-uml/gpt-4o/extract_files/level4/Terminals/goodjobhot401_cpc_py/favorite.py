import sqlite3

class FAVORITE_SQL:
    def add_favorite_sql(self):
        return """
        INSERT INTO Favorite (user_id, symbol)
        VALUES (?, ?)
        """

    def remove_favorite_sql(self):
        return """
        DELETE FROM Favorite
        WHERE user_id = ? AND symbol = ?
        """

class FAVORITE_SERVICE:
    def __init__(self, conn):
        self.conn = conn
        self.favorite_repository = FAVORITE_SQL()
        self.user_repository = USER_SQL()

    def add_favorite(self, favorite_list):
        cursor = self.conn.cursor()
        for symbol in favorite_list:
            cursor.execute(self.favorite_repository.add_favorite_sql(), (self.user_repository.get_user_id(), symbol))
        self.conn.commit()

    def remove_favorite(self, favorite_list):
        cursor = self.conn.cursor()
        for symbol in favorite_list:
            cursor.execute(self.favorite_repository.remove_favorite_sql(), (self.user_repository.get_user_id(), symbol))
        self.conn.commit()

class FAVORITE_REPOSITORIES:
    def __init__(self, conn):
        self.conn = conn
        self.cursor = conn.cursor()

    def add_favorite(self, user_id, symbol_list):
        for symbol in symbol_list:
            self.cursor.execute("INSERT INTO Favorite (user_id, symbol) VALUES (?, ?)", (user_id, symbol))
        self.conn.commit()

    def remove_favorite(self, user_id, symbol_list):
        for symbol in symbol_list:
            self.cursor.execute("DELETE FROM Favorite WHERE user_id = ? AND symbol = ?", (user_id, symbol))
        self.conn.commit()

class USER_SQL:
    def get_user_id(self):
        return """
        SELECT id FROM User WHERE target = 1
        """