import requests
import hmac
import hashlib
import time

class TOOL:
    def __init__(self, api_key, api_secret):
        self.api_key = api_key
        self.api_secret = api_secret

    def _get_server_time(self):
        url = "https://api.mexc.com/api/v3/time"
        response = requests.get(url)
        return response.json()["serverTime"]

    def _sign_v3(self, req_time, sign_params):
        query_string = "&".join([f"{key}={value}" for key, value in sign_params.items()])
        signature = hmac.new(self.api_secret.encode(), (query_string + f"&timestamp={req_time}").encode(), hashlib.sha256).hexdigest()
        return signature

    def public_request(self, method, url, params=None):
        response = requests.request(method, url, params=params)
        return response.json()

    def sign_request(self, method, url, params=None):
        req_time = self._get_server_time()
        params["timestamp"] = req_time
        signature = self._sign_v3(req_time, params)
        headers = {
            "X-MEXC-APIKEY": self.api_key,
            "Content-Type": "application/x-www-form-urlencoded"
        }
        params["signature"] = signature
        response = requests.request(method, url, params=params, headers=headers)
        return response.json()

class mexc_market:
    def __init__(self):
        self.api = TOOL(api_key="your_api_key", api_secret="your_api_secret")
        self.hosts = "https://api.mexc.com"
        self.method = "GET"

    def get_24hr_ticker(self, params):
        url = f"{self.hosts}/api/v3/ticker/24hr"
        return self.api.public_request(self.method, url, params)

    def get_ETF_info(self, params):
        url = f"{self.hosts}/api/v3/etf/info"
        return self.api.public_request(self.method, url, params)

    def get_aggtrades(self, params):
        url = f"{self.hosts}/api/v3/aggTrades"
        return self.api.public_request(self.method, url, params)

    def get_avgprice(self, params):
        url = f"{self.hosts}/api/v3/avgPrice"
        return self.api.public_request(self.method, url, params)

    def get_bookticker(self, params):
        url = f"{self.hosts}/api/v3/ticker/bookTicker"
        return self.api.public_request(self.method, url, params)

    def get_deals(self, params):
        url = f"{self.hosts}/api/v3/trades"
        return self.api.public_request(self.method, url, params)

    def get_defaultSymbols(self):
        url = f"{self.hosts}/api/v3/exchangeInfo"
        return self.api.public_request(self.method, url)

    def get_depth(self, params):
        url = f"{self.hosts}/api/v3/depth"
        return self.api.public_request(self.method, url, params)

    def get_exchangeInfo(self, params):
        url = f"{self.hosts}/api/v3/exchangeInfo"
        return self.api.public_request(self.method, url, params)

    def get_kline(self, params):
        url = f"{self.hosts}/api/v3/klines"
        return self.api.public_request(self.method, url, params)

    def get_ping(self):
        url = f"{self.hosts}/api/v3/ping"
        return self.api.public_request(self.method, url)

    def get_price(self, params):
        url = f"{self.hosts}/api/v3/ticker/price"
        return self.api.public_request(self.method, url, params)

    def get_timestamp(self):
        url = f"{self.hosts}/api/v3/time"
        return self.api.public_request(self.method, url)