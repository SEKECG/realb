import sqlite3

class USER_SQL:
    def auto_choose_user(self):
        return "UPDATE user SET target = 1 WHERE id = (SELECT id FROM user LIMIT 1);"

    def create_user(self):
        return "INSERT INTO user (name, target) VALUES (?, ?);"

    def get_asset_sql(self):
        return "SELECT symbol, amount FROM asset WHERE user_id = ?;"

    def get_favorite_sql(self):
        return "SELECT symbol FROM favorite WHERE user_id = ?;"

    def get_user(self):
        return "SELECT * FROM user WHERE target = 1;"

    def get_users(self):
        return "SELECT * FROM user;"

    def is_taget_sql(self):
        return "SELECT * FROM user WHERE target = 1;"

    def remove_all_target(self):
        return "UPDATE user SET target = 0 WHERE target = 1;"

    def remove_asset_sql(self):
        return "DELETE FROM asset WHERE user_id = ?;"

    def remove_favorite_sql(self):
        return "DELETE FROM favorite WHERE user_id = ?;"

    def remove_user_sql(self):
        return "DELETE FROM user WHERE id = ?;"

    def switch_target_user(self):
        return "UPDATE user SET target = 1 WHERE id = ?;"

    def update_user(self, fields):
        return f"UPDATE user SET {fields} WHERE id = ?;"


class USER_REPOSITORIES:
    def __init__(self, conn):
        self.conn = conn
        self.cursor = conn.cursor()

    def create_default_user(self):
        self.cursor.execute("INSERT INTO user (name, target) VALUES ('default', 1);")
        self.conn.commit()
        return self.cursor.lastrowid

    def _auto_choose_user(self):
        self.cursor.execute("UPDATE user SET target = 1 WHERE id = (SELECT id FROM user LIMIT 1);")
        self.conn.commit()

    def _auto_switch_user(self):
        self._remove_all_target()
        self._auto_choose_user()

    def _is_user_target(self):
        self.cursor.execute("SELECT * FROM user WHERE target = 1;")
        return len(self.cursor.fetchall()) == 1

    def _remove_all_target(self):
        self.cursor.execute("UPDATE user SET target = 0 WHERE target = 1;")
        self.conn.commit()

    def create_user(self, name, target=0):
        self.cursor.execute("INSERT INTO user (name, target) VALUES (?, ?);", (name, target))
        self.conn.commit()
        user_id = self.cursor.lastrowid
        self.switch_user(user_id)
        return user_id

    def get_user(self):
        self.cursor.execute("SELECT * FROM user WHERE target = 1;")
        user = self.cursor.fetchone()
        if user:
            user_id = user['id']
            self.cursor.execute("SELECT symbol, amount FROM asset WHERE user_id = ?;", (user_id,))
            assets = self.cursor.fetchall()
            self.cursor.execute("SELECT symbol FROM favorite WHERE user_id = ?;", (user_id,))
            favorites = self.cursor.fetchall()
            return {
                'user': user,
                'assets': assets,
                'favorites': favorites
            }
        return None

    def get_users(self):
        self.cursor.execute("SELECT * FROM user;")
        return self.cursor.fetchall()

    def remove_user(self, user_id):
        self.cursor.execute("DELETE FROM asset WHERE user_id = ?;", (user_id,))
        self.cursor.execute("DELETE FROM favorite WHERE user_id = ?;", (user_id,))
        self.cursor.execute("DELETE FROM user WHERE id = ?;", (user_id,))
        self.conn.commit()
        if not self._is_user_target():
            self._auto_switch_user()

    def switch_user(self, user_id):
        self._remove_all_target()
        self.cursor.execute("UPDATE user SET target = 1 WHERE id = ?;", (user_id,))
        self.conn.commit()

    def update_user(self, user_id, name):
        self.cursor.execute("UPDATE user SET name = ? WHERE id = ?;", (name, user_id))
        self.conn.commit()


class USER_SERVICE:
    def __init__(self, conn):
        self.repository = USER_REPOSITORIES(conn)

    def create_default_user(self):
        return self.repository.create_default_user()

    def create_user(self, name):
        return self.repository.create_user(name)

    def get_position_ratio(self, sort=None, reverse=False, pie=False):
        user = self.repository.get_user()
        if user:
            assets = user['assets']
            total_value = sum(asset['amount'] for asset in assets)
            ratios = [{'symbol': asset['symbol'], 'ratio': asset['amount'] / total_value} for asset in assets]
            if sort:
                ratios.sort(key=lambda x: x[sort], reverse=reverse)
            return ratios
        return []

    def get_user(self, print_table=False):
        user = self.repository.get_user()
        if print_table and user:
            print(f"User: {user['user']['name']}")
            print("Assets:")
            for asset in user['assets']:
                print(f"  {asset['symbol']}: {asset['amount']}")
            print("Favorites:")
            for favorite in user['favorites']:
                print(f"  {favorite['symbol']}")
        return user

    def get_users(self):
        return self.repository.get_users()

    def remove_user(self, user_id):
        self.repository.remove_user(user_id)

    def switch_user(self, user_id):
        self.repository.switch_user(user_id)

    def update_user(self, user_id, name):
        self.repository.update_user(user_id, name)