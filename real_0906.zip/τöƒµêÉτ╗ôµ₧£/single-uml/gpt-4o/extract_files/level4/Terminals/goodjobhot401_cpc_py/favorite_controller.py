# favorite_controller.py

from src.cpc.services.favorite import FAVORITE_SERVICE
from src.cpc.repositories.favorite import FAVORITE_REPOSITORIES
from src.cpc.middlewares.db_connect import db_connection

class FAVORITE:
    def __init__(self, conn):
        self.favorite_service = FAVORITE_SERVICE(conn)

    @db_connection
    def add_favorite(self, favorite_list):
        try:
            self.favorite_service.add_favorite(favorite_list)
            print("Favorites added successfully.")
        except Exception as e:
            print(f"Error adding favorites: {e}")

    @db_connection
    def remove_favorite(self, favorite_list):
        try:
            self.favorite_service.remove_favorite(favorite_list)
            print("Favorites removed successfully.")
        except Exception as e:
            print(f"Error removing favorites: {e}")

if __name__ == "__main__":
    import sqlite3
    conn = sqlite3.connect('path_to_db')
    favorite_controller = FAVORITE(conn)
    favorite_controller.add_favorite(['BTCUSDT', 'ETHUSDT'])
    favorite_controller.remove_favorite(['BTCUSDT'])