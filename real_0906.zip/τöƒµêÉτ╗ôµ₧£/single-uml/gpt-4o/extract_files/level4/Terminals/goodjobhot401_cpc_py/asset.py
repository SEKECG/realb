import sqlite3

class ASSET_SQL:
    def add_asset_sql(self):
        return """
        INSERT INTO Asset (symbol, amount, user_id)
        VALUES (?, ?, ?)
        """

    def remove_asset_sql(self):
        return """
        DELETE FROM Asset
        WHERE symbol = ? AND user_id = ?
        """

    def update_asset_sql(self):
        return """
        UPDATE Asset
        SET amount = ?
        WHERE symbol = ? AND user_id = ?
        """

class ASSET_SERVICE:
    def __init__(self, conn):
        self.conn = conn
        self.asset_repository = ASSET_SQL()
        self.user_repository = USER_SQL()

    def add_asset(self, asset_list):
        cursor = self.conn.cursor()
        for asset in asset_list:
            cursor.execute(self.asset_repository.add_asset_sql(), (asset['symbol'], asset['amount'], asset['user_id']))
        self.conn.commit()

    def remove_asset(self, asset_list):
        cursor = self.conn.cursor()
        for asset in asset_list:
            cursor.execute(self.asset_repository.remove_asset_sql(), (asset['symbol'], asset['user_id']))
        self.conn.commit()

    def update_asset(self, asset_list):
        cursor = self.conn.cursor()
        for asset in asset_list:
            cursor.execute(self.asset_repository.update_asset_sql(), (asset['amount'], asset['symbol'], asset['user_id']))
        self.conn.commit()

class ASSET_REPOSITORIES:
    def __init__(self, conn):
        self.conn = conn
        self.cursor = conn.cursor()

    def add_asset(self, user_id, symbol_list):
        for symbol, amount in symbol_list.items():
            self.cursor.execute("INSERT INTO Asset (user_id, symbol, amount) VALUES (?, ?, ?)", (user_id, symbol, amount))
        self.conn.commit()

    def remove_asset(self, user_id, symbol_list):
        for symbol in symbol_list:
            self.cursor.execute("DELETE FROM Asset WHERE user_id = ? AND symbol = ?", (user_id, symbol))
        self.conn.commit()

    def update_asset(self, user_id, symbol_list):
        for symbol, amount in symbol_list.items():
            self.cursor.execute("UPDATE Asset SET amount = ? WHERE user_id = ? AND symbol = ?", (amount, user_id, symbol))
        self.conn.commit()

if __name__ == "__main__":
    conn = sqlite3.connect('database.db')
    asset_service = ASSET_SERVICE(conn)
    asset_repositories = ASSET_REPOSITORIES(conn)
    # Example usage
    asset_service.add_asset([{'symbol': 'BTC', 'amount': 1.5, 'user_id': 1}])
    asset_service.remove_asset([{'symbol': 'BTC', 'user_id': 1}])
    asset_service.update_asset([{'symbol': 'BTC', 'amount': 2.0, 'user_id': 1}])