import requests
from rich.console import Console
from src.server.api import fetch_problem_list
from src.server.auth import Auth

console = Console()

status_map = {
    "ac": "Accepted",
    "notac": "Not Accepted",
    "tried": "Tried",
    "untouched": "Untouched"
}

def list_problems(difficulty=None, status=None, tag=None, category_slug=None):
    auth = Auth()
    session = auth.get_session()
    csrf_token = session.cookies.get("csrftoken")
    session_id = session.cookies.get("LEETCODE_SESSION")

    problems = fetch_problem_list(csrf_token, session_id, category_slug, limit=100, skip=0, filters={
        "difficulty": difficulty,
        "status": status,
        "tags": tag
    })

    if problems:
        console.print("Available Problems:")
        for problem in problems:
            console.print(f"[{status_map.get(problem['status'], 'Unknown')}] {problem['title']} - {problem['difficulty']}")
    else:
        console.print("No problems found.")

if __name__ == "__main__":
    list_problems()