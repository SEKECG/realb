import json
from rich.console import Console
from rich.panel import Panel
from rich.markdown import Markdown

COLORS = {
    "Easy": "green",
    "Medium": "yellow",
    "Hard": "red"
}

STYLES = {
    "header": "bold",
    "difficulty": "bold",
    "stats": "italic",
    "topics": "bold cyan",
    "similar_questions": "bold magenta"
}

console = Console()

class ProblemDetails:
    def __init__(self, problem_data):
        self.problem_number = problem_data.get("problem_number")
        self.title = problem_data.get("title")
        self.content = problem_data.get("content")
        self.difficulty = problem_data.get("difficulty")
        self.stats = json.loads(problem_data.get("stats", "{}"))
        self.topics = problem_data.get("topics", [])
        self.similar_questions = problem_data.get("similar_questions", [])

    def _create_header(self):
        difficulty_color = COLORS.get(self.difficulty, "white")
        header = f"[{difficulty_color}]{self.problem_number}. {self.title} ({self.difficulty})[/]"
        return header

    def _format_markdown(self, content):
        markdown_content = Markdown(content)
        return markdown_content

    def _format_similar_questions(self):
        formatted_questions = []
        for question in self.similar_questions[:5]:
            title = question.get("title")
            difficulty = question.get("difficulty")
            link = question.get("link")
            formatted_questions.append(f"[{COLORS.get(difficulty, 'white')}]{title} ({difficulty})[/] - {link}")
        return "\n".join(formatted_questions)

    def _format_stats(self):
        acceptance_rate = self.stats.get("acceptance_rate", "N/A")
        total_accepted = self.stats.get("total_accepted", "N/A")
        total_submissions = self.stats.get("total_submissions", "N/A")
        stats = f"Acceptance Rate: {acceptance_rate}\nTotal Accepted: {total_accepted}\nTotal Submissions: {total_submissions}"
        return stats

    def _format_topics(self):
        if not self.topics:
            return ""
        formatted_topics = ", ".join(self.topics)
        return f"[{STYLES['topics']}]{formatted_topics}[/]"

    def display_additional_info(self):
        topics_panel = Panel(self._format_topics(), title="Topics", style=STYLES["topics"])
        similar_questions_panel = Panel(self._format_similar_questions(), title="Similar Questions", style=STYLES["similar_questions"])
        console.print(topics_panel)
        console.print(similar_questions_panel)

    def display_problem(self):
        header = self._create_header()
        content_panel = Panel(self._format_markdown(self.content), title=header, style=STYLES["header"])
        console.print(content_panel)

    def display_stats(self):
        stats_panel = Panel(self._format_stats(), title="Statistics", style=STYLES["stats"])
        console.print(stats_panel)