import os
import subprocess
from src.server.api import get_daily_question
from src.server.solution_manager import SolutionManager
from src.server.auth import Auth
from src.lib.problem_ui import ProblemDetails
from src.lib.submission_ui import display_submission_results, create_submission_progress

def daily(lang=None, editor=None, full=False, no_editor=False):
    """
    Get and work on today's LeetCode daily challenge.

    Fetches the daily coding challenge, displays problem details,
    and opens it in your preferred editor.
    """
    auth = Auth()
    if not auth.is_authenticated:
        print("Please login first.")
        return

    question_data = get_daily_question()
    if not question_data:
        print("Failed to fetch the daily question.")
        return

    problem_details = ProblemDetails(question_data)
    problem_details.display_problem()

    if no_editor:
        return

    solution_manager = SolutionManager(auth.get_session())
    title_slug = question_data['titleSlug']
    code_template = solution_manager.get_question_data(title_slug)['codeSnippets'][0]['code']

    file_name = f"{title_slug}.{lang}"
    with open(file_name, 'w') as f:
        f.write(code_template)

    if editor:
        subprocess.run([editor, file_name])
    else:
        subprocess.run(['vim', file_name])

    if full:
        with create_submission_progress():
            result = solution_manager.test_solution(title_slug, code_template, lang, full)
            display_submission_results(result, is_test=True)

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Work on today's LeetCode daily challenge.")
    parser.add_argument('--lang', help="Programming language for the solution template.")
    parser.add_argument('--editor', help="Code editor to open the solution file.")
    parser.add_argument('--full', action='store_true', help="Run full test cases after editing.")
    parser.add_argument('--no-editor', action='store_true', help="Do not open the editor.")

    args = parser.parse_args()
    daily(args.lang, args.editor, args.full, args.no_editor)