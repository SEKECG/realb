import requests
import json
from gql import gql, Client
from gql.transport.requests import RequestsHTTPTransport

BASE_URL = "https://leetcode.com/graphql"

def get_daily_question():
    query = gql("""
    query {
        activeDailyCodingChallengeQuestion {
            link
            question {
                title
                titleSlug
                content
                difficulty
                stats
                similarQuestions
                topicTags {
                    name
                }
            }
        }
    }
    """)
    client = create_leetcode_client()
    result = client.execute(query)
    return result['activeDailyCodingChallengeQuestion']

def fetch_problem_list(csrf_token, session_id, categorySlug, limit, skip, filters):
    query = gql("""
    query problemsetQuestionList($categorySlug: String, $limit: Int, $skip: Int, $filters: QuestionListFilterInput) {
        problemsetQuestionList(
            categorySlug: $categorySlug
            limit: $limit
            skip: $skip
            filters: $filters
        ) {
            total
            questions {
                title
                titleSlug
                difficulty
                stats
                similarQuestions
                topicTags {
                    name
                }
            }
        }
    }
    """)
    client = create_leetcode_client(csrf_token, session_id)
    variables = {
        "categorySlug": categorySlug,
        "limit": limit,
        "skip": skip,
        "filters": filters
    }
    result = client.execute(query, variable_values=variables)
    return result['problemsetQuestionList']

def fetch_user_profile(csrf_token, session_id):
    query = gql("""
    query {
        userProfilePublicProfile {
            username
            profile {
                realName
                aboutMe
                userAvatar
                reputation
                ranking
                contestBadge {
                    name
                    icon
                }
            }
            languageStats {
                languageName
                problemsSolved
            }
            skillStats {
                advanced {
                    tagName
                    problemsSolved
                }
                intermediate {
                    tagName
                    problemsSolved
                }
                fundamental {
                    tagName
                    problemsSolved
                }
            }
            recentSubmissionList {
                title
                titleSlug
                timestamp
            }
        }
    }
    """)
    client = create_leetcode_client(csrf_token, session_id)
    result = client.execute(query)
    return result['userProfilePublicProfile']

def create_leetcode_client(csrf_token=None, session_id=None):
    headers = {
        "Content-Type": "application/json",
        "Referer": "https://leetcode.com",
    }
    if csrf_token and session_id:
        headers.update({
            "x-csrftoken": csrf_token,
            "cookie": f"LEETCODE_SESSION={session_id}; csrftoken={csrf_token}"
        })
    transport = RequestsHTTPTransport(
        url=BASE_URL,
        use_json=True,
        headers=headers,
        verify=True
    )
    client = Client(
        transport=transport,
        fetch_schema_from_transport=True
    )
    return client