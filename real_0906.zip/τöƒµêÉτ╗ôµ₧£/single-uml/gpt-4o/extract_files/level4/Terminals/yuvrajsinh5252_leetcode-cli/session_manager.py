import os
import json
from typing import Optional, Dict

class SessionManager:
    def __init__(self):
        self.config_dir = os.path.join(os.path.expanduser("~"), ".leetcode-cli")
        self.config_file = os.path.join(self.config_dir, "session.json")
        self._ensure_config_dir()

    def _ensure_config_dir(self):
        if not os.path.exists(self.config_dir):
            os.makedirs(self.config_dir)

    def load_session(self) -> Optional[Dict[str, str]]:
        if os.path.exists(self.config_file):
            with open(self.config_file, "r") as file:
                return json.load(file)
        return None

    def save_session(self, csrftoken, session_token, user_name):
        session_data = {
            "csrftoken": csrftoken,
            "session_token": session_token,
            "user_name": user_name
        }
        with open(self.config_file, "w") as file:
            json.dump(session_data, file)

    def clear_session(self):
        if os.path.exists(self.config_file):
            os.remove(self.config_file)