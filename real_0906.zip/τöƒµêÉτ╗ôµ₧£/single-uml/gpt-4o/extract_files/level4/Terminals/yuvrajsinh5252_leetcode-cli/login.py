import requests
from src.server.auth import Auth
from src.server.session_manager import SessionManager
from src.server.config import BASE_URL

def login():
    session_manager = SessionManager()
    auth = Auth()
    
    csrf_token = input("Enter CSRF token: ")
    session_token = input("Enter session token: ")
    
    response = auth.login_with_session(csrf_token, session_token)
    
    if response.get("status") == "success":
        session_manager.save_session(csrf_token, session_token, response.get("username"))
        print("Login successful!")
    else:
        print("Login failed. Please check your tokens and try again.")

def logout():
    session_manager = SessionManager()
    session_manager.clear_session()
    print("Logout successful!")

if __name__ == "__main__":
    action = input("Enter 'login' to login or 'logout' to logout: ").strip().lower()
    if action == "login":
        login()
    elif action == "logout":
        logout()
    else:
        print("Invalid action. Please enter 'login' or 'logout'.")