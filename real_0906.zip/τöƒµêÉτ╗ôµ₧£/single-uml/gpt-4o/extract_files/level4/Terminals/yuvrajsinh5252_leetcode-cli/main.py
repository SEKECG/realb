import click
from src.commands.daily import daily
from src.commands.edit import edit
from src.commands.list_problems import list_problems
from src.commands.login import login, logout
from src.commands.profile import profile
from src.commands.show import show
from src.commands.solution import solutions
from src.commands.submit import submit
from src.commands.test import test
from src.lib.welcome import display_welcome

@click.group()
def app():
    """LeetCode CLI - A command-line tool for LeetCode problems."""
    pass

@app.command()
@click.pass_context
def callback(ctx):
    display_welcome(ctx)

app.add_command(daily, name="daily")
app.add_command(edit, name="edit")
app.add_command(list_problems, name="list")
app.add_command(login, name="login")
app.add_command(logout, name="logout")
app.add_command(profile, name="profile")
app.add_command(show, name="show")
app.add_command(solutions, name="solutions")
app.add_command(submit, name="submit")
app.add_command(test, name="test")

if __name__ == "__main__":
    app()