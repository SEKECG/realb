import datetime
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

console = Console()

def display_problem_list(data):
    table = Table(title="LeetCode Problems")
    table.add_column("ID", justify="right", style="cyan", no_wrap=True)
    table.add_column("Title", style="magenta")
    table.add_column("Difficulty", justify="right", style="green")
    table.add_column("Status", justify="right", style="yellow")
    table.add_column("Acceptance Rate", justify="right", style="blue")

    for problem in data:
        table.add_row(
            str(problem["id"]),
            problem["title"],
            problem["difficulty"],
            problem["status"],
            f"{problem['acceptance_rate']}%"
        )

    console.print(table)

def display_user_stats(data):
    profile_info = f"[bold]Username:[/bold] {data['username']}\n[bold]Ranking:[/bold] {data['ranking']}\n[bold]Solved Problems:[/bold] {data['solved_problems']}/{data['total_problems']}"
    console.print(Panel(profile_info, title="User Profile"))

    contest_stats = create_contest_stats(data['contest_info'])
    console.print(contest_stats)

    language_stats = create_language_stats(data['language_stats'])
    console.print(language_stats)

    progress_panel = create_progress_panel(data['progress'])
    console.print(progress_panel)

    recent_activity = create_recent_activity(data['recent_submissions'])
    console.print(recent_activity)

    skill_stats = create_skill_stats(data['skill_stats'])
    console.print(skill_stats)

    social_links = create_social_links(data['user'], data['websites'])
    console.print(social_links)

def create_contest_stats(contest_info):
    contest_stats = f"[bold]Rating:[/bold] {contest_info['rating']}\n[bold]Contests Attended:[/bold] {contest_info['contests_attended']}"
    return Panel(contest_stats, title="Contest Statistics")

def create_language_stats(data):
    language_stats = "[bold]Top 5 Languages:[/bold]\n"
    for lang in data[:5]:
        language_stats += f"{lang['language']}: {lang['problems_solved']} problems solved\n"
    return Panel(language_stats, title="Language Proficiency")

def create_progress_panel(data):
    progress = "[bold]Progress:[/bold]\n"
    for level in ["Easy", "Medium", "Hard"]:
        progress += f"{level}: {data[level]['solved']}/{data[level]['total']} solved\n"
    return Panel(progress, title="Progress Tracking")

def create_recent_activity(recent_submissions):
    table = Table(title="Recent Activity")
    table.add_column("Problem", style="magenta")
    table.add_column("Language", style="cyan")
    table.add_column("Timestamp", style="green")

    for submission in recent_submissions:
        table.add_row(
            submission["problem"],
            submission["language"],
            format_timestamp(submission["timestamp"])
        )

    return table

def create_skill_stats(data):
    table = Table(title="Skill Statistics")
    table.add_column("Skill Level", style="magenta")
    table.add_column("Tag", style="cyan")
    table.add_column("Problems Solved", style="green")

    for level in ["advanced", "intermediate", "fundamental"]:
        for skill in data[level]:
            table.add_row(
                level.capitalize(),
                skill["tag"],
                str(skill["problems_solved"])
            )

    return table

def create_social_links(user, websites):
    links = f"[bold]GitHub:[/bold] {user['github']}\n[bold]LinkedIn:[/bold] {user['linkedin']}\n[bold]Twitter:[/bold] {user['twitter']}\n"
    for site in websites:
        links += f"[bold]Website:[/bold] {site}\n"
    return Panel(links, title="Social Links")

def format_timestamp(timestamp):
    return datetime.datetime.fromtimestamp(timestamp).strftime("%Y-%m-%d %H:%M")