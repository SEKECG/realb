import os
from typing import Any, List, Tuple

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

console = Console()

def create_submission_progress():
    console.print("Creating submission progress context...")

def display_auth_error():
    console.print("[bold red]Error: Not authenticated.[/bold red]")

def display_exception_error(e):
    console.print(f"[bold red]Exception: {e}[/bold red]")

def display_file_not_found_error(file):
    console.print(f"[bold red]Error: File '{file}' not found.[/bold red]")

def display_language_detection_error(extension):
    console.print(f"[bold red]Error: Cannot detect language from extension '{extension}'[/bold red]")

def display_language_detection_message(lang):
    console.print(f"[bold green]Language auto-detected: {lang}[/bold green]")

def display_problem_not_found_error(problem):
    console.print(f"[bold red]Error: Problem '{problem}' not found.[/bold red]")

def display_submission_canceled():
    console.print("[bold yellow]Submission canceled.[/bold yellow]")

def display_submission_details(problem, problem_name, lang, file):
    console.print(f"[bold green]Submitting solution for problem '{problem_name}' ({problem})[/bold green]")
    console.print(f"Language: {lang}")
    console.print(f"File: {file}")

def display_submission_results(result, is_test):
    status, run_success = _determine_status(result, is_test)
    status_style = _get_status_styling(status, result["status_code"], run_success, is_test, result)
    content_parts = _build_content_parts(result, status, run_success, status_style)
    console.print(Panel("\n".join(content_parts), title="Submission Results"))

def _build_content_parts(result, status, run_success, status_style):
    parts = [
        f"[{status_style}]Status: {status}[/]",
        f"Runtime: {result['runtime']} ms",
        f"Memory: {result['memory']} MB",
    ]
    if not run_success:
        _display_error_details(result, status, result["status_code"])
    else:
        _display_output_comparison(result, status, run_success)
        _display_stdout(result)
    return parts

def _determine_status(result, is_test):
    if is_test:
        status = result["status"]
        run_success = status == "Accepted"
    else:
        status = result["status"]
        run_success = status == "Accepted"
    return status, run_success

def _display_error_details(result, status, status_code):
    if status_code in ["Compile Error", "Runtime Error"]:
        console.print(f"[bold red]Error Details: {result['error_message']}[/bold red]")

def _display_general_error(result, run_success, status):
    if not run_success:
        console.print(f"[bold red]General Error: {result['error_message']}[/bold red]")

def _display_memory_warning(result):
    if result["memory"] > 450:
        console.print("[bold yellow]Warning: Memory usage is high.[/bold yellow]")

def _display_output_comparison(result, status, run_success):
    if run_success and "expected_output" in result:
        console.print(f"Expected Output: {result['expected_output']}")
        console.print(f"Your Output: {result['your_output']}")

def _display_stdout(result):
    if "stdout" in result:
        console.print(f"Standard Output: {result['stdout']}")

def _format_test_case_stats(result):
    return f"Test Cases Passed: {result['passed_test_cases']} / {result['total_test_cases']}"

def _get_status_styling(status, status_code, run_success, is_test, result):
    if run_success:
        return "bold green"
    elif status_code in ["Compile Error", "Runtime Error"]:
        return "bold red"
    else:
        return "bold yellow"