import os
import subprocess
from src.server.api import create_leetcode_client
from src.server.solution_manager import SolutionManager
from src.server.session_manager import SessionManager
from src.server.config import LANGUAGE_MAP
from src.lib.submission_ui import display_submission_results, display_file_not_found_error, display_language_detection_error, display_problem_not_found_error, display_exception_error

def test(problem, file):
    try:
        # Check if file exists
        if not os.path.isfile(file):
            display_file_not_found_error(file)
            return

        # Detect language from file extension
        _, ext = os.path.splitext(file)
        lang = LANGUAGE_MAP.get(ext)
        if not lang:
            display_language_detection_error(ext)
            return

        # Load session
        session_manager = SessionManager()
        session_data = session_manager.load_session()
        if not session_data:
            display_problem_not_found_error(problem)
            return

        # Create LeetCode client
        client = create_leetcode_client(session_data['csrftoken'], session_data['session_token'])

        # Initialize SolutionManager
        solution_manager = SolutionManager(client)

        # Read code from file
        with open(file, 'r') as f:
            code = f.read()

        # Test solution
        result = solution_manager.test_solution(problem, code, lang)
        display_submission_results(result, is_test=True)

    except Exception as e:
        display_exception_error(e)

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Test a solution with LeetCode's test cases")
    parser.add_argument("problem", help="Problem identifier (slug or number)")
    parser.add_argument("file", help="Path to the solution file")
    args = parser.parse_args()

    test(args.problem, args.file)