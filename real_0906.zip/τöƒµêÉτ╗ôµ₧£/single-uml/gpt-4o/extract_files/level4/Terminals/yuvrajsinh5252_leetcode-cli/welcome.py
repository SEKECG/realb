# src/lib/welcome.py

from rich.console import Console

console = Console()

def get_leetcode_ascii():
    return """
     _      _        _   _____          _ _       
    | |    | |      | | |  __ \        | (_)      
    | | ___| |_ __ _| | | |  | | ___  _| |_ _ __  
    | |/ _ \ __/ _` | | | |  | |/ _ \| | | | '_ \ 
    | |  __/ || (_| | | | |__| | (_) | | | | | | |
    |_|\___|\__\__,_|_| |_____/ \___/|_|_|_|_| |_|
    """

def display_welcome(app):
    console.print(get_leetcode_ascii(), style="bold yellow")
    console.print("\nWelcome to LeetCode CLI Tool!\n", style="bold green")
    console.print("Available commands:", style="bold blue")
    console.print("  daily    - Work on today's LeetCode challenge")
    console.print("  list     - Browse available problems with filters")
    console.print("  show     - View problem details")
    console.print("  edit     - Open problem in editor with templates")
    console.print("  test     - Run test cases against solution")
    console.print("  submit   - Submit solution to LeetCode")
    console.print("  solutions- View community solutions")
    console.print("  profile  - View user statistics")
    console.print("  login    - Manage authentication")
    console.print("  logout   - Manage authentication")