import os
import subprocess
from server.api import get_daily_question
from server.auth import Auth
from server.solution_manager import SolutionManager
from server.config import LANGUAGE_MAP

def edit(problem, lang, editor):
    """
    Solves a problem by passing lang param and open it with your code editor.
    """
    auth = Auth()
    if not auth.is_authenticated:
        print("Please login first.")
        return

    solution_manager = SolutionManager(auth.get_session())
    question_data = solution_manager.get_question_data(problem)

    if not question_data:
        print(f"Problem '{problem}' not found.")
        return

    title_slug = question_data['titleSlug']
    code_template = solution_manager.get_code_template(title_slug, lang)

    file_name = f"{title_slug}.{LANGUAGE_MAP[lang]}"
    with open(file_name, 'w') as file:
        file.write(code_template)

    if editor == 'vim':
        subprocess.run(['vim', file_name])
    elif editor == 'code':
        subprocess.run(['code', file_name])
    elif editor == 'nano':
        subprocess.run(['nano', file_name])
    else:
        print(f"Editor '{editor}' not supported.")

    print(f"Opened {file_name} in {editor}.")