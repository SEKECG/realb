```python
# src/commands/solution.py

from src.server.solution_manager import SolutionManager
from src.lib.solution_ui import SolutionUI
from src.server.auth import Auth

def solutions(problem, best=False):
    auth = Auth()
    if not auth.is_authenticated:
        print("Please login first.")
        return

    session = auth.get_session()
    solution_manager = SolutionManager(session)
    fetched_solution = solution_manager.get_problem_solutions(problem, best)
    
    if not fetched_solution:
        print(f"No solutions found for problem: {problem}")
        return
    
    solution_ui = SolutionUI(fetched_solution)
    solution_ui.show_solution()

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Fetch solution for a problem")
    parser.add_argument("problem", type=str, help="Problem identifier (title slug or question number)")
    parser.add_argument("--best", action="store_true", help="Fetch the best solution")
    
    args = parser.parse_args()
    solutions(args.problem, args.best)
```