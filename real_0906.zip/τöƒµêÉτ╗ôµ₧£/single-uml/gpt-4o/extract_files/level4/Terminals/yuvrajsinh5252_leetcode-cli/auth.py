import requests
from typing import Dict, Any
from .session_manager import SessionManager

class Auth:
    BASE_URL = "https://leetcode.com"
    
    def __init__(self):
        self.is_authenticated = False
        self.session = requests.Session()
        self.session_manager = SessionManager()
        self._load_saved_session()

    def _load_saved_session(self):
        session_data = self.session_manager.load_session()
        if session_data:
            csrf_token = session_data.get("csrf_token")
            leetcode_session = session_data.get("session_token")
            if csrf_token and leetcode_session:
                self.login_with_session(csrf_token, leetcode_session)

    def get_session(self) -> requests.Session:
        return self.session

    def login_with_session(self, csrf_token: str, leetcode_session: str) -> Dict[str, Any]:
        self.session.cookies.set("csrftoken", csrf_token)
        self.session.cookies.set("LEETCODE_SESSION", leetcode_session)
        response = self.verify_csrf_token(csrf_token)
        if response.get("valid"):
            self.is_authenticated = True
            self.session_manager.save_session(csrf_token, leetcode_session, response.get("username"))
        return response

    def verify_csrf_token(self, csrf_token: str) -> Dict[str, Any]:
        headers = {
            "x-csrftoken": csrf_token,
            "referer": self.BASE_URL,
        }
        response = self.session.post(f"{self.BASE_URL}/graphql", headers=headers)
        if response.status_code == 200:
            return {"valid": True, "username": response.json().get("data", {}).get("user", {}).get("username")}
        return {"valid": False}