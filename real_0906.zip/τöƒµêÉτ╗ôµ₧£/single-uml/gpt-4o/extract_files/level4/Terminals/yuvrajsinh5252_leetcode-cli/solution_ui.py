import webbrowser
from rich.console import Console
from rich.table import Table

console = Console()

class SolutionUI:
    COLUMNS = ["Title", "Author", "Date", "Upvotes", "Tags"]
    COLUMN_WIDTHS = [30, 20, 15, 10, 30]
    LEETCODE_BASE_URL = "https://leetcode.com"
    MAX_TAGS = 5
    STYLES = {
        "title": "bold cyan",
        "author": "magenta",
        "date": "green",
        "upvotes": "yellow",
        "tags": "blue",
    }

    def __init__(self, fetched_solution):
        self.total_solutions = len(fetched_solution)
        self.solutions = fetched_solution

    def _format_author(self, author_data):
        return f"[{self.STYLES['author']}]{author_data}[/]"

    def _format_date(self, date_str):
        return f"[{self.STYLES['date']}]{date_str}[/]"

    def _format_number(self, number):
        return f"[{self.STYLES['upvotes']}]{number}[/]"

    def _format_reactions(self, reactions):
        return f"[{self.STYLES['upvotes']}]{reactions}[/]"

    def _format_tags(self, tags):
        formatted_tags = ", ".join(tags[:self.MAX_TAGS])
        return f"[{self.STYLES['tags']}]{formatted_tags}[/]"

    def _open_solution_url(self, solution_node):
        webbrowser.open(f"{self.LEETCODE_BASE_URL}{solution_node}")

    def _truncate_text(self, text, max_length):
        if len(text) > max_length:
            return text[:max_length] + "..."
        return text

    def handle_solution_selection(self, index):
        if 1 <= index <= self.total_solutions:
            solution_node = self.solutions[index - 1]["node"]
            self._open_solution_url(solution_node)
        else:
            console.print(f"Invalid selection: {index}", style="bold red")

    def show_solution(self):
        table = Table(show_header=True, header_style="bold magenta")
        for col, width in zip(self.COLUMNS, self.COLUMN_WIDTHS):
            table.add_column(col, width=width)

        for solution in self.solutions:
            node = solution["node"]
            title = self._truncate_text(node["title"], self.COLUMN_WIDTHS[0])
            author = self._format_author(node["author"]["username"])
            date = self._format_date(node["createdAt"])
            upvotes = self._format_number(node["upvoteCount"])
            tags = self._format_tags(node["tags"])

            table.add_row(title, author, date, upvotes, tags)

        console.print(table)