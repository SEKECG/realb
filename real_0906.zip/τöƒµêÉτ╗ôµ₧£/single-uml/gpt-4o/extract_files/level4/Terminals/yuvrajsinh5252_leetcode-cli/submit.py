import os
import sys
import json
import requests
from src.server.auth import Auth
from src.server.solution_manager import SolutionManager
from src.server.config import LANGUAGE_MAP
from src.lib.submission_ui import (
    display_auth_error,
    display_exception_error,
    display_file_not_found_error,
    display_language_detection_error,
    display_language_detection_message,
    display_problem_not_found_error,
    display_submission_canceled,
    display_submission_details,
    display_submission_results,
    create_submission_progress,
)

def submit(problem, file, lang=None, force=False):
    try:
        auth = Auth()
        if not auth.is_authenticated:
            display_auth_error()
            return

        if not os.path.exists(file):
            display_file_not_found_error(file)
            return

        if lang is None:
            extension = os.path.splitext(file)[1][1:]
            lang = LANGUAGE_MAP.get(extension)
            if lang is None:
                display_language_detection_error(extension)
                return
            display_language_detection_message(lang)

        with open(file, 'r') as f:
            code = f.read()

        solution_manager = SolutionManager(auth.get_session())
        problem_data = solution_manager.get_question_data(problem)
        if not problem_data:
            display_problem_not_found_error(problem)
            return

        display_submission_details(problem, problem_data['title'], lang, file)

        if not force:
            confirmation = input("Do you want to submit the solution? [y/N]: ")
            if confirmation.lower() != 'y':
                display_submission_canceled()
                return

        with create_submission_progress():
            result = solution_manager.submit_solution(problem_data['titleSlug'], code, lang)
            display_submission_results(result, is_test=False)

    except Exception as e:
        display_exception_error(e)

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Submit a solution to LeetCode")
    parser.add_argument("problem", help="Problem identifier (title slug or problem number)")
    parser.add_argument("file", help="Path to the solution file")
    parser.add_argument("--lang", help="Programming language (optional)")
    parser.add_argument("--force", action="store_true", help="Force submission without confirmation")

    args = parser.parse_args()
    submit(args.problem, args.file, args.lang, args.force)