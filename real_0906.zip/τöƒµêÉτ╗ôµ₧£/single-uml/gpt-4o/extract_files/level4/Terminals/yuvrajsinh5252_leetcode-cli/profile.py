# profile.py

import requests
from rich.console import Console
from src.server.api import fetch_user_profile
from src.server.auth import Auth

console = Console()

def profile():
    auth = Auth()
    if not auth.is_authenticated:
        console.print("[red]You are not logged in. Please login first.[/red]")
        return

    session = auth.get_session()
    user_profile = fetch_user_profile(session)

    if user_profile:
        console.print("[bold green]User Profile:[/bold green]")
        console.print(f"Username: {user_profile['username']}")
        console.print(f"Total Problems Solved: {user_profile['total_solved']}")
        console.print(f"Ranking: {user_profile['ranking']}")
        console.print(f"Contest Rating: {user_profile['contest_rating']}")
        console.print(f"Language Proficiency: {user_profile['language_proficiency']}")
        console.print(f"Recent Submissions: {user_profile['recent_submissions']}")
    else:
        console.print("[red]Failed to fetch user profile.[/red]")

if __name__ == "__main__":
    profile()