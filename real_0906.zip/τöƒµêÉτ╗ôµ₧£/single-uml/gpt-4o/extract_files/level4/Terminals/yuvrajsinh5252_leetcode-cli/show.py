import os
import json
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table
from server.api import fetch_problem_list, get_daily_question
from server.auth import Auth
from server.session_manager import SessionManager
from server.solution_manager import SolutionManager
from lib.problem_ui import ProblemDetails

console = Console()

def show(problem, save=None, compact=None):
    """
    Show problem details including description and test cases

    Fetches and displays the problem statement, examples, and metadata.
    Use --compact for a condensed view or --save to export to a file.
    """
    session_manager = SessionManager()
    session_data = session_manager.load_session()
    if not session_data:
        console.print("[red]Error: Not authenticated. Please login first.[/red]")
        return

    auth = Auth()
    auth.login_with_session(session_data['csrf_token'], session_data['session_token'])
    solution_manager = SolutionManager(auth.get_session())

    question_data = solution_manager.get_question_data(problem)
    if not question_data:
        console.print(f"[red]Error: Problem '{problem}' not found.[/red]")
        return

    problem_details = ProblemDetails(question_data)
    problem_details.display_problem()

    if save:
        _save_problem_to_file(question_data)

def _save_problem_to_file(question_data):
    """
    Save the problem statement to a markdown file
    """
    problem_title = question_data['title']
    file_name = f"{problem_title.replace(' ', '_')}.md"
    with open(file_name, 'w') as file:
        file.write(f"# {problem_title}\n\n")
        file.write(question_data['content'])
    console.print(f"[green]Problem saved to {file_name}[/green]")