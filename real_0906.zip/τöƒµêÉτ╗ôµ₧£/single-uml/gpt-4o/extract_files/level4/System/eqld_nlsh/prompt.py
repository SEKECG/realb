import os
from pathlib import Path
from typing import List, Dict, Optional

class PromptBuilder:
    BASE_SYSTEM_PROMPT = "Base system prompt"
    EXPLANATION_SYSTEM_PROMPT = "Explanation system prompt"
    FIXING_SYSTEM_PROMPT = "Fixing system prompt"
    GIT_COMMIT_SYSTEM_PROMPT = "Git commit system prompt"

    def __init__(self, config):
        self.config = config
        self.shell = config.get_shell()

    def _gather_tools_context(self, tools):
        context = []
        for tool in tools:
            try:
                context.append(tool.get_context())
            except Exception as e:
                context.append(f"Error gathering context from {tool.name}: {str(e)}")
        return "\n".join(context)

    def build_explanation_system_prompt(self, tools):
        context = self._gather_tools_context(tools)
        return f"{self.EXPLANATION_SYSTEM_PROMPT}\n{context}"

    def build_fixing_system_prompt(self, tools):
        context = self._gather_tools_context(tools)
        return f"{self.FIXING_SYSTEM_PROMPT}\n{context}"

    def build_fixing_user_prompt(self, prompt, failed_command, failed_command_exit_code, failed_command_output):
        return (f"Original prompt: {prompt}\n"
                f"Failed command: {failed_command}\n"
                f"Exit code: {failed_command_exit_code}\n"
                f"Output: {failed_command_output}")

    def build_git_commit_system_prompt(self, declined_messages):
        declined = "\n".join(declined_messages)
        return f"{self.GIT_COMMIT_SYSTEM_PROMPT}\nDeclined messages:\n{declined}"

    def build_git_commit_user_prompt(self, git_diff, changed_files_content):
        files_content = "\n".join(f"{file}: {content}" for file, content in changed_files_content.items())
        return f"Git diff:\n{git_diff}\nChanged files content:\n{files_content}"

    def build_system_prompt(self, tools, declined_commands):
        context = self._gather_tools_context(tools)
        declined = "\n".join(declined_commands)
        return f"{self.BASE_SYSTEM_PROMPT}\n{context}\nDeclined commands:\n{declined}"

    def load_prompt_from_file(self, file_path):
        with open(file_path, 'r') as file:
            return file.read()