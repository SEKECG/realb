import argparse
import subprocess
import os
import json
from pathlib import Path
from typing import Optional, Union, List, Dict

from nlsh.config import Config
from nlsh.prompt import PromptBuilder
from nlsh.backends import BackendManager
from nlsh.cli import confirm_execution
from nlsh.editor import edit_text_in_editor

FILE_CONTENT_HEADER = "### File Content ###"
GIT_COMMIT_MESSAGE_MAX_TOKENS = 512

class ContextLengthExceededError(Exception):
    pass

class EmptyCommitMessageError(Exception):
    pass

class GitCommandError(Exception):
    pass

class NlgcError(Exception):
    pass

def _generate_and_confirm_message(config, args, git_diff, changed_files_content, declined_messages):
    backend_index = args.backend_index if args.backend_index is not None else 0
    verbose = _get_verbose_level(args)
    log_file = args.log_file if args.log_file else None

    try:
        message = generate_commit_message(
            config=config,
            backend_index=backend_index,
            git_diff=git_diff,
            changed_files_content=changed_files_content,
            declined_messages=declined_messages,
            verbose=verbose,
            log_file=log_file
        )
    except (ContextLengthExceededError, EmptyCommitMessageError, NlgcError) as e:
        print(f"Error generating commit message: {e}")
        return False, 1

    confirmation = confirm_commit(message)
    if confirmation == "edit":
        edited_message = edit_text_in_editor(message, ".txt")
        if edited_message:
            message = edited_message
        else:
            return False, 1
    elif confirmation == "regenerate":
        declined_messages.append(message)
        return _generate_and_confirm_message(config, args, git_diff, changed_files_content, declined_messages)
    elif confirmation == "explain":
        print("Explanation requested but not implemented.")
        return False, 1
    elif not confirmation:
        return False, 1

    exit_code = run_git_commit(message)
    return True, exit_code

def _get_git_root():
    try:
        git_root = subprocess.check_output(["git", "rev-parse", "--show-toplevel"]).strip().decode()
        return git_root
    except subprocess.CalledProcessError:
        raise RuntimeError("Not a git repository")

def _get_verbose_level(args):
    return args.verbose.count("-v") + args.verbose.count("--verbose")

def _main(config, args):
    include_full_files = args.include_full_files
    git_diff, changed_files_content = _prepare_git_data(args, include_full_files)
    declined_messages = []
    success, exit_code = _generate_and_confirm_message(config, args, git_diff, changed_files_content, declined_messages)
    return exit_code

def _prepare_git_data(args, include_full_files):
    staged = args.staged
    git_diff = get_git_diff(staged)
    changed_files = get_changed_files(staged)
    git_root = _get_git_root()

    changed_files_content = {}
    if include_full_files:
        for file_path in changed_files:
            content = read_file_content(file_path, git_root)
            if content:
                changed_files_content[file_path] = content

    if not git_diff and not changed_files_content:
        raise RuntimeError("No changes to commit")

    return git_diff, changed_files_content

def confirm_commit(message):
    print(f"Generated commit message:\n{message}")
    response = input("Do you want to commit this message? (yes/edit/regenerate/explain/no): ").strip().lower()
    if response == "yes":
        return True
    elif response == "edit":
        return "edit"
    elif response == "regenerate":
        return "regenerate"
    elif response == "explain":
        return "explain"
    else:
        return False

def generate_commit_message(config, backend_index, git_diff, changed_files_content, declined_messages, verbose, log_file):
    backend_manager = BackendManager(config)
    backend = backend_manager.get_backend(backend_index)
    prompt_builder = PromptBuilder(config)

    system_prompt = prompt_builder.build_git_commit_system_prompt(declined_messages)
    user_prompt = prompt_builder.build_git_commit_user_prompt(git_diff, changed_files_content)

    response = backend.generate_response(
        prompt=user_prompt,
        system_context=system_prompt,
        verbose=verbose,
        strip_markdown=True,
        max_tokens=GIT_COMMIT_MESSAGE_MAX_TOKENS,
        regeneration_count=len(declined_messages)
    )

    if not response:
        raise EmptyCommitMessageError("Generated commit message is empty")

    return response

def get_changed_files(staged):
    try:
        if staged:
            output = subprocess.check_output(["git", "diff", "--name-only", "--cached"]).strip().decode()
        else:
            output = subprocess.check_output(["git", "diff", "--name-only"]).strip().decode()
        return output.splitlines()
    except subprocess.CalledProcessError:
        raise RuntimeError("Failed to get changed files")

def get_git_diff(staged):
    try:
        if staged:
            output = subprocess.check_output(["git", "diff", "--cached"]).strip().decode()
        else:
            output = subprocess.check_output(["git", "diff"]).strip().decode()
        return output
    except subprocess.CalledProcessError:
        raise RuntimeError("Failed to get git diff")

def main():
    parser = argparse.ArgumentParser(description="Generate git commit messages using LLM")
    parser.add_argument("--backend-index", type=int, help="Backend index to use")
    parser.add_argument("--include-full-files", action="store_true", help="Include full file contents in the prompt")
    parser.add_argument("--staged", action="store_true", help="Use staged changes")
    parser.add_argument("--verbose", action="store_true", help="Enable verbose mode")
    parser.add_argument("--log-file", type=str, help="Path to log file")
    args = parser.parse_args()

    config = Config()
    exit_code = _main(config, args)
    exit(exit_code)

def parse_args(args):
    parser = argparse.ArgumentParser(description="Parse command-line arguments for nlgc")
    parser.add_argument("--backend-index", type=int, help="Backend index to use")
    parser.add_argument("--include-full-files", action="store_true", help="Include full file contents in the prompt")
    parser.add_argument("--staged", action="store_true", help="Use staged changes")
    parser.add_argument("--verbose", action="store_true", help="Enable verbose mode")
    parser.add_argument("--log-file", type=str, help="Path to log file")
    return parser.parse_args(args)

def read_file_content(file_path, git_root):
    try:
        with open(os.path.join(git_root, file_path), "r") as file:
            return file.read()
    except Exception:
        return None

def run_git_commit(message):
    try:
        subprocess.check_call(["git", "commit", "-m", message])
        return 0
    except subprocess.CalledProcessError as e:
        print(f"Failed to commit: {e}")
        return e.returncode