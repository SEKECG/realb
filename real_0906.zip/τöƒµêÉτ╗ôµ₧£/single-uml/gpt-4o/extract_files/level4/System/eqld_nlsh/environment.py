import os
import re

class EnvInspector:
    IMPORTANT_ENV_VARS = ["PATH", "HOME", "SHELL"]
    SENSITIVE_ENV_PATTERNS = [re.compile(r".*SECRET.*"), re.compile(r".*PASSWORD.*")]

    def get_context(self):
        env_vars = {key: value for key, value in os.environ.items() if key in self.IMPORTANT_ENV_VARS}
        sensitive_vars = {key: value for key, value in os.environ.items() if any(pattern.match(key) for pattern in self.SENSITIVE_ENV_PATTERNS)}
        
        context = "Environment Variables:\n"
        for key, value in env_vars.items():
            context += f"{key}: {value}\n"
        
        context += "\nSensitive Environment Variables:\n"
        for key, value in sensitive_vars.items():
            context += f"{key}: {value}\n"
        
        return context