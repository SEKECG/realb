import os
import tempfile
import subprocess

def edit_text_in_editor(initial_text, suffix):
    """
    Opens the default editor to edit the given text.

    Args:
        initial_text: The text to be edited.
        suffix: The file suffix to use for the temporary file (e.g., ".sh", ".txt").

    Returns:
        The edited text as a string if the user saves changes, 
        or None if the edit is cancelled, the resulting text is empty,
        or an error occurs during editing.
    """
    editor = os.getenv('EDITOR', 'nano')
    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmpfile:
        tmpfile.write(initial_text.encode('utf-8'))
        tmpfile.flush()
        tmpfile_path = tmpfile.name

    try:
        subprocess.call([editor, tmpfile_path])
        with open(tmpfile_path, 'r', encoding='utf-8') as tmpfile:
            edited_text = tmpfile.read()
        if edited_text.strip():
            return edited_text
    except Exception as e:
        print(f"An error occurred while editing the text: {e}")
    finally:
        os.remove(tmpfile_path)
    return None