import re

class BackendManager:
    def __init__(self, config):
        self.backends = []
        self.config = config

    def get_backend(self, index=None):
        if index is None:
            index = self.config.get('default_backend', 0)
        backend_config = self.config.get_backend(index)
        return LLMBackend(backend_config)


class LLMBackend:
    def __init__(self, config):
        self.api_key = config.get('api_key')
        self.client = None
        self.config = config
        self.is_reasoning_model = config.get('is_reasoning_model', False)
        self.model = config.get('model')
        self.name = config.get('name')
        self.timeout = config.get('timeout', 30)
        self.url = config.get('url')

    def _calculate_temperature(self, regeneration_count):
        base_temperature = 0.2
        increment = 0.1
        max_temperature = 1.0
        temperature = base_temperature + (increment * regeneration_count)
        return min(temperature, max_temperature)

    def _generate_non_streaming_response(self, messages, temperature, max_tokens, strip_markdown):
        response = "Generated response without streaming"
        if strip_markdown:
            response = strip_markdown_code_blocks(response)
        return response

    def _generate_streaming_response(self, messages, temperature, max_tokens, strip_markdown):
        response = "Generated response with streaming"
        if strip_markdown:
            response = strip_markdown_code_blocks(response)
        return response

    def generate_response(self, prompt, system_context, verbose, strip_markdown, max_tokens, regeneration_count):
        temperature = self._calculate_temperature(regeneration_count)
        if self.is_reasoning_model:
            response = self._generate_streaming_response(
                [{"role": "system", "content": system_context}, {"role": "user", "content": prompt}],
                temperature,
                max_tokens,
                strip_markdown
            )
        else:
            response = self._generate_non_streaming_response(
                [{"role": "system", "content": system_context}, {"role": "user", "content": prompt}],
                temperature,
                max_tokens,
                strip_markdown
            )
        return response


def strip_markdown_code_blocks(text):
    text = re.sub(r'```.*?\n(.*?)\n```', r'\1', text, flags=re.DOTALL)
    text = re.sub(r'`([^`]*)`', r'\1', text)
    return text