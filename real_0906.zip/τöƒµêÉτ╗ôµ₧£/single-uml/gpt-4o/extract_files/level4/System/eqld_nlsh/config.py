import os
import yaml
from pathlib import Path
from typing import Optional, Dict, Any

class ConfigValidationError(Exception):
    pass

class Config:
    DEFAULT_CONFIG = {
        'backends': [
            {
                'name': 'openai',
                'api_key': 'your-api-key',
                'url': 'https://api.openai.com/v1/engines/davinci-codex/completions',
                'timeout': 30,
                'is_reasoning_model': True
            }
        ],
        'shell': 'bash'
    }

    def __init__(self, config_path: Optional[str] = None):
        self.config_file_path = config_path
        self.config_file_found = False
        self.config = self.DEFAULT_CONFIG
        self._apply_env_overrides()
        self._load_config_file()

    def _apply_env_overrides(self):
        shell = os.getenv('NLSH_SHELL')
        if shell:
            self.config['shell'] = shell

    def _find_config_file(self, config_path: Optional[str] = None) -> Optional[Path]:
        if config_path:
            config_file = Path(config_path)
            if config_file.exists():
                return config_file
        default_path = self._get_default_config_path()
        if default_path.exists():
            return default_path
        return None

    def _get_default_config_path(self) -> Path:
        xdg_config_home = os.getenv('XDG_CONFIG_HOME')
        if xdg_config_home:
            return Path(xdg_config_home) / 'nlsh' / 'config.yaml'
        return Path.home() / '.config' / 'nlsh' / 'config.yaml'

    def _load_config_file(self):
        config_file = self._find_config_file(self.config_file_path)
        if config_file:
            self.config_file_found = True
            with open(config_file, 'r') as file:
                file_config = yaml.safe_load(file)
                self._update_config(self.config, file_config)
                self._validate_config(self.config)

    def _update_config(self, base_config: Dict[str, Any], new_config: Dict[str, Any]):
        for key, value in new_config.items():
            if isinstance(value, dict) and key in base_config:
                self._update_config(base_config[key], value)
            else:
                base_config[key] = value

    def _validate_config(self, config: Dict[str, Any]):
        if 'shell' not in config or config['shell'] not in ['bash', 'zsh', 'fish', 'powershell']:
            raise ConfigValidationError('Invalid shell configuration.')

    def create_default_config(self, config_path: Optional[str] = None) -> Path:
        config_file = Path(config_path) if config_path else self._get_default_config_path()
        config_file.parent.mkdir(parents=True, exist_ok=True)
        with open(config_file, 'w') as file:
            yaml.safe_dump(self.DEFAULT_CONFIG, file)
        return config_file

    def get_backend(self, index: Optional[int] = None) -> Optional[Dict[str, Any]]:
        if index is not None and index < len(self.config['backends']):
            return self.config['backends'][index]
        return self.config['backends'][0]

    def get_nlgc_config(self) -> Dict[str, Any]:
        return self.config.get('nlgc', self.DEFAULT_CONFIG.get('nlgc', {}))

    def get_shell(self) -> str:
        return self.config['shell']