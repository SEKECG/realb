import abc

class BaseTool(abc.ABC):
    def __init__(self, config):
        self.config = config
        self.name = self.__class__.__name__

    @abc.abstractmethod
    def get_context(self):
        pass

    @property
    def name(self):
        return self.__class__.__name__