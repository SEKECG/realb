import platform
import os

class SystemInfo:
    def get_context(self):
        os_info = platform.system()
        kernel_info = platform.release()
        architecture_info = platform.machine()
        return f"OS: {os_info}, Kernel: {kernel_info}, Architecture: {architecture_info}"

if __name__ == "__main__":
    system_info = SystemInfo()
    print(system_info.get_context())