import os
import shlex

class DirLister:
    def _format_file_info(self, entry):
        return {
            "name": entry.name,
            "size": self._format_size(entry.stat().st_size),
            "path": self._sanitize_path(entry.path)
        }

    def _format_size(self, size_bytes):
        if size_bytes == 0:
            return "0B"
        size_name = ("B", "KB", "MB", "GB", "TB")
        i = int(math.floor(math.log(size_bytes, 1024)))
        p = math.pow(1024, i)
        s = round(size_bytes / p, 2)
        return f"{s} {size_name[i]}"

    def _sanitize_path(self, path):
        return shlex.quote(path)

    def get_context(self):
        files = []
        with os.scandir() as it:
            for entry in it:
                if not entry.name.startswith('.') and entry.is_file():
                    files.append(self._format_file_info(entry))
        return files