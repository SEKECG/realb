# nlsh/__init__.py

__version__ = "1.0.0"

def get_tools(config):
    from .tools import base, directory, environment, system
    tools = [
        directory.DirLister(),
        environment.EnvInspector(),
        system.SystemInfo()
    ]
    return tools

def get_tool_class(tool_name):
    from .tools import base, directory, environment, system
    tool_classes = {
        "DirLister": directory.DirLister,
        "EnvInspector": environment.EnvInspector,
        "SystemInfo": system.SystemInfo
    }
    return tool_classes.get(tool_name)

AVAILABLE_TOOLS = ["DirLister", "EnvInspector", "SystemInfo"]