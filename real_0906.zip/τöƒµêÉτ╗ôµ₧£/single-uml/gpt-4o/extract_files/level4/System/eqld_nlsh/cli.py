import argparse
import signal
import sys
from typing import Union, Optional, List, Dict, Tuple

from nlsh.config import Config
from nlsh.backends import BackendManager
from nlsh.prompt import PromptBuilder
from nlsh.editor import edit_text_in_editor
from nlsh.spinner import Spinner
from nlsh.git_commit import GitCommandError, generate_commit_message, confirm_commit, run_git_commit

def _get_prompt(args, config):
    if args.prompt_file:
        with open(args.prompt_file, 'r') as file:
            return file.read()
    return args.prompt

def _handle_edit_command(command):
    edited_command = edit_text_in_editor(command, ".sh")
    if edited_command is None:
        return command, False
    return edited_command, True

def _handle_explain_command(config, args, command):
    backend_manager = BackendManager(config)
    backend = backend_manager.get_backend(args.backend_index)
    explanation = backend.generate_response(
        prompt=f"Explain the following command: {command}",
        system_context=config.get_shell(),
        verbose=args.verbose,
        strip_markdown=True,
        max_tokens=500,
        regeneration_count=0
    )
    print(explanation)
    return True

def _process_command_confirmation(config, args, command, declined_commands):
    confirmation = confirm_execution(command)
    if confirmation == "regenerate":
        return 1, True, {}
    elif confirmation == "explain":
        _handle_explain_command(config, args, command)
        return 0, True, {}
    elif confirmation == "edit":
        edited_command, should_continue = _handle_edit_command(command)
        if should_continue:
            return 0, True, {"edited_command": edited_command}
        return 0, False, {}
    elif confirmation:
        exit_code, output = execute_command(command)
        if exit_code != 0:
            return exit_code, False, {"failed_command": command, "failed_command_exit_code": exit_code, "failed_command_output": output}
        return exit_code, False, {}
    declined_commands.append(command)
    return 0, False, {}

def confirm_execution(command):
    response = input(f"Do you want to execute the following command? [y/n/regenerate/explain/edit]: {command}\n")
    if response.lower() in ["y", "yes"]:
        return True
    elif response.lower() in ["n", "no"]:
        return False
    return response.lower()

def confirm_fix(command, code):
    response = input(f"Do you want to fix the following command? [y/n]: {command}\nExit code: {code}\n")
    return response.lower() in ["y", "yes"]

def execute_command(command):
    try:
        result = subprocess.run(command, shell=True, check=True, capture_output=True, text=True)
        return result.returncode, result.stdout
    except subprocess.CalledProcessError as e:
        return e.returncode, e.output

def explain_command(config, backend_index, command, verbose, log_file):
    backend_manager = BackendManager(config)
    backend = backend_manager.get_backend(backend_index)
    explanation = backend.generate_response(
        prompt=f"Explain the following command: {command}",
        system_context=config.get_shell(),
        verbose=verbose,
        strip_markdown=True,
        max_tokens=500,
        regeneration_count=0
    )
    if log_file:
        log(log_file, backend, config.get_shell(), command, explanation)
    return explanation

def generate_command(config, backend_index, prompt, declined_commands, verbose, log_file):
    backend_manager = BackendManager(config)
    backend = backend_manager.get_backend(backend_index)
    system_prompt = PromptBuilder(config).build_system_prompt([], declined_commands)
    command = backend.generate_response(
        prompt=prompt,
        system_context=system_prompt,
        verbose=verbose,
        strip_markdown=True,
        max_tokens=500,
        regeneration_count=0
    )
    if log_file:
        log(log_file, backend, system_prompt, prompt, command)
    return command

def generate_command_fix(config, backend_index, prompt, failed_command, failed_command_exit_code, failed_command_output, verbose, log_file):
    backend_manager = BackendManager(config)
    backend = backend_manager.get_backend(backend_index)
    system_prompt = PromptBuilder(config).build_fixing_system_prompt([])
    user_prompt = PromptBuilder(config).build_fixing_user_prompt(prompt, failed_command, failed_command_exit_code, failed_command_output)
    fixed_command = backend.generate_response(
        prompt=user_prompt,
        system_context=system_prompt,
        verbose=verbose,
        strip_markdown=True,
        max_tokens=500,
        regeneration_count=0
    )
    if log_file:
        log(log_file, backend, system_prompt, user_prompt, fixed_command)
    return fixed_command

def handle_keyboard_interrupt(signum, frame):
    print("\nKeyboard interrupt received. Exiting...")
    sys.exit(0)

def log(log_file, backend, system_prompt, prompt, response):
    with open(log_file, 'a') as file:
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "backend": backend.name,
            "system_prompt": system_prompt,
            "prompt": prompt,
            "response": response
        }
        file.write(json.dumps(log_entry) + "\n")

def main():
    signal.signal(signal.SIGINT, handle_keyboard_interrupt)
    parser = argparse.ArgumentParser(description="Neural Shell Command Line Interface")
    parser.add_argument("--config", type=str, help="Path to configuration file")
    parser.add_argument("--backend-index", type=int, default=0, help="Backend index to use")
    parser.add_argument("--prompt", type=str, help="Prompt for command generation")
    parser.add_argument("--prompt-file", type=str, help="File containing prompt for command generation")
    parser.add_argument("--verbose", action="store_true", help="Enable verbose mode")
    parser.add_argument("--log-file", type=str, help="Path to log file")
    args = parser.parse_args()

    config = Config(args.config)
    declined_commands = []

    prompt = _get_prompt(args, config)
    command = generate_command(config, args.backend_index, prompt, declined_commands, args.verbose, args.log_file)

    while True:
        exit_code, should_continue, fix_info = _process_command_confirmation(config, args, command, declined_commands)
        if not should_continue:
            break
        if "edited_command" in fix_info:
            command = fix_info["edited_command"]
        elif "failed_command" in fix_info:
            if confirm_fix(fix_info["failed_command"], fix_info["failed_command_exit_code"]):
                command = generate_command_fix(
                    config, args.backend_index, prompt, fix_info["failed_command"],
                    fix_info["failed_command_exit_code"], fix_info["failed_command_output"],
                    args.verbose, args.log_file
                )
            else:
                break

    sys.exit(exit_code)

def parse_args(args):
    parser = argparse.ArgumentParser(description="Neural Shell Command Line Interface")
    parser.add_argument("--config", type=str, help="Path to configuration file")
    parser.add_argument("--backend-index", type=int, default=0, help="Backend index to use")
    parser.add_argument("--prompt", type=str, help="Prompt for command generation")
    parser.add_argument("--prompt-file", type=str, help="File containing prompt for command generation")
    parser.add_argument("--verbose", action="store_true", help="Enable verbose mode")
    parser.add_argument("--log-file", type=str, help="Path to log file")
    return parser.parse_args(args)

def safe_write(stream, text):
    try:
        stream.write(text)
    except UnicodeEncodeError:
        stream.write(text.encode("utf-8", errors="replace").decode("utf-8"))

if __name__ == "__main__":
    main()