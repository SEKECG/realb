import argparse
import signal
import sys
from nlsh.config import Config
from nlsh.backends import BackendManager
from nlsh.cli import main as cli_main
from nlsh.git_commit import main as git_commit_main

def main():
    parser = argparse.ArgumentParser(description="Neural Shell (nlsh) - AI-driven command-line assistant")
    parser.add_argument('--config', type=str, help='Path to configuration file')
    parser.add_argument('--git-commit', action='store_true', help='Generate a git commit message')
    args = parser.parse_args()

    config = Config(args.config)

    if args.git_commit:
        exit_code = git_commit_main(config, args)
    else:
        exit_code = cli_main(config, args)

    sys.exit(exit_code)

if __name__ == "__main__":
    signal.signal(signal.SIGINT, signal.SIG_DFL)
    main()