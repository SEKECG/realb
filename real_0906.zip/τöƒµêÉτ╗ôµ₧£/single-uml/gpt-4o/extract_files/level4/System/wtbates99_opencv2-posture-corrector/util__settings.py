import json
import os

# Constants
POSTURE_LANDMARKS = [
    "nose", "left_eye_inner", "left_eye", "left_eye_outer", "right_eye_inner",
    "right_eye", "right_eye_outer", "left_ear", "right_ear", "mouth_left",
    "mouth_right", "left_shoulder", "right_shoulder", "left_elbow", "right_elbow",
    "left_wrist", "right_wrist", "left_pinky", "right_pinky", "left_index",
    "right_index", "left_thumb", "right_thumb", "left_hip", "right_hip",
    "left_knee", "right_knee", "left_ankle", "right_ankle", "left_heel",
    "right_heel", "left_foot_index", "right_foot_index"
]

CUSTOMIZABLE_SETTINGS = {
    "camera_id": 0,
    "fps": 30,
    "frame_width": 640,
    "frame_height": 480,
    "min_detection_confidence": 0.5,
    "min_tracking_confidence": 0.5,
    "notification_cooldown": 60,
    "poor_posture_threshold": 50,
    "posture_message": "Please correct your posture!",
    "db_logging_enabled": True,
    "db_write_interval": 60
}

IMMUTABLE_SETTINGS = {
    "app_name": "OpenCV2 Posture Corrector",
    "version": "1.0.0",
    "author": "Your Name",
    "privacy_policy": "All processing is done locally—no data is ever stored or transmitted."
}

USER_SETTINGS_FILE = "user_settings.json"

def get_setting(key):
    if key in IMMUTABLE_SETTINGS:
        return IMMUTABLE_SETTINGS[key]
    elif key in CUSTOMIZABLE_SETTINGS:
        return CUSTOMIZABLE_SETTINGS[key]
    else:
        raise KeyError(f"Setting '{key}' not found.")

def save_user_settings():
    with open(USER_SETTINGS_FILE, 'w') as file:
        json.dump(CUSTOMIZABLE_SETTINGS, file, indent=4)

def load_user_settings():
    if os.path.exists(USER_SETTINGS_FILE):
        with open(USER_SETTINGS_FILE, 'r') as file:
            user_settings = json.load(file)
            CUSTOMIZABLE_SETTINGS.update(user_settings)

def update_setting(key, value):
    if key in CUSTOMIZABLE_SETTINGS:
        CUSTOMIZABLE_SETTINGS[key] = value
    else:
        raise KeyError(f"Setting '{key}' is not customizable.")

# Load user settings at startup
load_user_settings()