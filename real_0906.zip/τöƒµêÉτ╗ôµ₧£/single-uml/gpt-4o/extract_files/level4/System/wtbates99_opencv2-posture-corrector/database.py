import sqlite3
from datetime import datetime

class Database:
    def __init__(self, db_path):
        self.conn = sqlite3.connect(db_path)
        self.cursor = self.conn.cursor()
        self.posture_landmarks = [
            'nose', 'left_eye_inner', 'left_eye', 'left_eye_outer', 'right_eye_inner', 'right_eye', 'right_eye_outer',
            'left_ear', 'right_ear', 'mouth_left', 'mouth_right', 'left_shoulder', 'right_shoulder', 'left_elbow',
            'right_elbow', 'left_wrist', 'right_wrist', 'left_pinky', 'right_pinky', 'left_index', 'right_index',
            'left_thumb', 'right_thumb', 'left_hip', 'right_hip', 'left_knee', 'right_knee', 'left_ankle', 'right_ankle',
            'left_heel', 'right_heel', 'left_foot_index', 'right_foot_index'
        ]
        self._create_tables()

    def _create_tables(self):
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS posture_scores (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                score INTEGER NOT NULL
            )
        ''')
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS pose_landmarks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                ''' + ', '.join([f'{landmark} REAL' for landmark in self.posture_landmarks]) + '''
            )
        ''')
        self.conn.commit()

    def close(self):
        self.conn.close()

    def create_table(self, table_name, columns):
        columns_def = ', '.join([f'{col} {dtype}' for col, dtype in columns.items()])
        self.cursor.execute(f'''
            CREATE TABLE IF NOT EXISTS {table_name} (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                {columns_def}
            )
        ''')
        self.conn.commit()

    def insert(self, table_name, values):
        placeholders = ', '.join(['?' for _ in values[0]])
        self.cursor.executemany(f'''
            INSERT INTO {table_name} VALUES (NULL, {placeholders})
        ''', values)
        self.conn.commit()

    def save_pose_data(self, landmarks, score):
        timestamp = datetime.now().isoformat()
        self.cursor.execute('''
            INSERT INTO posture_scores (timestamp, score) VALUES (?, ?)
        ''', (timestamp, score))
        landmarks_values = [timestamp] + [landmarks.get(landmark, None) for landmark in self.posture_landmarks]
        self.cursor.execute(f'''
            INSERT INTO pose_landmarks (timestamp, {', '.join(self.posture_landmarks)}) VALUES ({', '.join(['?' for _ in landmarks_values])})
        ''', landmarks_values)
        self.conn.commit()