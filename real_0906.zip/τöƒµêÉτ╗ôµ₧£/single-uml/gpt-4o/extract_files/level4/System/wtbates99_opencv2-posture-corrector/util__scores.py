import time

class Scores:
    SCORE_THRESHOLD = 50
    WINDOW_SIZE = 10

    def __init__(self):
        self.buffer_size = self.WINDOW_SIZE
        self.current_index = 0
        self.is_buffer_full = False
        self.scores = [0] * self.buffer_size
        self.timestamps = [0] * self.buffer_size

    def add_score(self, score):
        self.scores[self.current_index] = score
        self.timestamps[self.current_index] = time.time()
        self.current_index += 1
        if self.current_index >= self.buffer_size:
            self.current_index = 0
            self.is_buffer_full = True

    def get_average_score(self):
        if not self.is_buffer_full and self.current_index == 0:
            return 0.0
        valid_scores = self.scores[:self.current_index] if not self.is_buffer_full else self.scores
        return sum(valid_scores) / len(valid_scores)