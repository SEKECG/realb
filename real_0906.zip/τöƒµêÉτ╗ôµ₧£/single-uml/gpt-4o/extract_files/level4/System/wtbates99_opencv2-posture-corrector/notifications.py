import time
from util__send_notification import send_notification

class Notifications:
    def __init__(self, icon_path):
        self.icon_path = icon_path
        self.interval_message = "Time to check your posture!"
        self.last_notification_time = 0
        self.notification_cooldown = 3600  # 1 hour cooldown
        self.poor_posture_threshold = 50
        self.posture_message = "Your posture needs improvement!"

    def check_and_notify(self, posture_score):
        current_time = time.time()
        if posture_score < self.poor_posture_threshold and (current_time - self.last_notification_time) > self.notification_cooldown:
            send_notification(self.posture_message, "Posture Alert", self.icon_path)
            self.last_notification_time = current_time

    def set_interval_message(self, message):
        self.interval_message = message
        send_notification(self.interval_message, "Interval Notification", self.icon_path)