import os
import platform
import subprocess

def send_notification(message, title, icon_path):
    if platform.system() == "Windows":
        import win10toast
        toaster = win10toast.ToastNotifier()
        toaster.show_toast(title, message, icon_path=icon_path, duration=10)
    elif platform.system() == "Darwin":
        os.system(f"osascript -e 'display notification \"{message}\" with title \"{title}\"'")
    elif platform.system() == "Linux":
        subprocess.run(["notify-send", title, message, "--icon", icon_path])