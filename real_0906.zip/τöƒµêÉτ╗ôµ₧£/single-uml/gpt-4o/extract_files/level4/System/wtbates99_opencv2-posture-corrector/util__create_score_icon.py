import cv2
import numpy as np

def create_score_icon(score):
    # Create a blank image
    icon_size = 100
    icon = np.zeros((icon_size, icon_size, 4), dtype=np.uint8)

    # Define the color based on the score
    if score >= 75:
        color = (0, 255, 0, 255)  # Green
    elif score >= 50:
        color = (255, 255, 0, 255)  # Yellow
    else:
        color = (255, 0, 0, 255)  # Red

    # Draw the circle
    cv2.circle(icon, (icon_size // 2, icon_size // 2), icon_size // 2, color, -1)

    # Put the score text in the center
    font = cv2.FONT_HERSHEY_SIMPLEX
    text = str(score)
    text_size = cv2.getTextSize(text, font, 1, 2)[0]
    text_x = (icon_size - text_size[0]) // 2
    text_y = (icon_size + text_size[1]) // 2
    cv2.putText(icon, text, (text_x, text_y), font, 1, (255, 255, 255, 255), 2)

    return icon