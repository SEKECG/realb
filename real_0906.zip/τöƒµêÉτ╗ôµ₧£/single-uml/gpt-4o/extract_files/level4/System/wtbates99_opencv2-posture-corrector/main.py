import os
import sys
import signal
import json
import time
from PyQt5.QtWidgets import QApplication, QSystemTrayIcon, QMenu, QAction
from PyQt5.QtGui import QIcon
from PyQt5.QtCore import QTimer

from database import Database
from notifications import Notifications
from pose_detector import PoseDetector
from settings_interface import SettingsInterface
from tray_interface import PostureTrackerTray
from util__settings import load_user_settings, save_user_settings, get_setting
from util__send_notification import send_notification
from webcam import Webcam

LOCK_FILE = "posture_tracker.lock"

def kill_existing_instance(lock_file):
    if os.path.exists(lock_file):
        with open(lock_file, 'r') as f:
            pid = int(f.read().strip())
            try:
                os.kill(pid, signal.SIGTERM)
            except OSError:
                pass

def main():
    kill_existing_instance(LOCK_FILE)
    with open(LOCK_FILE, 'w') as f:
        f.write(str(os.getpid()))

    app = QApplication(sys.argv)
    tray_icon = QSystemTrayIcon(QIcon("icon.png"), app)
    tray_menu = QMenu()

    posture_tracker = PostureTrackerTray(tray_icon, tray_menu)
    posture_tracker.initialize()

    tray_icon.setContextMenu(tray_menu)
    tray_icon.show()

    signal.signal(signal.SIGINT, posture_tracker.signal_handler)
    signal.signal(signal.SIGTERM, posture_tracker.signal_handler)

    sys.exit(app.exec_())

if __name__ == "__main__":
    main()