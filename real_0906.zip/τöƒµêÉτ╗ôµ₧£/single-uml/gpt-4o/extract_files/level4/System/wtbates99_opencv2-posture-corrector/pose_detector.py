import cv2
import numpy as np
import mediapipe as mp
from util__settings import get_setting

class PoseDetector:
    def __init__(self, min_detection_confidence=None, min_tracking_confidence=None, frame_width=None, frame_height=None):
        self.frame_width = frame_width or get_setting('frame_width')
        self.frame_height = frame_height or get_setting('frame_height')
        self.ideal_neck_vector = np.array([0, -1])
        self.ideal_spine_vector = np.array([0, -1])
        self.mp_draw = mp.solutions.drawing_utils
        self.mp_pose = mp.solutions.pose
        self.pose = self.mp_pose.Pose(min_detection_confidence=min_detection_confidence or get_setting('min_detection_confidence'),
                                      min_tracking_confidence=min_tracking_confidence or get_setting('min_tracking_confidence'))
        self.posture_landmarks = get_setting('POSTURE_LANDMARKS')
        self.score_thresholds = get_setting('score_thresholds')
        self.weights = get_setting('weights')

    def _calculate_posture_score(self, landmarks):
        neck_vector = landmarks[self.posture_landmarks['neck']] - landmarks[self.posture_landmarks['shoulders']]
        spine_vector = landmarks[self.posture_landmarks['spine_base']] - landmarks[self.posture_landmarks['spine_mid']]
        neck_angle = self.angle_between(neck_vector, self.ideal_neck_vector)
        spine_angle = self.angle_between(spine_vector, self.ideal_spine_vector)
        score = 100 - (self.weights['neck'] * neck_angle + self.weights['spine'] * spine_angle)
        return max(0, min(100, score))

    def _detect_pose(self, frame):
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = self.pose.process(frame_rgb)
        return results

    def _draw_landmarks(self, frame, results):
        if results.pose_landmarks:
            self.mp_draw.draw_landmarks(frame, results.pose_landmarks, self.mp_pose.POSE_CONNECTIONS)

    def _draw_posture_feedback(self, frame, score):
        color = (0, 255, 0) if score > self.score_thresholds['good'] else (0, 0, 255)
        cv2.putText(frame, f'Score: {score:.2f}', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, color, 2)

    def _preprocess_frame(self, frame):
        frame_resized = cv2.resize(frame, (self.frame_width, self.frame_height))
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        frame_gray = cv2.cvtColor(frame_resized, cv2.COLOR_BGR2GRAY)
        frame_clahe = clahe.apply(frame_gray)
        frame_preprocessed = cv2.cvtColor(frame_clahe, cv2.COLOR_GRAY2BGR)
        return frame_preprocessed

    @staticmethod
    def angle_between(v1, v2):
        dot_product = np.dot(v1, v2)
        norms = np.linalg.norm(v1) * np.linalg.norm(v2)
        return np.degrees(np.arccos(dot_product / norms))

    def process_frame(self, frame):
        preprocessed_frame = self._preprocess_frame(frame)
        results = self._detect_pose(preprocessed_frame)
        score = self._calculate_posture_score(results.pose_landmarks.landmark) if results.pose_landmarks else 0
        self._draw_landmarks(preprocessed_frame, results)
        self._draw_posture_feedback(preprocessed_frame, score)
        return preprocessed_frame, score, results

cap = cv2.VideoCapture(0)
detector = PoseDetector()

while True:
    ret, frame = cap.read()
    if not ret:
        break
    processed_frame, score, results = detector.process_frame(frame)
    cv2.imshow('Posture Detection', processed_frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()