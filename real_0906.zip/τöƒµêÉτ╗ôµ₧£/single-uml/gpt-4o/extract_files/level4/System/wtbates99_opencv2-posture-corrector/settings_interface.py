import json
import os
from PyQt5.QtWidgets import QDialog, QTabWidget, QVBoxLayout, QPushButton, QComboBox, QSpinBox, QLineEdit, QTableWidget, QTableWidgetItem, QHBoxLayout, QLabel, QCheckBox
from util__settings import CUSTOMIZABLE_SETTINGS, IMMUTABLE_SETTINGS, USER_SETTINGS_FILE, save_user_settings, load_user_settings, update_setting

class SettingsInterface(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Settings")
        self.tabs = QTabWidget()
        self.camera_tab = self.init_camera_tab()
        self.general_tab = self.init_general_tab()
        self.tracking_tab = self.init_tracking_tab()
        self.tabs.addTab(self.camera_tab, "Camera")
        self.tabs.addTab(self.general_tab, "General")
        self.tabs.addTab(self.tracking_tab, "Tracking")
        self.button_box = QHBoxLayout()
        self.ok_button = QPushButton("OK")
        self.cancel_button = QPushButton("Cancel")
        self.button_box.addWidget(self.ok_button)
        self.button_box.addWidget(self.cancel_button)
        self.ok_button.clicked.connect(self.accept)
        self.cancel_button.clicked.connect(self.reject)
        layout = QVBoxLayout()
        layout.addWidget(self.tabs)
        layout.addLayout(self.button_box)
        self.setLayout(layout)

    def accept(self):
        self.update_camera_settings()
        self.update_general_settings()
        self.update_tracking_settings()
        save_user_settings()
        super().accept()

    def init_camera_tab(self):
        tab = QVBoxLayout()
        self.camera_combo = QComboBox()
        self.camera_combo.addItems(self.get_available_cameras(10))
        self.fps_spinbox = QSpinBox()
        self.fps_spinbox.setRange(1, 60)
        self.width_spinbox = QSpinBox()
        self.width_spinbox.setRange(320, 1920)
        self.height_spinbox = QSpinBox()
        self.height_spinbox.setRange(240, 1080)
        self.model_complexity_spinbox = QSpinBox()
        self.model_complexity_spinbox.setRange(0, 2)
        tab.addWidget(QLabel("Camera"))
        tab.addWidget(self.camera_combo)
        tab.addWidget(QLabel("FPS"))
        tab.addWidget(self.fps_spinbox)
        tab.addWidget(QLabel("Width"))
        tab.addWidget(self.width_spinbox)
        tab.addWidget(QLabel("Height"))
        tab.addWidget(self.height_spinbox)
        tab.addWidget(QLabel("Model Complexity"))
        tab.addWidget(self.model_complexity_spinbox)
        return tab

    def init_general_tab(self):
        tab = QVBoxLayout()
        self.cooldown_spinbox = QSpinBox()
        self.cooldown_spinbox.setRange(1, 60)
        self.poor_posture_spinbox = QSpinBox()
        self.poor_posture_spinbox.setRange(0, 100)
        self.posture_message_lineedit = QLineEdit()
        self.db_logging_checkbox = QCheckBox("Enable DB Logging")
        self.db_write_interval_spinbox = QSpinBox()
        self.db_write_interval_spinbox.setRange(1, 60)
        tab.addWidget(QLabel("Notification Cooldown"))
        tab.addWidget(self.cooldown_spinbox)
        tab.addWidget(QLabel("Poor Posture Threshold"))
        tab.addWidget(self.poor_posture_spinbox)
        tab.addWidget(QLabel("Posture Message"))
        tab.addWidget(self.posture_message_lineedit)
        tab.addWidget(self.db_logging_checkbox)
        tab.addWidget(QLabel("DB Write Interval"))
        tab.addWidget(self.db_write_interval_spinbox)
        return tab

    def init_tracking_tab(self):
        tab = QVBoxLayout()
        self.tracking_table = QTableWidget()
        self.tracking_table.setColumnCount(2)
        self.tracking_table.setHorizontalHeaderLabels(["Label", "Duration (min)"])
        self.populate_tracking_table()
        self.new_interval_label_edit = QLineEdit()
        self.new_interval_spinbox = QSpinBox()
        self.new_interval_spinbox.setRange(1, 240)
        self.add_interval_button = QPushButton("Add Interval")
        self.remove_interval_button = QPushButton("Remove Interval")
        self.add_interval_button.clicked.connect(self.add_tracking_interval)
        self.remove_interval_button.clicked.connect(self.remove_tracking_interval)
        tab.addWidget(self.tracking_table)
        tab.addWidget(QLabel("New Interval Label"))
        tab.addWidget(self.new_interval_label_edit)
        tab.addWidget(QLabel("New Interval Duration"))
        tab.addWidget(self.new_interval_spinbox)
        tab.addWidget(self.add_interval_button)
        tab.addWidget(self.remove_interval_button)
        return tab

    def get_available_cameras(self, max_index):
        available_cameras = []
        for i in range(max_index):
            cap = cv2.VideoCapture(i)
            if cap.isOpened():
                available_cameras.append(f"Camera {i}")
                cap.release()
        return available_cameras

    def populate_tracking_table(self):
        self.tracking_table.setRowCount(len(CUSTOMIZABLE_SETTINGS["tracking_intervals"]))
        for i, interval in enumerate(CUSTOMIZABLE_SETTINGS["tracking_intervals"]):
            self.tracking_table.setItem(i, 0, QTableWidgetItem(interval["label"]))
            self.tracking_table.setItem(i, 1, QTableWidgetItem(str(interval["duration"])))

    def add_tracking_interval(self):
        label = self.new_interval_label_edit.text()
        duration = self.new_interval_spinbox.value()
        CUSTOMIZABLE_SETTINGS["tracking_intervals"].append({"label": label, "duration": duration})
        self.populate_tracking_table()

    def remove_tracking_interval(self):
        selected_rows = self.tracking_table.selectionModel().selectedRows()
        for row in sorted(selected_rows, reverse=True):
            del CUSTOMIZABLE_SETTINGS["tracking_intervals"][row.row()]
        self.populate_tracking_table()

    def update_camera_settings(self):
        update_setting("camera_id", self.camera_combo.currentIndex())
        update_setting("fps", self.fps_spinbox.value())
        update_setting("frame_width", self.width_spinbox.value())
        update_setting("frame_height", self.height_spinbox.value())
        update_setting("model_complexity", self.model_complexity_spinbox.value())

    def update_general_settings(self):
        update_setting("notification_cooldown", self.cooldown_spinbox.value())
        update_setting("poor_posture_threshold", self.poor_posture_spinbox.value())
        update_setting("posture_message", self.posture_message_lineedit.text())
        update_setting("db_logging_enabled", self.db_logging_checkbox.isChecked())
        update_setting("db_write_interval", self.db_write_interval_spinbox.value())

    def update_tracking_settings(self):
        tracking_intervals = []
        for row in range(self.tracking_table.rowCount()):
            label = self.tracking_table.item(row, 0).text()
            duration = int(self.tracking_table.item(row, 1).text())
            tracking_intervals.append({"label": label, "duration": duration})
        update_setting("tracking_intervals", tracking_intervals)