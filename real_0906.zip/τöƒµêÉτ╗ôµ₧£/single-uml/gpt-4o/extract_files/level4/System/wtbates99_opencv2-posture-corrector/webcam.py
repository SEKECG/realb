import cv2
import threading
import time
from pose_detector import PoseDetector

class Webcam:
    def __init__(self):
        self.camera_id = 0
        self.fps = 30
        self.frame_time = 1 / self.fps
        self.is_running = False
        self.cap = cv2.VideoCapture(self.camera_id)
        self._callback = None
        self._latest_frame = None
        self._latest_score = None
        self._latest_pose_results = None
        self.thread = None

    def __del__(self):
        self.stop()
        if self.cap.isOpened():
            self.cap.release()

    def start(self, callback=None):
        self._callback = callback
        self.is_running = True
        self.thread = threading.Thread(target=self._capture_loop)
        self.thread.start()

    def stop(self):
        self.is_running = False
        if self.thread is not None:
            self.thread.join()

    def _capture_loop(self):
        detector = PoseDetector()
        while self.is_running:
            ret, frame = self.cap.read()
            if not ret:
                break
            frame, score, pose_results = detector.process_frame(frame)
            self._latest_frame = frame
            self._latest_score = score
            self._latest_pose_results = pose_results
            if self._callback:
                self._callback(frame, score, pose_results)
            time.sleep(self.frame_time)

    def get_latest_frame(self):
        return self._latest_frame, self._latest_score

    def get_latest_pose_results(self):
        return self._latest_pose_results