import sys
import signal
from PyQt5.QtWidgets import QApplication, QSystemTrayIcon, QMenu, QAction, QLabel, QMainWindow
from PyQt5.QtGui import QIcon
from PyQt5.QtCore import QTimer
from database import Database
from pose_detector import PoseDetector
from webcam import Webcam
from notifications import Notifications
from util__settings import get_setting, load_user_settings, save_user_settings
from util__create_score_icon import create_score_icon
from util__scores import Scores
from util__send_notification import send_notification

class PostureTrackerTray:
    def __init__(self):
        self.current_score = 0
        self.db = None
        self.db_enabled = False
        self.detector = None
        self.frame_reader = None
        self.icon_path = "icon.png"
        self.interval_menu = None
        self.interval_menu_action = None
        self.interval_timer = QTimer()
        self.last_db_save = None
        self.last_tracking_time = None
        self.notifier = Notifications(self.icon_path)
        self.scores = Scores()
        self.settings_action = None
        self.timer = QTimer()
        self.toggle_tracking_action = None
        self.toggle_video_action = None
        self.tracking_enabled = False
        self.tracking_interval = 4 * 60 * 60  # 4 hours
        self.video_label = QLabel()
        self.video_window = QMainWindow()

        self._initialize_application()
        self._initialize_components()
        self._setup_signal_handling()
        self._setup_timers()
        self._setup_tray_menu()

    def _initialize_application(self):
        self.app = QApplication(sys.argv)
        self.tray_icon = QSystemTrayIcon(QIcon(self.icon_path), self.app)
        self.tray_icon.setToolTip("Posture Tracker")
        self.tray_icon.show()

    def _initialize_components(self):
        self.detector = PoseDetector()
        self.frame_reader = Webcam()
        self.db = Database(get_setting("db_path"))
        self.db_enabled = get_setting("db_logging")

    def _setup_signal_handling(self):
        signal.signal(signal.SIGINT, self.signal_handler)
        signal.signal(signal.SIGTERM, self.signal_handler)

    def _setup_timers(self):
        self.timer.timeout.connect(self.update_tracking)
        self.interval_timer.timeout.connect(self.check_interval)

    def _setup_tray_menu(self):
        menu = QMenu()
        self.toggle_tracking_action = QAction("Toggle Tracking", self.app)
        self.toggle_tracking_action.triggered.connect(self.toggle_tracking)
        menu.addAction(self.toggle_tracking_action)

        self.toggle_video_action = QAction("Toggle Video", self.app)
        self.toggle_video_action.triggered.connect(self.toggle_video)
        menu.addAction(self.toggle_video_action)

        self.settings_action = QAction("Settings", self.app)
        self.settings_action.triggered.connect(self.open_settings)
        menu.addAction(self.settings_action)

        quit_action = QAction("Quit", self.app)
        quit_action.triggered.connect(self.quit_application)
        menu.addAction(quit_action)

        self.tray_icon.setContextMenu(menu)

    def _create_interval_menu(self, parent_menu):
        self.interval_menu = QMenu("Tracking Interval", parent_menu)
        self.interval_menu_action = QAction("Set Interval", self.app)
        self.interval_menu_action.triggered.connect(self.set_interval)
        self.interval_menu.addAction(self.interval_menu_action)
        parent_menu.addMenu(self.interval_menu)

    def _create_video_window(self):
        self.video_window.setWindowTitle("Posture Tracker Video Feed")
        self.video_window.setCentralWidget(self.video_label)
        self.video_window.resize(640, 480)

    def _save_to_db(self, average_score):
        if self.db_enabled and self.db:
            self.db.save_pose_data(self.detector.posture_landmarks, average_score)

    def _start_tracking(self):
        self.tracking_enabled = True
        self.timer.start(get_setting("tracking_interval") * 1000)

    def _stop_tracking(self):
        self.tracking_enabled = False
        self.timer.stop()

    def _update_video_display(self, frame):
        self.video_label.setPixmap(frame)

    def check_interval(self):
        if self.tracking_enabled:
            self.start_interval_tracking()

    def on_video_window_closed(self):
        self.video_window.hide()

    def open_settings(self):
        settings_dialog = SettingsInterface(self.video_window)
        if settings_dialog.exec_():
            self.reload_settings()

    def quit_application(self):
        self.tray_icon.hide()
        self.app.quit()

    def reload_settings(self):
        load_user_settings()
        self._initialize_components()

    def set_interval(self, minutes):
        self.tracking_interval = minutes * 60

    def signal_handler(self, signum, frame):
        self.quit_application()

    def start_interval_tracking(self):
        self.last_tracking_time = time.time()
        self._start_tracking()
        QTimer.singleShot(self.tracking_interval * 1000, self.stop_interval_tracking)

    def stop_interval_tracking(self):
        self._stop_tracking()

    def toggle_tracking(self):
        if self.tracking_enabled:
            self._stop_tracking()
        else:
            self._start_tracking()

    def toggle_video(self):
        if self.video_window.isVisible():
            self.video_window.hide()
        else:
            self.video_window.show()

    def update_tracking(self):
        frame = self.frame_reader.get_latest_frame()
        processed_frame, score, pose_results = self.detector.process_frame(frame)
        self.scores.add_score(score)
        average_score = self.scores.get_average_score()
        self._update_video_display(processed_frame)
        self.notifier.check_and_notify(average_score)
        self._save_to_db(average_score)

if __name__ == "__main__":
    tray_app = PostureTrackerTray()
    sys.exit(tray_app.app.exec_())