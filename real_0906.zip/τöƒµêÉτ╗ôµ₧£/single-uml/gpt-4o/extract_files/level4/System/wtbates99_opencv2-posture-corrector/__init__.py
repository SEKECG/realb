# src/__init__.py

# Import necessary modules and classes
from .database import Database
from .main import kill_existing_instance, main
from .notifications import Notifications
from .pose_detector import PoseDetector
from .settings_interface import SettingsInterface
from .tray_interface import PostureTrackerTray
from .util__create_score_icon import create_score_icon
from .util__scores import Scores
from .util__send_notification import send_notification
from .util__settings import get_setting, save_user_settings, load_user_settings, update_setting
from .webcam import Webcam

__all__ = [
    "Database",
    "kill_existing_instance",
    "main",
    "Notifications",
    "PoseDetector",
    "SettingsInterface",
    "PostureTrackerTray",
    "create_score_icon",
    "Scores",
    "send_notification",
    "get_setting",
    "save_user_settings",
    "load_user_settings",
    "update_setting",
    "Webcam"
]