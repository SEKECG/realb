import os
import logging
import getpass
import random

logger = logging.getLogger(__name__)
handler = logging.StreamHandler()
logger.addHandler(handler)
logger.setLevel(logging.DEBUG)

class SecureBytes:
    def __init__(self, data=None, length=None):
        if isinstance(data, str):
            self._data = bytearray(data.encode())
        elif isinstance(data, (bytes, bytearray)):
            self._data = bytearray(data)
        elif length is not None:
            self._data = bytearray(os.urandom(length))
        else:
            self._data = bytearray()

    def __del__(self):
        self.clear()

    def __len__(self):
        return len(self._data) if self._data else 0

    def __repr__(self):
        return f"<SecureBytes: {len(self._data)} bytes>"

    def clear(self):
        for i in range(len(self._data)):
            self._data[i] = 0
        self._data = bytearray()

    def get(self):
        return bytes(self._data)

    def to_bytes(self):
        return bytes(self._data)

    def wipe(self):
        for i in range(len(self._data)):
            self._data[i] = random.randint(0, 255)
        self.clear()

def secure_password_prompt(prompt):
    password = getpass.getpass(prompt)
    secure_bytes = SecureBytes(password)
    wipe_sensitive_data(password)
    return secure_bytes

def secure_string_to_bytes(s):
    secure_bytes = SecureBytes(s)
    wipe_sensitive_data(s)
    return secure_bytes

def wipe_sensitive_data(variable):
    if isinstance(variable, str):
        variable = bytearray(variable.encode())
    if isinstance(variable, (bytes, bytearray)):
        for i in range(len(variable)):
            variable[i] = 0
    variable = None

def with_secure_context(func):
    def wrapper(*args, **kwargs):
        result = func(*args, **kwargs)
        for arg in args:
            if isinstance(arg, SecureBytes):
                arg.clear()
        for key, value in kwargs.items():
            if isinstance(value, SecureBytes):
                value.clear()
        return result
    return wrapper