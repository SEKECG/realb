import json
from typing import Optional, Dict, Any
from cryptguard.crypto_core.argon_utils import generate_key_from_password
from cryptguard.crypto_core.config import META_ARGON_PARAMS, META_SALT_SIZE
from cryptguard.crypto_core.secure_bytes import SecureBytes
from cryptguard.crypto_core.key_obfuscator import KeyObfuscator
from cryptguard.crypto_core.chunk_crypto import decrypt_chunk, encrypt_chunk

def decrypt_meta_json(meta_path, user_password) -> Optional[Dict[str, Any]]:
    try:
        with open(meta_path, 'rb') as f:
            encrypted_meta = f.read()
        
        key_obfuscator = generate_key_from_password(user_password, META_SALT_SIZE, META_ARGON_PARAMS)
        key_obfuscator.deobfuscate()
        key = key_obfuscator._key
        
        decrypted_meta = decrypt_chunk(encrypted_meta, key, 0, None, 0)
        meta_dict = json.loads(decrypted_meta)
        
        key_obfuscator.clear()
        return meta_dict
    except Exception as e:
        print(f"Error decrypting metadata: {e}")
        return None

def encrypt_meta_json(meta_path, meta_plain, user_password) -> bool:
    try:
        meta_json = json.dumps(meta_plain).encode('utf-8')
        
        key_obfuscator = generate_key_from_password(user_password, META_SALT_SIZE, META_ARGON_PARAMS)
        key_obfuscator.obfuscate()
        key = key_obfuscator._key
        
        encrypted_meta = encrypt_chunk(meta_json, key, None, 0)
        
        with open(meta_path, 'wb') as f:
            f.write(encrypted_meta)
        
        key_obfuscator.clear()
        return True
    except Exception as e:
        print(f"Error encrypting metadata: {e}")
        return False