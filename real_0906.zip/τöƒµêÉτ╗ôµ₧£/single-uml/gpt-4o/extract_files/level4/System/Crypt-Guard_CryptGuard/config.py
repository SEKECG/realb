# config.py

DEFAULT_ARGON_PARAMS = {
    "memory_cost": 128 * 1024,  # 128 MB
    "parallelism": 2,
    "time_cost": 3
}

USE_RS = False

ARGON_MEMORY_COST = 128 * 1024  # 128 MB
ARGON_MEMORY_COST_BALANCED = 128 * 1024  # 128 MB
ARGON_MEMORY_COST_FAST = 64 * 1024  # 64 MB
ARGON_MEMORY_COST_SECURE = 256 * 1024  # 256 MB

ARGON_PARALLELISM = 2
ARGON_PARALLELISM_BALANCED = 2
ARGON_PARALLELISM_FAST = 1
ARGON_PARALLELISM_SECURE = 4

ARGON_TIME_COST = 3
ARGON_TIME_COST_BALANCED = 3
ARGON_TIME_COST_FAST = 1
ARGON_TIME_COST_SECURE = 5

CHUNK_SIZE = 1 * 1024 * 1024  # 1 MB default chunk size
MAX_ATTEMPTS = 5  # Maximum password attempts before blocking
MAX_CHUNK_SIZE = 100 * 1024 * 1024  # 100 MB

META_ARGON_PARAMS = {
    "memory_cost": 64 * 1024,  # 64 MB
    "parallelism": 1,
    "time_cost": 2
}
META_SALT_SIZE = 16  # bytes for metadata salt
META_VERSION = 1  # current metadata format version

RS_PARITY_BYTES = 16  # Reed-Solomon parity bytes by default
SIGN_METADATA = True  # enable HMAC signature in metadata (optional)
SINGLE_SHOT_SUBCHUNK_SIZE = 1 * 1024 * 1024  # 1 MB, adjustable
STREAMING_THRESHOLD = 10 * 1024 * 1024  # 10 MB threshold for streaming mode

def set_use_rs(value):
    global USE_RS
    USE_RS = value