import os
import math
import multiprocessing
from cryptguard.crypto_core.argon_utils import generate_key_from_password
from cryptguard.crypto_core.chunk_crypto import encrypt_chunk, decrypt_chunk
from cryptguard.crypto_core.config import CHUNK_SIZE, STREAMING_THRESHOLD
from cryptguard.crypto_core.metadata import encrypt_meta_json, decrypt_meta_json
from cryptguard.crypto_core.utils import generate_unique_filename

def calculate_optimal_workers(file_size):
    cpu_count = multiprocessing.cpu_count()
    if file_size < STREAMING_THRESHOLD:
        return 1
    return min(cpu_count, math.ceil(file_size / CHUNK_SIZE))

def encrypt_data_streaming(file_path, password, file_type, original_ext, key_file_hash, chunk_size=CHUNK_SIZE):
    file_size = os.path.getsize(file_path)
    workers = calculate_optimal_workers(file_size)
    key = generate_key_from_password(password, key_file_hash)
    
    with open(file_path, 'rb') as f:
        chunk_index = 0
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            encrypted_chunk = encrypt_chunk(chunk, key, file_type, chunk_index)
            chunk_index += 1
            # Save encrypted_chunk to file or buffer

    meta_data = {
        'file_type': file_type,
        'original_ext': original_ext,
        'chunk_size': chunk_size,
        'key_file_hash': key_file_hash
    }
    meta_path = generate_unique_filename(file_path, '.meta')
    encrypt_meta_json(meta_path, meta_data, password)

def decrypt_data_streaming(enc_path, password):
    meta_path = enc_path.replace('.enc', '.meta')
    meta_data = decrypt_meta_json(meta_path, password)
    key_file_hash = meta_data['key_file_hash']
    key = generate_key_from_password(password, key_file_hash)
    
    with open(enc_path, 'rb') as f:
        chunk_index = 0
        while True:
            chunk = f.read(meta_data['chunk_size'])
            if not chunk:
                break
            decrypted_chunk = decrypt_chunk(chunk, key, chunk_index)
            chunk_index += 1
            # Save decrypted_chunk to file or buffer