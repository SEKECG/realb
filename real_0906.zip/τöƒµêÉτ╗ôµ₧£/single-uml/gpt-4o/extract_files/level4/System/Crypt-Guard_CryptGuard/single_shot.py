import os
import json
from cryptguard.crypto_core.argon_utils import generate_key_from_password
from cryptguard.crypto_core.chunk_crypto import encrypt_chunk, decrypt_chunk
from cryptguard.crypto_core.config import SINGLE_SHOT_SUBCHUNK_SIZE, CHUNK_SIZE
from cryptguard.crypto_core.key_obfuscator import KeyObfuscator
from cryptguard.crypto_core.metadata import encrypt_meta_json, decrypt_meta_json
from cryptguard.crypto_core.secure_bytes import SecureBytes
from cryptguard.crypto_core.utils import generate_unique_filename

def encrypt_data_single(data, password, file_type, original_ext, key_file_hash=None, subchunk_size=SINGLE_SHOT_SUBCHUNK_SIZE):
    key_obfuscator = generate_key_from_password(password, salt=os.urandom(16), params=None, extra=key_file_hash)
    encrypted_chunks = []
    offset = 0

    while offset < len(data):
        chunk = data[offset:offset + subchunk_size]
        encrypted_chunk = encrypt_chunk(chunk, key_obfuscator, aad=None, chunk_index=offset // subchunk_size)
        encrypted_chunks.append(encrypted_chunk)
        key_obfuscator.obfuscate()
        offset += subchunk_size

    encrypted_data = b''.join(encrypted_chunks)
    meta_data = {
        'file_type': file_type,
        'original_ext': original_ext,
        'multi_sub_block': len(data) > subchunk_size
    }
    meta_path = generate_unique_filename(prefix='meta', extension='.json')
    encrypt_meta_json(meta_path, meta_data, password)

    enc_path = generate_unique_filename(prefix='enc', extension='.enc')
    with open(enc_path, 'wb') as enc_file:
        enc_file.write(encrypted_data)

    return enc_path, meta_path

def decrypt_data_single(enc_path, password):
    with open(enc_path, 'rb') as enc_file:
        encrypted_data = enc_file.read()

    meta_path = enc_path.replace('.enc', '.json')
    meta_data = decrypt_meta_json(meta_path, password)
    if not meta_data:
        raise ValueError("Invalid password or corrupted metadata")

    key_obfuscator = generate_key_from_password(password, salt=os.urandom(16), params=None, extra=None)
    decrypted_chunks = []
    offset = 0

    if meta_data['multi_sub_block']:
        while offset < len(encrypted_data):
            chunk = encrypted_data[offset:offset + SINGLE_SHOT_SUBCHUNK_SIZE]
            decrypted_chunk = decrypt_chunk(chunk, key_obfuscator, offset=offset, aad=None, chunk_index=offset // SINGLE_SHOT_SUBCHUNK_SIZE)
            decrypted_chunks.append(decrypted_chunk)
            key_obfuscator.deobfuscate()
            offset += SINGLE_SHOT_SUBCHUNK_SIZE
    else:
        decrypted_chunk = decrypt_chunk(encrypted_data, key_obfuscator, offset=0, aad=None, chunk_index=0)
        decrypted_chunks.append(decrypted_chunk)

    decrypted_data = b''.join(decrypted_chunks)
    return decrypted_data