import hashlib
import os

from cryptguard.crypto_core.secure_bytes import SecureBytes, wipe_sensitive_data
from cryptguard.crypto_core.utils import generate_ephemeral_token
from cryptguard.crypto_core.config import USE_RS

ZXC_AVAILABLE = False

def validate_key_file(expected_hash):
    key_file_path = input("Enter the path to the key file: ")
    if not os.path.exists(key_file_path):
        print("Key file does not exist.")
        return False

    file_hash = get_file_hash(key_file_path)
    if file_hash != expected_hash:
        print("Key file hash does not match the expected hash.")
        return False

    return True

def choose_auth_method():
    print("Choose authentication method:")
    print("1. Password + Key File")
    print("2. Password Only")
    choice = input("Enter your choice (1 or 2): ")

    if choice == '1':
        password = get_single_password()
        key_file_hash = get_file_hash(input("Enter the path to the key file: "))
        combined_password = get_combined_password(password, key_file_hash)
        return combined_password
    elif choice == '2':
        password = get_single_password()
        return password
    else:
        print("Invalid choice.")
        return None

def get_combined_password(password, key_file_hash):
    combined = SecureBytes(password.get() + key_file_hash)
    wipe_sensitive_data(password)
    wipe_sensitive_data(key_file_hash)
    return combined

def get_file_hash(file_path):
    sha256 = hashlib.sha256()
    with open(file_path, 'rb') as f:
        while chunk := f.read(8192):
            sha256.update(chunk)
    return sha256.digest()

def get_single_password():
    password = input("Enter your password: ")
    confirm_password = input("Confirm your password: ")

    if password != confirm_password:
        print("Passwords do not match.")
        return None

    secure_password = SecureBytes(password)
    wipe_sensitive_data(password)
    wipe_sensitive_data(confirm_password)
    return secure_password

def validate_password(password):
    if len(password) < 8:
        print("Password must be at least 8 characters long.")
        return False

    if not any(char.isdigit() for char in password):
        print("Password must contain at least one digit.")
        return False

    if not any(char.isupper() for char in password):
        print("Password must contain at least one uppercase letter.")
        return False

    if not any(char.islower() for char in password):
        print("Password must contain at least one lowercase letter.")
        return False

    if not any(char in "!@#$%^&*()-_=+[]{}|;:'\",.<>?/`~" for char in password):
        print("Password must contain at least one special character.")
        return False

    return True