# __init__.py

from .argon_utils import generate_key_from_password, get_argon2_parameters_for_encryption
from .chunk_crypto import decrypt_chunk, encrypt_chunk
from .config import (
    DEFAULT_ARGON_PARAMS, USE_RS, ARGON_MEMORY_COST, ARGON_MEMORY_COST_BALANCED,
    ARGON_MEMORY_COST_FAST, ARGON_MEMORY_COST_SECURE, ARGON_PARALLELISM,
    ARGON_PARALLELISM_BALANCED, ARGON_PARALLELISM_FAST, ARGON_PARALLELISM_SECURE,
    ARGON_TIME_COST, ARGON_TIME_COST_BALANCED, ARGON_TIME_COST_FAST, ARGON_TIME_COST_SECURE,
    CHUNK_SIZE, MAX_ATTEMPTS, MAX_CHUNK_SIZE, META_ARGON_PARAMS, META_SALT_SIZE,
    META_VERSION, RS_PARITY_BYTES, SIGN_METADATA, SINGLE_SHOT_SUBCHUNK_SIZE,
    STREAMING_THRESHOLD, set_use_rs
)
from .key_obfuscator import KeyObfuscator
from .metadata import decrypt_meta_json, encrypt_meta_json
from .rs_codec import rs_encode_data, rs_decode_data
from .secure_bytes import (
    SecureBytes, secure_password_prompt, secure_string_to_bytes, wipe_sensitive_data,
    with_secure_context
)
from .single_shot import decrypt_data_single, encrypt_data_single
from .streaming import calculate_optimal_workers, decrypt_data_streaming, encrypt_data_streaming
from .utils import generate_unique_filename, clear_screen, generate_ephemeral_token, generate_random_number