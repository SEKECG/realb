import os
import random

class KeyObfuscator:
    """
    Protects cryptographic keys in memory by splitting and obfuscating them.
    Instead of storing the key directly, it stores components that can be
    combined to recreate the key only when needed.
    """

    def __init__(self, key_bytes):
        self._key = key_bytes
        self._mask = None
        self._obfuscated = None
        self._parts = None
        self.obfuscate()

    def __del__(self):
        self.clear()

    def clear(self):
        """
        Clear all sensitive data and reset the object's state by removing keys, masks, and obfuscated parts,
        ensuring no residual data remains in memory.
        """
        if self._key:
            self._key = None
        if self._mask:
            self._mask = None
        if self._obfuscated:
            self._obfuscated = None
        if self._parts:
            self._parts = None

    def obfuscate(self):
        """
        Obfuscate a sensitive key by XOR-ing it with a random mask and securely storing the result and mask,
        then clearing the original key from memory.
        """
        self._mask = os.urandom(len(self._key))
        self._obfuscated = bytes(a ^ b for a, b in zip(self._key, self._mask))
        self._parts = (self._mask, self._obfuscated)
        self._key = None

    def deobfuscate(self):
        """
        Deobfuscate the obfuscated data by applying an XOR operation between the mask and the obfuscated parts
        to retrieve the original key.
        """
        if self._parts:
            mask, obfuscated = self._parts
            self._key = bytes(a ^ b for a, b in zip(mask, obfuscated))
            self._mask = None
            self._obfuscated = None
            self._parts = None