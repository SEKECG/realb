import os
import random
import string
import time

def generate_unique_filename(prefix, extension):
    sanitized_prefix = ''.join(c for c in prefix if c.isalnum())
    timestamp = time.strftime("%Y%m%d%H%M%S")
    random_hex = ''.join(random.choices(string.hexdigits, k=8))
    return f"{sanitized_prefix}_{timestamp}_{random_hex}.{extension}"

def clear_screen():
    if os.name == 'nt':
        os.system('cls')
    else:
        os.system('clear')

def generate_ephemeral_token(n_bits):
    return ''.join(random.choices(string.hexdigits, k=n_bits // 4))

def generate_random_number(n_bits):
    return random.getrandbits(n_bits)