import os
import struct
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305
from cryptography.hazmat.primitives.kdf.argon2 import Argon2id
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend
from .config import USE_RS, RS_PARITY_BYTES
from .rs_codec import rs_encode_data, rs_decode_data

def encrypt_chunk(chunk, key, aad, chunk_index):
    chacha = ChaCha20Poly1305(key)
    nonce = struct.pack("<Q", chunk_index)
    encrypted_chunk = chacha.encrypt(nonce, chunk, aad)
    if USE_RS:
        encrypted_chunk = rs_encode_data(encrypted_chunk, len(encrypted_chunk), RS_PARITY_BYTES)
    return encrypted_chunk

def decrypt_chunk(data, key, offset, aad, chunk_index):
    chacha = ChaCha20Poly1305(key)
    nonce = struct.pack("<Q", chunk_index)
    if USE_RS:
        data = rs_decode_data(data, RS_PARITY_BYTES)
    decrypted_chunk = chacha.decrypt(nonce, data, aad)
    return decrypted_chunk, offset + len(decrypted_chunk)