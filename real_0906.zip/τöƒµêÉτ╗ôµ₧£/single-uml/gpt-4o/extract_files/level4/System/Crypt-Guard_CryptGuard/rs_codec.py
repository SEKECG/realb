import reedsolo

def rs_encode_data(data, block_size, parity_bytes):
    rs = reedsolo.RSCodec(parity_bytes)
    encoded_blocks = []
    for i in range(0, len(data), block_size):
        block = data[i:i + block_size]
        encoded_block = rs.encode(block)
        encoded_blocks.append(encoded_block)
    return b''.join(encoded_blocks)

def rs_decode_data(data, parity_bytes):
    rs = reedsolo.RSCodec(parity_bytes)
    decoded_blocks = []
    block_size = rs.nsym + rs.npar
    for i in range(0, len(data), block_size):
        block = data[i:i + block_size]
        decoded_block = rs.decode(block)
        decoded_blocks.append(decoded_block)
    return b''.join(decoded_blocks)