import tkinter as tk
from tkinter import filedialog

def select_file_for_encryption():
    root = tk.Tk()
    root.withdraw()
    file_path = filedialog.askopenfilename(title="Select a file for encryption")
    return file_path if file_path else ""

def select_files_for_decryption():
    root = tk.Tk()
    root.withdraw()
    enc_file_path = filedialog.askopenfilename(title="Select the encrypted file (.enc)")
    meta_file_path = filedialog.askopenfilename(title="Select the metadata file (.meta)")
    return (enc_file_path, meta_file_path) if enc_file_path and meta_file_path else ("", "")