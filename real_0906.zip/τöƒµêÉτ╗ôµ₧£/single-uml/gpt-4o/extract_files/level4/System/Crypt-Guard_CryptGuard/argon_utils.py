import hashlib
import os
import sys
from argon2 import PasswordHasher, Type
from cryptguard.crypto_core.key_obfuscator import KeyObfuscator
from cryptguard.crypto_core.config import DEFAULT_ARGON_PARAMS

def generate_key_from_password(password, salt, params=None, extra=None):
    if params is None:
        params = DEFAULT_ARGON_PARAMS

    ph = PasswordHasher(
        time_cost=params['time_cost'],
        memory_cost=params['memory_cost'],
        parallelism=params['parallelism'],
        hash_len=params['hash_len'],
        type=Type.ID
    )

    key = ph.hash(password + salt + (extra if extra else ''))
    obfuscator = KeyObfuscator(key.encode())
    obfuscator.obfuscate()
    return obfuscator

def get_argon2_parameters_for_encryption():
    return DEFAULT_ARGON_PARAMS