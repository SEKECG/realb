import json
from typing import Optional
from flask import Flask, request, jsonify
from core.data_def import PushMsg
from notify.notice import send_notice_msg

class WebhookMonitor:
    def __init__(self, host, port):
        self.app = Flask(__name__)
        self.host = host
        self.port = port
        self._register_routes()
        print(f"WebhookMonitor initialized on {host}:{port}")

    def _parse_tweet_data(self, raw_data):
        try:
            data = json.loads(raw_data)
            tweet = data.get("tweet")
            if tweet:
                push_msg = PushMsg(
                    tweet=tweet
                )
                return push_msg
            return None
        except json.JSONDecodeError:
            return None

    def _register_routes(self):
        @self.app.route('/webhook', methods=['POST'])
        def webhook():
            raw_data = request.data.decode('utf-8')
            push_msg = self._parse_tweet_data(raw_data)
            if push_msg:
                send_notice_msg(content=push_msg.tweet, title="New Tweet Notification")
                return jsonify({"status": "success"}), 200
            return jsonify({"status": "error"}), 400

    def start(self):
        self.app.run(host=self.host, port=self.port)

if __name__ == "__main__":
    monitor = WebhookMonitor(host="0.0.0.0", port=5000)
    monitor.start()