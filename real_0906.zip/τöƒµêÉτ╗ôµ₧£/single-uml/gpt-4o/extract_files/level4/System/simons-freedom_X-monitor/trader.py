import requests
from typing import Optional, Dict

class ChainBase:
    def __init__(self, chain_id, config):
        self.chain_id = chain_id
        self.config = config
        self.client = None
        self.initialized = False

    def buy_token(self, token_address, amount_usd, private_key) -> Optional[str]:
        pass

    def get_explorer_url(self, tx_hash) -> str:
        pass

    def initialize(self) -> bool:
        pass

class EvmChain(ChainBase):
    def __init__(self, chain_id, config):
        super().__init__(chain_id, config)
        self.web3 = None
        self.router_abi = None
        self.erc20_abi = None
        self.initialized = False

    def buy_token(self, token_address, amount_usd, private_key) -> Optional[str]:
        pass

    def initialize(self) -> bool:
        pass

class SolanaChain(ChainBase):
    def __init__(self, chain_id, config):
        super().__init__(chain_id, config)
        self.client = None
        self.jupiter_api = "https://api.jupiter.ag"
        self.initialized = False

    def _get_jupiter_quote(self, input_mint, output_mint, amount) -> Optional[Dict]:
        pass

    def _get_jupiter_swap_tx(self, quote, user_public_key) -> Optional[str]:
        pass

    def buy_token(self, token_address, amount_usd, private_key) -> Optional[str]:
        pass

    def initialize(self) -> bool:
        pass

class ChainTrader:
    BASE_CHAIN_CONFIG = {
        "eth": {"chain_id": 1, "rpc_url": "https://mainnet.infura.io/v3/YOUR_INFURA_PROJECT_ID"},
        "bsc": {"chain_id": 56, "rpc_url": "https://bsc-dataseed.binance.org/"},
        "sol": {"chain_id": "solana", "rpc_url": "https://api.mainnet-beta.solana.com"}
    }

    def __init__(self):
        self.chain_config = self.BASE_CHAIN_CONFIG
        self.chains = {
            "eth": EvmChain(self.chain_config["eth"]["chain_id"], self.chain_config["eth"]),
            "bsc": EvmChain(self.chain_config["bsc"]["chain_id"], self.chain_config["bsc"]),
            "sol": SolanaChain(self.chain_config["sol"]["chain_id"], self.chain_config["sol"])
        }

    def buy_token(self, chain, token_address, amount_usd=None) -> Optional[str]:
        if chain not in self.chains:
            return None
        return self.chains[chain].buy_token(token_address, amount_usd, self.chain_config[chain]["private_key"])

    def get_tx_explorer_url(self, chain, tx_hash) -> str:
        if chain not in self.chains:
            return ""
        return self.chains[chain].get_explorer_url(tx_hash)

    def initialize_chains(self):
        for chain in self.chains.values():
            chain.initialize()

def get_token_prices():
    url = "https://api.coingecko.com/api/v3/simple/price?ids=ethereum,binancecoin,solana&vs_currencies=usd"
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    return None