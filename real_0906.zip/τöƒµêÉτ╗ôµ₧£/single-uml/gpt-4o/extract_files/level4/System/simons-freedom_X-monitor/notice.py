import hashlib
import hmac
import time
import requests
from notify.dingding import DingTalkRobot

_robot = None

def _get_robot():
    global _robot
    if _robot is None:
        _robot = DingTalkRobot(robot_id="your_robot_id", secret="your_secret")
    return _robot

def send_warn_action_card(title, text, btn_orientation, btns):
    robot = _get_robot()
    return robot.send_action_card(title, text, btn_orientation, btns)

def send_notice_msg(content, title="系统通知", btn_info=None):
    robot = _get_robot()
    if btn_info is None:
        btn_info = []
    return robot.send_action_card(title, content, "0", btn_info)