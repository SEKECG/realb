# data_def.py

from typing import Optional

class Msg:
    """
    Represent a message with metadata including push type, title, content, sender's name, and screen name.
    """
    def __init__(self, push_type, title, content, sender_name, screen_name):
        self.push_type = push_type
        self.title = title
        self.content = content
        self.sender_name = sender_name
        self.screen_name = screen_name

class Tweet:
    """
    Represent a tweet's data structure with attributes for identification, content, metadata, and interaction status, including media, URLs, and timestamps.
    """
    def __init__(self, tweet_id, content, author, timestamp, media_urls, interaction_status):
        self.tweet_id = tweet_id
        self.content = content
        self.author = author
        self.timestamp = timestamp
        self.media_urls = media_urls
        self.interaction_status = interaction_status

class PushMsg:
    """
    A class to represent a push notification message with type, title, content, user, and optional tweet details.
    """
    def __init__(self, push_type, title, content, user, tweet: Optional[Tweet] = None):
        self.push_type = push_type
        self.title = title
        self.content = content
        self.user = user
        self.tweet = tweet

class User:
    """
    Represent a user profile with attributes related to social media account details, statistics, and verification status.
    """
    def __init__(self, user_id, username, display_name, followers_count, verified):
        self.user_id = user_id
        self.username = username
        self.display_name = display_name
        self.followers_count = followers_count
        self.verified = verified