import requests
from bs4 import BeautifulSoup
from typing import Optional

def get_tweet_details(url):
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')
    author = extract_author(soup)
    content = extract_content(soup)
    time = extract_time(soup)
    return {
        'author': author,
        'content': content,
        'time': time
    }

def extract_author(soup):
    user_section = soup.find('div', {'class': 'user-section'})
    if user_section:
        name = user_section.find('span', {'class': 'name'}).text
        username = user_section.find('span', {'class': 'username'}).text
        return {'name': name, 'username': username}
    return None

def extract_content(soup):
    title_tag = soup.find('title')
    if title_tag:
        content = title_tag.text.split(':')[1].split('/')[0].strip().strip('"')
        return content
    return None

def extract_time(soup):
    time_tag = soup.find('time')
    if time_tag:
        return time_tag['datetime']
    return None

key = None
result = None
tweet_url = None
value = None