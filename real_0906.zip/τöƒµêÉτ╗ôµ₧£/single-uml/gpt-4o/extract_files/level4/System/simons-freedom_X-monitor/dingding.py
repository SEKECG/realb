import time
import hmac
import hashlib
import base64
import requests

class DingTalkRobot:
    def __init__(self, robot_id, secret):
        self.robot_id = robot_id
        self.secret = secret
        self.headers = {"Content-Type": "application/json"}
        self.start_time = time.time()
        self.times = 0

    def __post(self, data):
        url = self.__spliceUrl()
        response = requests.post(url, headers=self.headers, data=data.encode("utf-8"))
        return response.json()

    def __spliceUrl(self):
        timestamp = str(round(time.time() * 1000))
        secret_enc = self.secret.encode("utf-8")
        string_to_sign = '{}\n{}'.format(timestamp, self.secret)
        string_to_sign_enc = string_to_sign.encode("utf-8")
        hmac_code = hmac.new(secret_enc, string_to_sign_enc, digestmod=hashlib.sha256).digest()
        sign = base64.b64encode(hmac_code).decode("utf-8")
        return f"https://oapi.dingtalk.com/robot/send?access_token={self.robot_id}&timestamp={timestamp}&sign={sign}"

    def is_not_null_and_blank_str(self, content):
        return content is not None and content.strip() != ""

    def send_action_card(self, title, markdown_msg, btnOrientation="0", btn_info=None):
        if btn_info is None:
            btn_info = []
        data = {
            "msgtype": "actionCard",
            "actionCard": {
                "title": title,
                "text": markdown_msg,
                "btnOrientation": btnOrientation,
                "btns": [{"title": btn[0], "actionURL": btn[1]} for btn in btn_info]
            }
        }
        return self.__post(data)

    def send_image(self, title, image_url, is_at_all=False, at_mobiles=None):
        if at_mobiles is None:
            at_mobiles = []
        markdown_msg = f"![{title}]({image_url})"
        return self.send_markdown(title, markdown_msg, is_at_all, at_mobiles)

    def send_json(self, msg, is_at_all=False, at_mobiles=None):
        if at_mobiles is None:
            at_mobiles = []
        data = {
            "msgtype": "markdown",
            "markdown": {
                "title": "JSON Message",
                "text": msg
            },
            "at": {
                "atMobiles": at_mobiles,
                "isAtAll": is_at_all
            }
        }
        return self.__post(data)

    def send_markdown(self, title, markdown_msg, is_at_all=False, at_mobiles=None):
        if at_mobiles is None:
            at_mobiles = []
        data = {
            "msgtype": "markdown",
            "markdown": {
                "title": title,
                "text": markdown_msg
            },
            "at": {
                "atMobiles": at_mobiles,
                "isAtAll": is_at_all
            }
        }
        return self.__post(data)

    def send_msg(self, mssg):
        markdown_msg = "\n".join(mssg)
        return self.send_markdown("Transaction Notification", markdown_msg)

    def send_text(self, msg, is_at_all=False, at_mobiles=None):
        if at_mobiles is None:
            at_mobiles = []
        data = {
            "msgtype": "text",
            "text": {
                "content": msg
            },
            "at": {
                "atMobiles": at_mobiles,
                "isAtAll": is_at_all
            }
        }
        return self.__post(data)