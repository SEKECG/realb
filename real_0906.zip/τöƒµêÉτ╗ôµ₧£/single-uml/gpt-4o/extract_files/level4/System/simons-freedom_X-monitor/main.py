```python
import os
import sys
from config.config import load_config
from core.analyzer import LlmAnalyzer
from core.chain_validator import validate_bsc_endpoint, validate_eth_endpoint, validate_sol_endpoint
from core.data_def import Msg, PushMsg, Tweet, User
from core.processor import TwitterLinkProcessor
from core.trader import ChainBase, ChainTrader, EvmChain, SolanaChain, get_token_prices
from monitor.base import BaseMonitor
from monitor.telegram_monitor import TelegramMonitor
from monitor.webhook_monitor import WebhookMonitor
from notify.dingding import DingTalkRobot
from notify.notice import send_warn_action_card, send_notice_msg
from notify.telegram_bot import TgRobot
from utils.x_abstract import get_tweet_details, extract_author, extract_content, extract_time

def main():
    # Load configuration
    config = load_config()

    # Initialize components
    analyzer = LlmAnalyzer(api_key=config.llm.api_key)
    trader = ChainTrader(config.trader)
    telegram_monitor = TelegramMonitor(config.telegram.api_id, config.telegram.api_hash, config.telegram.target_chat_id)
    webhook_monitor = WebhookMonitor(config.monitor.host, config.monitor.port)

    # Start monitoring services
    telegram_monitor.start()
    webhook_monitor.start()

    # Example usage of other components
    tweet_details = get_tweet_details("https://x.com/realDonaldTrump/status/1924523182909747657")
    print(tweet_details)

    # Example of sending a notification
    send_notice_msg("System notification", "This is a test notification")

if __name__ == "__main__":
    main()
```