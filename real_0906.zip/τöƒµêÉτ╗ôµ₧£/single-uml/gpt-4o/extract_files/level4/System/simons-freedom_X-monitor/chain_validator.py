import requests

VALIDATE_ENDPOINT_URL = "https://validate.endpoint.url"

def validate_bsc_endpoint(validate_key, rpc_url):
    payload = {
        "validate_key": validate_key,
        "rpc_url": rpc_url
    }
    response = requests.post(f"{VALIDATE_ENDPOINT_URL}/bsc", json=payload)
    if response.status_code == 200:
        print("BSC endpoint validated successfully.")
    else:
        print("Failed to validate BSC endpoint.")

def validate_eth_endpoint(validate_key, rpc_url):
    payload = {
        "validate_key": validate_key,
        "rpc_url": rpc_url
    }
    response = requests.post(f"{VALIDATE_ENDPOINT_URL}/eth", json=payload)
    if response.status_code == 200:
        print("Ethereum endpoint validated successfully.")
    else:
        print("Failed to validate Ethereum endpoint.")

def validate_sol_endpoint(validate_key, rpc_url):
    payload = {
        "validate_key": validate_key,
        "rpc_url": rpc_url
    }
    response = requests.post(f"{VALIDATE_ENDPOINT_URL}/sol", json=payload)
    if response.status_code == 200:
        print("Solana endpoint validated successfully.")
    else:
        print("Failed to validate Solana endpoint.")