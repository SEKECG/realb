# base.py

from core.analyzer import LlmAnalyzer
from core.data_def import PushMsg
from core.processor import TwitterLinkProcessor
from core.trader import ChainTrader
from core.token_searcher import TokenSearcher
from notify.notice import send_notice_msg

class BaseMonitor:
    def __init__(self):
        self.analyzer = LlmAnalyzer(api_key="your_api_key")
        self.token_searcher = TokenSearcher(max_retries=3, retry_delay=5)
        self.trader = ChainTrader()

    def _analyze_message(self, msg):
        analysis_result = self.analyzer.analyze_content(msg.content)
        return analysis_result

    def _format_token_notification(self, token_names, search_results, tweet_author, tweet_content):
        notification_msg = f"Author: {tweet_author}\nContent: {tweet_content}\nTokens: {', '.join(token_names)}"
        return notification_msg, search_results

    def _init_trader(self):
        self.trader.initialize_chains()

    def _search_tokens(self, token_names):
        search_results = self.token_searcher.batch_search_tokens(token_names, concurrency=5)
        return search_results

    def _should_trade(self, token):
        return token.is_open_source and not token.is_honeypot and token.liquidity_usd > 5000

    def process_message(self, message):
        analysis_result = self._analyze_message(message)
        if not analysis_result:
            return

        token_names = analysis_result.get("tokens", [])
        search_results = self._search_tokens(token_names)
        notification_msg, tokens = self._format_token_notification(token_names, search_results, message.author, message.content)

        send_notice_msg(notification_msg)

        for token in tokens:
            if self._should_trade(token):
                self.trader.buy_token(chain="eth", token_address=token.address, amount_usd=100)