import telegram
import pandas as pd

class TgRobot:
    def __init__(self, token, chat_id):
        self.token = token
        self.chat_id = chat_id
        self.bot = telegram.Bot(token=self.token)

    def send_dataframe(self, content):
        """
        Send DataFrame message
        """
        if isinstance(content, pd.DataFrame):
            content = content.to_string()
        self.bot.send_message(chat_id=self.chat_id, text=content)

    def send_document(self, doc_path):
        """
        Send document file
        """
        self.bot.send_document(chat_id=self.chat_id, document=open(doc_path, 'rb'))

    def send_html(self, html_text):
        """
        Send HTML message
        """
        self.bot.send_message(chat_id=self.chat_id, text=html_text, parse_mode=telegram.ParseMode.HTML)

    def send_msg(self, mssg):
        """
        Send concatenated message
        """
        self.bot.send_message(chat_id=self.chat_id, text=mssg)

    def send_photo(self, photo_path):
        """
        Send photo
        """
        self.bot.send_photo(chat_id=self.chat_id, photo=open(photo_path, 'rb'))

    def send_text(self, content):
        """
        Send text message
        """
        self.bot.send_message(chat_id=self.chat_id, text=content)