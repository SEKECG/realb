import streamlit as st
import random
from utils import load_css, show_info, show_warning, show_error, show_success

# Initialize page config
st.set_page_config(
    page_title="EduNexus 2.0",
    page_icon="🚀",
    layout="wide"
)

# Load custom CSS
load_css()

# Page header
st.title("🚀 EduNexus 2.0")
st.markdown("### Your AI-powered educational companion")

# Random inspirational quotes
quotes = [
    "Education is the most powerful weapon which you can use to change the world. - Nelson Mandela",
    "The beautiful thing about learning is that no one can take it away from you. - B.B. King",
    "Education is not the filling of a pail, but the lighting of a fire. - William Butler Yeats",
    "The expert in anything was once a beginner. - Helen Hayes",
    "Learning is a treasure that will follow its owner everywhere. - Chinese Proverb"
]

st.markdown(f"*\"{random.choice(quotes)}\"*")

# Features section
st.header("🌟 Key Features")

col1, col2, col3, col4 = st.columns(4)

with col1:
    st.markdown("""
    ### 📚 Personalized Learning
    Customized learning plans tailored to your needs
    """)

with col2:
    st.markdown("""
    ### ✨ Smart Summaries
    Convert lengthy documents into concise summaries
    """)

with col3:
    st.markdown("""
    ### 💻 AI Code Mentor
    Real-time coding assistance and expert reviews
    """)

with col4:
    st.markdown("""
    ### 📅 Study Planner
    Create and manage effective study schedules
    """)

# Team section
st.header("👨‍💻 Our Team")

team_col1, team_col2, team_col3, team_col4, team_col5, team_col6 = st.columns(6)

with team_col1:
    st.markdown("""
    **M Ibrahim Qasmi**  
    Team Leader, Data Science Specialist
    """)

with team_col2:
    st.markdown("""
    **TIJANI S. OLALEKAN**  
    Software Engineer, Development Specialist
    """)

with team_col3:
    st.markdown("""
    **Maryam Sikander**  
    ML Engineer, Machine Learning Specialist
    """)

with team_col4:
    st.markdown("""
    **Ahmad Fakhar**  
    Data Analyst
    """)

with team_col5:
    st.markdown("""
    **M Jawad**  
    Data Analyst
    """)

with team_col6:
    st.markdown("""
    **TAYYAB SAJJAD**  
    Web Expert, Web Development Specialist
    """)