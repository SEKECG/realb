import os
import streamlit as st
from ibm_watson_machine_learning.foundation_models import Model
from ibm_watson_machine_learning.metanames import GenTextParamsMetaNames as GenParams

def load_css():
    """UI Components"""
    st.markdown("""
    <style>
        .stApp {
            background-color: #f5f5f5;
        }
        .feature-card {
            padding: 20px;
            border-radius: 10px;
            background-color: white;
            box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
            transition: 0.3s;
            margin-bottom: 20px;
        }
        .feature-card:hover {
            box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
        }
        .team-card {
            padding: 15px;
            border-radius: 10px;
            background-color: white;
            box-shadow: 0 4px 8px 0 rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
    </style>
    """, unsafe_allow_html=True)

def init_watsonx():
    """Initialize WatsonX credentials and return model inference object"""
    try:
        api_key = os.getenv("WATSONX_API_KEY")
        project_id = os.getenv("WATSONX_PROJECT_ID")
        
        if not api_key or not project_id:
            raise ValueError("WatsonX API credentials not found in environment variables")
            
        credentials = {
            "url": "https://us-south.ml.cloud.ibm.com",
            "apikey": api_key
        }
        
        model_params = {
            GenParams.DECODING_METHOD: "sample",
            GenParams.MAX_NEW_TOKENS: 1000,
            GenParams.MIN_NEW_TOKENS: 1,
            GenParams.TEMPERATURE: 0.7,
            GenParams.TOP_K: 50,
            GenParams.TOP_P: 1
        }
        
        model = Model(
            model_id="ibm/granite-13b-instruct-v1",
            credentials=credentials,
            project_id=project_id,
            params=model_params
        )
        
        return model
        
    except Exception as e:
        show_error(f"Failed to initialize WatsonX: {str(e)}")
        return None

def run_watson_granite(prompt, system_prompt=None):
    """Run WatsonX model with error handling"""
    try:
        model = init_watsonx()
        if not model:
            return None
            
        if system_prompt:
            prompt = f"{system_prompt}\n\n{prompt}"
            
        response = model.generate_text(prompt)
        return response
        
    except Exception as e:
        show_error(f"Error in WatsonX model execution: {str(e)}")
        return None

def show_error(message):
    """Display an error message with a warning emoji in a Streamlit application."""
    st.error(f"⚠️ {message}")

def show_info(message):
    """Display an informational message to the user with a preceding ℹ️ icon using Streamlit's info method."""
    st.info(f"ℹ️ {message}")

def show_success(message):
    """Display a success message with a checkmark prefix in a Streamlit application."""
    st.success(f"✅ {message}")

def show_warning(message):
    """Display a warning message with a warning icon in a user interface using the Streamlit library."""
    st.warning(f"⚠️ {message}")