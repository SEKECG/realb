from typing import List, Optional, Dict, Any

class BaseNode:
    """Base class for all node types."""
    def __init__(self, level_seq: List[int], level_text: str, title: str, content: str):
        self.level_seq = level_seq
        self.level_text = level_text
        self.title = title
        self.content = content

    def concat_node(self, node: 'BaseNode') -> None:
        """Concatenate another node's content onto the current node."""
        self.content += '\n' + node.content

class ChainNode(BaseNode):
    """Node in a chain structure; stores flat information only."""
    def __init__(self, level_seq: List[int], level_text: str, title: str, content: str, pattern_priority: int):
        super().__init__(level_seq, level_text, title, content)
        self.pattern_priority = pattern_priority

class TreeNode(BaseNode):
    """Node in a tree structure; includes hierarchical relationships."""
    def __init__(self, level_seq: List[int], level_text: str, title: str, content: str):
        super().__init__(level_seq, level_text, title, content)
        self.parent: Optional['TreeNode'] = None
        self.children: List['TreeNode'] = []

    @staticmethod
    def from_chain_node(chain_node: ChainNode) -> 'TreeNode':
        """Convert a chain node to a tree node."""
        return TreeNode(
            level_seq=chain_node.level_seq,
            level_text=chain_node.level_text,
            title=chain_node.title,
            content=chain_node.content
        )

    def add_child(self, child: 'TreeNode') -> None:
        """Add a child node to the current node."""
        child.parent = self
        self.children.append(child)

    def get_full_content(self) -> str:
        """Get the full content of the current node and all its children."""
        content = self.content
        for child in self.children:
            content += '\n' + child.get_full_content()
        return content

    def merge_all_children(self) -> None:
        """Merge all children into the current node."""
        for child in self.children:
            self.concat_node(child)
            child.merge_all_children()
        self.children = []