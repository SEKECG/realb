from typing import Optional, Dict, List

# Roman numeral conversion
ROMAN_NUMERALS = {
    'I': 1, 'V': 5, 'X': 10, 'L': 50,
    'C': 100, 'D': 500, 'M': 1000
}

def roman_to_int(roman_str: str) -> Optional[int]:
    """Convert a Roman numeral string to an integer."""
    if not roman_str or not all(c in ROMAN_NUMERALS for c in roman_str):
        return None
    
    total = 0
    prev_value = 0
    
    for c in reversed(roman_str):
        value = ROMAN_NUMERALS[c]
        if value < prev_value:
            total -= value
        else:
            total += value
        prev_value = value
    
    return total

# Chinese number conversion
CHINESE_NUMBERS = {
    '零': 0, '〇': 0,
    '一': 1, '壹': 1,
    '二': 2, '贰': 2, '两': 2,
    '三': 3, '叁': 3,
    '四': 4, '肆': 4,
    '五': 5, '伍': 5,
    '六': 6, '陆': 6,
    '七': 7, '柒': 7,
    '八': 8, '捌': 8,
    '九': 9, '玖': 9,
    '十': 10, '拾': 10,
    '百': 100, '佰': 100,
    '千': 1000, '仟': 1000,
    '万': 10000, '萬': 10000,
    '亿': 100000000, '億': 100000000,
    '兆': 1000000000000
}

def chinese_to_int(chinese_str: str) -> Optional[int]:
    """Convert Chinese numeric characters to an integer."""
    if not chinese_str:
        return None
    
    total = 0
    current = 0
    prev_value = 0
    
    for c in chinese_str:
        if c not in CHINESE_NUMBERS:
            return None
        
        value = CHINESE_NUMBERS[c]
        
        if value >= 10:
            if current == 0:
                current = 1
            total += current * value
            current = 0
        else:
            current = value
        
        prev_value = value
    
    total += current
    return total

# Constants for pattern testing
ALL_ROMAN_NUMERALS = ['I', 'V', 'X', 'L', 'C', 'D', 'M']
ALL_CHINESE_CHARS = list(CHINESE_NUMBERS.keys())