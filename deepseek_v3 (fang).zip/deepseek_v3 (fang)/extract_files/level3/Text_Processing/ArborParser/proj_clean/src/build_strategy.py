from typing import List, Optional
from .node import TreeNode, ChainNode

def get_last_level(level_seq: List[int]) -> int:
    """Return the last element of a list of integers, or 0 if the list is empty."""
    return level_seq[-1] if level_seq else 0

def get_prefix(level_seq: List[int]) -> List[int]:
    """Return the prefix of a given sequence by removing the last element."""
    return level_seq[:-1]

def is_imm_next(front_seq: List[int], back_seq: List[int]) -> bool:
    """Determine if two nodes are immediate siblings based on their sequences."""
    if len(front_seq) == len(back_seq):
        return (get_prefix(front_seq) == get_prefix(back_seq) and 
                get_last_level(back_seq) == get_last_level(front_seq) + 1)
    elif len(back_seq) == len(front_seq) + 1:
        return front_seq == get_prefix(back_seq)
    elif len(front_seq) > len(back_seq):
        truncated = front_seq[:len(back_seq)]
        return is_imm_next(truncated, back_seq)
    return False

def is_root(node: TreeNode) -> bool:
    """Check if a node is the root of a tree."""
    return node.parent is None

class TreeBuildingStrategy:
    """Abstract base class for tree building strategies."""
    def build_tree(self, chain: List[ChainNode]) -> TreeNode:
        """Build a tree from a list of ChainNodes."""
        raise NotImplementedError

class StrictStrategy(TreeBuildingStrategy):
    """Concrete implementation of a strict tree building strategy."""
    def build_tree(self, chain: List[ChainNode]) -> TreeNode:
        """Convert chain nodes to a tree structure using strict rules."""
        if not chain:
            raise ValueError("Chain cannot be empty")
        
        root = TreeNode.from_chain_node(chain[0])
        current_parent = root
        
        for node in chain[1:]:
            tree_node = TreeNode.from_chain_node(node)
            
            if is_imm_next(current_parent.level_seq, tree_node.level_seq):
                current_parent.add_child(tree_node)
                current_parent = tree_node
            else:
                while not is_imm_next(current_parent.level_seq, tree_node.level_seq):
                    if current_parent.parent is None:
                        break
                    current_parent = current_parent.parent
                
                if is_imm_next(current_parent.level_seq, tree_node.level_seq):
                    current_parent.add_child(tree_node)
                    current_parent = tree_node
                else:
                    raise ValueError("Invalid hierarchy in strict mode")
        
        return root

class AutoPruneStrategy(TreeBuildingStrategy):
    """Concrete implementation of an auto-prune tree building strategy."""
    def build_tree(self, chain: List[ChainNode]) -> TreeNode:
        """Convert chain nodes to a tree structure using auto-prune rules."""
        if not chain:
            raise ValueError("Chain cannot be empty")
        
        root = TreeNode.from_chain_node(chain[0])
        current_parent = root
        
        for node in chain[1:]:
            tree_node = TreeNode.from_chain_node(node)
            
            if is_imm_next(current_parent.level_seq, tree_node.level_seq):
                current_parent.add_child(tree_node)
                current_parent = tree_node
            else:
                while not is_imm_next(current_parent.level_seq, tree_node.level_seq):
                    if current_parent.parent is None:
                        break
                    current_parent = current_parent.parent
                
                if is_imm_next(current_parent.level_seq, tree_node.level_seq):
                    current_parent.add_child(tree_node)
                    current_parent = tree_node
                else:
                    current_parent.add_child(tree_node)
                    current_parent = tree_node
        
        return root