import json
from pathlib import Path
from typing import List, Dict, Any, Union
from .node import TreeNode, ChainNode

class TreeBuilder:
    """Class that builds a tree using a specified strategy."""
    def __init__(self, strategy=None):
        """Initialize the TreeBuilder with a specified strategy."""
        self.strategy = strategy or StrictStrategy()

    def build_tree(self, chain: List[ChainNode]) -> TreeNode:
        """Build a tree from a list of ChainNodes using the specified strategy."""
        return self.strategy.build_tree(chain)

class TreeExporter:
    """Class for exporting trees in various formats."""
    @staticmethod
    def export_chain(chain: List[ChainNode]) -> str:
        """Export the chain as a string."""
        return '\n'.join(node.content for node in chain)

    @staticmethod
    def export_tree(tree: TreeNode) -> str:
        """Export the tree as a formatted string."""
        return TreeExporter._export_tree_internal(tree, '', True, True)

    @staticmethod
    def _export_tree_internal(node: TreeNode, prefix: str, is_last: bool, is_root: bool) -> str:
        """Recursively output the tree structure."""
        if is_root:
            line = node.level_text + ' ' + node.title
        else:
            branch = '└── ' if is_last else '├── '
            line = prefix + branch + node.level_text + ' ' + node.title
        
        result = [line]
        new_prefix = prefix + ('    ' if is_last else '│   ')
        
        for i, child in enumerate(node.children):
            result.append(TreeExporter._export_tree_internal(
                child, new_prefix, i == len(node.children) - 1, False
            ))
        
        return '\n'.join(result)

    @staticmethod
    def _node_to_dict(node: TreeNode) -> Dict[str, Any]:
        """Convert a node to dictionary format."""
        return {
            'level_seq': node.level_seq,
            'level_text': node.level_text,
            'title': node.title,
            'content': node.content,
            'children': [TreeExporter._node_to_dict(child) for child in node.children]
        }

    @staticmethod
    def export_to_json(tree: TreeNode) -> str:
        """Export the tree structure to a JSON string."""
        return json.dumps(TreeExporter._node_to_dict(tree), indent=2, ensure_ascii=False)

    @staticmethod
    def export_to_json_file(tree: TreeNode, file_path: Union[str, Path]) -> None:
        """Export the tree structure to a JSON file."""
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(TreeExporter._node_to_dict(tree), f, indent=2, ensure_ascii=False)