import re
from dataclasses import dataclass
from typing import List, Dict, Callable, Any, Optional

@dataclass
class LevelPattern:
    """A pattern for matching and converting text into a hierarchical list of integers."""
    regex: re.Pattern
    converter: Callable[[re.Match], List[int]]
    description: str

@dataclass
class NumberTypeInfo:
    """Information about a number type, including its regex pattern and conversion method."""
    pattern: str
    converter: Callable[[str], int]
    name: str

class NumberType:
    """Class containing different types of number information."""
    ARABIC = NumberTypeInfo(
        pattern=r'\d+',
        converter=lambda x: int(x),
        name='arabic'
    )
    ROMAN = NumberTypeInfo(
        pattern=r'[IVXLCDMivxlcdm]+',
        converter=lambda x: roman_to_int(x.upper()),
        name='roman'
    )
    CHINESE = NumberTypeInfo(
        pattern=r'[零一二三四五六七八九十百千万亿兆]+',
        converter=lambda x: chinese_to_int(x),
        name='chinese'
    )
    LETTER = NumberTypeInfo(
        pattern=r'[A-Za-z]',
        converter=lambda x: ord(x.upper()) - ord('A') + 1,
        name='letter'
    )
    CIRCLED = NumberTypeInfo(
        pattern=r'[⓪①-⑳]',
        converter=lambda x: int(x) if x.isdigit() else ord(x) - ord('①') + 1,
        name='circled'
    )

@dataclass
class PatternBuilder:
    """A builder for creating LevelPattern instances with configurable parameters."""
    prefix_regex: str = r'^'
    number_type: NumberTypeInfo = NumberType.ARABIC
    suffix_regex: str = r'[\.\s]'
    separator: str = '.'
    min_level: int = 1
    max_level: int = 3

    def __post_init__(self):
        """Validate the configuration of the PatternBuilder."""
        if self.min_level < 1:
            raise ValueError("min_level must be at least 1")
        if self.max_level < self.min_level:
            raise ValueError("max_level must be >= min_level")

    def build(self) -> LevelPattern:
        """Build a LevelPattern from the current configuration."""
        number_pattern = self.number_type.pattern
        separator = re.escape(self.separator)
        
        pattern = (
            f"{self.prefix_regex}"
            f"({number_pattern}(?:{separator}{number_pattern}){{{self.min_level-1},{self.max_level-1}}})"
            f"{self.suffix_regex}"
        )
        
        def converter(match: re.Match) -> List[int]:
            numbers = match.group(1).split(self.separator)
            return [self.number_type.converter(num) for num in numbers]
        
        return LevelPattern(
            regex=re.compile(pattern),
            converter=converter,
            description=f"{self.number_type.name} pattern with separator '{self.separator}'"
        )

    def modify(self, **kwargs) -> 'PatternBuilder':
        """Create a new PatternBuilder with modified attributes."""
        new_builder = PatternBuilder(
            prefix_regex=self.prefix_regex,
            number_type=self.number_type,
            suffix_regex=self.suffix_regex,
            separator=self.separator,
            min_level=self.min_level,
            max_level=self.max_level
        )
        for k, v in kwargs.items():
            setattr(new_builder, k, v)
        return new_builder

# Predefined pattern builders
NUMERIC_DOT_PATTERN_BUILDER = PatternBuilder()
NUMERIC_DASH_PATTERN_BUILDER = PatternBuilder(separator='-')
ROMAN_PATTERN_BUILDER = PatternBuilder(number_type=NumberType.ROMAN)
CHINESE_CHAPTER_PATTERN_BUILDER = PatternBuilder(number_type=NumberType.CHINESE, prefix_regex=r'^第')
ENGLISH_CHAPTER_PATTERN_BUILDER = PatternBuilder(number_type=NumberType.LETTER, prefix_regex=r'^Chapter\s')
CIRCLED_PATTERN_BUILDER = PatternBuilder(number_type=NumberType.CIRCLED)