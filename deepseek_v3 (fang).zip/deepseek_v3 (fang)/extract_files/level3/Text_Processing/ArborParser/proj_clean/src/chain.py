import re
from typing import List, Optional
from .pattern import LevelPattern
from .node import ChainNode

class ChainParser:
    """Parses text into a sequence of ChainNodes using predefined patterns."""
    def __init__(self, patterns: List[LevelPattern]):
        """Initialize the ChainParser with the given patterns."""
        self.patterns = patterns

    def _detect_level(self, line: str) -> Optional[ChainNode]:
        """Apply all patterns to detect the title hierarchy."""
        for pattern in self.patterns:
            match = pattern.regex.match(line)
            if match:
                level_seq = pattern.converter(match)
                return ChainNode(
                    level_seq=level_seq,
                    level_text=match.group(0),
                    title=line[match.end():].strip(),
                    content=line,
                    pattern_priority=self.patterns.index(pattern)
                )
        return None

    def parse_to_chain(self, text: str) -> List[ChainNode]:
        """Core parsing logic to convert text into a chain of nodes."""
        lines = text.split('\n')
        chain = []
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
                
            node = self._detect_level(line)
            if node:
                chain.append(node)
        
        return chain