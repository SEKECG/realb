from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from methods import StudentModule, TeacherModule, AdminModule
from models import db, Students, Teachers, Admins, Exams, Questions, QuestionBanks, QuestionOptions, ExamQuestions, StudentAnswers, StudentGrades
import logging
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'your_secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///exam_system.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)

student_module = StudentModule()
teacher_module = TeacherModule()
admin_module = AdminModule()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/student/register', methods=['GET', 'POST'])
def student_register():
    if request.method == 'POST':
        data = request.form if not request.is_json else request.json
        result = student_module.register(
            data.get('student_id'),
            data.get('name'),
            data.get('student_class'),
            data.get('gender'),
            data.get('phone_number'),
            data.get('password'),
            data.get('confirm_password')
        )
        if request.is_json:
            return jsonify(result)
        return redirect(url_for('home'))
    return render_template('student_register.html')

@app.route('/student/login', methods=['GET', 'POST'])
def student_login():
    if request.method == 'POST':
        data = request.form if not request.is_json else request.json
        result = student_module.login(data.get('student_id'), data.get('password'))
        if request.is_json:
            return jsonify(result)
        session['student_id'] = data.get('student_id')
        return redirect(url_for('exam_list'))
    return render_template('student_login.html')

@app.route('/student/logout')
def student_logout():
    result = student_module.logout()
    session.pop('student_id', None)
    return redirect(url_for('home'))

@app.route('/exams')
def exam_list():
    if 'student_id' not in session:
        return redirect(url_for('student_login'))
    result = student_module.list_exams()
    if request.headers.get('X-Requested-With') == 'WeChat':
        return jsonify(result)
    return render_template('exam_list.html', exams=result)

@app.route('/exam/<exam_id>', methods=['GET', 'POST'])
def take_exam(exam_id):
    if 'student_id' not in session:
        return redirect(url_for('student_login'))
    if request.method == 'POST':
        answers = request.form if not request.is_json else request.json
        result = student_module.submit_exam_answers(session['student_id'], exam_id, answers)
        if request.headers.get('X-Requested-With') == 'WeChat':
            return jsonify(result)
        return redirect(url_for('exam_list'))
    return render_template('take_exam.html', exam_id=exam_id)

@app.route('/teacher/register', methods=['GET', 'POST'])
def teacher_register():
    if request.method == 'POST':
        data = request.form
        result = teacher_module.register(
            data.get('teacher_id'),
            data.get('name'),
            data.get('gender'),
            data.get('phone_number'),
            data.get('password'),
            data.get('confirm_password')
        )
        return redirect(url_for('teacher_login'))
    return render_template('teacher_register.html')

@app.route('/teacher/login', methods=['GET', 'POST'])
def teacher_login():
    if request.method == 'POST':
        data = request.form
        result = teacher_module.login(data.get('teacher_id'), data.get('password'))
        if result.get('status') == 'success':
            session['teacher_id'] = data.get('teacher_id')
            return redirect(url_for('teacher_dashboard'))
        return render_template('teacher_login.html', error=result.get('message'))
    return render_template('teacher_login.html')

@app.route('/teacher/logout')
def teacher_logout():
    teacher_module.logout()
    session.pop('teacher_id', None)
    return redirect(url_for('home'))

@app.route('/teacher/dashboard')
def teacher_dashboard():
    if 'teacher_id' not in session:
        return redirect(url_for('teacher_login'))
    return render_template('teacher_dashboard.html')

@app.route('/teacher/exams')
def manage_exams():
    if 'teacher_id' not in session:
        return redirect(url_for('teacher_login'))
    exams = Exams.query.filter_by(teacher_id=session['teacher_id']).all()
    return render_template('manage_exams.html', exams=exams)

@app.route('/teacher/exam/create', methods=['GET', 'POST'])
def create_exam():
    if 'teacher_id' not in session:
        return redirect(url_for('teacher_login'))
    if request.method == 'POST':
        result = teacher_module.create_exam(
            request.form.get('name'),
            request.form.get('start_time'),
            request.form.get('end_time'),
            request.form.get('question_bank_id')
        )
        if result.get('status') == 'success':
            return redirect(url_for('edit_exam', exam_id=result.get('exam_id')))
    question_banks = QuestionBanks.query.all()
    return render_template('create_exam.html', question_banks=question_banks)

@app.route('/teacher/exam/<exam_id>/edit', methods=['GET', 'POST'])
def edit_exam(exam_id):
    if 'teacher_id' not in session:
        return redirect(url_for('teacher_login'))
    exam = Exams.query.get(exam_id)
    if request.method == 'POST':
        result = teacher_module.edit_exam(
            exam_id,
            request.form.get('name'),
            request.form.get('start_time'),
            request.form.get('end_time')
        )
        if result.get('status') == 'success':
            return redirect(url_for('manage_exams'))
    return render_template('edit_exam.html', exam=exam)

@app.route('/teacher/exam/<exam_id>/delete')
def delete_exam(exam_id):
    if 'teacher_id' not in session:
        return redirect(url_for('teacher_login'))
    result = teacher_module.delete_exam(exam_id)
    return redirect(url_for('manage_exams'))

@app.route('/teacher/question_banks')
def manage_question_banks():
    if 'teacher_id' not in session:
        return redirect(url_for('teacher_login'))
    question_banks = QuestionBanks.query.all()
    return render_template('manage_question_banks.html', question_banks=question_banks)

@app.route('/teacher/question_bank/<question_bank_id>')
def question_bank_details(question_bank_id):
    if 'teacher_id' not in session:
        return redirect(url_for('teacher_login'))
    question_bank = QuestionBanks.query.get(question_bank_id)
    questions = Questions.query.filter_by(question_bank_id=question_bank_id).all()
    return render_template('question_bank_details.html', question_bank=question_bank, questions=questions)

@app.route('/teacher/question/<question_bank_id>/<question_id>/edit', methods=['GET', 'POST'])
def edit_question(question_bank_id, question_id):
    if 'teacher_id' not in session:
        return redirect(url_for('teacher_login'))
    question = Questions.query.get(question_id)
    if request.method == 'POST':
        result = teacher_module.update_question(
            question_id,
            request.form.get('question_type'),
            request.form.get('content'),
            request.form.get('answer')
        )
        if result.get('status') == 'success':
            return redirect(url_for('question_bank_details', question_bank_id=question_bank_id))
    return render_template('edit_question.html', question=question)

@app.route('/teacher/exam/<exam_id>/grade')
def grade_exam(exam_id):
    if 'teacher_id' not in session:
        return redirect(url_for('teacher_login'))
    result = teacher_module.auto_grade_exam(exam_id)
    return redirect(url_for('view_grades', exam_id=exam_id))

@app.route('/teacher/exam/<exam_id>/grades')
def view_grades(exam_id):
    if 'teacher_id' not in session:
        return redirect(url_for('teacher_login'))
    result = teacher_module.view_exam_grades(exam_id)
    return render_template('view_grades.html', grades=result)

@app.route('/teacher/exam/<exam_id>/report')
def exam_report(exam_id):
    if 'teacher_id' not in session:
        return redirect(url_for('teacher_login'))
    result = teacher_module.generate_exam_report(exam_id)
    return render_template('exam_report.html', report=result)

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        result = admin_module.login(request.form.get('username'), request.form.get('password'))
        if result.get('status') == 'success':
            session['admin_id'] = request.form.get('username')
            return redirect(url_for('admin_dashboard'))
        return render_template('admin_login.html', error=result.get('message'))
    return render_template('admin_login.html')

@app.route('/admin/logout')
def admin_logout():
    admin_module.logout()
    session.pop('admin_id', None)
    return redirect(url_for('home'))

@app.route('/admin/dashboard')
def admin_dashboard():
    if 'admin_id' not in session:
        return redirect(url_for('admin_login'))
    return render_template('admin_dashboard.html')

@app.route('/admin/students')
def manage_students():
    if 'admin_id' not in session:
        return redirect(url_for('admin_login'))
    students = Students.query.all()
    return render_template('manage_students.html', students=students)

@app.route('/admin/student/add', methods=['GET', 'POST'])
def add_student_page():
    if 'admin_id' not in session:
        return redirect(url_for('admin_login'))
    if request.method == 'POST':
        result = admin_module.modify_student_account('add', None, {
            'student_id': request.form.get('student_id'),
            'name': request.form.get('name'),
            'student_class': request.form.get('student_class'),
            'gender': request.form.get('gender'),
            'phone_number': request.form.get('phone_number'),
            'password': request.form.get('password')
        })
        if result.get('status') == 'success':
            return redirect(url_for('manage_students'))
    return render_template('add_student.html')

@app.route('/admin/student/<student_id>/update', methods=['GET', 'POST'])
def update_student(student_id):
    if 'admin_id' not in session:
        return redirect(url_for('admin_login'))
    student = Students.query.get(student_id)
    if request.method == 'POST':
        result = admin_module.modify_student_account('update', student_id, {
            'name': request.form.get('name'),
            'gender': request.form.get('gender'),
            'phone_number': request.form.get('phone_number'),
            'password': request.form.get('password')
        })
        if result.get('status') == 'success':
            return redirect(url_for('manage_students'))
    return render_template('update_student.html', student=student)

@app.route('/admin/student/<student_id>/delete')
def delete_student(student_id):
    if 'admin_id' not in session:
        return redirect(url_for('admin_login'))
    result = admin_module.modify_student_account('delete', student_id, None)
    return redirect(url_for('manage_students'))

@app.route('/admin/teachers')
def manage_teachers():
    if 'admin_id' not in session:
        return redirect(url_for('admin_login'))
    teachers = Teachers.query.all()
    return render_template('manage_teachers.html', teachers=teachers)

@app.route('/admin/teacher/add', methods=['GET', 'POST'])
def add_teacher_page():
    if 'admin_id' not in session:
        return redirect(url_for('admin_login'))
    if request.method == 'POST':
        result = admin_module.modify_teacher_account('add', None, {
            'teacher_id': request.form.get('teacher_id'),
            'name': request.form.get('name'),
            'gender': request.form.get('gender'),
            'phone_number': request.form.get('phone_number'),
            'password': request.form.get('password')
        })
        if result.get('status') == 'success':
            return redirect(url_for('manage_teachers'))
    return render_template('add_teacher.html')

@app.route('/admin/teacher/<teacher_id>/update', methods=['GET', 'POST'])
def update_teacher(teacher_id):
    if 'admin_id' not in session:
        return redirect(url_for('admin_login'))
    teacher = Teachers.query.get(teacher_id)
    if request.method == 'POST':
        result = admin_module.modify_teacher_account('update', teacher_id, {
            'name': request.form.get('name'),
            'gender': request.form.get('gender'),
            'phone_number': request.form.get('phone_number'),
            'password': request.form.get('password')
        })
        if result.get('status') == 'success':
            return redirect(url_for('manage_teachers'))
    return render_template('update_teacher.html', teacher=teacher)

@app.route('/admin/teacher/<teacher_id>/delete')
def delete_teacher(teacher_id):
    if 'admin_id' not in session:
        return redirect(url_for('admin_login'))
    result = admin_module.modify_teacher_account('delete', teacher_id, None)
    return redirect(url_for('manage_teachers'))

@app.route('/admin/logs')
def view_logs():
    if 'admin_id' not in session:
        return redirect(url_for('admin_login'))
    log_file = f"logs/{datetime.now().strftime('%Y-%m-%d')}.log"
    try:
        with open(log_file, 'r') as f:
            logs = f.read()
    except FileNotFoundError:
        logs = "No logs found for today"
    return render_template('view_logs.html', logs=logs)

def char_from_index(index):
    return chr(ord('A') + index - 1)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)