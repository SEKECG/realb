import os
import subprocess
import requests
import json
from tree_sitter import Language, Parser
import shutil
from pathlib import Path

# Initialize tree-sitter for C/C++ parsing
Language.build_library(
    'build/my-languages.so',
    ['vendor/tree-sitter-c', 'vendor/tree-sitter-cpp']
)
CPP_LANGUAGE = Language('build/my-languages.so', 'cpp')
parser = Parser()
parser.set_language(CPP_LANGUAGE)

def LLM_analyze(del_lines, patch, add_lines, patch_last, funcs):
    """
    Determine if a vulnerability in a fix commit was introduced by a historical patch.
    Uses an LLM to analyze patch differences and output a JSON response.
    """
    # This would be replaced with actual LLM API calls in a real implementation
    prompt = f"""
    Analyze these code changes to determine if a vulnerability was introduced:
    
    Original code (deleted lines):
    {del_lines}
    
    New code (added lines):
    {add_lines}
    
    Current patch:
    {patch}
    
    Previous patch:
    {patch_last}
    
    Affected functions:
    {funcs}
    
    Was this change likely to introduce a vulnerability? Respond with JSON: {{"is_vulnerability": bool, "confidence": float, "reason": str}}
    """
    
    # Simulated LLM response
    return {
        "is_vulnerability": True,
        "confidence": 0.85,
        "reason": "The change removes a security check without adding proper validation"
    }

def LLM_vulfix(description, patch):
    """
    Determine if a given patch is related to a vulnerability fix.
    Returns 1 if it is, 0 if not.
    """
    # Simulated LLM analysis
    vul_keywords = ['vulnerability', 'security', 'CVE', 'buffer overflow', 'race condition']
    if any(keyword.lower() in description.lower() for keyword in vul_keywords):
        return 1
    
    # Check patch content for security fixes
    if 'sanitize' in patch or 'validate' in patch or 'check' in patch:
        return 1
    
    return 0

def delete_folder_if_smaller_than_1gb(folder_path):
    """Delete a folder if its size is smaller than 1GB."""
    size = get_folder_size(folder_path)
    if size < 1e9:  # 1GB in bytes
        shutil.rmtree(folder_path)
        return True
    return False

def file_download(url, save_path):
    """Download a file from a URL and save it locally."""
    headers = {'Authorization': 'token YOUR_GITHUB_TOKEN'}
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        with open(save_path, 'wb') as f:
            f.write(response.content)
        return True
    return False

def find_function_define(root_node, code, line_number):
    """Find the function definition containing the given line number."""
    query = CPP_LANGUAGE.query("""
    (function_definition
        body: (compound_statement) @body) @function
    """)
    
    captures = query.captures(root_node)
    for node, _ in captures:
        start_line = node.start_point[0] + 1
        end_line = node.end_point[0] + 1
        
        if start_line <= line_number <= end_line:
            function_code = code.split('\n')[start_line-1:end_line]
            function_name = "unknown"
            # Try to extract function name
            if node.child_by_field_name('declarator'):
                declarator = node.child_by_field_name('declarator')
                if declarator.child_by_field_name('declarator'):
                    declarator = declarator.child_by_field_name('declarator')
                if declarator.type == 'identifier':
                    function_name = code.split('\n')[declarator.start_point[0]][declarator.start_point[1]:declarator.end_point[1]]
            
            return '\n'.join(function_code), function_name
    
    return None, None

def get_add_lines(patch):
    """Extract added/deleted lines from a patch."""
    if not patch:
        return []
    
    lines = []
    for line in patch.split('\n'):
        if line.startswith('-') or line.startswith('+'):
            lines.append(line[1:].strip())
    
    return lines

def get_commit(filepath, repo, sha):
    """Get commit history for a specific file."""
    cmd = f'git log --follow --pretty=format:"%H" -- {filepath}'
    result = run_git_command(cmd, repo)
    if not result:
        return []
    
    commits = result.strip().split('\n')
    return commits

def get_commit_information(repo_url):
    """Get detailed commit information from GitHub API."""
    api_url = f"https://api.github.com/repos/{repo_url}/commits"
    headers = {'Authorization': 'token YOUR_GITHUB_TOKEN'}
    response = requests.get(api_url, headers=headers)
    if response.status_code == 200:
        return response.json()
    return None

def get_file_history(repo_path, file_path):
    """Get file history including renames."""
    cmd = f'git -C {repo_path} log --follow --name-only --pretty=format: -- {file_path}'
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    if result.returncode == 0:
        return result.stdout.strip().split('\n')
    return []

def get_folder_size(folder_path):
    """Calculate folder size excluding .git directories."""
    total_size = 0
    for dirpath, dirnames, filenames in os.walk(folder_path):
        if '.git' in dirnames:
            dirnames.remove('.git')
        for f in filenames:
            fp = os.path.join(dirpath, f)
            total_size += os.path.getsize(fp)
    return total_size

def get_func(file_path, line_number):
    """Extract function definition at a specific line."""
    with open(file_path, 'r') as f:
        code = f.read()
    
    tree = parser.parse(bytes(code, 'utf8'))
    return find_function_define(tree.root_node, code, line_number)

def get_functions(commit):
    """Get modified functions from a commit."""
    # This would need actual implementation to download files and analyze changes
    return []

def get_line(patch):
    """Extract line numbers from a patch."""
    if not patch:
        return None
    
    # Example patch header: @@ -50,6 +50,7 @@
    lines = patch.split('\n')
    for line in lines:
        if line.startswith('@@'):
            parts = line.split(' ')
            old_line = parts[1].split(',')[0][1:]
            return int(old_line)
    return None

def get_repo(url):
    """Extract repository name from URL."""
    if 'github.com' in url:
        parts = url.split('github.com/')[1].split('/')
        return f"{parts[0]}/{parts[1]}"
    return None

def run_git_command(command, repo_path):
    """Run a git command in the specified repository."""
    try:
        result = subprocess.run(
            f'git -C {repo_path} {command}',
            shell=True,
            check=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        return result.stdout
    except subprocess.CalledProcessError as e:
        print(f"Git command failed: {e.stderr}")
        return None

def url_change(url):
    """Convert GitHub commit URL to repository Git URL."""
    if 'github.com' in url and '/commit/' in url:
        repo_part = url.split('github.com/')[1].split('/commit/')[0]
        return f"https://github.com/{repo_part}.git"
    return url

def vul_intro_check(commit_infor):
    """Extract modified files from commit information."""
    if not commit_infor or 'files' not in commit_infor:
        return []
    
    return [f['filename'] for f in commit_infor['files']]

# Main execution
if __name__ == "__main__":
    # Example usage
    repo_url = "https://github.com/example/repo"
    commit_info = get_commit_information(repo_url)
    if commit_info:
        modified_files = vul_intro_check(commit_info[0])
        print(f"Modified files: {modified_files}")