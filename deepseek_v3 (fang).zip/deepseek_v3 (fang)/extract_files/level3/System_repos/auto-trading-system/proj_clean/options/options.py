from datetime import datetime, timedelta
from configs.utils import OptionInstruction, OptionType, TradeReason
import pandas as pd

class Options:
    def __init__(self, position_json):
        self.position_json = position_json
        self.option_symbol = position_json.get('symbol', '')
        self.ticker = self.option_symbol.split()[0]
        self.option_type = OptionType.CALL if 'C' in self.option_symbol else OptionType.PUT
        self.short_quantity = position_json.get('shortQuantity', 0)
        
        # Parse expiration date and strike price from symbol
        parts = self.option_symbol.split()
        if len(parts) >= 2:
            date_part = parts[1][:6]
            strike_part = parts[1][7:]
            self.expiration_date = datetime.strptime(date_part, '%y%m%d').date()
            self.strike_price = float(strike_part) / 1000
        
        self.option_cost = position_json.get('averagePrice', 0)
        self.option_market_price = position_json.get('currentMarketValue', 0) / self.short_quantity if self.short_quantity else 0
        self.profit = (self.option_cost - self.option_market_price) * self.short_quantity
        self.stock_price = 0
        self.delta = 0
        self.theta = 0
        self.theta_decay_percentage = 0

    @staticmethod
    def create_an_option_order(ticker, expiration_date, strike_price, option_price, quantity, option_type, instruction):
        return {
            'ticker': ticker,
            'expiration_date': expiration_date,
            'strike_price': strike_price,
            'option_price': option_price,
            'quantity': quantity,
            'option_type': option_type,
            'instruction': instruction
        }

    @staticmethod
    def form_an_option_symbol(ticker, expiration_date, strike_price, option_type):
        date_str = expiration_date.strftime('%y%m%d')
        strike_str = f"{int(strike_price * 1000):08d}"
        return f"{ticker}  {date_str}{option_type.value[0]}{strike_str}"

    def create_btc_order(self):
        profit = (self.option_cost - self.option_market_price) * self.short_quantity
        return {
            'ticker': self.ticker,
            'expiration_date': self.expiration_date,
            'strike_price': self.strike_price,
            'option_price': self.option_market_price,
            'quantity': self.short_quantity,
            'option_type': self.option_type,
            'instruction': OptionInstruction.BUY_TO_CLOSE,
            'profit': profit
        }

    def create_a_rollout_order(self, new_expiration_date, new_strike_price, new_option_price):
        btc_order = self.create_btc_order()
        sto_order = self.create_an_option_order(
            self.ticker, new_expiration_date, new_strike_price, 
            new_option_price, self.short_quantity, self.option_type, 
            OptionInstruction.SELL_TO_OPEN
        )
        return {
            'btc_order': btc_order,
            'sto_order': sto_order,
            'net_credit': (new_option_price - self.option_market_price) * self.short_quantity
        }

    def is_gain_larger_than_50_percent(self):
        return self.option_market_price < 0.5 * self.option_cost

    def is_winning(self, max_delta_for_btc):
        if not self.is_gain_larger_than_50_percent():
            return False
        
        if self.option_type == OptionType.PUT:
            return self.delta >= -max_delta_for_btc
        else:
            return self.delta <= max_delta_for_btc

    def is_losing(self):
        if self.option_type == OptionType.CALL:
            return False
            
        days_to_expire = (self.expiration_date - datetime.now().date()).days
        if days_to_expire > 14:
            return False
            
        intrinsic_value = max(0, self.strike_price - self.stock_price)
        extrinsic_value = self.option_market_price - intrinsic_value
        return extrinsic_value < 0.005 * self.strike_price

    def set_stock_price(self, stock_price):
        self.stock_price = stock_price

    def set_delta(self, delta):
        self.delta = delta

    def set_theta(self, theta):
        self.theta = theta

    def sto_after_a_win(self, option_chains, min_expiration_weeks, min_delta, max_delta, min_premium_percentage, min_premium):
        if self.option_type == OptionType.PUT:
            candidates = option_chains.get_option_candidates_from_expiration_date_and_delta_range(
                datetime.now().date() + timedelta(weeks=min_expiration_weeks),
                min_delta, max_delta, min_premium_percentage, min_premium, self.option_type
            )
        else:
            candidates = option_chains.get_call_option_candidates_from_min_strike_price_and_min_premium_percentage(
                self.strike_price, min_premium, min_premium_percentage
            )
        
        if candidates:
            best_candidate = candidates[0]
            return self.create_an_option_order(
                self.ticker, best_candidate['expirationDate'], best_candidate['strikePrice'],
                best_candidate['mark'], self.short_quantity, self.option_type, OptionInstruction.SELL_TO_OPEN
            )
        return None

    def sto_after_btc_a_loss(self, option_chains):
        max_strike_price = self.strike_price * 0.98
        min_premium = self.option_market_price + 0.3
        
        candidates = option_chains.get_put_option_candidates_from_max_strike_price_and_min_premium(
            max_strike_price, min_premium
        )
        
        if candidates:
            best_candidate = candidates[0]
            return (
                self.create_an_option_order(
                    self.ticker, best_candidate['expirationDate'], best_candidate['strikePrice'],
                    best_candidate['mark'], self.short_quantity, self.option_type, OptionInstruction.SELL_TO_OPEN
                ),
                best_candidate['expirationDate']
            )
        return None, None

    @staticmethod
    def sto_an_option_order(ticker, option_chains, quantity, option_type, min_expiration_weeks, min_delta, max_delta, min_premium_percentage, min_premium, cost_basis):
        if option_type == OptionType.PUT:
            candidates = option_chains.get_option_candidates_from_expiration_date_and_delta_range(
                datetime.now().date() + timedelta(weeks=min_expiration_weeks),
                min_delta, max_delta, min_premium_percentage, min_premium, option_type
            )
        else:
            candidates = option_chains.get_call_option_candidates_from_min_strike_price_and_min_premium_percentage(
                cost_basis, min_premium, min_premium_percentage
            )
        
        if candidates:
            best_candidate = candidates[0]
            return {
                'ticker': ticker,
                'expiration_date': best_candidate['expirationDate'],
                'strike_price': best_candidate['strikePrice'],
                'option_price': best_candidate['mark'],
                'quantity': quantity,
                'option_type': option_type,
                'instruction': OptionInstruction.SELL_TO_OPEN
            }
        return None