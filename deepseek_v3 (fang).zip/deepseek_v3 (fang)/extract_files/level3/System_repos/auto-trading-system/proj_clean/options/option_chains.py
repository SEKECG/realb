import pandas as pd
from datetime import datetime

EXISTING_OPTION_CHAINS_COLUMNS = [
    'symbol', 'description', 'bid', 'ask', 'mark', 'bidSize', 'askSize', 
    'last', 'highPrice', 'lowPrice', 'openPrice', 'closePrice', 
    'totalVolume', 'openInterest', 'volatility', 'delta', 'gamma', 
    'theta', 'vega', 'rho', 'timeValue', 'theoreticalOptionValue', 
    'theoreticalVolatility', 'strikePrice', 'expirationDate', 
    'daysToExpiration', 'expirationType', 'lastTradingDay', 
    'multiplier', 'settlementType', 'deliverableNote', 
    'isIndexOption', 'percentChange', 'markChange', 'markPercentChange'
]

OPTION_CHAINS_COLUMNS = [
    'symbol', 'description', 'bid', 'ask', 'mark', 'totalVolume', 
    'openInterest', 'volatility', 'delta', 'theta', 'strikePrice', 
    'expirationDate', 'daysToExpiration', 'option_type'
]

class OptionChains:
    def __init__(self, option_chains_json):
        self.option_chains_json = option_chains_json
        self.call_option_chains_json = option_chains_json.get('callExpDateMap', {})
        self.put_option_chains_json = option_chains_json.get('putExpDateMap', {})
        
        calls = []
        for exp_date, strikes in self.call_option_chains_json.items():
            for strike, options in strikes.items():
                for option in options:
                    option['option_type'] = 'CALL'
                    calls.append(option)
        
        puts = []
        for exp_date, strikes in self.put_option_chains_json.items():
            for strike, options in strikes.items():
                for option in options:
                    option['option_type'] = 'PUT'
                    puts.append(option)
        
        all_options = calls + puts
        self.option_chains_df = pd.DataFrame(all_options)
        if not self.option_chains_df.empty:
            self.option_chains_df = self.option_chains_df[OPTION_CHAINS_COLUMNS]
            self.option_chains_df['expirationDate'] = pd.to_datetime(self.option_chains_df['expirationDate']).dt.date

    def filter_option_candidates(self):
        if self.option_chains_df.empty:
            return pd.DataFrame()
        
        filtered = self.option_chains_df[
            (self.option_chains_df['openInterest'] > 0) &
            (self.option_chains_df['totalVolume'] > 0) &
            (self.option_chains_df['bid'].notna()) &
            (self.option_chains_df['ask'].notna()) &
            ((self.option_chains_df['ask'] - self.option_chains_df['bid']) / self.option_chains_df['mark'] < 0.1)
        ]
        return filtered

    def get_option_candidates_from_expiration_date_and_delta_range(self, min_expiration_date, min_delta, max_delta, min_premium_percentage, min_premium, option_type):
        filtered = self.filter_option_candidates()
        if filtered.empty:
            return []
        
        candidates = filtered[
            (filtered['option_type'] == option_type) &
            (filtered['expirationDate'] >= min_expiration_date) &
            (filtered['delta'] >= min_delta) &
            (filtered['delta'] <= max_delta) &
            (filtered['mark'] / filtered['strikePrice'] >= min_premium_percentage) &
            (filtered['mark'] >= min_premium)
        ]
        
        candidates = candidates.sort_values(
            by=['expirationDate', 'mark', 'delta'],
            ascending=[True, False, True if option_type == 'PUT' else False]
        )
        
        return candidates.to_dict('records')

    def get_call_option_candidates_from_min_strike_price_and_min_premium_percentage(self, min_strike_price, min_premium, min_premium_percentage):
        filtered = self.filter_option_candidates()
        if filtered.empty:
            return []
        
        candidates = filtered[
            (filtered['option_type'] == 'CALL') &
            (filtered['strikePrice'] >= min_strike_price) &
            (filtered['mark'] >= min_premium) &
            (filtered['mark'] / filtered['strikePrice'] >= min_premium_percentage)
        ]
        
        candidates = candidates.sort_values(
            by=['expirationDate', 'mark', 'delta'],
            ascending=[True, False, False]
        )
        
        return candidates.to_dict('records')

    def get_put_option_candidates_from_max_strike_price_and_min_premium(self, max_strike_price, min_premium):
        filtered = self.filter_option_candidates()
        if filtered.empty:
            return []
        
        candidates = filtered[
            (filtered['option_type'] == 'PUT') &
            (filtered['strikePrice'] <= max_strike_price) &
            (filtered['mark'] >= min_premium)
        ]
        
        candidates = candidates.sort_values(
            by=['expirationDate', 'mark', 'delta'],
            ascending=[True, False, True]
        )
        
        return candidates.to_dict('records')

    def get_delta_from_option_symbol(self, option_symbol):
        if self.option_chains_df.empty:
            return 0.0
        
        option = self.option_chains_df[self.option_chains_df['symbol'] == option_symbol]
        if option.empty:
            return 0.0
        
        return option.iloc[0]['delta']

    def get_theta_from_option_symbol(self, option_symbol):
        if self.option_chains_df.empty:
            return 0.0
        
        option = self.option_chains_df[self.option_chains_df['symbol'] == option_symbol]
        if option.empty:
            return 0.0
        
        return option.iloc[0]['theta']