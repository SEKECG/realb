import os
import matplotlib.pyplot as plt
from enum import Enum

TOP_LEVEL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

class OptionInstruction(Enum):
    BUY_TO_OPEN = "BUY_TO_OPEN"
    SELL_TO_OPEN = "SELL_TO_OPEN"
    BUY_TO_CLOSE = "BUY_TO_CLOSE"
    SELL_TO_CLOSE = "SELL_TO_CLOSE"

class OptionType(Enum):
    CALL = "CALL"
    PUT = "PUT"

class StockInstruction(Enum):
    BUY = "BUY"
    SELL = "SELL"

class TradeReason(Enum):
    BTC_FROM_LOSING = "BTC_FROM_LOSING"
    BTC_FROM_WINNING = "BTC_FROM_WINNING"
    ROLLOUT_FROM_LOSING = "ROLLOUT_FROM_LOSING"
    ROLLOUT_FROM_WINNING = "ROLLOUT_FROM_WINNING"
    STO_FROM_EARNINGS = "STO_FROM_EARNINGS"
    STO_FROM_LARGE_PRICE_CHANGE = "STO_FROM_LARGE_PRICE_CHANGE"
    STO_FROM_LOSING = "STO_FROM_LOSING"
    STO_FROM_THE_WHEEL = "STO_FROM_THE_WHEEL"
    STO_FROM_WINNING = "STO_FROM_WINNING"
    STO_FROM_other = "STO_FROM_other"

def sum_of_option_strike_prices(call_option_tickers, option_type):
    total = 0.0
    for ticker in call_option_tickers:
        parts = ticker.split('C' if option_type == OptionType.CALL else 'P')
        if len(parts) > 1:
            strike_str = parts[1][:8]
            strike = float(strike_str) / 1000
            total += strike
    return total

def theta_scatter_plot(ax, deltas, theta_decay_percentages, expiration_dates, strike_prices, tickers, subtitle):
    scatter = ax.scatter(
        deltas, 
        theta_decay_percentages,
        s=[s/10 for s in strike_prices],
        c=expiration_dates,
        alpha=0.5
    )
    ax.set_xlabel('Delta')
    ax.set_ylabel('Theta Decay Percentage')
    ax.set_title(f'Theta Decay Analysis\n{subtitle}')
    
    for i, ticker in enumerate(tickers):
        ax.annotate(ticker, (deltas[i], theta_decay_percentages[i]))
    
    plt.colorbar(scatter, label='Days to Expiration')
    legend1 = ax.legend(*scatter.legend_elements(), title="Strike Prices")
    ax.add_artist(legend1)