import pkg_resources
from typing import Optional, Dict, Any
from .models import (
    ConfigNodeRequest, ConfigNodeResponse, NodesResponse, 
    ActionsResponse, ActionsChangeResponse, NodeInfo, 
    NodesInfoResponse
)
from .utils import DucoUrlSession

class APIClient:
    def __init__(self, base_url, verify):
        self.base_url = base_url.rstrip('/')
        self.session = DucoUrlSession(base_url, verify)

    def _duco_pem(self):
        return pkg_resources.resource_filename(__name__, "duco.pem")

    def close(self):
        self.session.close()

    def raw_get(self, endpoint, params=None):
        response = self.session.get(endpoint, params=params)
        return response.json()

    def get_api_info(self):
        response = self.session.get("/api")
        return response.json()

    def get_info(self, module=None, submodule=None, parameter=None):
        params = {}
        if module:
            params["Module"] = module
        if submodule:
            params["SubModule"] = submodule
        if parameter:
            params["Parameter"] = parameter
        
        response = self.session.get("/api/info", params=params)
        return response.json()

    def get_logs(self):
        response = self.session.get("/api/logs")
        return response.json()

    def get_nodes(self):
        response = self.session.get("/api/nodes")
        return NodesInfoResponse(**response.json())

    def get_node_info(self, node_id):
        response = self.session.get(f"/api/nodes/{node_id}")
        return NodeInfo(**response.json())

    def get_config_nodes(self):
        response = self.session.get("/api/nodes/config")
        return NodesResponse(**response.json())

    def get_config_node(self, node_id):
        response = self.session.get(f"/api/nodes/{node_id}/config")
        return ConfigNodeResponse(**response.json())

    def patch_config_node(self, node_id, config):
        if not isinstance(config, ConfigNodeRequest):
            config = ConfigNodeRequest(**config)
        
        response = self.session.patch(
            f"/api/nodes/{node_id}/config",
            json=config.dict(exclude_unset=True)
        )
        return ConfigNodeResponse(**response.json())

    def get_actions_node(self, node_id, action=None):
        params = {"Action": action} if action else None
        response = self.session.get(f"/api/nodes/{node_id}/actions", params=params)
        return ActionsResponse(**response.json())

    def get_action(self, action):
        response = self.session.get("/api/actions", params={"Action": action})
        return response.json()

    def post_action_node(self, action, value, node_id):
        actions = self.get_actions_node(node_id, action)
        action_info = next((a for a in actions.Actions if a.Action == action), None)
        
        if not action_info:
            raise ValueError(f"Action {action} not found for node {node_id}")
        
        if action_info.ValType == "Enum":
            if str(value) not in [str(opt["Val"]) for opt in action_info.Enum]:
                raise ValueError(f"Value {value} not in allowed values for action {action}")
        elif action_info.ValType == "Bool":
            value = bool(value)
        elif action_info.ValType == "Int":
            value = int(value)
        
        response = self.session.post(
            f"/api/nodes/{node_id}/actions",
            json={"Action": action, "Value": value}
        )
        return ActionsChangeResponse(**response.json())