from typing import Optional, Union, Any, Dict, List
from pydantic import BaseModel, validator, root_validator
import pkg_resources

PYDANTIC_V2 = pkg_resources.parse_version(
    pkg_resources.get_distribution("pydantic").version
) >= pkg_resources.parse_version("2.0.0")

def extract_val(data):
    if isinstance(data, dict) and "Val" in data:
        return data["Val"]
    return data

def unified_validator(*uargs, **ukwargs):
    def decorator(f):
        if PYDANTIC_V2:
            return validator(*uargs, **ukwargs, mode="before")(f)
        return validator(*uargs, **ukwargs, pre=True)(f)
    return decorator

class ParameterConfig(BaseModel):
    Val: Optional[Union[str, int]] = None
    Id: Optional[int] = None
    Min: Optional[int] = None
    Max: Optional[int] = None
    Inc: Optional[int] = None

    @root_validator(pre=True)
    def ensure_keys(cls, values):
        expected_keys = ["Val", "Id", "Min", "Max", "Inc"]
        for key in expected_keys:
            if key not in values:
                values[key] = None
        return values

class ConfigNodeRequest(BaseModel):
    Name: Optional[str] = None
    FlowLvlAutoMin: Optional[int] = None
    FlowLvlAutoMax: Optional[int] = None
    FlowLvlMan1: Optional[int] = None
    FlowLvlMan2: Optional[int] = None
    FlowLvlMan3: Optional[int] = None
    FlowLvlSwitch: Optional[int] = None
    FlowMax: Optional[int] = None
    Co2SetPoint: Optional[int] = None
    RhSetPoint: Optional[int] = None
    RhDetMode: Optional[int] = None
    ShowSensorLvl: Optional[int] = None
    SwitchMode: Optional[int] = None
    TempDepEnable: Optional[int] = None
    TimeMan: Optional[int] = None

class ConfigNodeResponse(BaseModel):
    SerialBoard: str
    SerialDuco: str
    Name: Optional[ParameterConfig] = None
    FlowLvlAutoMin: Optional[ParameterConfig] = None
    FlowLvlAutoMax: Optional[ParameterConfig] = None
    FlowLvlMan1: Optional[ParameterConfig] = None
    FlowLvlMan2: Optional[ParameterConfig] = None
    FlowLvlMan3: Optional[ParameterConfig] = None
    FlowLvlSwitch: Optional[ParameterConfig] = None
    FlowMax: Optional[ParameterConfig] = None
    Co2SetPoint: Optional[ParameterConfig] = None
    RhSetPoint: Optional[ParameterConfig] = None
    RhDetMode: Optional[ParameterConfig] = None
    ShowSensorLvl: Optional[ParameterConfig] = None
    SwitchMode: Optional[ParameterConfig] = None
    TempDepEnable: Optional[ParameterConfig] = None
    TimeMan: Optional[ParameterConfig] = None

class NodeConfig(BaseModel):
    SerialBoard: str
    SerialDuco: str
    Name: Optional[ParameterConfig] = None
    FlowLvlAutoMin: Optional[ParameterConfig] = None
    FlowLvlAutoMax: Optional[ParameterConfig] = None
    FlowLvlMan1: Optional[ParameterConfig] = None
    FlowLvlMan2: Optional[ParameterConfig] = None
    FlowLvlMan3: Optional[ParameterConfig] = None
    FlowLvlSwitch: Optional[ParameterConfig] = None
    FlowMax: Optional[ParameterConfig] = None
    Co2SetPoint: Optional[ParameterConfig] = None
    RhSetPoint: Optional[ParameterConfig] = None
    RhDetMode: Optional[ParameterConfig] = None
    ShowSensorLvl: Optional[ParameterConfig] = None
    SwitchMode: Optional[ParameterConfig] = None
    TempDepEnable: Optional[ParameterConfig] = None
    TimeMan: Optional[ParameterConfig] = None

class NodesResponse(BaseModel):
    Nodes: List[NodeConfig]

class GeneralInfo(BaseModel):
    Val: str
    Id: Optional[int] = None

class NodeGeneralInfo(BaseModel):
    Type: str
    Addr: int

    @unified_validator("Addr")
    def validate_addr(cls, v):
        return extract_val(v)

class NetworkDucoInfo(BaseModel):
    CommErrorCtr: int

    @unified_validator("CommErrorCtr")
    def validate_comm_error_ctr(cls, values):
        values["CommErrorCtr"] = extract_val(values["CommErrorCtr"])
        return values

class VentilationInfo(BaseModel):
    State: Optional[str] = None
    FlowLvlOvrl: int
    FlowLvlTgt: Optional[int] = None
    TimeStateRemain: Optional[int] = None
    TimeStateEnd: Optional[int] = None
    Mode: Optional[str] = None

    @unified_validator("*")
    def validate_ventilation_fields(cls, values):
        for field in values:
            if field in ["TimeStateRemain", "TimeStateEnd"]:
                if isinstance(values[field], str) and values[field] == "-":
                    values[field] = None
                else:
                    values[field] = extract_val(values[field])
            else:
                values[field] = extract_val(values[field])
        return values

class SensorData(BaseModel):
    data: Optional[Dict[str, Union[int, float, str]]] = None

    @root_validator(pre=True)
    def extract_sensor_values(cls, values):
        data = {}
        for field, value in values.items():
            if isinstance(value, dict) and "Val" in value:
                data[field] = value["Val"]
            else:
                data[field] = value
        return {"data": data}

class NodeInfo(BaseModel):
    General: NodeGeneralInfo
    NetworkDuco: NetworkDucoInfo
    Ventilation: VentilationInfo
    Sensor: Optional[SensorData] = None

class NodesInfoResponse(BaseModel):
    Nodes: Optional[List[NodeInfo]] = None

class ActionInfo(BaseModel):
    Action: str
    ValType: str
    Enum: Optional[List[Dict[str, Any]]] = None

    @root_validator(pre=True)
    def set_optional_enum(cls, values):
        if values.get("ValType") != "Enum":
            values.pop("Enum", None)
        return values

class ActionsResponse(BaseModel):
    NodeId: int
    Actions: List[ActionInfo]

class ActionsChangeResponse(BaseModel):
    Status: int
    Result: str

class FirmwareResponse(BaseModel):
    Uploaded: str
    Version: str
    Size: int
    Files: List[Dict[str, Union[str, int]]]
    Name: str
    Type: str
    Crc: int