import time

class ApiKeyGenerator:
    def generate_api_key(self, board_serial, mac_address, time):
        combined = f"{board_serial}{mac_address}{time}"
        key = ""
        
        for i in range(0, len(combined), 2):
            c1 = combined[i]
            c2 = combined[i+1] if i+1 < len(combined) else '0'
            key += self.transform_char(c1, c2)
        
        while len(key) < 64:
            key += self.transform_char(key[-2], key[-1])
        
        return key[:64]

    def transform_char(self, c1, c2):
        xor_result = ord(c1) ^ ord(c2)
        adjusted = (xor_result % 26) + 65
        return chr(adjusted)