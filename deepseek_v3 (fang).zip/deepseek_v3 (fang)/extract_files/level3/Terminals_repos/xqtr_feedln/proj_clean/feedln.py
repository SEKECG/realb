import argparse
import csv
import os
import sqlite3
import subprocess
import sys
import threading
import time
from configparser import ConfigParser
from typing import Any, Optional

# Constants
SPEAK = "espeak.exe"  # Windows 下可能需要更换为其他 TTS 引擎
version = "1.0"
cfgfile = "feedln.cfg"
database = "feedln.db"
logfile = "feedln.log"
feedfile = "feeds.csv"

# Default configurations
media = "vlc"  # Default to VLC
browser = "chrome"  # Default to Chrome
editor = "notepad"  # Default to Notepad
reqtimeout = 30
program = "feedln"


def header(text: Any) -> None:
    """Print a formatted header text with the prefix 'Header: ' followed by the provided text."""
    print(f"Header: {text}")


def footer(text: Any, color: Optional[Any] = None) -> None:
    """Print the given text as a footer, optionally with a specified color."""
    print(f"Footer: {text}")


def footerpop(text: Any, delay: Any, color: Optional[Any] = None) -> None:
    """Display a text message in the footer with a specified color and delay before proceeding."""
    footer(text, color)
    time.sleep(delay)


def format_file_size(size_in_bytes: Any) -> str:
    """Convert a file size in bytes into a human-readable string with appropriate units (Bytes, KB, MB, GB)."""
    for unit in ['Bytes', 'KB', 'MB', 'GB']:
        if size_in_bytes < 1024.0:
            return f"{size_in_bytes:.2f} {unit}"
        size_in_bytes /= 1024.0
    return f"{size_in_bytes:.2f} TB"


def is_program_installed(program_name: Any) -> bool:
    """Check if a specified program is installed on a Windows system by using the 'where' command to locate the executable."""
    try:
        subprocess.run(["where", program_name], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        return True
    except subprocess.CalledProcessError:
        return False


def run_program(param: Any) -> None:
    """Execute a system command specified by the input parameter and handle any subprocess errors by printing the error message."""
    try:
        subprocess.run(param, check=True)
    except subprocess.CalledProcessError as e:
        print(f"Error running program: {e}")


def log_event(message: Any) -> None:
    """Log an event with the specified message."""
    with open(logfile, "a") as f:
        f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} - {message}\n")


def load_config() -> None:
    """Load and set configuration settings for media player, web browser, text editor, and request timeout from a configuration file, or use default values if the file does not exist."""
    global media, browser, editor, reqtimeout
    config = ConfigParser()
    if os.path.exists(cfgfile):
        config.read(cfgfile)
        media = config.get('DEFAULT', 'media', fallback=media)
        browser = config.get('DEFAULT', 'browser', fallback=browser)
        editor = config.get('DEFAULT', 'editor', fallback=editor)
        reqtimeout = config.getint('DEFAULT', 'reqtimeout', fallback=reqtimeout)
    else:
        with open(cfgfile, "w") as f:
            config['DEFAULT'] = {
                'media': media,
                'browser': browser,
                'editor': editor,
                'reqtimeout': str(reqtimeout)
            }
            config.write(f)


def check_feed_file() -> None:
    """Ensure the existence of a feed file by creating it with default headers and sample data if it does not already exist."""
    if not os.path.exists(feedfile):
        with open(feedfile, "w", newline='') as f:
            writer = csv.writer(f)
            writer.writerow(["Title", "URL", "Category", "Tags"])
            writer.writerow(["Sample Feed", "http://example.com/feed", "Sample", "example"])
        log_event(f"Created default feed file: {feedfile}")


def setup_database() -> sqlite3.Connection:
    """Set up the SQLite database with required tables."""
    conn = sqlite3.connect(database)
    cursor = conn.cursor()
    
    # Create tables if they don't exist
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS feed_sources (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE,
            url TEXT,
            tags TEXT
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS categories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS feed_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            feed_id INTEGER,
            title TEXT,
            summary TEXT,
            content TEXT,
            is_read INTEGER DEFAULT 0,
            FOREIGN KEY (feed_id) REFERENCES feed_sources (id)
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS feed_categories (
            feed_id INTEGER,
            category_id INTEGER,
            PRIMARY KEY (feed_id, category_id),
            FOREIGN KEY (feed_id) REFERENCES feed_sources (id),
            FOREIGN KEY (category_id) REFERENCES categories (id)
        )
    ''')
    
    conn.commit()
    return conn


def load_feeds_to_db(csv_file: Any, conn: Any) -> None:
    """Load RSS feed data from a CSV file into a SQLite database, including feed details and associated categories, while skipping duplicates."""
    cursor = conn.cursor()
    
    with open(csv_file, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            # Insert or ignore feed source
            cursor.execute(
                "INSERT OR IGNORE INTO feed_sources (name, url, tags) VALUES (?, ?, ?)",
                (row["Title"], row["URL"], row.get("Tags", ""))
            )
            
            # Get feed ID
            cursor.execute("SELECT id FROM feed_sources WHERE name = ?", (row["Title"],))
            feed_id = cursor.fetchone()[0]
            
            # Insert or ignore category
            if "Category" in row and row["Category"]:
                cursor.execute(
                    "INSERT OR IGNORE INTO categories (name) VALUES (?)",
                    (row["Category"],)
                )
                
                # Get category ID
                cursor.execute("SELECT id FROM categories WHERE name = ?", (row["Category"],))
                category_id = cursor.fetchone()[0]
                
                # Link feed to category
                cursor.execute(
                    "INSERT OR IGNORE INTO feed_categories (feed_id, category_id) VALUES (?, ?)",
                    (feed_id, category_id)
                )
    
    conn.commit()
    log_event(f"Loaded feeds from {csv_file} into database")


def parse_arguments() -> argparse.Namespace:
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description="Feedln - RSS Feed Reader")
    parser.add_argument("input_file", nargs="?", default=feedfile, help="CSV file containing feed data")
    return parser.parse_args()


class InterruptibleTTS:
    """Provide interruptible text-to-speech (TTS) functionality with the ability to start and stop speech synthesis dynamically."""
    
    def __init__(self) -> None:
        """Initialize the instance with default values for the attributes 'speaking' and 'enabled', setting both to False."""
        self.speaking = False
        self.enabled = False
        self.thread: Optional[threading.Thread] = None
    
    def speak(self, text: Any) -> None:
        """To asynchronously synthesize and speak the given text using a system command, while managing the speaking state with a threading mechanism."""
        if not self.enabled:
            return
            
        def _speak():
            self.speaking = True
            try:
                subprocess.run([SPEAK, text], check=True)
            except subprocess.CalledProcessError as e:
                print(f"TTS error: {e}")
            finally:
                self.speaking = False
        
        self.thread = threading.Thread(target=_speak)
        self.thread.start()
    
    def stop(self) -> None:
        """Stop the espeak.exe process if it is currently running and set the speaking flag to False."""
        if self.speaking and self.thread:
            subprocess.run(["taskkill", "/f", "/im", SPEAK], check=False)
            self.thread.join()
            self.speaking = False


def main() -> None:
    """Main function to load feed data from a specified CSV file into a SQLite database after validating the file and setting up the database connection."""
    load_config()
    check_feed_file()
    
    args = parse_arguments()
    if not os.path.exists(args.input_file):
        print(f"Error: Input file '{args.input_file}' not found")
        sys.exit(1)
    
    conn = setup_database()
    try:
        load_feeds_to_db(args.input_file, conn)
        print(f"Successfully loaded feeds from {args.input_file}")
    except Exception as e:
        print(f"Error loading feeds: {e}")
    finally:
        conn.close()


if __name__ == "__main__":
    main()