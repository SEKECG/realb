#!/usr/bin/env python3
import os
import re
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

import google.generativeai as genai
from dotenv import load_dotenv

# Constants
API_KEY_FILENAME = ".env"
COMMAND_SUGGESTER_SCRIPT = "command_suggester.py"
TMUX_VIEWER_SESSION_NAME = "ai_terminal_x_viewer"
VISUAL_TERMINAL = "xfce4-terminal"
TMUX_HISTORY_LIMIT = "5000"

# ANSI color codes
reset = "\033[0m"
red = "\033[31m"
green = "\033[32m"
yellow = "\033[33m"
blue = "\033[34m"
purple = "\033[35m"
cyan = "\033[36m"
gold = "\033[38;5;214m"

# Global variables
ai_model = None
api_key = None
persistent_viewer_active = False
tmux_path_global = None
visual_term_path_global = None
xclip_path_global = None

# Prompts
base_prompt = """You are an expert Linux system administrator. 
Translate the user's request into an accurate Bash command. 
Provide ONLY the command in a code block and a concise explanation.
The command must work on standard Linux distributions."""

risk_check_prompt = """Analyze this Linux command for potential risks:
1. Could it modify or delete important files?
2. Does it require elevated (sudo) privileges?
3. Could it cause system instability?
4. Could it expose sensitive data?

Respond with:
- "SAFE" if the command is low-risk
- "WARNING" if it has moderate risks (explain)
- "DANGEROUS" if it could cause serious harm (explain)
- "UNKNOWN" if you can't determine

Command to analyze:"""

banner = f"""{gold}
╔════════════════════════════════════════════════════════════╗
║ {cyan}Ai-Terminal-X: AI-Powered Linux Command Assistant{reset}{gold}    ║
║ {purple}Generate, explain, and execute Linux commands safely{reset}{gold} ║
╚════════════════════════════════════════════════════════════╝
{reset}"""

def check_external_tools():
    """Check for required external tools (tmux, terminal, xclip)"""
    global tmux_path_global, visual_term_path_global, xclip_path_global
    
    def find_tool(tool_name):
        try:
            path = subprocess.check_output(["which", tool_name], stderr=subprocess.PIPE).decode().strip()
            return path if path else None
        except subprocess.CalledProcessError:
            return None
    
    tmux_path_global = find_tool("tmux")
    visual_term_path_global = find_tool(VISUAL_TERMINAL)
    xclip_path_global = find_tool("xclip")
    
    if not tmux_path_global:
        print(f"{red}Error: 'tmux' is required but not found. Please install it.{reset}")
        sys.exit(1)
    if not visual_term_path_global:
        print(f"{yellow}Warning: '{VISUAL_TERMINAL}' not found. Separate window mode may not work.{reset}")

def check_tmux_session(session_name):
    """Check if a tmux session exists"""
    if not tmux_path_global:
        return False
    try:
        subprocess.run([tmux_path_global, "has-session", "-t", session_name], 
                      check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        return True
    except subprocess.CalledProcessError:
        return False

def configure_ai(api_key):
    """Configure Google AI connection"""
    try:
        genai.configure(api_key=api_key)
        model = genai.GenerativeModel('gemini-1.5-flash-latest')
        # Test the connection
        model.generate_content("Test connection")
        return model
    except Exception as e:
        print(f"{red}Error configuring AI: {e}{reset}")
        sys.exit(1)

def load_api_key():
    """Load API key from .env file or prompt user"""
    try:
        load_dotenv(API_KEY_FILENAME)
        key = os.getenv("GEMINI_API_KEY")
        if not key:
            print(f"{yellow}API key not found in {API_KEY_FILENAME}{reset}")
            key = input(f"{cyan}Enter your Google Gemini API key: {reset}").strip()
        return key
    except Exception as e:
        print(f"{red}Error loading API key: {e}{reset}")
        sys.exit(1)

def get_user_input(prompt):
    """Get user input with colored prompt"""
    try:
        return input(f"{cyan}{prompt}{reset}").strip()
    except (KeyboardInterrupt, EOFError):
        print("\nExiting...")
        sys.exit(0)

def gemini_command_and_explanation(model, user_input):
    """Get command and explanation from AI"""
    if not user_input:
        return None, None
    
    try:
        response = model.generate_content([base_prompt, user_input])
        text = response.text
        
        # Extract command and explanation
        command_match = re.search(r'```(?:bash)?\n(.+?)\n```', text, re.DOTALL)
        explanation_match = re.search(r'(?:\n|^)([^`]+?)(?=\n```|$)', text, re.DOTALL)
        
        command = command_match.group(1).strip() if command_match else None
        explanation = explanation_match.group(1).strip() if explanation_match else None
        
        return command, explanation
    except Exception as e:
        print(f"{red}Error generating command: {e}{reset}")
        return None, None

def explain_command(model, command_input):
    """Get detailed explanation of a command or concept"""
    if not command_input:
        return None
    
    prompt = f"""Explain this Linux command/concept in detail:
- Purpose and typical use cases
- Breakdown of options/arguments
- Practical examples
- Common pitfalls

Command/concept: {command_input}"""
    
    try:
        response = model.generate_content(prompt)
        return response.text
    except Exception as e:
        print(f"{red}Error getting explanation: {e}{reset}")
        return None

def validate_command_risk(model, command_to_check):
    """Check if a command is potentially dangerous"""
    if not command_to_check:
        return "UNKNOWN", "Empty command"
    
    try:
        response = model.generate_content([risk_check_prompt, command_to_check])
        text = response.text.strip().upper()
        
        if "SAFE" in text:
            return "SAFE", "Command appears safe"
        elif "WARNING" in text:
            return "WARNING", response.text
        elif "DANGEROUS" in text:
            return "DANGEROUS", response.text
        else:
            return "UNKNOWN", response.text
    except Exception as e:
        print(f"{red}Error validating command risk: {e}{reset}")
        return "UNKNOWN", str(e)

def launch_persistent_viewer_if_needed():
    """Launch tmux viewer window if not running"""
    global persistent_viewer_active
    
    if not check_tmux_session(TMUX_VIEWER_SESSION_NAME):
        try:
            subprocess.Popen([
                visual_term_path_global,
                "--title=Ai-Terminal-X Viewer",
                "--geometry=120x40",
                "-e",
                tmux_path_global,
                "new-session",
                "-s", TMUX_VIEWER_SESSION_NAME,
                "-d"
            ])
            time.sleep(1)  # Give it time to start
            persistent_viewer_active = True
        except Exception as e:
            print(f"{red}Error launching persistent viewer: {e}{reset}")
            persistent_viewer_active = False
    else:
        persistent_viewer_active = True

def send_command_to_tmux_viewer(session_name, command):
    """Send command to tmux viewer"""
    try:
        subprocess.run([
            tmux_path_global,
            "send-keys",
            "-t", f"{session_name}:0",
            command,
            "Enter"
        ], check=True)
        return True
    except Exception as e:
        print(f"{red}Error sending command to tmux: {e}{reset}")
        return False

def send_interrupt_to_tmux_viewer(session_name):
    """Send Ctrl+C to tmux viewer"""
    try:
        subprocess.run([
            tmux_path_global,
            "send-keys",
            "-t", f"{session_name}:0",
            "C-c"
        ], check=True)
        return True
    except Exception as e:
        print(f"{red}Error sending interrupt to tmux: {e}{reset}")
        return False

def run_visual_pause_window(command_to_execute):
    """Run command in a new terminal window that pauses"""
    if not visual_term_path_global:
        print(f"{red}Visual terminal not found. Cannot open separate window.{reset}")
        return False
    
    try:
        subprocess.Popen([
            visual_term_path_global,
            "--title=Ai-Terminal-X Execution",
            "--geometry=120x40",
            "--hold",
            "-e",
            "bash",
            "-c",
            f"{command_to_execute}; echo; read -p 'Press Enter to close...'"
        ])
        return True
    except Exception as e:
        print(f"{red}Error opening separate window: {e}{reset}")
        return False

def handle_command_execution(ai_generated_command, primary_mode, execution_mode, user_input_request):
    """Handle command execution based on mode"""
    if not ai_generated_command:
        return
    
    # Log the command
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_entry = f"{timestamp} | {execution_mode} | {user_input_request} | {ai_generated_command}\n"
    
    try:
        with open("ai_cmd_x_history.log", "a") as f:
            f.write(log_entry)
    except Exception as e:
        print(f"{yellow}Warning: Could not log command: {e}{reset}")
    
    # Execute based on mode
    if primary_mode == "persistent":
        if not persistent_viewer_active:
            print(f"{yellow}Persistent viewer not active. Falling back to separate window.{reset}")
            run_visual_pause_window(ai_generated_command)
        else:
            send_command_to_tmux_viewer(TMUX_VIEWER_SESSION_NAME, ai_generated_command)
    else:
        run_visual_pause_window(ai_generated_command)

def select_execution_mode():
    """Let user select execution mode"""
    print(f"\n{blue}Select execution mode:{reset}")
    print(f"{green}1. Persistent Viewer (single window for all commands){reset}")
    print(f"{green}2. Separate Window (new window for each command){reset}")
    
    while True:
        choice = get_user_input("Enter choice (1/2): ")
        if choice == "1":
            return "persistent"
        elif choice == "2":
            return "separate"
        else:
            print(f"{red}Invalid choice. Please enter 1 or 2.{reset}")

def run_main_loop():
    """Main program loop"""
    global ai_model, api_key
    
    print(banner)
    
    # Initial setup
    api_key = load_api_key()
    ai_model = configure_ai(api_key)
    check_external_tools()
    
    # Select execution mode
    execution_mode = select_execution_mode()
    if execution_mode == "persistent":
        launch_persistent_viewer_if_needed()
    
    # Main interaction loop
    while True:
        print(f"\n{gold}Main Menu:{reset}")
        print(f"{green}1. Generate and execute command{reset}")
        print(f"{green}2. Explain command/concept{reset}")
        print(f"{green}3. Exit{reset}")
        
        choice = get_user_input("Enter choice (1/2/3): ")
        
        if choice == "1":
            user_input = get_user_input("Describe what you want to do: ")
            if not user_input:
                continue
                
            command, explanation = gemini_command_and_explanation(ai_model, user_input)
            if not command:
                print(f"{red}No command generated. Try being more specific.{reset}")
                continue
                
            print(f"\n{blue}Generated command:{reset}\n{command}")
            if explanation:
                print(f"\n{blue}Explanation:{reset}\n{explanation}")
                
            risk_level, risk_detail = validate_command_risk(ai_model, command)
            if risk_level == "DANGEROUS":
                print(f"\n{red}WARNING: This command appears dangerous!{reset}")
                print(risk_detail)
                confirm = get_user_input("Execute anyway? (y/N): ").lower()
                if confirm != "y":
                    continue
            elif risk_level == "WARNING":
                print(f"\n{yellow}WARNING: This command has potential risks{reset}")
                print(risk_detail)
                confirm = get_user_input("Execute? (Y/n): ").lower()
                if confirm == "n":
                    continue
            
            handle_command_execution(command, execution_mode, "command", user_input)
            
        elif choice == "2":
            user_input = get_user_input("Enter command/concept to explain: ")
            if not user_input:
                continue
                
            explanation = explain_command(ai_model, user_input)
            if explanation:
                print(f"\n{blue}Explanation:{reset}\n{explanation}")
            else:
                print(f"{red}Could not generate explanation.{reset}")
                
        elif choice == "3":
            print(f"{green}Exiting Ai-Terminal-X. Goodbye!{reset}")
            sys.exit(0)
        else:
            print(f"{red}Invalid choice. Please enter 1, 2, or 3.{reset}")

if __name__ == "__main__":
    try:
        run_main_loop()
    except KeyboardInterrupt:
        print("\nExiting...")
        sys.exit(0)