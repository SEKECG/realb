import torch
from .camera_embed import CameraSettingEmbedding

def embed_camera_settings(
    focal_length, aperture, iso_speed, exposure_time,
    prompt_embeds, negative_focal_length=None, negative_aperture=None,
    negative_iso_speed=None, negative_exposure_time=None,
    negative_prompt_embeds=None, cam_embed=None, device=None
):
    if device is None:
        device = prompt_embeds.device
    
    if cam_embed is None:
        cam_embed = CameraSettingEmbedding(
            embedding_dim=prompt_embeds.shape[-1],
            hidden_dim=256,
            num_layers=3
        ).to(device)
    
    # Process positive prompt
    cam_embeds = cam_embed(
        torch.tensor(focal_length, device=device).float(),
        torch.tensor(aperture, device=device).float(),
        torch.tensor(iso_speed, device=device).float(),
        torch.tensor(exposure_time, device=device).float()
    )
    prompt_embeds = prompt_embeds + cam_embeds.unsqueeze(0)
    
    # Process negative prompt if provided
    if negative_prompt_embeds is not None:
        neg_focal = negative_focal_length if negative_focal_length is not None else focal_length
        neg_aperture = negative_aperture if negative_aperture is not None else aperture
        neg_iso = negative_iso_speed if negative_iso_speed is not None else iso_speed
        neg_exposure = negative_exposure_time if negative_exposure_time is not None else exposure_time
        
        neg_cam_embeds = cam_embed(
            torch.tensor(neg_focal, device=device).float(),
            torch.tensor(neg_aperture, device=device).float(),
            torch.tensor(neg_iso, device=device).float(),
            torch.tensor(neg_exposure, device=device).float()
        )
        negative_prompt_embeds = negative_prompt_embeds + neg_cam_embeds.unsqueeze(0)
    
    return prompt_embeds, negative_prompt_embeds