import torch
import torch.nn as nn
import torch.nn.functional as F

class CameraSettingEmbedding(nn.Module):
    def __init__(self, embedding_dim, hidden_dim, num_layers, activation="silu", layer_norm=True, zero_init=False, logize_input=True):
        super().__init__()
        self.activation = {
            "silu": nn.SiLU(),
            "relu": nn.ReLU(),
            "gelu": nn.GELU()
        }[activation.lower()]
        self.logize_input = logize_input
        self.zero_init = zero_init

        def make_mlp():
            layers = []
            for i in range(num_layers):
                in_dim = hidden_dim if i > 0 else 1
                out_dim = hidden_dim if i < num_layers - 1 else embedding_dim
                layers.append(nn.Linear(in_dim, out_dim))
                if i < num_layers - 1:
                    if layer_norm:
                        layers.append(nn.LayerNorm(out_dim))
                    layers.append(self.activation)
            return nn.Sequential(*layers)

        self.embed_focal_length = make_mlp()
        self.embed_aperture = make_mlp()
        self.embed_iso_speed = make_mlp()
        self.embed_exposure_time = make_mlp()

        if zero_init:
            for param in self.parameters():
                param.data.zero_()

    def focal_length_forward(self, x_focal_length):
        if self.logize_input:
            x_focal_length = torch.log(x_focal_length + 1e-8)
        return self.embed_focal_length(x_focal_length.unsqueeze(-1))

    def aperture_forward(self, x_aperture):
        if self.logize_input:
            x_aperture = torch.log(x_aperture + 1e-8)
        return self.embed_aperture(x_aperture.unsqueeze(-1))

    def iso_speed_forward(self, x_iso_speed):
        if self.logize_input:
            x_iso_speed = torch.log(x_iso_speed + 1e-8)
        return self.embed_iso_speed(x_iso_speed.unsqueeze(-1))

    def exposure_time_forward(self, x_exposure_time):
        if self.logize_input:
            x_exposure_time = torch.log(x_exposure_time + 1e-8)
        return self.embed_exposure_time(x_exposure_time.unsqueeze(-1))

    def forward(self, x_focal_length, x_aperture, x_iso_speed, x_exposure_time):
        focal_emb = self.focal_length_forward(x_focal_length)
        aperture_emb = self.aperture_forward(x_aperture)
        iso_emb = self.iso_speed_forward(x_iso_speed)
        exposure_emb = self.exposure_time_forward(x_exposure_time)
        return torch.cat([focal_emb, aperture_emb, iso_emb, exposure_emb], dim=-1)