import argparse
import torch
from diffusers import StableDiffusionPipeline
from .inference import embed_camera_settings
from .camera_embed import CameraSettingEmbedding

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_id", type=str, default="runwayml/stable-diffusion-v1-5")
    parser.add_argument("--output_dir", type=str, default="outputs")
    parser.add_argument("--prompt", type=str, required=True)
    parser.add_argument("--negative_prompt", type=str, default="")
    parser.add_argument("--focal_length", type=float, default=35.0)
    parser.add_argument("--aperture", type=float, default=2.8)
    parser.add_argument("--iso_speed", type=float, default=100.0)
    parser.add_argument("--exposure_time", type=float, default=1/125)
    parser.add_argument("--num_inference_steps", type=int, default=50)
    parser.add_argument("--guidance_scale", type=float, default=7.5)
    parser.add_argument("--seed", type=int, default=None)
    return parser.parse_args()

def main():
    args = parse_args()
    
    device = "cuda" if torch.cuda.is_available() else "cpu"
    
    pipe = StableDiffusionPipeline.from_pretrained(
        args.model_id,
        torch_dtype=torch.float16 if device == "cuda" else torch.float32
    ).to(device)
    
    prompt_embeds = pipe._encode_prompt(
        args.prompt,
        device,
        1,
        False,
        args.negative_prompt
    )
    
    cam_embed = CameraSettingEmbedding(
        embedding_dim=prompt_embeds[0].shape[-1],
        hidden_dim=256,
        num_layers=3
    ).to(device)
    
    prompt_embeds, negative_prompt_embeds = embed_camera_settings(
        args.focal_length,
        args.aperture,
        args.iso_speed,
        args.exposure_time,
        prompt_embeds[0],
        negative_prompt_embeds=prompt_embeds[1],
        cam_embed=cam_embed,
        device=device
    )
    
    generator = None
    if args.seed is not None:
        generator = torch.Generator(device=device).manual_seed(args.seed)
    
    image = pipe(
        prompt_embeds=prompt_embeds,
        negative_prompt_embeds=negative_prompt_embeds,
        num_inference_steps=args.num_inference_steps,
        guidance_scale=args.guidance_scale,
        generator=generator
    ).images[0]
    
    import os
    os.makedirs(args.output_dir, exist_ok=True)
    image.save(f"{args.output_dir}/generated_image.png")

if __name__ == "__main__":
    main()