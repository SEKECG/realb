import asyncio
import json
import logging
import os
import subprocess
from contextlib import AsyncExitStack
from typing import Any, Awaitable, Callable, Dict, List, Optional, Tuple, Union

from langchain.tools import BaseTool

# Type aliases
McpServerCleanupFn = Callable[[], Awaitable[None]]
McpServersConfig = Dict[str, Dict[str, Any]]
SingleMcpServerConfig = Union["McpServerCommandBasedConfig", "McpServerUrlBasedConfig"]
Transport = Tuple[Any, Any]


class McpServerCommandBasedConfig:
    """Configuration for an MCP server launched via command line."""

    def __init__(
        self,
        command: str,
        args: Optional[List[str]] = None,
        env: Optional[Dict[str, str]] = None,
        cwd: Optional[str] = None,
        errlog: Optional[Any] = None,
    ):
        self.command = command
        self.args = args or []
        self.env = env or {}
        self.cwd = cwd
        self.errlog = errlog


class McpServerUrlBasedConfig:
    """Configuration for a remote MCP server accessed via URL."""

    def __init__(
        self,
        url: str,
        headers: Optional[Dict[str, str]] = None,
    ):
        self.url = url
        self.headers = headers or {}


def init_logger() -> logging.Logger:
    """A very simple pre-configured logger for fallback."""
    logger = logging.getLogger("langchain_mcp_tools")
    logger.setLevel(logging.INFO)
    handler = logging.StreamHandler()
    handler.setFormatter(
        logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    )
    logger.addHandler(handler)
    return logger


def fix_schema(schema: Dict) -> Dict:
    """Converts JSON Schema \"type\": [\"string\", \"null\"] to \"anyOf\" format."""
    if "type" in schema and isinstance(schema["type"], list):
        schema["anyOf"] = [{"type": t} for t in schema["type"]]
        del schema["type"]
    return schema


async def spawn_mcp_server_and_get_transport(
    server_name: str,
    server_config: SingleMcpServerConfig,
    exit_stack: AsyncExitStack,
    logger: logging.Logger,
) -> Transport:
    """Spawns an MCP server process and establishes communication channels."""
    try:
        if isinstance(server_config, McpServerUrlBasedConfig):
            # Handle URL-based server connection
            if server_config.url.startswith(("http://", "https://")):
                # SSE connection
                logger.info(f"Connecting to SSE server at {server_config.url}")
                # Implementation would use aiohttp or similar for SSE
                raise NotImplementedError("SSE transport not implemented")
            elif server_config.url.startswith(("ws://", "wss://")):
                # WebSocket connection
                logger.info(f"Connecting to WebSocket server at {server_config.url}")
                # Implementation would use websockets library
                raise NotImplementedError("WebSocket transport not implemented")
            else:
                raise ValueError(f"Invalid URL scheme for server {server_name}")
        elif isinstance(server_config, McpServerCommandBasedConfig):
            # Handle command-based server process
            logger.info(
                f"Starting server {server_name} with command: {server_config.command} {server_config.args}"
            )
            process = await asyncio.create_subprocess_exec(
                server_config.command,
                *server_config.args,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=server_config.errlog or subprocess.PIPE,
                env={**os.environ, **server_config.env},
                cwd=server_config.cwd,
            )
            await exit_stack.enter_async_context(process)
            return (process.stdout, process.stdin)
        else:
            raise ValueError(f"Invalid server configuration type for {server_name}")
    except Exception as e:
        logger.error(f"Failed to spawn server {server_name}: {str(e)}")
        raise


async def get_mcp_server_tools(
    server_name: str,
    transport: Transport,
    exit_stack: AsyncExitStack,
    logger: logging.Logger,
) -> List[BaseTool]:
    """Retrieves and converts MCP server tools to LangChain format."""
    try:
        receive_stream, send_stream = transport
        # In a real implementation, we would communicate with the server here
        # to get the tool definitions and convert them to LangChain tools
        logger.info(f"Getting tools from server {server_name}")
        raise NotImplementedError("Tool conversion not implemented")
    except Exception as e:
        logger.error(f"Failed to get tools from server {server_name}: {str(e)}")
        raise


async def convert_mcp_to_langchain_tools(
    server_configs: McpServersConfig,
    logger: Optional[logging.Logger] = None,
) -> Tuple[List[BaseTool], McpServerCleanupFn]:
    """Initialize multiple MCP servers and convert their tools to LangChain format."""
    if logger is None:
        logger = init_logger()

    async def cleanup() -> None:
        """Cleanup function to shutdown all server connections."""
        await exit_stack.aclose()
        logger.info("All MCP server connections cleaned up")

    exit_stack = AsyncExitStack()
    tools: List[BaseTool] = []

    try:
        # Initialize servers in parallel
        server_init_tasks = []
        for server_name, config in server_configs.items():
            # Determine config type
            if "url" in config:
                server_config = McpServerUrlBasedConfig(**config)
            else:
                server_config = McpServerCommandBasedConfig(**config)

            task = spawn_mcp_server_and_get_transport(
                server_name, server_config, exit_stack, logger
            )
            server_init_tasks.append(task)

        transports = await asyncio.gather(*server_init_tasks)

        # Get tools from each server
        tool_tasks = []
        for server_name, transport in zip(server_configs.keys(), transports):
            task = get_mcp_server_tools(server_name, transport, exit_stack, logger)
            tool_tasks.append(task)

        all_tools = await asyncio.gather(*tool_tasks)
        tools = [tool for server_tools in all_tools for tool in server_tools]

        return tools, cleanup

    except Exception as e:
        logger.error(f"Error initializing MCP servers: {str(e)}")
        await cleanup()
        raise