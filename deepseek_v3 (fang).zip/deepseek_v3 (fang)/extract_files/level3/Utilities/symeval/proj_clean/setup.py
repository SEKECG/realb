from setuptools import setup, find_packages

cfg = {
    "name": "symeval",
    "version": "0.1.0",
    "description": "Symbolic Math Expression Evaluator",
    "author": "",
    "author_email": "",
    "license": "MIT",
    "packages": find_packages(),
    "install_requires": [
        "sympy",
        "pebble",
        "tqdm",
        "regex"
    ],
    "python_requires": ">=3.7",
}

setup(**cfg)