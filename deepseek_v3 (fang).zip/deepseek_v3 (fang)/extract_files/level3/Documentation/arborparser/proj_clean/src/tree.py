import json
from pathlib import Path
from typing import Dict, Any, Union, List
from .node import TreeNode

class TreeBuilder:
    def __init__(self, strategy):
        self.strategy = strategy

    def build_tree(self, chain):
        return self.strategy.build_tree(chain)

class TreeExporter:
    @staticmethod
    def export_chain(chain):
        return '\n'.join(node.content for node in chain)

    @staticmethod
    def export_tree(tree):
        return TreeExporter._export_tree_internal(tree, "", True, True)

    @staticmethod
    def _export_tree_internal(node, prefix, is_last, is_root):
        connector = "└── " if is_last else "├── "
        if is_root:
            result = f"{node.level_text} {node.title}\n"
        else:
            result = f"{prefix}{connector}{node.level_text} {node.title}\n"
        
        new_prefix = prefix + ("    " if is_last else "│   ")
        
        if hasattr(node, 'children'):
            for i, child in enumerate(node.children):
                result += TreeExporter._export_tree_internal(
                    child,
                    new_prefix,
                    i == len(node.children) - 1,
                    False
                )
        return result

    @staticmethod
    def _node_to_dict(node):
        node_dict = {
            'level_text': node.level_text,
            'title': node.title,
            'content': node.content
        }
        if hasattr(node, 'children'):
            node_dict['children'] = [
                TreeExporter._node_to_dict(child)
                for child in node.children
            ]
        return node_dict

    @staticmethod
    def export_to_json(tree):
        return json.dumps(TreeExporter._node_to_dict(tree), indent=2, ensure_ascii=False)

    @staticmethod
    def export_to_json_file(tree, file_path):
        file_path = Path(file_path)
        with file_path.open('w', encoding='utf-8') as f:
            json.dump(TreeExporter._node_to_dict(tree), f, indent=2, ensure_ascii=False)