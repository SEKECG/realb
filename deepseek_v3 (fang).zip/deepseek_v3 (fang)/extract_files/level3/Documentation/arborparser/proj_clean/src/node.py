from typing import List, Optional, Dict, Any

class BaseNode:
    def __init__(self, level_seq, level_text, title, content):
        self.level_seq = level_seq
        self.level_text = level_text
        self.title = title
        self.content = content

    def concat_node(self, node):
        self.content += '\n' + node.content

class ChainNode(BaseNode):
    def __init__(self, level_seq, level_text, title, content, pattern_priority):
        super().__init__(level_seq, level_text, title, content)
        self.pattern_priority = pattern_priority

class TreeNode(BaseNode):
    def __init__(self, level_seq, level_text, title, content):
        super().__init__(level_seq, level_text, title, content)
        self.parent = None
        self.children = []

    @staticmethod
    def from_chain_node(chain_node):
        return TreeNode(
            level_seq=chain_node.level_seq,
            level_text=chain_node.level_text,
            title=chain_node.title,
            content=chain_node.content
        )

    def add_child(self, child):
        child.parent = self
        self.children.append(child)

    def merge_all_children(self):
        for child in self.children:
            self.content += '\n' + child.content
            for grandchild in child.children:
                self.add_child(grandchild)
        self.children = []

    def get_full_content(self):
        content = self.content
        for child in self.children:
            content += '\n' + child.get_full_content()
        return content