from typing import List, Tuple, Dict, Any, Optional
from llama_index.text_splitter import SentenceSplitter
from .node import BaseNode, TreeNode
from .chain import ChainParser
from .tree import TreeBuilder
from .build_strategy import StrictStrategy

class ArborParserNodeParser:
    def __init__(self, chunk_size, chunk_overlap, merge_threshold, is_merge_small_node, level_patterns):
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.merge_threshold = merge_threshold
        self.is_merge_small_node = is_merge_small_node
        self.patterns = level_patterns
        self.sentence_splitter = SentenceSplitter(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap
        )

    def parse_text(self, text):
        chain_parser = ChainParser(self.patterns)
        chain = chain_parser.parse_to_chain(text)
        
        tree_builder = TreeBuilder(StrictStrategy())
        tree = tree_builder.build_tree(chain)
        
        if self.is_merge_small_node:
            self.merge_deep_nodes(tree)
            
        return self.collect_chunks_with_path(tree, [])

    def get_nodes_from_documents(self, documents, show_progress):
        results = []
        for doc in documents:
            results.extend(self.parse_text(doc.text))
        return results

    def merge_deep_nodes(self, node):
        if not hasattr(node, 'children'):
            return
        
        for child in node.children:
            self.merge_deep_nodes(child)
            
        if len(node.content) < self.merge_threshold and node.children:
            node.merge_all_children()

    def split_node_content(self, node):
        return self.sentence_splitter.split_text(node.content)

    def collect_chunks_with_path(self, node, title_path):
        chunks = []
        current_path = title_path + [node.title]
        
        node_chunks = self.split_node_content(node)
        for chunk in node_chunks:
            chunks.append((chunk, {
                'title_path': current_path,
                'level_text': node.level_text
            }))
            
        if hasattr(node, 'children'):
            for child in node.children:
                chunks.extend(self.collect_chunks_with_path(child, current_path))
                
        return chunks