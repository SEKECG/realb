import re
from typing import List, Optional
from dataclasses import dataclass
from .node import ChainNode

@dataclass
class LevelPattern:
    regex: re.Pattern
    converter: callable
    description: str

class ChainParser:
    def __init__(self, patterns):
        self.patterns = patterns

    def _detect_level(self, line):
        for pattern in self.patterns:
            match = pattern.regex.match(line)
            if match:
                level_seq = pattern.converter(match)
                title = line[match.end():].strip()
                return ChainNode(
                    level_seq=level_seq,
                    level_text=match.group().strip(),
                    title=title,
                    content=line,
                    pattern_priority=self.patterns.index(pattern)
                )
        return None

    def parse_to_chain(self, text):
        chain = []
        lines = text.split('\n')
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
                
            node = self._detect_level(line)
            if node:
                chain.append(node)
            elif chain:
                chain[-1].content += '\n' + line
                
        return chain