from typing import List, Optional
from .node import TreeNode

def is_root(node):
    return not hasattr(node, 'parent') or node.parent is None

def get_last_level(level_seq):
    return level_seq[-1] if level_seq else 0

def get_prefix(level_seq):
    return level_seq[:-1] if level_seq else []

def is_imm_next(front_seq, back_seq):
    if not front_seq or not back_seq:
        return False
        
    if len(front_seq) == len(back_seq):
        prefix = get_prefix(front_seq)
        back_prefix = get_prefix(back_seq)
        if prefix == back_prefix:
            return get_last_level(front_seq) + 1 == get_last_level(back_seq)
    
    elif len(back_seq) == len(front_seq) + 1:
        return front_seq == get_prefix(back_seq)
    
    elif len(front_seq) > len(back_seq):
        truncated = front_seq[:len(back_seq)]
        return is_imm_next(truncated, back_seq)
        
    return False

class TreeBuildingStrategy:
    def build_tree(self, chain):
        raise NotImplementedError

class StrictStrategy(TreeBuildingStrategy):
    def build_tree(self, chain):
        if not chain:
            return None
            
        root = TreeNode.from_chain_node(chain[0])
        current_parent = root
        
        for node in chain[1:]:
            tree_node = TreeNode.from_chain_node(node)
            
            while current_parent and not is_imm_next(current_parent.level_seq, tree_node.level_seq):
                current_parent = current_parent.parent
                
            if current_parent:
                current_parent.add_child(tree_node)
                current_parent = tree_node
            else:
                root.add_child(tree_node)
                current_parent = tree_node
                
        return root

class AutoPruneStrategy(TreeBuildingStrategy):
    def build_tree(self, chain):
        if not chain:
            return None
            
        root = TreeNode.from_chain_node(chain[0])
        current_parent = root
        
        for node in chain[1:]:
            tree_node = TreeNode.from_chain_node(node)
            
            if is_imm_next(current_parent.level_seq, tree_node.level_seq):
                current_parent.add_child(tree_node)
                current_parent = tree_node
            else:
                current_parent.concat_node(tree_node)
                
        return root