import re
from dataclasses import dataclass
from typing import List, Dict, Callable, Optional
from .utils import chinese_to_int, roman_to_int

@dataclass
class NumberTypeInfo:
    pattern: str
    converter: Callable[[str], int]
    name: str

class NumberType:
    ARABIC = NumberTypeInfo(r'\d+', int, 'arabic')
    CHINESE = NumberTypeInfo(
        r'[零一二三四五六七八九十百千万亿两]+',
        chinese_to_int,
        'chinese'
    )
    ROMAN = NumberTypeInfo(
        r'[IVXLCDM]+',
        roman_to_int,
        'roman'
    )
    LETTER = NumberTypeInfo(
        r'[A-Za-z]',
        lambda x: ord(x.upper()) - ord('A') + 1,
        'letter'
    )
    CIRCLED = NumberTypeInfo(
        r'[①-⑳]',
        lambda x: ord(x) - ord('①') + 1,
        'circled'
    )

@dataclass
class PatternBuilder:
    prefix_regex: str
    number_type: NumberTypeInfo
    suffix_regex: str
    separator: str
    min_level: int = 1
    max_level: int = 3

    def __post_init__(self):
        if self.min_level < 1:
            raise ValueError("min_level must be at least 1")
        if self.max_level < self.min_level:
            raise ValueError("max_level must be >= min_level")

    def build(self):
        num_pattern = self.number_type.pattern
        separator = re.escape(self.separator)
        
        pattern = f"{self.prefix_regex}(({num_pattern}){separator}){{{self.min_level-1},{self.max_level-1}}}({num_pattern}){self.suffix_regex}"
        
        def converter(match):
            numbers = []
            for group in match.groups():
                if group and group in match.groupdict():
                    continue
                if group and self.separator in group:
                    parts = group.split(self.separator)
                    for part in parts:
                        if part:
                            numbers.append(self.number_type.converter(part))
                    continue
                if group:
                    numbers.append(self.number_type.converter(group))
            return numbers
            
        return LevelPattern(
            regex=re.compile(pattern),
            converter=converter,
            description=f"{self.number_type.name} pattern"
        )

    def modify(self, **kwargs):
        new_params = {
            'prefix_regex': self.prefix_regex,
            'number_type': self.number_type,
            'suffix_regex': self.suffix_regex,
            'separator': self.separator,
            'min_level': self.min_level,
            'max_level': self.max_level
        }
        new_params.update(kwargs)
        return PatternBuilder(**new_params)

CHINESE_CHAPTER_PATTERN_BUILDER = PatternBuilder(
    prefix_regex=r'^第',
    number_type=NumberType.CHINESE,
    suffix_regex=r'[章节条]',
    separator=''
)

ENGLISH_CHAPTER_PATTERN_BUILDER = PatternBuilder(
    prefix_regex=r'^(Chapter|Section)\s',
    number_type=NumberType.ARABIC,
    suffix_regex=r'\b',
    separator='.'
)

NUMERIC_DOT_PATTERN_BUILDER = PatternBuilder(
    prefix_regex=r'^',
    number_type=NumberType.ARABIC,
    suffix_regex=r'(?=\s|$)',
    separator='.'
)

NUMERIC_DASH_PATTERN_BUILDER = PatternBuilder(
    prefix_regex=r'^',
    number_type=NumberType.ARABIC,
    suffix_regex=r'(?=\s|$)',
    separator='-'
)

ROMAN_PATTERN_BUILDER = PatternBuilder(
    prefix_regex=r'^',
    number_type=NumberType.ROMAN,
    suffix_regex=r'(?=\s|$)',
    separator='.'
)

CIRCLED_PATTERN_BUILDER = PatternBuilder(
    prefix_regex=r'^',
    number_type=NumberType.CIRCLED,
    suffix_regex=r'(?=\s|$)',
    separator='.'
)