import json
import os
import sounddevice as sd
from pathlib import Path
from typing import Dict, Any

_SD_DEFAULTS: Dict[str, Any] = {
    'device': None,
    'channels': 2,
    'dtype': 'float32',
    'latency': 'high',
    'samplerate': 44100,
    'blocksize': 0,
    'extra_settings': None
}

_SD_DEFAULTS_PATH = Path.home() / '.pyquist_sd_defaults.json'

def _set_sd_default(name, value, write=True):
    """Set and manage default sound device configurations, including validation and persistence of settings."""
    if name not in _SD_DEFAULTS:
        raise ValueError(f'Invalid sounddevice default: {name}')
    sd.default.__setattr__(name, value)
    if write:
        _SD_DEFAULTS[name] = value
        with open(_SD_DEFAULTS_PATH, 'w') as f:
            json.dump(_SD_DEFAULTS, f)

def _restore_sd_defaults():
    """Restore the sounddevice defaults by loading them from a JSON file and applying each setting, handling any errors that occur during the process."""
    if not _SD_DEFAULTS_PATH.exists():
        return
    try:
        with open(_SD_DEFAULTS_PATH) as f:
            defaults = json.load(f)
        for name, value in defaults.items():
            _set_sd_default(name, value, write=False)
    except Exception:
        pass

def set_sd_defaults(**kwargs):
    """Sets the default `sounddevice` parameters.
    
    To override without writing to cache, change `sounddevice.default` directly."""
    for name, value in kwargs.items():
        _set_sd_default(name, value)

def play(audio, safe=True, normalize=True):
    """Plays the audio using sounddevice."""
    if normalize:
        audio = audio.normalize()
    sd.play(audio.T, audio.sample_rate)
    sd.wait()

def record(duration, progress_bar=False, **kwargs):
    """Records audio from the default input device.
    
    Parameters:
        duration: The duration of the recording in seconds.
        progress_bar: Whether to display a progress bar.
    
    Returns:
        The recorded audio.
    """
    sample_rate = sd.default.samplerate
    recording = sd.rec(int(duration * sample_rate), samplerate=sample_rate, channels=1, **kwargs)
    sd.wait()
    return Audio.from_array(recording.T, sample_rate)

_restore_sd_defaults()