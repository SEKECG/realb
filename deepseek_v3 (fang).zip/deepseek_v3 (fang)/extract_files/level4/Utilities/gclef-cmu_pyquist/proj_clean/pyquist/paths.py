from pathlib import Path

LIB_DIR = Path(__file__).parent
TEST_DATA_DIR = LIB_DIR / 'test_data'
CACHE_DIR = LIB_DIR / 'cache'