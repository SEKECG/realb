import numpy as np

class AudioBuffer(np.ndarray):
    """Represents a buffer of raw audio samples.
    
    Type signature inspired by JUCE AudioBuffer.
    
    https://docs.juce.com/master/classAudioBuffer.html"""
    
    def __new__(cls, num_samples, num_channels, array=None):
        """Initializes a buffer of raw 32-bit float audio samples.
        
        Parameters:
            num_samples: The number of samples in the buffer.
            num_channels: The number of channels in the buffer.
            array: An optional numpy array to use as the buffer.
                   If None, a zero-filled buffer will be created.
                   Must be same shape as num_channels / num_samples.
        """
        if array is None:
            array = np.zeros((num_channels, num_samples), dtype=np.float32)
        return array.view(cls)
    
    def __array_finalize__(self, obj):
        """Called after array viewing, slicing, creating from template, etc."""
        pass
    
    def __array_function__(self, func, types, args, kwargs):
        """Handles casting of ndarrays, etc. before array_wrap.
        
        See https://numpy.org/doc/stable/reference/arrays.classes.html#numpy.class.__array_function__"""
        return super().__array_function__(func, types, args, kwargs)
    
    def __array_wrap__(self, result, *args, **kwargs):
        """Ensures that output of ufuncs like sum() is np.ndarray or scalar."""
        return np.ndarray.__array_wrap__(self, result, *args, **kwargs)
    
    def __getitem__(self, *args, **kwargs):
        """Ensure any non-2D slices return ndarray instead of AudioBuffer."""
        result = super().__getitem__(*args, **kwargs)
        if len(result.shape) != 2:
            return result.view(np.ndarray)
        return result
    
    def clear(self):
        """Clears the buffer by zeroing all samples."""
        self.fill(0)
    
    @property
    def num_channels(self):
        """Returns the number of channels in the buffer."""
        return self.shape[0]
    
    @property
    def num_samples(self):
        """Returns the number of samples in the buffer."""
        return self.shape[1]

class Audio(AudioBuffer):
    """Initializes an audio waveform (AudioBuffer with a sample rate)."""
    
    def __new__(cls, *args, sample_rate, **kwargs):
        """Initializes an audio waveform (AudioBuffer with a sample rate).
        
        Parameters:
            sample_rate: The sample rate of the audio.
        """
        obj = super().__new__(cls, *args, **kwargs)
        obj._sample_rate = sample_rate
        return obj
    
    def __array_finalize__(self, obj):
        """Called after array viewing, slicing, creating from template, etc."""
        if obj is None:
            return
        self._sample_rate = getattr(obj, '_sample_rate', None)
    
    def __array_function__(self, func, types, args, kwargs):
        """Ensure sample_rate is passed along for functions like np.concatenate.
        
        See https://numpy.org/doc/stable/reference/arrays.classes.html#numpy.class.__array_function__"""
        result = super().__array_function__(func, types, args, kwargs)
        if isinstance(result, Audio):
            result._sample_rate = self._sample_rate
        return result
    
    @classmethod
    def from_array(cls, array, sample_rate):
        """Creates an AudioBuffer from a numpy array.
        
        Parameters:
            array: The numpy array of audio samples.
            sample_rate: The sample rate of the audio.
        """
        return cls(array.shape[1], array.shape[0], array=array, sample_rate=sample_rate)
    
    @classmethod
    def from_file(cls, file):
        """Creates an AudioBuffer from a file.
        
        Parameters:
            file: The path to the file or a file-like object.
        """
        raise NotImplementedError()
    
    @classmethod
    def from_url(cls, url):
        """Creates an AudioBuffer from a URL.
        
        Parameters:
            url: The URL of the audio file.
        """
        raise NotImplementedError()
    
    def clip(self, peak_gain, in_place=False):
        """Clips the audio to a peak gain."""
        if in_place:
            np.clip(self, -peak_gain, peak_gain, out=self)
            return self
        return Audio.from_array(np.clip(self, -peak_gain, peak_gain), self.sample_rate)
    
    def normalize(self, peak_dbfs=0, in_place=False):
        """Returns a normalized version of the audio."""
        peak_gain = 10 ** (peak_dbfs / 20)
        current_peak = np.max(np.abs(self))
        if current_peak == 0:
            return self
        scale = peak_gain / current_peak
        if in_place:
            self *= scale
            return self
        return Audio.from_array(self * scale, self.sample_rate)
    
    def resample(self, new_sample_rate, **kwargs):
        """Resamples the waveform to a new sample rate.
        
        Parameters:
            new_sample_rate: The new sample rate to resample to.
        """
        raise NotImplementedError()
    
    def write(self, file, **kwargs):
        """Writes the audio to a file.
        
        Parameters:
            file: The path to the file or a file-like object.
        """
        raise NotImplementedError()
    
    @property
    def duration(self):
        """Returns the duration of the audio in seconds."""
        return self.num_samples / self.sample_rate
    
    @property
    def peak_gain(self):
        """Returns the peak amplitude of the audio."""
        return np.max(np.abs(self))
    
    @property
    def sample_rate(self):
        """Returns the sample rate of the audio."""
        return self._sample_rate