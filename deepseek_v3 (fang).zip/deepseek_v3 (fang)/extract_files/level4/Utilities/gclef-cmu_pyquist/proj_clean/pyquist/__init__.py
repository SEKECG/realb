__all__ = []

def load_tests(loader, standard_tests, pattern):
    """NOTE: This changes the test discovery pattern from "test*.py" (default) to "*test.py".
    Dynamically discover and add test modules matching the pattern \"*test.py\" from a specified directory to the standard test suite, then return the augmented test suite.
    """
    pass