import os
import re
import logging
from typing import List, Dict, Tuple
import chromadb
from chromadb.config import Settings

class ChromaCollectionManager:
    def __init__(self, persist_directory):
        self.persist_directory = persist_directory
        self.client = chromadb.Client(Settings(
            chroma_db_impl="duckdb+parquet",
            persist_directory=persist_directory
        ))
        self.logger = logging.getLogger(__name__)
        logging.basicConfig(level=logging.INFO)

    def _get_all_uuid_directories(self) -> List[str]:
        uuid_pattern = re.compile(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')
        return [
            d for d in os.listdir(self.persist_directory) 
            if uuid_pattern.match(d) and os.path.isdir(os.path.join(self.persist_directory, d))
        ]

    def _get_collection_uuid_mapping(self) -> Dict[str, str]:
        mapping = {}
        for collection in self.client.list_collections():
            mapping[collection.name] = collection.id
        return mapping

    def create_collection(self, collection_name: str) -> bool:
        try:
            self.client.create_collection(collection_name)
            self.logger.info(f"Created collection: {collection_name}")
            return True
        except Exception as e:
            self.logger.error(f"Failed to create collection {collection_name}: {e}")
            return False

    def delete_collection(self, collection_name: str) -> bool:
        try:
            self.client.delete_collection(collection_name)
            self.logger.info(f"Deleted collection: {collection_name}")
            return True
        except Exception as e:
            self.logger.error(f"Failed to delete collection {collection_name}: {e}")
            return False

    def delete_collections(self, collection_names: List[str]) -> dict:
        results = {}
        for name in collection_names:
            results[name] = self.delete_collection(name)
        return results

    def delete_orphaned_uuid_dirs(self) -> Tuple[int, List[str]]:
        collection_uuids = set(self._get_collection_uuid_mapping().values())
        all_uuids = set(self._get_all_uuid_directories())
        orphaned_uuids = all_uuids - collection_uuids
        
        deleted = []
        for uuid in orphaned_uuids:
            try:
                dir_path = os.path.join(self.persist_directory, uuid)
                os.rmdir(dir_path)
                deleted.append(uuid)
            except Exception as e:
                self.logger.error(f"Failed to delete orphaned UUID directory {uuid}: {e}")
        
        return len(deleted), deleted

    def get_collection_info(self, collection_name: str) -> dict:
        try:
            collection = self.client.get_collection(collection_name)
            return {
                'name': collection.name,
                'id': collection.id,
                'metadata': collection.metadata,
                'count': collection.count()
            }
        except Exception as e:
            self.logger.error(f"Failed to get info for collection {collection_name}: {e}")
            return {}

    def list_collections(self) -> List[str]:
        return [col.name for col in self.client.list_collections()]

    def list_collections_with_uuids(self) -> Tuple[List[Dict], List[str]]:
        collections = []
        for col in self.client.list_collections():
            collections.append({
                'name': col.name,
                'id': col.id,
                'count': col.count()
            })
        
        collection_uuids = set(self._get_collection_uuid_mapping().values())
        all_uuids = set(self._get_all_uuid_directories())
        orphaned_uuids = list(all_uuids - collection_uuids)
        
        return collections, orphaned_uuids

def main():
    import argparse
    parser = argparse.ArgumentParser(description="ChromaDB Collection Manager")
    parser.add_argument('--path', required=True, help="Path to ChromaDB persistence directory")
    args = parser.parse_args()
    
    manager = ChromaCollectionManager(args.path)
    
    while True:
        print("\nOptions:")
        print("1. List collections")
        print("2. Create collection")
        print("3. Delete collection")
        print("4. Delete multiple collections")
        print("5. Get collection info")
        print("6. Cleanup orphaned UUID directories")
        print("7. Exit")
        
        choice = input("Enter your choice: ")
        
        if choice == '1':
            collections, orphaned = manager.list_collections_with_uuids()
            print("\nCollections:")
            for col in collections:
                print(f"- {col['name']} (ID: {col['id']}, Count: {col['count']})")
            if orphaned:
                print("\nOrphaned UUID directories:")
                for uuid in orphaned:
                    print(f"- {uuid}")
        
        elif choice == '2':
            name = input("Enter collection name: ")
            if manager.create_collection(name):
                print(f"Collection '{name}' created successfully")
        
        elif choice == '3':
            name = input("Enter collection name to delete: ")
            if manager.delete_collection(name):
                print(f"Collection '{name}' deleted successfully")
        
        elif choice == '4':
            names = input("Enter collection names to delete (comma separated): ").split(',')
            names = [n.strip() for n in names]
            results = manager.delete_collections(names)
            for name, success in results.items():
                status = "success" if success else "failed"
                print(f"Deletion of '{name}': {status}")
        
        elif choice == '5':
            name = input("Enter collection name: ")
            info = manager.get_collection_info(name)
            if info:
                print(f"\nCollection Info:")
                for k, v in info.items():
                    print(f"{k}: {v}")
        
        elif choice == '6':
            count, deleted = manager.delete_orphaned_uuid_dirs()
            print(f"Deleted {count} orphaned UUID directories")
            if deleted:
                print("Deleted directories:")
                for uuid in deleted:
                    print(f"- {uuid}")
        
        elif choice == '7':
            break
        
        else:
            print("Invalid choice")

if __name__ == "__main__":
    main()