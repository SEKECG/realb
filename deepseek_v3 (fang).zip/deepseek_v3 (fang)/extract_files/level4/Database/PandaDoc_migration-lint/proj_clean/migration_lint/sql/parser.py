from typing import Sequence, Tuple
from .constants import StatementType

def classify_migration(raw_sql) -> Sequence[Tuple[str, StatementType]]:
    # Implementation would go here
    return []

def classify_statement(statement, context) -> StatementType:
    # Implementation would go here
    return StatementType.BACKWARD_COMPATIBLE