from typing import List
from .base import BaseLinter

DOCS_URL = "https://example.com/docs"

class CompatibilityLinter(BaseLinter):
    def lint(self, migration_sql, changed_files, report_restricted=True) -> List[str]:
        errors = []
        # Implementation would go here
        return errors