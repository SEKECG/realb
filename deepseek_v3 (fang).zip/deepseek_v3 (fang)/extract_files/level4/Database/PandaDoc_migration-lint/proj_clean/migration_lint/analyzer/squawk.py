import platform
import subprocess
from pathlib import Path
from typing import List, Optional

from ..util.env import get_bool_env

class SquawkLinter:
    def __init__(self, config_path, pg_version):
        self.config_path = config_path
        self.pg_version = pg_version
        self.ignored_rules = []
        self.squawk = self._get_squawk_path()

    def _get_squawk_path(self) -> Path:
        system = platform.system().lower()
        if system == "linux":
            return Path("squawk-linux")
        elif system == "darwin":
            return Path("squawk-macos")
        else:
            raise RuntimeError(f"Unsupported platform: {system}")

    def squawk_command(self, migration_sql) -> str:
        cmd = [
            str(self.squawk),
            "--pg-version", str(self.pg_version),
            "--config", str(self.config_path),
            "--stdin"
        ]
        return " ".join(cmd)

    def lint(self, migration_sql, changed_files) -> List[str]:
        cmd = self.squawk_command(migration_sql)
        result = subprocess.run(
            cmd,
            input=migration_sql,
            capture_output=True,
            text=True,
            shell=True
        )
        if result.returncode != 0:
            return [result.stderr]
        return []