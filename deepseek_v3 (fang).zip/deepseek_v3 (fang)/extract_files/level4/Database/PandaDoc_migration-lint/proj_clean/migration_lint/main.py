from typing import Optional
from .analyzer import Analyzer
from .analyzer.compat import CompatibilityLinter
from .analyzer.squawk import SquawkLinter
from .extractor import Extractor
from .source_loader import SourceLoader

def main(
    loader_type,
    extractor_type,
    squawk_config_path=None,
    squawk_pg_version=None,
    **kwargs
):
    loader = SourceLoader.get(loader_type)(**kwargs)
    extractor = Extractor.get(extractor_type)(**kwargs)
    
    linters = [CompatibilityLinter()]
    if squawk_config_path and squawk_pg_version:
        linters.append(SquawkLinter(squawk_config_path, squawk_pg_version))
    
    analyzer = Analyzer(loader, extractor, linters)
    analyzer.analyze()