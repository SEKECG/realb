import os

def get_bool_env(var_name, default=False) -> bool:
    val = os.getenv(var_name, str(default)).lower()
    return val in ('true', '1', 't', 'y', 'yes')