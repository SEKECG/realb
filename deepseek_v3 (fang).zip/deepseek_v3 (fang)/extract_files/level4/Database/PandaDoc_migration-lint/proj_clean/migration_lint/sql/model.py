from dataclasses import dataclass
from typing import List, Optional

@dataclass
class ConditionalMatch:
    locator: 'SegmentLocator'
    match_by: str

@dataclass
class KeywordLocator:
    type: str

@dataclass
class SegmentLocator:
    type: Optional[str] = None
    raw: Optional[str] = None
    children: Optional[List['SegmentLocator']] = None
    inverted: bool = False
    ignore_order: bool = False
    only_with: Optional[ConditionalMatch] = None