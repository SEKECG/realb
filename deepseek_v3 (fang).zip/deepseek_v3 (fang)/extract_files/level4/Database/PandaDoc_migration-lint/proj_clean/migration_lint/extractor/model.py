from dataclasses import dataclass, field
from typing import List, Optional

from ..source_loader.model import SourceDiff

@dataclass
class ExtendedSourceDiff(SourceDiff):
    allowed_with_backward_incompatible: bool = False

    @classmethod
    def of_source_diff(cls, source_diff, allowed_with_backward_incompatible=False):
        return cls(
            path=source_diff.path,
            old_path=source_diff.old_path,
            diff=source_diff.diff,
            allowed_with_backward_incompatible=allowed_with_backward_incompatible
        )

@dataclass
class Migration:
    path: str
    raw_sql: str

@dataclass
class MigrationsMetadata:
    changed_files: List[ExtendedSourceDiff] = field(default_factory=list)
    migrations: List[Migration] = field(default_factory=list)