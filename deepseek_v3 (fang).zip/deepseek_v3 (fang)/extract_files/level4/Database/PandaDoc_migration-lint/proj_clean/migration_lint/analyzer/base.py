from typing import List, Sequence
from ..extractor.model import MigrationsMetadata
from ..source_loader.model import SourceDiff

CLASSIFICATION_LINK = "https://example.com/classification"
IGNORE_LINK = "https://example.com/ignore"
MANUALLY_IGNORE_ANNOTATION = "migration-lint: ignore"

class BaseLinter:
    def lint(self, migration_sql, changed_files) -> List[str]:
        raise NotImplementedError()

class Analyzer:
    def __init__(self, loader, extractor, linters):
        self.loader = loader
        self.extractor = extractor
        self.linters = linters

    def analyze(self):
        changed_files = self.loader.get_changed_files()
        metadata = self.extractor.create_metadata(changed_files)
        
        for migration in metadata.migrations:
            for linter in self.linters:
                linter.lint(migration.raw_sql, changed_files)