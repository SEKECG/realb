import sqlite3
from datetime import datetime
from util__settings import POSTURE_LANDMARKS

class Database:
    def __init__(self, db_path):
        self.conn = sqlite3.connect(db_path)
        self.cursor = self.conn.cursor()
        self.posture_landmarks = POSTURE_LANDMARKS
        self._create_tables()

    def _create_tables(self):
        self.create_table(
            "posture_scores",
            [
                "timestamp TEXT PRIMARY KEY",
                "score REAL NOT NULL"
            ]
        )
        
        landmarks_columns = ["timestamp TEXT PRIMARY KEY"]
        for landmark in self.posture_landmarks:
            landmarks_columns.append(f"{landmark}_x REAL NOT NULL")
            landmarks_columns.append(f"{landmark}_y REAL NOT NULL")
            landmarks_columns.append(f"{landmark}_z REAL NOT NULL")
            
        self.create_table("pose_landmarks", landmarks_columns)

    def create_table(self, table_name, columns):
        columns_str = ", ".join(columns)
        self.cursor.execute(
            f"CREATE TABLE IF NOT EXISTS {table_name} ({columns_str})"
        )
        self.conn.commit()

    def insert(self, table_name, values):
        placeholders = ", ".join(["?"] * len(values))
        self.cursor.execute(
            f"INSERT INTO {table_name} VALUES ({placeholders})",
            values
        )
        self.conn.commit()

    def save_pose_data(self, landmarks, score):
        timestamp = datetime.now().isoformat()
        
        # Save score
        self.insert("posture_scores", [timestamp, score])
        
        # Save landmarks
        landmark_values = [timestamp]
        for landmark in self.posture_landmarks:
            landmark_values.extend([
                landmarks[landmark].x,
                landmarks[landmark].y,
                landmarks[landmark].z
            ])
        
        self.insert("pose_landmarks", landmark_values)

    def close(self):
        self.conn.close()