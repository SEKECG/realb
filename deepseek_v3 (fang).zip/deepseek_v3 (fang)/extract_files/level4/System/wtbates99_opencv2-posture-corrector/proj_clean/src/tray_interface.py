from PyQt5.QtWidgets import (QSystemTrayIcon, QMenu, QAction, QLabel, 
                            QVBoxLayout, QWidget, QMessageBox)
from PyQt5.QtGui import QIcon, QPixmap, QImage
from PyQt5.QtCore import QTimer, QSize, Qt, pyqtSignal
import time
from datetime import datetime, timedelta
from util__settings import get_setting
from util__create_score_icon import create_score_icon
from notifications import Notifications
from webcam import Webcam
from pose_detector import PoseDetector
from database import Database
from util__scores import Scores
from settings_interface import SettingsInterface
import os

class PostureTrackerTray:
    def __init__(self):
        self._initialize_application()
        self._initialize_components()
        self._setup_tray_menu()
        self._setup_timers()
        self._setup_signal_handling()
        
        self.tracking_enabled = False
        self.db_enabled = get_setting("db_logging")
        self.tracking_interval = get_setting("tracking_duration")
        self.current_score = 0
        self.scores = Scores()
        self.last_tracking_time = None
        self.last_db_save = None
        
        if self.db_enabled:
            db_path = os.path.join(os.path.expanduser("~"), "posture_data.db")
            self.db = Database(db_path)
        else:
            self.db = None

    def _initialize_application(self):
        self.tray_icon = QSystemTrayIcon()
        self.icon_path = os.path.join(os.path.dirname(__file__), "icon.png")
        self.tray_icon.setIcon(QIcon(self.icon_path))
        self.tray_icon.show()

    def _initialize_components(self):
        self.frame_reader = Webcam()
        self.detector = PoseDetector(
            min_detection_confidence=get_setting("min_detection_confidence"),
            min_tracking_confidence=get_setting("min_tracking_confidence"),
            frame_width=get_setting("frame_width"),
            frame_height=get_setting("frame_height")
        )
        self.notifier = Notifications(self.icon_path)
        self.video_window = None
        self.video_label = None

    def _setup_tray_menu(self):
        menu = QMenu()
        
        # Tracking toggle
        self.toggle_tracking_action = QAction("Start Tracking")
        self.toggle_tracking_action.triggered.connect(self.toggle_tracking)
        menu.addAction(self.toggle_tracking_action)
        
        # Video toggle
        self.toggle_video_action = QAction("Show Video")
        self.toggle_video_action.triggered.connect(self.toggle_video)
        menu.addAction(self.toggle_video_action)
        
        # Interval menu
        self.interval_menu = menu.addMenu("Tracking Interval")
        self._create_interval_menu(self.interval_menu)
        
        # Settings
        self.settings_action = QAction("Settings")
        self.settings_action.triggered.connect(self.open_settings)
        menu.addAction(self.settings_action)
        
        # Quit
        quit_action = QAction("Quit")
        quit_action.triggered.connect(self.quit_application)
        menu.addAction(quit_action)
        
        self.tray_icon.setContextMenu(menu)

    def _create_interval_menu(self, parent_menu):
        intervals = get_setting("intervals")
        for name, minutes in intervals.items():
            action = QAction(name)
            action.triggered.connect(lambda _, m=minutes: self.set_interval(m))
            parent_menu.addAction(action)
        
        parent_menu.addSeparator()
        custom_action = QAction("Custom...")
        custom_action.triggered.connect(lambda: self.set_interval(
            get_setting("tracking_duration")
        ))
        parent_menu.addAction(custom_action)

    def _setup_timers(self):
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_tracking)
        self.timer.start(1000 // get_setting("fps"))
        
        self.interval_timer = QTimer()
        self.interval_timer.timeout.connect(self.check_interval)
        self.interval_timer.start(1000)

    def _setup_signal_handling(self):
        import signal
        signal.signal(signal.SIGINT, self.signal_handler)
        signal.signal(signal.SIGTERM, self.signal_handler)

    def _create_video_window(self):
        self.video_window = QWidget()
        self.video_window.setWindowTitle("Posture Corrector - Live Feed")
        self.video_window.setWindowFlags(Qt.WindowStaysOnTopHint)
        self.video_window.resize(640, 480)
        
        layout = QVBoxLayout()
        self.video_label = QLabel()
        layout.addWidget(self.video_label)
        self.video_window.setLayout(layout)
        
        self.video_window.closeEvent = lambda event: self.on_video_window_closed()
        self.video_window.show()

    def _update_video_display(self, frame):
        if self.video_window and self.video_label:
            height, width, channel = frame.shape
            bytes_per_line = 3 * width
            q_img = QImage(frame.data, width, height, bytes_per_line, QImage.Format_RGB888)
            pixmap = QPixmap.fromImage(q_img)
            self.video_label.setPixmap(pixmap.scaled(
                self.video_label.size(), 
                Qt.KeepAspectRatio,
                Qt.SmoothTransformation
            ))

    def _start_tracking(self):
        self.frame_reader.start(self._process_frame)
        self.toggle_tracking_action.setText("Stop Tracking")
        self.tracking_enabled = True

    def _stop_tracking(self):
        self.frame_reader.stop()
        self.toggle_tracking_action.setText("Start Tracking")
        self.tracking_enabled = False

    def _save_to_db(self, average_score):
        if not self.db_enabled:
            return
            
        current_time = time.time()
        if (self.last_db_save is None or 
            current_time - self.last_db_save >= get_setting("db_write_interval") * 60):
            self.db.save_pose_data(
                self.frame_reader.get_latest_pose_results(),
                average_score
            )
            self.last_db_save = current_time

    def toggle_tracking(self):
        if self.tracking_enabled:
            self._stop_tracking()
        else:
            self._start_tracking()

    def toggle_video(self):
        if self.video_window and self.video_window.isVisible():
            self.video_window.hide()
            self.toggle_video_action.setText("Show Video")
        else:
            if self.video_window is None:
                self._create_video_window()
            else:
                self.video_window.show()
            self.toggle_video_action.setText("Hide Video")

    def update_tracking(self):
        if not self.tracking_enabled:
            return
            
        frame, score, results = self.frame_reader.get_latest_frame()
        if frame is not None and score is not None:
            self.current_score = score
            self.scores.add_score(score)
            self.notifier.check_and_notify(score)
            
            average_score = self.scores.get_average_score()
            icon = create_score_icon(average_score)
            self.tray_icon.setIcon(QIcon(icon))
            
            if self.video_window and self.video_window.isVisible():
                self._update_video_display(frame)
            
            self._save_to_db(average_score)

    def check_interval(self):
        if self.last_tracking_time is None:
            return
            
        elapsed = (datetime.now() - self.last_tracking_time).total_seconds()
        if elapsed >= self.tracking_interval * 60:
            self.stop_interval_tracking()

    def start_interval_tracking(self):
        self.last_tracking_time = datetime.now()
        if not self.tracking_enabled:
            self._start_tracking()
        
        interval_name = next(
            (name for name, minutes in get_setting("intervals").items() 
             if minutes == self.tracking_interval),
            f"{self.tracking_interval} min"
        )
        self.notifier.set_interval_message(
            f"Tracking posture for {interval_name} interval"
        )

    def stop_interval_tracking(self):
        self._stop_tracking()
        self.last_tracking_time = None
        self.notifier.set_interval_message(
            "Interval tracking completed"
        )

    def set_interval(self, minutes):
        self.tracking_interval = minutes
        if self.tracking_enabled:
            self.start_interval_tracking()

    def open_settings(self):
        settings_dialog = SettingsInterface()
        if settings_dialog.exec_():
            self.reload_settings()

    def reload_settings(self):
        self.db_enabled = get_setting("db_logging")
        self.timer.setInterval(1000 // get_setting("fps"))
        
        if not self.db_enabled and hasattr(self, 'db'):
            self.db.close()
            self.db = None
        elif self.db_enabled and not hasattr(self, 'db'):
            db_path = os.path.join(os.path.expanduser("~"), "posture_data.db")
            self.db = Database(db_path)

    def on_video_window_closed(self):
        self.toggle_video_action.setText("Show Video")

    def signal_handler(self, signum, frame):
        self.quit_application()

    def quit_application(self):
        self.frame_reader.stop()
        if hasattr(self, 'db') and self.db:
            self.db.close()
        QApplication.quit()