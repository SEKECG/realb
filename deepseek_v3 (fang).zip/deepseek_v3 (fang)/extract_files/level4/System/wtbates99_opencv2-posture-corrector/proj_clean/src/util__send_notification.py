from plyer import notification
from PyQt5.QtWidgets import QMessageBox
import platform

def send_notification(message, title, icon_path):
    if platform.system() == "Linux":
        # Linux systems might not show notifications properly, fallback to message box
        msg = QMessageBox()
        msg.setIconPixmap(QPixmap(icon_path).scaled(64, 64))
        msg.setText(message)
        msg.setWindowTitle(title)
        msg.setStandardButtons(QMessageBox.Ok)
        msg.exec_()
    else:
        try:
            notification.notify(
                title=title,
                message=message,
                app_icon=icon_path,
                timeout=10
            )
        except:
            # Fallback if plyer notification fails
            print(f"Notification: {title} - {message}")