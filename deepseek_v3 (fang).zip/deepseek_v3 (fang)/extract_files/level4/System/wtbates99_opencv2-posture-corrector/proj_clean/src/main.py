import os
import sys
import signal
import psutil
from PyQt5.QtWidgets import QApplication
from tray_interface import PostureTrackerTray

def kill_existing_instance(lock_file):
    if os.path.exists(lock_file):
        with open(lock_file, 'r') as f:
            pid = int(f.read().strip())
        
        try:
            process = psutil.Process(pid)
            if any("python" in cmd.lower() for cmd in process.cmdline()):
                process.terminate()
        except psutil.NoSuchProcess:
            pass
        
        os.remove(lock_file)

def main():
    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)
    
    # Single instance check
    lock_file = os.path.join(os.path.expanduser("~"), ".posture_corrector.lock")
    kill_existing_instance(lock_file)
    
    with open(lock_file, 'w') as f:
        f.write(str(os.getpid()))
    
    # Handle signals for proper cleanup
    signal.signal(signal.SIGINT, lambda *args: app.quit())
    signal.signal(signal.SIGTERM, lambda *args: app.quit())
    
    tray = PostureTrackerTray()
    
    def cleanup():
        if os.path.exists(lock_file):
            os.remove(lock_file)
    
    app.aboutToQuit.connect(cleanup)
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()