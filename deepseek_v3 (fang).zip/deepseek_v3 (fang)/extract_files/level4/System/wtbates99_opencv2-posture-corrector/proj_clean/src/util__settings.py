import json
import os
from pathlib import Path

# Constants
POSTURE_LANDMARKS = [
    "nose", "left_shoulder", "right_shoulder", 
    "left_elbow", "right_elbow", "left_wrist", 
    "right_wrist", "left_hip", "right_hip"
]

CUSTOMIZABLE_SETTINGS = {
    "camera": {
        "default_camera": 0,
        "fps": 30,
        "frame_width": 640,
        "frame_height": 480,
        "model_complexity": 1
    },
    "general": {
        "notification_cooldown": 5,
        "poor_posture_threshold": 70,
        "posture_message": "Please sit up straight!",
        "db_logging": True,
        "db_write_interval": 5
    },
    "tracking": {
        "tracking_duration": 30,
        "intervals": {
            "Quick Check": 5,
            "Standard": 30,
            "Long": 120
        }
    }
}

IMMUTABLE_SETTINGS = {
    "version": "1.0",
    "min_detection_confidence": 0.5,
    "min_tracking_confidence": 0.5
}

USER_SETTINGS_FILE = str(Path.home() / ".posture_corrector_settings.json")

def get_setting(key):
    if key in IMMUTABLE_SETTINGS:
        return IMMUTABLE_SETTINGS[key]
    
    for category in CUSTOMIZABLE_SETTINGS.values():
        if key in category:
            return category[key]
    
    raise KeyError(f"Setting '{key}' not found")

def save_user_settings():
    with open(USER_SETTINGS_FILE, 'w') as f:
        json.dump(CUSTOMIZABLE_SETTINGS, f, indent=4)

def load_user_settings():
    if os.path.exists(USER_SETTINGS_FILE):
        with open(USER_SETTINGS_FILE, 'r') as f:
            user_settings = json.load(f)
            for category, settings in user_settings.items():
                if category in CUSTOMIZABLE_SETTINGS:
                    CUSTOMIZABLE_SETTINGS[category].update(settings)

def update_setting(key, value):
    for category in CUSTOMIZABLE_SETTINGS.values():
        if key in category:
            if key in IMMUTABLE_SETTINGS:
                raise ValueError(f"Cannot update immutable setting: {key}")
            category[key] = value
            save_user_settings()
            return
    
    raise KeyError(f"Setting '{key}' not found in customizable settings")

# Load user settings on module import
load_user_settings()