import time
from util__send_notification import send_notification

class Notifications:
    def __init__(self, icon_path):
        self.icon_path = icon_path
        self.notification_cooldown = get_setting("notification_cooldown")
        self.poor_posture_threshold = get_setting("poor_posture_threshold")
        self.posture_message = get_setting("posture_message")
        self.interval_message = ""
        self.last_notification_time = 0

    def check_and_notify(self, posture_score):
        current_time = time.time()
        if (posture_score < self.poor_posture_threshold and 
            current_time - self.last_notification_time >= self.notification_cooldown * 60):
            send_notification(
                self.posture_message,
                "Posture Alert",
                self.icon_path
            )
            self.last_notification_time = current_time

    def set_interval_message(self, message):
        self.interval_message = message
        send_notification(
            message,
            "Posture Tracker",
            self.icon_path
        )