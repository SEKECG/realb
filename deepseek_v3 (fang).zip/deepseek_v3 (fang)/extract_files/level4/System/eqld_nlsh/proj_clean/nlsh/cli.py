import argparse
import os
import signal
import subprocess
import sys
from typing import Any, Dict, List, Optional, Tuple, Union

from .backends import BackendManager, strip_markdown_code_blocks
from .config import Config
from .editor import edit_text_in_editor
from .prompt import PromptBuilder
from .spinner import Spinner
from .tools import get_tools

def safe_write(stream, text):
    """Safely write text to a stream."""
    try:
        stream.write(text)
        stream.flush()
    except (IOError, UnicodeEncodeError):
        pass

def handle_keyboard_interrupt(signum, frame):
    """Handle keyboard interrupt (Ctrl+C)."""
    print("\nOperation cancelled by user", file=sys.stderr)
    sys.exit(1)

def execute_command(command):
    """Execute a shell command safely."""
    try:
        process = subprocess.Popen(
            command,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            universal_newlines=True
        )
        stdout, stderr = process.communicate()
        return process.returncode, stdout + stderr
    except Exception as e:
        return -1, str(e)

def confirm_execution(command):
    """Ask for confirmation before executing a command."""
    print(f"\nCommand to execute:\n{command}\n")
    while True:
        response = input("Execute? [y]es/[n]o/[e]dit/[x]plain/[r]egenerate: ").lower()
        if response in ('y', 'yes'):
            return True
        elif response in ('n', 'no'):
            return False
        elif response in ('e', 'edit'):
            return "edit"
        elif response in ('x', 'explain'):
            return "explain"
        elif response in ('r', 'regenerate'):
            return "regenerate"
        else:
            print("Please enter y/n/e/x/r")

def confirm_fix(command, code):
    """Ask for confirmation before fixing failed command."""
    print(f"\nCommand failed with exit code {code}:\n{command}\n")
    response = input("Attempt to fix? [y]es/[n]o: ").lower()
    return response in ('y', 'yes')

def log(log_file, backend, system_prompt, prompt, response):
    """Log interactions with an LLM backend."""
    if not log_file:
        return
        
    try:
        import json
        from datetime import datetime
        
        entry = {
            "timestamp": datetime.now().isoformat(),
            "backend": backend.name,
            "model": backend.model,
            "system_prompt": system_prompt,
            "prompt": prompt,
            "response": response
        }
        
        with open(log_file, 'a') as f:
            f.write(json.dumps(entry) + "\n")
    except Exception:
        pass

def explain_command(config, backend_index, command, verbose, log_file):
    """Generate an explanation for a shell command."""
    backend_manager = BackendManager(config)
    backend = backend_manager.get_backend(backend_index)
    
    tools = get_tools(config)
    prompt_builder = PromptBuilder(config)
    
    system_prompt = prompt_builder.build_explanation_system_prompt(tools)
    user_prompt = f"Explain this command: {command}"
    
    with Spinner("Generating explanation..."):
        response = backend.generate_response(
            user_prompt,
            system_prompt,
            verbose,
            True,
            1000,
            0
        )
    
    log(log_file, backend, system_prompt, user_prompt, response)
    return response

def generate_command(config, backend_index, prompt, declined_commands, verbose, log_file):
    """Generate a command using the specified backend."""
    backend_manager = BackendManager(config)
    backend = backend_manager.get_backend(backend_index)
    
    tools = get_tools(config)
    prompt_builder = PromptBuilder(config)
    
    system_prompt = prompt_builder.build_system_prompt(tools, declined_commands)
    
    with Spinner("Generating command..."):
        response = backend.generate_response(
            prompt,
            system_prompt,
            verbose,
            True,
            1000,
            len(declined_commands)
        )
    
    log(log_file, backend, system_prompt, prompt, response)
    return response

def generate_command_fix(config, backend_index, prompt, failed_command, failed_command_exit_code, failed_command_output, verbose, log_file):
    """Generate a fix for failed command."""
    backend_manager = BackendManager(config)
    backend = backend_manager.get_backend(backend_index)
    
    tools = get_tools(config)
    prompt_builder = PromptBuilder(config)
    
    system_prompt = prompt_builder.build_fixing_system_prompt(tools)
    user_prompt = prompt_builder.build_fixing_user_prompt(
        prompt,
        failed_command,
        failed_command_exit_code,
        failed_command_output
    )
    
    with Spinner("Generating fix..."):
        response = backend.generate_response(
            user_prompt,
            system_prompt,
            verbose,
            True,
            1000,
            0
        )
    
    log(log_file, backend, system_prompt, user_prompt, response)
    return response

def _get_prompt(args, config):
    """Get prompt from file or command line."""
    if args.prompt_file:
        with open(args.prompt_file, 'r') as f:
            return f.read().strip()
    return ' '.join(args.prompt)

def _handle_edit_command(command):
    """Handle editing a command."""
    edited = edit_text_in_editor(command, ".sh")
    if not edited or edited.strip() == command.strip():
        return command, False
    return edited, True

def _handle_explain_command(config, args, command):
    """Handle explaining a command."""
    try:
        explanation = explain_command(
            config,
            args.backend,
            command,
            args.verbose,
            args.log_file
        )
        print(f"\nExplanation:\n{explanation}\n")
        return input("Continue with execution? [y]es/[n]o: ").lower() in ('y', 'yes')
    except Exception as e:
        print(f"Error generating explanation: {str(e)}", file=sys.stderr)
        return False

def _process_command_confirmation(config, args, command, declined_commands):
    """Process command confirmation and execution."""
    while True:
        action = confirm_execution(command)
        
        if action == "regenerate":
            return None, True, None
        elif action == "edit":
            command, should_continue = _handle_edit_command(command)
            if not should_continue:
                return None, False, None
        elif action == "explain":
            should_continue = _handle_explain_command(config, args, command)
            if not should_continue:
                return None, False, None
        elif action is True:
            exit_code, output = execute_command(command)
            if exit_code == 0:
                return exit_code, False, None
            else:
                fix_info = {
                    "command": command,
                    "exit_code": exit_code,
                    "output": output
                }
                return exit_code, False, fix_info
        else:
            declined_commands.append(command)
            return None, False, None

def parse_args(args=None):
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(description="Neural Shell - AI-driven command-line assistant")
    parser.add_argument("prompt", nargs="*", help="Prompt describing the command to generate")
    parser.add_argument("-f", "--prompt-file", help="Read prompt from file")
    parser.add_argument("-b", "--backend", type=int, default=0, help="Backend index to use")
    parser.add_argument("-v", "--verbose", action="store_true", help="Verbose output")
    parser.add_argument("-l", "--log-file", help="Log interactions to file")
    return parser.parse_args(args)

def main():
    """Main entry point."""
    signal.signal(signal.SIGINT, handle_keyboard_interrupt)
    
    args = parse_args()
    config = Config()
    
    try:
        prompt = _get_prompt(args, config)
        if not prompt:
            print("Error: No prompt provided", file=sys.stderr)
            return 1
            
        declined_commands = []
        should_continue = True
        
        while should_continue:
            try:
                command = generate_command(
                    config,
                    args.backend,
                    prompt,
                    declined_commands,
                    args.verbose,
                    args.log_file
                )
                
                exit_code, should_continue, fix_info = _process_command_confirmation(
                    config,
                    args,
                    command,
                    declined_commands
                )
                
                if fix_info and confirm_fix(fix_info["command"], fix_info["exit_code"]):
                    fixed_command = generate_command_fix(
                        config,
                        args.backend,
                        prompt,
                        fix_info["command"],
                        fix_info["exit_code"],
                        fix_info["output"],
                        args.verbose,
                        args.log_file
                    )
                    
                    exit_code, should_continue, _ = _process_command_confirmation(
                        config,
                        args,
                        fixed_command,
                        declined_commands
                    )
                
                if exit_code == 0:
                    return 0
                    
            except Exception as e:
                print(f"Error: {str(e)}", file=sys.stderr)
                return 1
                
        return 0
    except Exception as e:
        print(f"Error: {str(e)}", file=sys.stderr)
        return 1