import re
from typing import Any, Dict, List, Optional

def strip_markdown_code_blocks(text):
    """Strip Markdown code blocks from text."""
    # Handle multiline code blocks with or without language info
    text = re.sub(r'```[a-z]*\n.*?\n```', '', text, flags=re.DOTALL)
    # Handle single line code blocks
    text = re.sub(r'`.*?`', '', text)
    return text.strip()

class LLMBackend:
    """Base class for LLM backends."""
    
    def __init__(self, config):
        self.name = config.get('name', '')
        self.model = config.get('model', '')
        self.url = config.get('url', '')
        self.api_key = config.get('api_key', '')
        self.timeout = config.get('timeout', 30)
        self.is_reasoning_model = config.get('is_reasoning_model', False)
        self.client = None
        self.config = config

    def _calculate_temperature(self, regeneration_count):
        """Calculate temperature based on regeneration count."""
        temp = 0.2 + (regeneration_count * 0.1)
        return min(temp, 1.0)

    def _generate_non_streaming_response(self, messages, temperature, max_tokens, strip_markdown):
        """Generate a response without streaming."""
        raise NotImplementedError

    def _generate_streaming_response(self, messages, temperature, max_tokens, strip_markdown):
        """Generate a response using streaming mode."""
        raise NotImplementedError

    def generate_response(self, prompt, system_context, verbose, strip_markdown, max_tokens, regeneration_count):
        """Generate a response from the LLM."""
        temperature = self._calculate_temperature(regeneration_count)
        messages = [
            {"role": "system", "content": system_context},
            {"role": "user", "content": prompt}
        ]
        
        if self.is_reasoning_model and verbose:
            print("Reasoning tokens:", messages, file=sys.stderr)
        
        try:
            if self.config.get('stream', False):
                response = self._generate_streaming_response(
                    messages, temperature, max_tokens, strip_markdown
                )
            else:
                response = self._generate_non_streaming_response(
                    messages, temperature, max_tokens, strip_markdown
                )
            
            if strip_markdown:
                response = strip_markdown_code_blocks(response)
            
            return response
        except Exception as e:
            raise Exception(f"Error generating response: {str(e)}")

class BackendManager:
    """Manager for LLM backends."""
    
    def __init__(self, config):
        self.config = config
        self.backends = {}
        self._initialize_backends()

    def _initialize_backends(self):
        """Initialize all configured backends."""
        for idx, backend_config in enumerate(self.config.get('backends', [])):
            try:
                backend = LLMBackend(backend_config)
                self.backends[idx] = backend
            except Exception as e:
                print(f"Error initializing backend {idx}: {str(e)}", file=sys.stderr)

    def get_backend(self, index=None):
        """Get a backend instance."""
        if index is None:
            index = self.config.get('default_backend', 0)
        
        if index not in self.backends:
            raise ValueError(f"Backend index {index} not found")
        
        return self.backends[index]