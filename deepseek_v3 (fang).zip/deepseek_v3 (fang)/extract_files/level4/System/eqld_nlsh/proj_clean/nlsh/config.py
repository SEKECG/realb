import os
import shutil
from pathlib import Path
from typing import Any, Dict, Optional

class ConfigValidationError(Exception):
    """Configuration validation error."""
    pass

class Config:
    """Configuration manager for nlsh."""
    
    DEFAULT_CONFIG = {
        "shell": "bash",
        "default_backend": 0,
        "backends": [
            {
                "name": "default",
                "model": "gpt-3.5-turbo",
                "url": "https://api.openai.com/v1/chat/completions",
                "api_key": "",
                "timeout": 30,
                "is_reasoning_model": True
            }
        ],
        "nlgc": {
            "include_full_files": False,
            "max_tokens": 2000
        }
    }

    def __init__(self, config_path=None):
        self.config_file_path = None
        self.config_file_found = False
        self.config = self.DEFAULT_CONFIG.copy()
        
        config_file = self._find_config_file(config_path)
        if config_file:
            self._load_config_file(config_file)
        
        self._apply_env_overrides()

    def _find_config_file(self, config_path):
        """Find configuration file."""
        if config_path:
            config_path = Path(config_path)
            if config_path.exists():
                self.config_file_path = config_path
                self.config_file_found = True
                return config_path
            return None
            
        # Check standard locations
        locations = [
            Path("nlsh.yaml"),
            Path("nlsh.yml"),
            Path("~/.config/nlsh/nlsh.yaml").expanduser(),
            Path("~/.nlsh.yaml").expanduser(),
        ]
        
        for loc in locations:
            if loc.exists():
                self.config_file_path = loc
                self.config_file_found = True
                return loc
                
        return None

    def _load_config_file(self, config_file):
        """Load and validate configuration from file."""
        try:
            import yaml
            with open(config_file, 'r') as f:
                user_config = yaml.safe_load(f) or {}
            self._update_config(self.config, user_config)
            self._validate_config(self.config)
        except Exception as e:
            raise ConfigValidationError(f"Error loading config file: {str(e)}")

    def _update_config(self, base_config, new_config):
        """Recursively update configuration."""
        for key, value in new_config.items():
            if isinstance(value, dict) and key in base_config:
                self._update_config(base_config[key], value)
            else:
                base_config[key] = value

    def _validate_config(self, config):
        """Validate configuration structure and values."""
        if not isinstance(config.get('backends'), list):
            raise ConfigValidationError("Backends must be a list")
            
        if not isinstance(config.get('shell'), str):
            raise ConfigValidationError("Shell must be a string")
            
        if config['shell'] not in ('bash', 'zsh', 'fish', 'powershell'):
            raise ConfigValidationError("Unsupported shell")

    def _apply_env_overrides(self):
        """Apply environment variable overrides to configuration."""
        if 'NLSH_SHELL' in os.environ:
            self.config['shell'] = os.environ['NLSH_SHELL']

    def _get_default_config_path(self):
        """Get the default path where config file would be created."""
        xdg_config_home = os.environ.get('XDG_CONFIG_HOME')
        if xdg_config_home:
            return Path(xdg_config_home) / "nlsh" / "nlsh.yaml"
        return Path.home() / ".config" / "nlsh" / "nlsh.yaml"

    def create_default_config(self, config_path=None):
        """Create a default configuration file."""
        if not config_path:
            config_path = self._get_default_config_path()
            
        config_path.parent.mkdir(parents=True, exist_ok=True)
        
        try:
            import yaml
            with open(config_path, 'w') as f:
                yaml.dump(self.DEFAULT_CONFIG, f)
            return config_path
        except Exception as e:
            raise ConfigValidationError(f"Error creating config file: {str(e)}")

    def get_backend(self, index=None):
        """Get backend configuration."""
        if index is None:
            index = self.config.get('default_backend', 0)
        
        try:
            return self.config['backends'][index]
        except IndexError:
            return None

    def get_nlgc_config(self):
        """Get nlgc specific configuration."""
        return self.config.get('nlgc', {})

    def get_shell(self):
        """Get configured shell."""
        return self.config['shell']