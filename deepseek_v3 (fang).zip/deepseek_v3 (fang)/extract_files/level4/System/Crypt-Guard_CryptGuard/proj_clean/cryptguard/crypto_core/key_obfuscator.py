import os
from typing import Optional, Any
from .secure_bytes import SecureBytes

class KeyObfuscator:
    def __init__(self, key_bytes):
        self._key = key_bytes
        self._obfuscated = False
        self._parts = None
        self._mask = None
    
    def __del__(self):
        self.clear()
    
    def clear(self):
        if hasattr(self, '_key'):
            self._key.wipe()
            self._key = None
        if hasattr(self, '_mask'):
            if self._mask is not None:
                self._mask.wipe()
                self._mask = None
        if hasattr(self, '_parts'):
            if self._parts is not None:
                for part in self._parts:
                    part.wipe()
                self._parts = None
    
    def obfuscate(self):
        if self._obfuscated:
            return
        
        key_data = self._key.get()
        mask = SecureBytes(length=len(key_data))
        masked = SecureBytes(bytes([a ^ b for a, b in zip(key_data, mask.get())]))
        
        self._mask = mask
        self._parts = [masked]
        self._obfuscated = True
        self._key.wipe()
    
    def deobfuscate(self):
        if not self._obfuscated:
            return
        
        masked = self._parts[0].get()
        mask = self._mask.get()
        key_data = bytes([a ^ b for a, b in zip(masked, mask)])
        
        self._key = SecureBytes(key_data)
        self._obfuscated = False
        self._mask.wipe()
        self._mask = None
        for part in self._parts:
            part.wipe()
        self._parts = None