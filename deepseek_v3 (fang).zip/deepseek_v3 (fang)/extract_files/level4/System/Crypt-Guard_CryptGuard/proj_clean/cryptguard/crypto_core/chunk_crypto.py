from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305
from typing import Optional, Tuple, Any
from .rs_codec import rs_encode_data, rs_decode_data
from .config import USE_RS, RS_PARITY_BYTES
from .secure_bytes import SecureBytes

def encrypt_chunk(chunk, key, aad=None, chunk_index=None) -> bytes:
    if aad is None:
        aad = b''
    
    if chunk_index is not None:
        aad += str(chunk_index).encode()
    
    chacha = ChaCha20Poly1305(key.get())
    nonce = b'\x00' * 12  # Fixed nonce for chunk encryption
    ciphertext = chacha.encrypt(nonce, chunk, aad)
    
    if USE_RS:
        ciphertext = rs_encode_data(ciphertext, len(chunk), RS_PARITY_BYTES)
    
    return ciphertext

def decrypt_chunk(data, key, offset, aad=None, chunk_index=None):
    if aad is None:
        aad = b''
    
    if chunk_index is not None:
        aad += str(chunk_index).encode()
    
    if USE_RS:
        try:
            data = rs_decode_data(data, RS_PARITY_BYTES)
        except Exception as e:
            raise ValueError("Reed-Solomon decoding failed") from e
    
    chacha = ChaCha20Poly1305(key.get())
    nonce = b'\x00' * 12  # Fixed nonce for chunk decryption
    try:
        plaintext = chacha.decrypt(nonce, data, aad)
    except Exception as e:
        raise ValueError("Decryption failed") from e
    
    return plaintext, offset + len(data)