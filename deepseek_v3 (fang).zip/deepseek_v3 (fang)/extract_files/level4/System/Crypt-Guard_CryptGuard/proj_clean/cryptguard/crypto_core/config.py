DEFAULT_ARGON_PARAMS = {
    'time_cost': 3,
    'memory_cost': 65536,
    'parallelism': 4,
    'hash_len': 32,
    'salt_len': 16
}

USE_RS = True
ARGON_MEMORY_COST = 65536
ARGON_MEMORY_COST_BALANCED = 131072  # 128 MB
ARGON_MEMORY_COST_FAST = 65536       # 64 MB
ARGON_MEMORY_COST_SECURE = 262144    # 256 MB
ARGON_PARALLELISM = 4
ARGON_PARALLELISM_BALANCED = 4
ARGON_PARALLELISM_FAST = 2
ARGON_PARALLELISM_SECURE = 8
ARGON_TIME_COST = 3
ARGON_TIME_COST_BALANCED = 3
ARGON_TIME_COST_FAST = 2
ARGON_TIME_COST_SECURE = 4
CHUNK_SIZE = 1048576  # 1 MB default chunk size
MAX_ATTEMPTS = 3      # Maximum password attempts before blocking
MAX_CHUNK_SIZE = 104857600  # 100 MB
META_ARGON_PARAMS = DEFAULT_ARGON_PARAMS.copy()
META_SALT_SIZE = 32   # bytes for metadata salt
META_VERSION = "1.0"  # current metadata format version
RS_PARITY_BYTES = 8   # Reed-Solomon parity bytes by default
SIGN_METADATA = True  # enable HMAC signature in metadata (optional)
SINGLE_SHOT_SUBCHUNK_SIZE = 1048576  # 1 MB, adjustable
STREAMING_THRESHOLD = 10485760  # 10 MB threshold for streaming mode

def set_use_rs(value):
    global USE_RS
    USE_RS = value