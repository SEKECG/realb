import zfec
from typing import Optional, Any

def rs_encode_data(data, block_size, parity_bytes) -> bytes:
    if len(data) == 0:
        return b''
    
    k = max(1, len(data) // block_size)
    if k == 0:
        k = 1
    
    encoder = zfec.Encoder(k, k + parity_bytes)
    blocks = [data[i*block_size:(i+1)*block_size] for i in range(k)]
    encoded = encoder.encode(blocks)
    
    header = len(data).to_bytes(4, 'big')
    return header + b''.join(encoded)

def rs_decode_data(data, parity_bytes) -> bytes:
    if len(data) < 4:
        raise ValueError("Invalid data length")
    
    orig_len = int.from_bytes(data[:4], 'big')
    if orig_len == 0:
        return b''
    
    block_size = (len(data) - 4) // (1 + parity_bytes)
    if block_size <= 0:
        raise ValueError("Invalid block size")
    
    k = max(1, (orig_len + block_size - 1) // block_size)
    decoder = zfec.Decoder(k, k + parity_bytes)
    
    blocks = [data[4+i*block_size:4+(i+1)*block_size] for i in range(k + parity_bytes)]
    decoded = decoder.decode(blocks[:k], list(range(k)))
    
    return b''.join(decoded)[:orig_len]