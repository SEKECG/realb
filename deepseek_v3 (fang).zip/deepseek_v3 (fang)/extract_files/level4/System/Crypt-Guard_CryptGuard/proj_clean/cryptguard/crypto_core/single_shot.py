import os
from typing import Optional, Any
from .argon_utils import generate_key_from_password
from .chunk_crypto import encrypt_chunk, decrypt_chunk
from .secure_bytes import SecureBytes, wipe_sensitive_data
from .config import SINGLE_SHOT_SUBCHUNK_SIZE, STREAMING_THRESHOLD

def encrypt_data_single(data, password, file_type=None, original_ext=None, key_file_hash=None, subchunk_size=None):
    if subchunk_size is None:
        subchunk_size = SINGLE_SHOT_SUBCHUNK_SIZE
    
    salt = os.urandom(16)
    key = generate_key_from_password(password, salt)
    
    if len(data) > subchunk_size:
        # Multi-sub-block mode
        chunks = [data[i:i+subchunk_size] for i in range(0, len(data), subchunk_size)]
        encrypted_chunks = []
        
        for i, chunk in enumerate(chunks):
            encrypted = encrypt_chunk(chunk, key, b'subchunk', i)
            encrypted_chunks.append(encrypted)
            key.obfuscate()
            key.deobfuscate()
        
        ciphertext = b''.join(encrypted_chunks)
        multi_sub_block = True
    else:
        # Single block mode
        ciphertext = encrypt_chunk(data, key, b'single')
        multi_sub_block = False
    
    metadata = {
        'version': '1.0',
        'salt': salt.hex(),
        'file_type': file_type,
        'original_ext': original_ext,
        'key_file_hash': key_file_hash,
        'multi_sub_block': multi_sub_block,
        'encryption_mode': 'single_shot'
    }
    
    return ciphertext, metadata

def decrypt_data_single(enc_path, password):
    with open(enc_path, 'rb') as f:
        data = f.read()
    
    metadata_path = enc_path + '.meta'
    meta = decrypt_meta_json(metadata_path, password)
    if meta is None:
        raise ValueError("Failed to decrypt metadata")
    
    salt = bytes.fromhex(meta['salt'])
    key = generate_key_from_password(password, salt)
    
    if meta.get('multi_sub_block', False):
        # Multi-sub-block mode
        chunk_size = len(data) // (len(data) // SINGLE_SHOT_SUBCHUNK_SIZE + 1)
        chunks = [data[i:i+chunk_size] for i in range(0, len(data), chunk_size)]
        decrypted_chunks = []
        
        for i, chunk in enumerate(chunks):
            decrypted, _ = decrypt_chunk(chunk, key, 0, b'subchunk', i)
            decrypted_chunks.append(decrypted)
            key.obfuscate()
            key.deobfuscate()
        
        plaintext = b''.join(decrypted_chunks)
    else:
        # Single block mode
        plaintext, _ = decrypt_chunk(data, key, 0, b'single')
    
    return plaintext, meta