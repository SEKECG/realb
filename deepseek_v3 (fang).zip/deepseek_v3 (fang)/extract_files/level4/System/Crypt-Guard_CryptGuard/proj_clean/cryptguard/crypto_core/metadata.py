import json
import os
from typing import Optional, Dict, Any
from .argon_utils import generate_key_from_password
from .chunk_crypto import encrypt_chunk, decrypt_chunk
from .secure_bytes import SecureBytes, wipe_sensitive_data
from .config import META_SALT_SIZE, META_VERSION, SIGN_METADATA

def encrypt_meta_json(meta_path, meta_plain, user_password) -> bool:
    try:
        outer_salt = os.urandom(META_SALT_SIZE)
        inner_salt = os.urandom(META_SALT_SIZE)
        
        outer_key = generate_key_from_password(user_password, outer_salt)
        inner_key = generate_key_from_password(user_password, inner_salt)
        
        meta_json = json.dumps(meta_plain).encode()
        
        # First layer encryption
        ciphertext = encrypt_chunk(meta_json, inner_key, b'meta_inner')
        
        # Second layer encryption
        meta_dict = {
            'version': META_VERSION,
            'inner_salt': inner_salt.hex(),
            'ciphertext': ciphertext.hex()
        }
        
        if SIGN_METADATA:
            import hmac
            from hashlib import sha256
            h = hmac.new(outer_key.get(), digestmod=sha256)
            h.update(json.dumps(meta_dict).encode())
            meta_dict['signature'] = h.hexdigest()
        
        final_ciphertext = encrypt_chunk(
            json.dumps(meta_dict).encode(),
            outer_key,
            b'meta_outer'
        )
        
        with open(meta_path, 'wb') as f:
            f.write(outer_salt)
            f.write(final_ciphertext)
        
        return True
    except Exception as e:
        wipe_sensitive_data(user_password)
        return False

def decrypt_meta_json(meta_path, user_password) -> Optional[Dict[str, Any]]:
    try:
        with open(meta_path, 'rb') as f:
            outer_salt = f.read(META_SALT_SIZE)
            ciphertext = f.read()
        
        outer_key = generate_key_from_password(user_password, outer_salt)
        
        # First layer decryption
        outer_plain = decrypt_chunk(ciphertext, outer_key, 0, b'meta_outer')[0]
        meta_dict = json.loads(outer_plain.decode())
        
        if SIGN_METADATA:
            import hmac
            from hashlib import sha256
            h = hmac.new(outer_key.get(), digestmod=sha256)
            h.update(json.dumps({k: v for k, v in meta_dict.items() if k != 'signature'}).encode())
            if not hmac.compare_digest(h.hexdigest(), meta_dict['signature']):
                raise ValueError("Metadata signature mismatch")
        
        inner_salt = bytes.fromhex(meta_dict['inner_salt'])
        inner_key = generate_key_from_password(user_password, inner_salt)
        
        # Second layer decryption
        inner_ciphertext = bytes.fromhex(meta_dict['ciphertext'])
        inner_plain = decrypt_chunk(inner_ciphertext, inner_key, 0, b'meta_inner')[0]
        
        return json.loads(inner_plain.decode())
    except Exception as e:
        wipe_sensitive_data(user_password)
        return None