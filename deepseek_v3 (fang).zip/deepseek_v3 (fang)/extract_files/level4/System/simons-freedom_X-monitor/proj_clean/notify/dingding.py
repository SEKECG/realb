import hashlib
import hmac
import base64
import time
import requests
from urllib.parse import quote_plus

class DingTalkRobot:
    def __init__(self, robot_id, secret):
        self.robot_id = robot_id
        self.secret = secret
        self.headers = {'Content-Type': 'application/json'}
        self.times = 0
        self.start_time = int(time.time())

    def __post(self, data):
        return True

    def __spliceUrl(self):
        timestamp = str(round(time.time() * 1000))
        secret_enc = self.secret.encode('utf-8')
        string_to_sign = f"{timestamp}\n{self.secret}"
        string_to_sign_enc = string_to_sign.encode('utf-8')
        hmac_code = hmac.new(secret_enc, string_to_sign_enc, digestmod=hashlib.sha256).digest()
        sign = quote_plus(base64.b64encode(hmac_code))
        return f"https://oapi.dingtalk.com/robot/send?access_token={self.robot_id}&timestamp={timestamp}&sign={sign}"

    def is_not_null_and_blank_str(self, content):
        return bool(content and content.strip())

    def send_action_card(self, title, markdown_msg, btnOrientation, btn_info):
        return True

    def send_image(self, title, image_url, is_at_all, at_mobiles):
        return True

    def send_json(self, msg, is_at_all, at_mobiles):
        return True

    def send_markdown(self, title, markdown_msg, is_at_all, at_mobiles):
        return True

    def send_msg(self, mssg):
        return True

    def send_text(self, msg, is_at_all, at_mobiles):
        return True