import telegram

class TgRobot:
    def __init__(self, token, chat_id):
        self.token = token
        self.chat_id = chat_id
        self.bot = telegram.Bot(token=self.token)

    def send_dataframe(self, content):
        pass

    def send_document(self, doc_path):
        pass

    def send_html(self, html_text):
        pass

    def send_msg(self, mssg):
        pass

    def send_photo(self, photo_path):
        pass

    def send_text(self, content):
        pass