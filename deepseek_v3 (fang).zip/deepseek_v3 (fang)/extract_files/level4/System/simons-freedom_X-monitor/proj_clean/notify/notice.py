from notify.dingding import DingTalkRobot

_robot = None

def _get_robot():
    global _robot
    if _robot is None:
        _robot = DingTalkRobot("", "")
    return _robot

def send_warn_action_card(title, text, btn_orientation, btns) -> bool:
    return _get_robot().send_action_card(title, text, btn_orientation, btns)

def send_notice_msg(content, title="系统通知", btn_info=None) -> bool:
    return _get_robot().send_action_card(title, content, "0", btn_info or [])