from dataclasses import dataclass, field
from typing import Dict, Optional

@dataclass
class DingTalkConfig:
    secret: str
    token: str

@dataclass
class LlmConfig:
    pass

@dataclass
class MonitorConfig:
    pass

@dataclass
class TelegramConfig:
    pass

@dataclass
class TraderConfig:
    default_trade_amount_usd: float
    enabled: bool
    gas_price_multiplier: float
    high_confidence_amount_usd: float
    max_price_change_1h: float
    max_trade_amount_usd: float
    medium_confidence_amount_usd: float
    min_confidence: float
    min_liquidity_usd: float
    min_volume_usd: float
    private_keys: Dict[str, str] = field(default_factory=dict)
    router_addresses: Dict[str, str] = field(default_factory=dict)
    rpc_urls: Dict[str, str] = field(default_factory=dict)
    slippage_tolerance: float = 0.5

    def __post_init__(self):
        if self.private_keys is None:
            self.private_keys = {}
        if self.router_addresses is None:
            self.router_addresses = {}
        if self.rpc_urls is None:
            self.rpc_urls = {}

@dataclass
class Config:
    dingtalk: DingTalkConfig
    llm: LlmConfig
    monitor: MonitorConfig
    telegram: TelegramConfig
    trader: TraderConfig

    def __init__(self, monitor=None, llm=None, trader=None, telegram=None, dingtalk=None):
        self.monitor = monitor or MonitorConfig()
        self.llm = llm or LlmConfig()
        self.trader = trader or TraderConfig()
        self.telegram = telegram or TelegramConfig()
        self.dingtalk = dingtalk or DingTalkConfig()

def load_config() -> Config:
    return Config()