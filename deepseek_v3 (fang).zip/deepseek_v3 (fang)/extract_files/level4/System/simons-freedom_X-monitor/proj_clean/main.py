from config.config import load_config

def main():
    config = load_config()
    print("X-monitor started")

if __name__ == "__main__":
    main()