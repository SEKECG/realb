VALIDATE_ENDPOINT_URL = "https://validate.example.com"

def validate_bsc_endpoint(validate_key, rpc_url):
    pass

def validate_eth_endpoint(validate_key, rpc_url):
    pass

def validate_sol_endpoint(validate_key, rpc_url):
    pass