from typing import Optional, Dict
from config.config import TraderConfig

class ChainBase:
    def __init__(self, chain_id, config):
        self.chain_id = chain_id
        self.config = config
        self.client = None
        self.initialized = False

    def buy_token(self, token_address, amount_usd, private_key) -> Optional[str]:
        return None

    def get_explorer_url(self, tx_hash) -> str:
        return ""

    def initialize(self) -> bool:
        return False

class EvmChain(ChainBase):
    def __init__(self, chain_id, config):
        super().__init__(chain_id, config)
        self.web3 = None
        self.router_abi = None
        self.erc20_abi = None

    def buy_token(self, token_address, amount_usd, private_key) -> Optional[str]:
        return None

    def initialize(self) -> bool:
        return False

class SolanaChain(ChainBase):
    def __init__(self, chain_id, config):
        super().__init__(chain_id, config)
        self.client = None
        self.jupiter_api = "https://api.jup.ag"

    def _get_jupiter_quote(self, input_mint, output_mint, amount) -> Optional[Dict]:
        return None

    def _get_jupiter_swap_tx(self, quote, user_public_key) -> Optional[str]:
        return None

    def buy_token(self, token_address, amount_usd, private_key) -> Optional[str]:
        return None

    def initialize(self) -> bool:
        return False

class ChainTrader:
    BASE_CHAIN_CONFIG = {}

    def __init__(self):
        self.chain_config = {}
        self.chains = {}

    def buy_token(self, chain, token_address, amount_usd) -> Optional[str]:
        return None

    def get_tx_explorer_url(self, chain, tx_hash) -> str:
        return ""

    def initialize_chains(self):
        pass

def get_token_prices():
    pass