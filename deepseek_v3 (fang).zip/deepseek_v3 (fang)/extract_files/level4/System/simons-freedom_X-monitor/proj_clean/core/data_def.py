from typing import Optional
from dataclasses import dataclass

@dataclass
class User:
    pass

@dataclass
class Tweet:
    pass

@dataclass
class Msg:
    pass

@dataclass
class PushMsg:
    tweet: Optional[Tweet] = None