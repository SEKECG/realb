from fastapi import FastAPI
from core.data_def import PushMsg
from monitor.base import BaseMonitor

notice = None

class WebhookMonitor(BaseMonitor):
    def __init__(self, host, port):
        super().__init__()
        self.app = FastAPI()
        self.host = host
        self.port = port

    def _parse_tweet_data(self, raw_data) -> Optional[PushMsg]:
        return None

    def _register_routes(self):
        pass

    def start(self):
        pass