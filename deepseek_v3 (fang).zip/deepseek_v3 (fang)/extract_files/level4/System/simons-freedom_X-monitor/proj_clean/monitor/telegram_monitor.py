from monitor.base import BaseMonitor

notice = None

class TelegramMonitor(BaseMonitor):
    def __init__(self, api_id, api_hash, target_chat_id):
        super().__init__()
        self.api_id = api_id
        self.api_hash = api_hash
        self.client = None
        self.monitor_targets = []
        self.target_list = []

    def _build_target_list(self):
        pass

    def _client_main(self):
        pass

    def _handle_message(self, message):
        pass

    def _register_handlers(self):
        pass

    def _show_login_info(self, me):
        pass

    def parse_message(self, message):
        pass

    def start(self):
        pass