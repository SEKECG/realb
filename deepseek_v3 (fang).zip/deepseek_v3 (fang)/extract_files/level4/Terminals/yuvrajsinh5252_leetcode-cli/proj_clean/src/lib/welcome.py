from rich.console import Console

console = Console()

def display_welcome(app):
    ascii_art = get_leetcode_ascii()
    console.print(ascii_art)
    console.print("\nWelcome to LeetCode CLI\n")
    console.print("Available commands:")
    # Display commands from app

def get_leetcode_ascii():
    return r"""
      _           _           _             
     | |         | |         | |            
     | | ___  ___| |_ ___  __| | __ _  ___  
     | |/ _ \/ __| __/ _ \/ _` |/ _` |/ _ \ 
     | |  __/\__ \ ||  __/ (_| | (_| | (_) |
     |_|\___||___/\__\___|\__,_|\__, |\___/ 
                                 __/ |      
                                |___/       
    """