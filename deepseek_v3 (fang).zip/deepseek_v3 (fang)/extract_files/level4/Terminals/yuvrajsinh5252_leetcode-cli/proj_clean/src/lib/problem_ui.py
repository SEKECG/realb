from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel

COLORS = {
    'Easy': 'green',
    'Medium': 'yellow',
    'Hard': 'red'
}

STYLES = {
    'header': 'bold',
    'title': 'bold cyan',
    'difficulty': 'bold',
    'stats': 'dim',
    'topics': 'italic blue'
}

console = Console()

class ProblemDetails:
    def __init__(self, problem_data):
        self.problem_number = problem_data.get('questionFrontendId')
        self.title = problem_data.get('title')
        self.content = self._format_markdown(problem_data.get('content', ''))
        self.difficulty = problem_data.get('difficulty')
        self.stats = problem_data.get('stats')
        self.topics = [t.get('name') for t in problem_data.get('topicTags', [])]
        self.similar_questions = problem_data.get('similarQuestions', [])

    def _create_header(self):
        return f"{self.problem_number}. {self.title} ({self.difficulty})"

    def _format_markdown(self, content):
        return content

    def _format_similar_questions(self):
        return "\n".join([q['title'] for q in self.similar_questions[:5]])

    def _format_stats(self):
        return self.stats

    def _format_topics(self):
        return ", ".join(self.topics)

    def display_probelm(self):
        header = self._create_header()
        console.print(Panel(
            Markdown(self.content),
            title=header,
            title_align="left",
            style=COLORS.get(self.difficulty, 'white')
        ))

    def display_stats(self):
        console.print(Panel(
            self._format_stats(),
            title="Statistics",
            style="dim"
        ))

    def display_additional_info(self):
        console.print(Panel(
            f"Topics: {self._format_topics()}\n\nSimilar Questions:\n{self._format_similar_questions()}",
            title="Additional Info",
            style="blue"
        ))