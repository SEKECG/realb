import click
from ..server.api import get_daily_question
from ..lib.problem_ui import ProblemDetails

@click.command()
@click.option('--lang', help='Programming language')
@click.option('--editor', help='Editor to open')
@click.option('--full', is_flag=True, help='Show full details')
@click.option('--no_editor', is_flag=True, help='Skip opening editor')
def daily(lang, editor, full, no_editor):
    """Get and work on today's LeetCode daily challenge."""
    question = get_daily_question()
    problem = ProblemDetails(question)
    problem.display_probelm()
    if not no_editor:
        # Open in editor logic would go here
        pass