from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from datetime import datetime

console = Console()

def display_problem_list(data):
    table = Table(title="Problems")
    table.add_column("ID")
    table.add_column("Title")
    table.add_column("Difficulty")
    table.add_column("Status")
    table.add_column("Acceptance")
    # Add rows from data
    console.print(table)

def display_user_stats(data):
    console.print(Panel(
        f"User: {data.get('username')}\n"
        f"Solved: {data.get('solved')}/{data.get('total')}",
        title="Profile"
    ))

def create_contest_stats(contest_info):
    return f"Rating: {contest_info.get('rating')}"

def create_language_stats(data):
    return "\n".join([f"{lang}: {count}" for lang, count in data.items()][:5])

def create_progress_panel(data):
    return f"Easy: {data.get('easy')}\nMedium: {data.get('medium')}\nHard: {data.get('hard')}"

def create_recent_activity(recent_submissions):
    table = Table()
    table.add_column("Date")
    table.add_column("Problem")
    table.add_column("Status")
    # Add rows from recent_submissions
    return table

def create_skill_stats(data):
    table = Table()
    table.add_column("Skill")
    table.add_column("Solved")
    # Add rows from data
    return table

def create_social_links(user, websites):
    return "\n".join(websites)

def format_timestamp(timestamp):
    return datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d %H:%M')