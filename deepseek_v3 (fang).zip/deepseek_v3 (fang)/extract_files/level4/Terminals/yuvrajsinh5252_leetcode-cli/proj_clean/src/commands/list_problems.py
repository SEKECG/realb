import click
from ..server.api import fetch_problem_list
from ..server.auth import Auth

status_map = {
    'ac': 'Accepted',
    'notac': 'Not Accepted',
    None: 'Not Attempted'
}

@click.command()
@click.option('--difficulty', help='Filter by difficulty')
@click.option('--status', help='Filter by status')
@click.option('--tag', help='Filter by tag')
@click.option('--category_slug', help='Filter by category')
def list_problems(difficulty, status, tag, category_slug):
    """List available LeetCode problems with optional filters."""
    auth = Auth()
    if not auth.is_authenticated:
        print("Please login first")
        return
    
    filters = {}
    if difficulty:
        filters['difficulty'] = difficulty
    if status:
        filters['status'] = status
    if tag:
        filters['tag'] = tag
    
    problems = fetch_problem_list(
        auth.session.cookies.get('csrftoken'),
        auth.session.cookies.get('LEETCODE_SESSION'),
        category_slug,
        50, 0, filters
    )
    # Display logic would go here