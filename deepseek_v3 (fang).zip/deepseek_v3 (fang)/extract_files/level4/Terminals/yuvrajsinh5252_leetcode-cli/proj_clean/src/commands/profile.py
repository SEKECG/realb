import click
from ..server.api import fetch_user_profile
from ..lib.profile_ui import display_user_stats

@click.command()
def profile():
    """List all available LeetCode problems."""
    profile_data = fetch_user_profile()
    display_user_stats(profile_data)