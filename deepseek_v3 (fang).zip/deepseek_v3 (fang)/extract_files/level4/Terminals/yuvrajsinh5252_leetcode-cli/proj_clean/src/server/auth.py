import requests
from .session_manager import SessionManager

class Auth:
    BASE_URL = "https://leetcode.com"
    
    def __init__(self):
        self.is_authenticated = False
        self.session = requests.Session()
        self.session_manager = SessionManager()
        self._load_saved_session()

    def _load_saved_session(self):
        saved = self.session_manager.load_session()
        if saved:
            self.login_with_session(saved['csrftoken'], saved['session_token'])

    def get_session(self):
        return self.session

    def login_with_session(self, csrf_token, leetcode_session):
        self.session.cookies.set('csrftoken', csrf_token)
        self.session.cookies.set('LEETCODE_SESSION', leetcode_session)
        if self.verify_csrf_token(csrf_token):
            self.is_authenticated = True
            return {'status': 'success'}
        return {'status': 'failed'}

    def verify_csrf_token(self, csrf_token):
        try:
            resp = self.session.post(
                f"{self.BASE_URL}/graphql",
                headers={'x-csrftoken': csrf_token},
                json={'query': '{ user { username } }'}
            )
            return resp.status_code == 200
        except:
            return False