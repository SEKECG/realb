import click
from ..server.solution_manager import SolutionManager
from ..lib.problem_ui import ProblemDetails

@click.command()
@click.argument('problem')
@click.option('--save', is_flag=True, help='Save to file')
@click.option('--compact', is_flag=True, help='Compact view')
def show(problem, save, compact):
    """Show problem details including description and test cases."""
    manager = SolutionManager()
    question_data = manager.get_question_data(problem)
    problem = ProblemDetails(question_data)
    problem.display_probelm()
    if save:
        _save_problem_to_file(question_data)

def _save_problem_to_file(question_data):
    """Save the problem statement to a markdown file."""
    # File saving logic would go here
    pass