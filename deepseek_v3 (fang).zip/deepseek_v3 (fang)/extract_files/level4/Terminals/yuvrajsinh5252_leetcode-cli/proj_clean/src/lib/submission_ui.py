from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress

console = Console()

def create_submission_progress():
    return Progress()

def display_auth_error():
    console.print("[red]Error: Not authenticated. Please login first.[/red]")

def display_exception_error(e):
    console.print(f"[red]Error: {str(e)}[/red]")

def display_file_not_found_error(file):
    console.print(f"[red]Error: File not found: {file}[/red]")

def display_language_detection_error(extension):
    console.print(f"[red]Error: Could not detect language for extension: {extension}[/red]")

def display_language_detection_message(lang):
    console.print(f"[green]Detected language: {lang}[/green]")

def display_problem_not_found_error(problem):
    console.print(f"[red]Error: Problem not found: {problem}[/red]")

def display_submission_canceled():
    console.print("[yellow]Submission canceled[/yellow]")

def display_submission_details(problem, problem_name, lang, file):
    console.print(Panel(
        f"Problem: [bold]{problem_name}[/bold]\n"
        f"Language: [bold]{lang}[/bold]\n"
        f"File: [bold]{file}[/bold]",
        title="Submission Details"
    ))

def display_submission_results(result, is_test):
    status = result.get('status', '')
    console.print(Panel(
        f"Status: [bold]{status}[/bold]",
        style="green" if status == 'Accepted' else "red"
    ))

# Helper methods would be implemented here