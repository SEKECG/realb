import click
from ..server.solution_manager import SolutionManager
from ..lib.solution_ui import SolutionUI

@click.command()
@click.argument('problem')
@click.option('--best', is_flag=True, help='Show only best solutions')
def solutions(problem, best):
    """Fetch solution for a problem."""
    manager = SolutionManager()
    solutions = manager.get_problem_solutions(problem, best)
    ui = SolutionUI(solutions)
    ui.show_solution()