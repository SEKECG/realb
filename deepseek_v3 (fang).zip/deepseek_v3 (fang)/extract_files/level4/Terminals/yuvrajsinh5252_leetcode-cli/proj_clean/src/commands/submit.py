import click
from ..server.solution_manager import SolutionManager
from ..lib.submission_ui import display_submission_details

@click.command()
@click.argument('problem')
@click.argument('file')
@click.option('--lang', help='Programming language')
@click.option('--force', is_flag=True, help='Skip confirmation')
def submit(problem, file, lang, force):
    """Submit a solution to LeetCode."""
    manager = SolutionManager()
    if not force:
        display_submission_details(problem, problem, lang, file)
    # Submission logic would go here