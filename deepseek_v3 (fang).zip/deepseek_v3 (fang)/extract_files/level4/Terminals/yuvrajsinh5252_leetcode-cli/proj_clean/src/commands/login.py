import click
from ..server.auth import Auth

@click.command()
def login():
    """Login to LeetCode."""
    auth = Auth()
    # Login logic would go here

@click.command()
def logout():
    """Logout from LeetCode."""
    auth = Auth()
    auth.session_manager.clear_session()