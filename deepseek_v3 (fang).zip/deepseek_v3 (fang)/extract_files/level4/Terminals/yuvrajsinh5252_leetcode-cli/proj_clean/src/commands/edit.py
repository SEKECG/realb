import click
from ..server.solution_manager import SolutionManager
from ..server.auth import Auth

@click.command()
@click.argument('problem')
@click.option('--lang', help='Programming language')
@click.option('--editor', help='Editor to open')
def edit(problem, lang, editor):
    """Solves a problem by passing lang param and open it with your code editor."""
    auth = Auth()
    if not auth.is_authenticated:
        print("Please login first")
        return
    
    manager = SolutionManager(auth.get_session())
    question_data = manager.get_question_data(problem)
    # Editor opening logic would go here