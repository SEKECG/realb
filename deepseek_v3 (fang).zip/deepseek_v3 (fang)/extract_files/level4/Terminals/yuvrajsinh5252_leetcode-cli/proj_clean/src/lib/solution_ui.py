from rich.console import Console
from rich.table import Table
from rich.style import Style

console = Console()

class SolutionUI:
    COLUMNS = ["#", "Title", "Author", "Date", "Votes", "Tags"]
    COLUMN_WIDTHS = [5, 40, 20, 15, 10, 30]
    LEETCODE_BASE_URL = "https://leetcode.com"
    MAX_TAGS = 3
    STYLES = {
        'title': Style(bold=True),
        'author': Style(italic=True),
        'votes': Style(color="green"),
        'tags': Style(color="blue")
    }

    def __init__(self, fetched_solution):
        self.solutions = fetched_solution.get('solutions', [])
        self.total_solutions = fetched_solution.get('total', 0)

    def show_solution(self):
        table = Table(title=f"Solutions ({self.total_solutions} total)")
        for col in self.COLUMNS:
            table.add_column(col)
        
        for idx, sol in enumerate(self.solutions[:10], 1):
            table.add_row(
                str(idx),
                self._truncate_text(sol.get('title', ''), 40),
                self._format_author(sol.get('author', {})),
                self._format_date(sol.get('date', '')),
                self._format_reactions(sol.get('reactions', {})),
                self._format_tags(sol.get('tags', []))
            )
        console.print(table)

    def _format_author(self, author_data):
        return author_data.get('username', '')

    def _format_date(self, date_str):
        return date_str[:10] if date_str else ''

    def _format_number(self, number):
        return str(number)

    def _format_reactions(self, reactions):
        return self._format_number(reactions.get('count', 0))

    def _format_tags(self, tags):
        return ", ".join(tags[:self.MAX_TAGS])

    def _truncate_text(self, text, max_length):
        return text[:max_length] + '...' if len(text) > max_length else text

    def handle_solution_selection(self, index):
        if 1 <= index <= len(self.solutions):
            self._open_solution_url(self.solutions[index-1])

    def _open_solution_url(self, solution_node):
        pass  # Browser opening logic would go here