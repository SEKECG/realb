import click
from ..server.solution_manager import SolutionManager
from ..lib.submission_ui import display_submission_results

@click.command()
@click.argument('problem')
@click.argument('file')
def test(problem, file):
    """Test a solution with LeetCode's test cases."""
    manager = SolutionManager()
    result = manager.test_solution(problem, file, None, True)
    display_submission_results(result, True)