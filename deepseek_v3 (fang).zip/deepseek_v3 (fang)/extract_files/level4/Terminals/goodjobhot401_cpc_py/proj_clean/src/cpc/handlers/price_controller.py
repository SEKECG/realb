from rich.console import Console
from services.price import PRICE_SERVICE
from middlewares.db_connect import db_connection

console = Console()

class PRICE:
    @staticmethod
    @db_connection
    def get_price_detail(symbols, conn=None):
        try:
            service = PRICE_SERVICE()
            service.get_price_detail(symbols)
        except Exception as e:
            console.print(f"[red]Error getting price details: {str(e)}[/red]")