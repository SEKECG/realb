class USER_SQL:
    @staticmethod
    def create_user():
        return "INSERT INTO User (name, target) VALUES (?, ?)"

    @staticmethod
    def get_users():
        return "SELECT * FROM User"

    @staticmethod
    def get_user():
        return "SELECT * FROM User WHERE target = 1"

    @staticmethod
    def is_taget_sql():
        return "SELECT * FROM User WHERE target = 1"

    @staticmethod
    def auto_choose_user():
        return "UPDATE User SET target = 1 WHERE id = (SELECT id FROM User LIMIT 1)"

    @staticmethod
    def remove_all_target():
        return "UPDATE User SET target = 0 WHERE target = 1"

    @staticmethod
    def switch_target_user():
        return "UPDATE User SET target = 1 WHERE id = ?"

    @staticmethod
    def update_user():
        return "UPDATE User SET name = ? WHERE id = ?"

    @staticmethod
    def remove_user_sql():
        return "DELETE FROM User WHERE id = ?"

    @staticmethod
    def get_favorite_sql():
        return "SELECT symbol FROM Favorite WHERE user_id = ?"

    @staticmethod
    def get_asset_sql():
        return "SELECT symbol, amount FROM Asset WHERE user_id = ?"

    @staticmethod
    def remove_favorite_sql():
        return "DELETE FROM Favorite WHERE user_id = ?"

    @staticmethod
    def remove_asset_sql():
        return "DELETE FROM Asset WHERE user_id = ?"