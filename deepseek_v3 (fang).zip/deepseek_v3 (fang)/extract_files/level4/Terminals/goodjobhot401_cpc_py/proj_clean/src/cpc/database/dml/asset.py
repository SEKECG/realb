class ASSET_SQL:
    @staticmethod
    def add_asset_sql():
        return "INSERT INTO Asset (symbol, amount, user_id) VALUES (?, ?, ?)"

    @staticmethod
    def remove_asset_sql():
        return "DELETE FROM Asset WHERE symbol = ? AND user_id = ?"

    @staticmethod
    def update_asset_sql():
        return "UPDATE Asset SET amount = ? WHERE symbol = ? AND user_id = ?"