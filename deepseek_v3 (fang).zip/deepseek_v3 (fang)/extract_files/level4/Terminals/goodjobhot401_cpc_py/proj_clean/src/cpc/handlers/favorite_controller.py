from rich.console import Console
from services.favorite import FAVORITE_SERVICE
from middlewares.db_connect import db_connection

console = Console()

class FAVORITE:
    @staticmethod
    @db_connection
    def add_favorite(favorite_list, conn=None):
        try:
            service = FAVORITE_SERVICE(conn)
            service.add_favorite(favorite_list)
            console.print("[green]Favorites added successfully[/green]")
        except Exception as e:
            console.print(f"[red]Error adding favorites: {str(e)}[/red]")

    @staticmethod
    @db_connection
    def remove_favorite(favorite_list, conn=None):
        try:
            service = FAVORITE_SERVICE(conn)
            service.remove_favorite(favorite_list)
            console.print("[green]Favorites removed successfully[/green]")
        except Exception as e:
            console.print(f"[red]Error removing favorites: {str(e)}[/red]")