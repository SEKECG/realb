from rich.console import Console
from services.user import USER_SERVICE
from middlewares.db_connect import db_connection

console = Console()

class USER:
    @staticmethod
    @db_connection
    def get_users(conn=None):
        try:
            service = USER_SERVICE(conn)
            service.get_users()
        except Exception as e:
            console.print(f"[red]Error getting users: {str(e)}[/red]")

    @staticmethod
    @db_connection
    def get_user(print_table=True, conn=None):
        try:
            service = USER_SERVICE(conn)
            service.get_user(print_table)
        except Exception as e:
            console.print(f"[red]Error getting user: {str(e)}[/red]")

    @staticmethod
    @db_connection
    def create_user(name, conn=None):
        try:
            service = USER_SERVICE(conn)
            service.create_user(name)
            console.print("[green]User created successfully[/green]")
        except Exception as e:
            console.print(f"[red]Error creating user: {str(e)}[/red]")

    @staticmethod
    @db_connection
    def switch_user(user_id, conn=None):
        try:
            service = USER_SERVICE(conn)
            service.switch_user(user_id)
            console.print("[green]User switched successfully[/green]")
        except Exception as e:
            console.print(f"[red]Error switching user: {str(e)}[/red]")

    @staticmethod
    @db_connection
    def update_user(user_id, name, conn=None):
        try:
            service = USER_SERVICE(conn)
            service.update_user(user_id, name)
            console.print("[green]User updated successfully[/green]")
        except Exception as e:
            console.print(f"[red]Error updating user: {str(e)}[/red]")

    @staticmethod
    @db_connection
    def remove_user(user_id, conn=None):
        try:
            service = USER_SERVICE(conn)
            service.remove_user(user_id)
            console.print("[green]User removed successfully[/green]")
        except Exception as e:
            console.print(f"[red]Error removing user: {str(e)}[/red]")

    @staticmethod
    @db_connection
    def get_position_ratio(sort=None, reverse=False, conn=None):
        try:
            service = USER_SERVICE(conn)
            service.get_position_ratio(sort, reverse)
        except Exception as e:
            console.print(f"[red]Error getting position ratio: {str(e)}[/red]")

    @staticmethod
    @db_connection
    def create_default_user(conn=None):
        try:
            service = USER_SERVICE(conn)
            service.create_default_user()
            console.print("[green]Default user created successfully[/green]")
        except Exception as e:
            console.print(f"[red]Error creating default user: {str(e)}[/red]")