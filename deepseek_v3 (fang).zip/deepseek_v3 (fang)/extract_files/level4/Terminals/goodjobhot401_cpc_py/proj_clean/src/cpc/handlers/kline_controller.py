from rich.console import Console
from services.kline import KLINE_SERVICE
from middlewares.db_connect import db_connection

console = Console()

class KLINE:
    @staticmethod
    @db_connection
    def get_kline(symbol, interval, limit, conn=None):
        try:
            service = KLINE_SERVICE()
            service.get_kline(symbol, interval, limit)
        except Exception as e:
            console.print(f"[red]Error getting kline data: {str(e)}[/red]")