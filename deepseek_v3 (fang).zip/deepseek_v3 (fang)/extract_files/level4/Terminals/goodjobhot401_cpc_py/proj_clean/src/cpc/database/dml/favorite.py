class FAVORITE_SQL:
    @staticmethod
    def add_favorite_sql():
        return "INSERT INTO Favorite (symbol, user_id) VALUES (?, ?)"

    @staticmethod
    def remove_favorite_sql():
        return "DELETE FROM Favorite WHERE symbol = ? AND user_id = ?"