from rich.console import Console
from services.asset import ASSET_SERVICE
from middlewares.db_connect import db_connection

console = Console()

class ASSET:
    @staticmethod
    @db_connection
    def add_asset(asset_list, conn=None):
        try:
            service = ASSET_SERVICE(conn)
            service.add_asset(asset_list)
            console.print("[green]Assets added successfully[/green]")
        except Exception as e:
            console.print(f"[red]Error adding assets: {str(e)}[/red]")

    @staticmethod
    @db_connection
    def update_asset(asset_list, conn=None):
        try:
            service = ASSET_SERVICE(conn)
            service.update_asset(asset_list)
            console.print("[green]Assets updated successfully[/green]")
        except Exception as e:
            console.print(f"[red]Error updating assets: {str(e)}[/red]")

    @staticmethod
    @db_connection
    def remove_asset(asset_list, conn=None):
        try:
            service = ASSET_SERVICE(conn)
            service.remove_asset(asset_list)
            console.print("[green]Assets removed successfully[/green]")
        except Exception as e:
            console.print(f"[red]Error removing assets: {str(e)}[/red]")