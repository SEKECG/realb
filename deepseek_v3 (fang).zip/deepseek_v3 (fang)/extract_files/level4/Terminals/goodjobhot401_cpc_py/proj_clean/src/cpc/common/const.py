INIT_USER_DATA = {
    'name': 'default',
    'favorites': ['BTCUSDT', 'ETHUSDT'],
    'assets': [('BTCUSDT', 0.1), ('ETHUSDT', 1.0)]
}

PRICE_DETAIL_ROW_MAP = {
    'symbol': 'Symbol',
    'price': 'Price',
    'priceChange': '24h Change',
    'priceChangePercent': '24h %',
    'highPrice': '24h High',
    'lowPrice': '24h Low',
    'volume': '24h Volume',
    'bidPrice': 'Bid',
    'askPrice': 'Ask'
}

VALID_INTERVAL = ['1m', '5m', '15m', '30m', '1h', '4h', '8h', '1d', '1W', '1M']