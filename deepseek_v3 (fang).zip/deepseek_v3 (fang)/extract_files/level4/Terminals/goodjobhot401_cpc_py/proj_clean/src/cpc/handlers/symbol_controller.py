from rich.console import Console
from services.symbol import SYMBOL_SERVICE
from middlewares.db_connect import db_connection

console = Console()

class SYMBOL:
    @staticmethod
    @db_connection
    def filter_symbols(query=None, conn=None):
        try:
            service = SYMBOL_SERVICE()
            service.filter_symbols(query)
        except Exception as e:
            console.print(f"[red]Error filtering symbols: {str(e)}[/red]")