import os
import sqlite3
from datetime import datetime

class ScanDatabase:
    def __init__(self, project_name):
        self.project_name = self._sanitize_project_name(project_name)
        self.db_directory = os.path.expanduser('~/.drsource')
        os.makedirs(self.db_directory, exist_ok=True)
        self.db_path = os.path.join(self.db_directory, f'{self.project_name}.db')
        self._create_tables()

    def _sanitize_project_name(self, name):
        if not name or name in ('.', '..'):
            return 'default_project'
        return ''.join(c if c.isalnum() or c in ('_', '-') else '_' for c in name)

    def _create_tables(self):
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS scans (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp DATETIME,
                    num_vulnerabilities INTEGER,
                    num_files_analyzed INTEGER,
                    scan_duration REAL
                )
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS vulnerabilities (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    scan_id INTEGER,
                    file TEXT,
                    vuln_type TEXT,
                    match TEXT,
                    line INTEGER,
                    FOREIGN KEY(scan_id) REFERENCES scans(id)
                )
            ''')
            conn.commit()

    def initialize(self):
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('DROP TABLE IF EXISTS scans')
            cursor.execute('DROP TABLE IF EXISTS vulnerabilities')
            conn.commit()
        self._create_tables()

    def start_scan(self):
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('INSERT INTO scans (timestamp) VALUES (?)', (datetime.now(),))
            conn.commit()
            return cursor.lastrowid

    def store_vulnerability(self, scan_id, vuln):
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO vulnerabilities (scan_id, file, vuln_type, match, line)
                VALUES (?, ?, ?, ?, ?)
            ''', (scan_id, vuln['file'], vuln['vuln_type'], vuln['match'], vuln['line']))
            conn.commit()

    def store_vulnerabilities(self, scan_id, vulns):
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.executemany('''
                INSERT INTO vulnerabilities (scan_id, file, vuln_type, match, line)
                VALUES (?, ?, ?, ?, ?)
            ''', [(scan_id, v['file'], v['vuln_type'], v['match'], v['line']) for v in vulns])
            conn.commit()

    def update_scan_summary(self, scan_id, num_vulnerabilities, num_files_analyzed, scan_duration):
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE scans 
                SET num_vulnerabilities = ?, num_files_analyzed = ?, scan_duration = ?
                WHERE id = ?
            ''', (num_vulnerabilities, num_files_analyzed, scan_duration, scan_id))
            conn.commit()

    def get_scan_history(self):
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT id, timestamp, num_vulnerabilities 
                FROM scans 
                ORDER BY timestamp DESC
            ''')
            return cursor.fetchall()

    def get_latest_scan_id(self):
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT MAX(id) FROM scans')
            result = cursor.fetchone()
            return result[0] if result and result[0] else None

    def compare_scans(self, old_scan_id, new_scan_id):
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Get new vulnerabilities
            cursor.execute('''
                SELECT file, vuln_type, match, line 
                FROM vulnerabilities 
                WHERE scan_id = ? 
                EXCEPT 
                SELECT file, vuln_type, match, line 
                FROM vulnerabilities 
                WHERE scan_id = ?
            ''', (new_scan_id, old_scan_id))
            new = cursor.fetchall()
            
            # Get resolved vulnerabilities
            cursor.execute('''
                SELECT file, vuln_type, match, line 
                FROM vulnerabilities 
                WHERE scan_id = ? 
                EXCEPT 
                SELECT file, vuln_type, match, line 
                FROM vulnerabilities 
                WHERE scan_id = ?
            ''', (old_scan_id, new_scan_id))
            resolved = cursor.fetchall()
            
            # Get persistent vulnerabilities
            cursor.execute('''
                SELECT file, vuln_type, match, line 
                FROM vulnerabilities 
                WHERE scan_id = ? 
                INTERSECT 
                SELECT file, vuln_type, match, line 
                FROM vulnerabilities 
                WHERE scan_id = ?
            ''', (old_scan_id, new_scan_id))
            persistent = cursor.fetchall()
            
            return {
                'new': new,
                'resolved': resolved,
                'persistent': persistent
            }