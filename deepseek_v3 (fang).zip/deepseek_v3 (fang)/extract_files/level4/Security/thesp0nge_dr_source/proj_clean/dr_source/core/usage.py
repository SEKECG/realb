import logging
import javalang

logger = logging.getLogger(__name__)

def find_usage_in_file(file_obj, target_class):
    try:
        ast_tree = javalang.parse.parse(file_obj.content)
        current_class = None
        used = False
        
        for path, node in ast_tree.filter(javalang.tree.ClassDeclaration):
            if not current_class:
                current_class = node.name
                
        for path, node in ast_tree.filter(javalang.tree.ClassCreator):
            if node.type.name == target_class:
                used = True
                break
                
        for path, node in ast_tree.filter(javalang.tree.ReferenceType):
            if node.name == target_class:
                used = True
                break
                
        return used, current_class
        
    except Exception as e:
        logger.warning(f"Error parsing {file_obj.path}: {e}")
        return False, None

def where_is_it_used(codebase, target_class):
    results = []
    
    for file_obj in codebase.files:
        if not file_obj.path.endswith('.java'):
            continue
            
        used, current_class = find_usage_in_file(file_obj, target_class)
        if used and current_class != target_class:
            results.append({
                'class': current_class,
                'file': file_obj.path
            })
            
    return results