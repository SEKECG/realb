import logging
import javalang

logger = logging.getLogger(__name__)

class TaintVisitor(javalang.visitor.Visitor):
    def __init__(self):
        self.source_qualifier = "request"
        self.source_member = "getParameter"
        self.tainted = {}

    def collect_identifiers(self, expr):
        identifiers = set()
        
        if isinstance(expr, javalang.tree.MemberReference):
            identifiers.add(expr.member)
        elif isinstance(expr, javalang.tree.This):
            identifiers.add("this")
        elif isinstance(expr, javalang.tree.MethodInvocation):
            if expr.qualifier:
                identifiers.update(self.collect_identifiers(expr.qualifier))
            identifiers.add(expr.member)
        elif isinstance(expr, javalang.tree.QualifiedName):
            identifiers.update(self.collect_identifiers(expr.qualifier))
            identifiers.add(expr.name)
        elif isinstance(expr, javalang.tree.Identifier):
            identifiers.add(expr.name)
            
        return identifiers

    def is_tainted(self, expr):
        if isinstance(expr, javalang.tree.Literal):
            return False
            
        identifiers = self.collect_identifiers(expr)
        return any(id in self.tainted for id in identifiers)

    def visit(self, node):
        super().visit(node)
        
        # Track variable declarations with tainted values
        if isinstance(node, javalang.tree.VariableDeclaration):
            if node.initializer and self.is_tainted(node.initializer):
                self.tainted[node.declarator.name] = {
                    'source': node.initializer,
                    'line': node.position.line if node.position else None
                }
                
        # Track assignments to existing variables
        elif isinstance(node, javalang.tree.Assignment):
            if self.is_tainted(node.value) and isinstance(node.expression, javalang.tree.Identifier):
                self.tainted[node.expression.name] = {
                    'source': node.value,
                    'line': node.position.line if node.position else None
                }

    def get_vulnerabilities(self, ast_tree, sink_list):
        vulnerabilities = []
        
        for path, node in ast_tree.filter(javalang.tree.MethodInvocation):
            if node.member in sink_list:
                for arg in node.arguments:
                    if self.is_tainted(arg):
                        vulnerabilities.append({
                            'match': f"{node.qualifier}.{node.member}" if node.qualifier else node.member,
                            'line': node.position.line if node.position else None
                        })
                        break
                        
        return vulnerabilities