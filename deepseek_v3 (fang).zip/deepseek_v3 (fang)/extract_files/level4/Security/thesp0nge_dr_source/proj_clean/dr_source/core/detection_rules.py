import os
import yaml
import logging

logger = logging.getLogger(__name__)

class DetectionRules:
    _instance = None

    def __init__(self):
        config_path = os.path.join(os.path.dirname(__file__), '../../config/detection_rules.yaml')
        self.rules = {}
        try:
            with open(config_path, 'r') as f:
                self.rules = yaml.safe_load(f) or {}
        except FileNotFoundError:
            logger.warning(f"Detection rules file not found at {config_path}")
        except yaml.YAMLError as e:
            logger.error(f"Error parsing detection rules: {e}")

    @classmethod
    def instance(cls):
        if cls._instance is None:
            cls._instance = DetectionRules()
        return cls._instance

    def get_rules(self, detector_key):
        return self.rules.get(detector_key, {})