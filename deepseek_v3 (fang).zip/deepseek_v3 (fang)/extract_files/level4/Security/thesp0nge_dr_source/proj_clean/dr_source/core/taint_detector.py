import logging

logger = logging.getLogger(__name__)

class TaintDetector:
    def detect_ast_taint(self, file_object, ast_tree, sink_list, vuln_prefix):
        from dr_source.core.taint_visitor import TaintVisitor
        
        visitor = TaintVisitor()
        visitor.visit(ast_tree)
        vulnerabilities = visitor.get_vulnerabilities(ast_tree, sink_list)
        
        results = []
        for vuln in vulnerabilities:
            results.append({
                'file': file_object.path,
                'vuln_type': f"{vuln_prefix}_AST",
                'match': vuln['match'],
                'line': vuln['line']
            })
            
        return results