class BaseDetector:
    def detect(self, file_object):
        raise NotImplementedError("Subclasses must implement detect() method")