import concurrent.futures
import time
import logging
from tqdm import tqdm
import javalang

logger = logging.getLogger(__name__)

class Scanner:
    def __init__(self, codebase, ast_mode=False):
        self.codebase = codebase
        self.ast_mode = ast_mode
        self.detectors = self._initialize_detectors()

    def _initialize_detectors(self):
        from dr_source.core.detectors import (
            SQLInjectionDetector, XSSDetector, PathTraversalDetector,
            CommandInjectionDetector, SerializationDetector, LDAPInjectionDetector,
            XXEDetector, SSRFDetector, CryptoDetector
        )
        
        detectors = [
            SQLInjectionDetector(),
            XSSDetector(),
            PathTraversalDetector(),
            CommandInjectionDetector(),
            SerializationDetector(),
            LDAPInjectionDetector(),
            XXEDetector(),
            SSRFDetector(),
            CryptoDetector()
        ]
        
        for detector in detectors:
            detector.ast_mode = self.ast_mode
            
        return detectors

    def scan(self):
        results = []
        start_time = time.time()
        
        with concurrent.futures.ThreadPoolExecutor() as executor:
            futures = {executor.submit(self.scan_file, file_obj): file_obj for file_obj in self.codebase.files}
            
            for future in tqdm(concurrent.futures.as_completed(futures), total=len(futures)):
                file_results = future.result()
                if file_results:
                    results.extend(file_results)
        
        scan_duration = time.time() - start_time
        return results, scan_duration

    def scan_file(self, file_obj):
        file_results = []
        
        if file_obj.path.endswith('.java') and self.ast_mode:
            try:
                ast_tree = javalang.parse.parse(file_obj.content)
            except Exception as e:
                logger.warning(f"Failed to parse {file_obj.path}: {e}")
                ast_tree = None
        else:
            ast_tree = None
            
        for detector in self.detectors:
            if ast_tree and hasattr(detector, 'detect_ast_from_tree'):
                vulns = detector.detect_ast_from_tree(file_obj, ast_tree)
            else:
                vulns = detector.detect(file_obj)
                
            if vulns:
                file_results.extend(vulns)
                
        return file_results