import re
import logging
from dr_source.core.detectors.base import BaseDetector
from dr_source.core.taint_detector import TaintDetector

logger = logging.getLogger(__name__)

class SQLInjectionDetector(BaseDetector):
    BUILTIN_REGEX_PATTERNS = [
        r'executeQuery\s*\(.*?\+\s*\w+\)',
        r'Statement\s*\.\s*execute\s*\(.*?\+\s*\w+\)',
        r'PreparedStatement\s*\.\s*execute\s*\(.*?\+\s*\w+\)'
    ]
    
    BUILTIN_AST_SINK = ['executeQuery', 'execute', 'executeUpdate']
    
    def __init__(self):
        self.regex_patterns = self.BUILTIN_REGEX_PATTERNS
        self.ast_sink = self.BUILTIN_AST_SINK
        self.ast_mode = False

    def detect(self, file_object):
        results = []
        
        for i, line in enumerate(file_object.content.split('\n')):
            for pattern in self.regex_patterns:
                if re.search(pattern, line):
                    results.append({
                        'file': file_object.path,
                        'vuln_type': 'SQL_INJECTION',
                        'match': line.strip(),
                        'line': i + 1
                    })
                    break
                    
        return results

    def detect_ast_from_tree(self, file_object, ast_tree):
        if not self.ast_mode:
            return []
            
        taint_detector = TaintDetector()
        return taint_detector.detect_ast_taint(file_object, ast_tree, self.ast_sink, 'SQL_INJECTION')