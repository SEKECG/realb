import os
from transformers import AutoTokenizer

current_dir = os.path.dirname(os.path.abspath(__file__))
tokenizer_path = os.path.join(current_dir, "tokenizer")
tokenizer = AutoTokenizer.from_pretrained(tokenizer_path)

def get_token_length(content):
    """Calculate the number of tokens in a given string using a tokenizer."""
    tokens = tokenizer.encode(content)
    return len(tokens)

def get_tokens(content):
    """Tokenize the input string content into a list of tokens using a predefined tokenizer."""
    return tokenizer.encode(content)