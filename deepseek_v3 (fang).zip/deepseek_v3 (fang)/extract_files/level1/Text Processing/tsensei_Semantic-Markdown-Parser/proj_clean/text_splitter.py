from typing import List, Optional

def split_text_into_sentences(text: str, parent_text: Optional[str] = None, chunk_size: int = 500) -> List[str]:
    """Split a given text into sentences or chunks of specified size, optionally prepending a parent text to each chunk."""
    sentences = []
    current_chunk = ""
    
    if parent_text:
        current_chunk = parent_text + "\n\n"
    
    for sentence in text.split('.'):
        sentence = sentence.strip()
        if not sentence:
            continue
            
        potential_chunk = current_chunk + sentence + "."
        if len(potential_chunk) > chunk_size and current_chunk:
            sentences.append(current_chunk.strip())
            current_chunk = sentence + "."
        else:
            current_chunk = potential_chunk
    
    if current_chunk:
        sentences.append(current_chunk.strip())
    
    return sentences