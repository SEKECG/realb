from typing import List, Optional
from token_encoder.encode import get_token_length
from text_splitter import split_text_into_sentences

class TreeElement:
    """Represents a node in the tree structure."""
    def __init__(self, header: Optional[str], content: str, token_length: int, children: List['TreeElement']):
        self.header = header
        self.content = content
        self.token_length = token_length
        self.children = children

class SemanticChunk:
    """Represents a semantically meaningful chunk of text."""
    def __init__(self, content: str, token_length: int, headers: List[str]):
        self.content = content
        self.token_length = token_length
        self.headers = headers

class SemanticMarkdownParser:
    """A parser that converts markdown text into semantic chunks based on its structure."""
    
    def parse_markdown_to_tree(self, markdown_text: str) -> TreeElement:
        """Parses markdown text into a tree structure."""
        if not markdown_text.strip():
            raise ValueError("Markdown text is empty or contains no content")
        
        # Simplified implementation - in reality would use MarkdownNodeParser
        root = TreeElement(None, "", 0, [])
        current_node = root
        
        for line in markdown_text.split('\n'):
            if line.startswith('#'):
                level = line.count('#')
                header = line.strip('#').strip()
                new_node = TreeElement(header, "", 0, [])
                current_node.children.append(new_node)
                current_node = new_node
            else:
                current_node.content += line + "\n"
        
        return root
    
    def get_full_header_path(self, headers: List[str]) -> str:
        """Creates a formatted header path string from a list of headers."""
        return " > ".join(headers)
    
    def format_chunk_with_headers(self, headers: List[str], content: str, include_hashes: bool = False) -> str:
        """Formats content with its header path."""
        if not headers:
            return content
        
        if include_hashes:
            header_text = "\n".join(f"{'#' * (i+1)} {header}" for i, header in enumerate(headers))
        else:
            header_text = self.get_full_header_path(headers)
        
        return f"{header_text}\n\n{content}"
    
    def combine_chunks(self, chunk1: SemanticChunk, chunk2: SemanticChunk) -> SemanticChunk:
        """Combines two semantic chunks while properly handling headers with markdown syntax."""
        common_prefix = 0
        for h1, h2 in zip(chunk1.headers, chunk2.headers):
            if h1 == h2:
                common_prefix += 1
            else:
                break
        
        combined_headers = chunk1.headers[:common_prefix]
        combined_content = self.format_chunk_with_headers(chunk1.headers[common_prefix:], chunk1.content)
        combined_content += "\n\n" + self.format_chunk_with_headers(chunk2.headers[common_prefix:], chunk2.content)
        
        return SemanticChunk(
            content=combined_content,
            token_length=chunk1.token_length + chunk2.token_length,
            headers=combined_headers
        )
    
    def process_tree_to_chunks(self, root: TreeElement, max_tokens: int = 500, current_headers: Optional[List[str]] = None) -> List[SemanticChunk]:
        """Processes the tree using post-order traversal to create semantic chunks."""
        if current_headers is None:
            current_headers = []
        
        chunks = []
        
        # Process children first (post-order traversal)
        for child in root.children:
            new_headers = current_headers.copy()
            if child.header:
                new_headers.append(child.header)
            chunks.extend(self.process_tree_to_chunks(child, max_tokens, new_headers))
        
        # Process current node
        if root.content.strip():
            content = root.content.strip()
            token_length = get_token_length(content)
            
            if token_length > max_tokens:
                split_content = split_text_into_sentences(content, None, max_tokens)
                for part in split_content:
                    chunks.append(SemanticChunk(
                        content=part,
                        token_length=get_token_length(part),
                        headers=current_headers.copy()
                    ))
            else:
                chunks.append(SemanticChunk(
                    content=content,
                    token_length=token_length,
                    headers=current_headers.copy()
                ))
        
        # Combine chunks where possible
        combined_chunks = []
        current_chunk = None
        
        for chunk in chunks:
            if current_chunk is None:
                current_chunk = chunk
            elif current_chunk.token_length + chunk.token_length <= max_tokens:
                current_chunk = self.combine_chunks(current_chunk, chunk)
            else:
                combined_chunks.append(current_chunk)
                current_chunk = chunk
        
        if current_chunk is not None:
            combined_chunks.append(current_chunk)
        
        return combined_chunks
    
    def get_semantic_chunks(self, root: TreeElement, max_tokens: int = 500) -> List[str]:
        """Processes the tree and returns formatted semantic chunks."""
        semantic_chunks = self.process_tree_to_chunks(root, max_tokens)
        return [self.format_chunk_with_headers(chunk.headers, chunk.content) for chunk in semantic_chunks]