import logging
import numpy as np

class AutonomousNavigation:
    def __init__(self, initial_position, destination):
        self.position = np.array(initial_position, dtype=float)
        self.destination = np.array(destination, dtype=float)
        self.speed = 1.0  # units per second
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)

    def calculate_direction(self):
        """Calculate the normalized direction vector to destination."""
        direction = self.destination - self.position
        distance = np.linalg.norm(direction)
        if distance < 1e-6:  # already at destination
            return np.zeros_like(direction)
        return direction / distance

    def has_reached_destination(self):
        """Check if destination has been reached."""
        distance = np.linalg.norm(self.destination - self.position)
        return distance < 0.1  # tolerance

    def move(self):
        """Move towards the destination."""
        if self.has_reached_destination():
            return False
        
        direction = self.calculate_direction()
        self.position += direction * self.speed
        self.logger.info(f"New position: {self.position}")
        return True

    def navigate(self):
        """Navigate continuously until destination is reached."""
        while not self.has_reached_destination():
            if not self.move():
                break
            time.sleep(0.1)  # small delay for simulation
        
        self.logger.info("Destination reached")