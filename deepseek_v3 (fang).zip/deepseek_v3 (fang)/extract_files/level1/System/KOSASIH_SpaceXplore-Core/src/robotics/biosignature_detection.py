import logging
import random

class BiosignatureDetection:
    def __init__(self, threshold):
        self.threshold = threshold
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)

    def analyze_data(self, biosensor_data):
        """Analyze biosensor data to detect biosignatures."""
        detection_score = random.random()  # Simulate detection score
        self.logger.info(f"Detection score: {detection_score:.2f}")
        return detection_score >= self.threshold

    def detect_biosignature(self, biosensor_data):
        """Detect biosignature and log the result."""
        detected = self.analyze_data(biosensor_data)
        if detected:
            self.logger.info("Biosignature detected!")
        else:
            self.logger.info("No biosignature detected")
        return detected