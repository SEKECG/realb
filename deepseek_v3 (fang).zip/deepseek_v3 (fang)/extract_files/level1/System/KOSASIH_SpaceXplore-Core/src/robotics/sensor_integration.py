import logging
import random

class SensorIntegration:
    def __init__(self):
        self.sensors = {
            "temperature": self.read_temperature,
            "humidity": self.read_humidity,
            "pressure": self.read_pressure,
            "biosensor": self.read_biosensor
        }
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)

    def read_temperature(self):
        """Simulate reading temperature."""
        temp = random.uniform(-50, 50)
        self.logger.info(f"Temperature: {temp:.1f}°C")
        return temp

    def read_humidity(self):
        """Simulate reading humidity."""
        humidity = random.uniform(0, 100)
        self.logger.info(f"Humidity: {humidity:.1f}%")
        return humidity

    def read_pressure(self):
        """Simulate reading pressure."""
        pressure = random.uniform(900, 1100)
        self.logger.info(f"Pressure: {pressure:.1f} hPa")
        return pressure

    def read_biosensor(self):
        """Simulate reading biosensor."""
        biosignal = random.choice([True, False])
        self.logger.info(f"Biosignal detected: {biosignal}")
        return biosignal

    def collect_data(self):
        """Collect data from all sensors."""
        data = {}
        for sensor_name, sensor_func in self.sensors.items():
            data[sensor_name] = sensor_func()
        return data