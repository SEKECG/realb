import logging
import time

class IonDrive:
    def __init__(self, thrust, fuel_mass, specific_impulse):
        self.thrust = thrust
        self.fuel_mass = fuel_mass
        self.specific_impulse = specific_impulse
        self.is_active = False
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)

    def activate(self):
        """Activate the Ion Drive if there is sufficient fuel."""
        if self.fuel_mass > 0:
            self.is_active = True
            self.logger.info("Ion Drive activated")
        else:
            self.logger.error("Cannot activate: no fuel remaining")

    def deactivate(self):
        """Deactivate the Ion Drive."""
        self.is_active = False
        self.logger.info("Ion Drive deactivated")

    def calculate_acceleration(self):
        """Calculate the acceleration if active."""
        if self.is_active and self.fuel_mass > 0:
            return self.thrust / self.fuel_mass
        return 0

    def consume_fuel(self, time):
        """Calculate and update the remaining fuel mass."""
        if not self.is_active:
            return
        
        fuel_consumed = (self.thrust * time) / (self.specific_impulse * 9.81)
        if fuel_consumed >= self.fuel_mass:
            self.fuel_mass = 0
            self.deactivate()
            self.logger.warning("Fuel depleted")
        else:
            self.fuel_mass -= fuel_consumed
            self.logger.info(f"Fuel consumed: {fuel_consumed:.2f} kg, remaining: {self.fuel_mass:.2f} kg")

    def simulate(self, duration):
        """Simulate the operation over a specified duration."""
        if not self.is_active:
            self.logger.warning("Cannot simulate: drive not active")
            return
        
        step = 1  # second
        for t in range(0, duration, step):
            if not self.is_active:
                break
            self.consume_fuel(step)
            self.logger.info(f"Time: {t}s, Status: {self.status()}")

    def status(self):
        """Retrieve the current operational status."""
        return {
            "active": self.is_active,
            "thrust": self.thrust,
            "fuel_mass": self.fuel_mass,
            "acceleration": self.calculate_acceleration()
        }