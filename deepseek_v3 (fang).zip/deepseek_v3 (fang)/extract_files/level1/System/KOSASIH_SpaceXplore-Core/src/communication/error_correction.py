import numpy as np
import logging

class ErrorCorrection:
    def __init__(self):
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)

    def hamming_code(self, data):
        """Encodes 4 bits of data using Hamming (7,4) code."""
        if len(data) != 4:
            raise ValueError("Input data must be 4 bits long")
        
        data_bits = np.array([int(bit) for bit in data])
        G = np.array([
            [1, 1, 0, 1],
            [1, 0, 1, 1],
            [1, 0, 0, 0],
            [0, 1, 1, 1],
            [0, 1, 0, 0],
            [0, 0, 1, 0],
            [0, 0, 0, 1]
        ])
        encoded = np.dot(G, data_bits) % 2
        self.logger.info(f"Encoded data: {encoded}")
        return encoded

    def detect_and_correct(self, received_data):
        """Detects and corrects a single-bit error in the received data."""
        H = np.array([
            [1, 0, 1, 0, 1, 0, 1],
            [0, 1, 1, 0, 0, 1, 1],
            [0, 0, 0, 1, 1, 1, 1]
        ])
        
        syndrome = np.dot(H, received_data) % 2
        error_pos = int(''.join(map(str, syndrome[::-1])), 2)
        
        if error_pos != 0:
            received_data[error_pos - 1] ^= 1
            self.logger.info(f"Corrected error at position {error_pos}")
        
        decoded_data = np.array([received_data[2], received_data[4], received_data[5], received_data[6]])
        return decoded_data