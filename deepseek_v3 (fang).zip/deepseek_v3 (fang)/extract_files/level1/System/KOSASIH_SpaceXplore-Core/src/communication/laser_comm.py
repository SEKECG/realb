import logging
import math

class LaserCommunication:
    def __init__(self, power, distance):
        self.power = power
        self.distance = distance
        self.efficiency = 0.8  # default efficiency
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)

    def calculate_signal_strength(self):
        """Calculate the signal strength based on power, efficiency, and distance."""
        signal_strength = (self.power * self.efficiency) / (self.distance ** 2)
        self.logger.info(f"Signal strength: {signal_strength:.2f}")
        return signal_strength

    def transmit_data(self, data):
        """Transmit the given data if the signal strength is above threshold."""
        signal_strength = self.calculate_signal_strength()
        if signal_strength > 0.1:  # minimum threshold
            self.logger.info(f"Transmitting data: {data}")
            return True
        else:
            self.logger.warning("Signal strength too low for transmission")
            return False