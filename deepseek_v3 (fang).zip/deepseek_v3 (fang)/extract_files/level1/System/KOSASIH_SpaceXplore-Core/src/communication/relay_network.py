import logging

class RelayNetwork:
    def __init__(self):
        self.relays = []
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)

    def add_relay(self, relay_id):
        """Add a relay ID to the network."""
        self.relays.append(relay_id)
        self.logger.info(f"Added relay: {relay_id}")

    def transmit_via_relays(self, data):
        """Transmit data through all available relays."""
        if not self.relays:
            self.logger.error("No relays available for transmission")
            return False
        
        self.logger.info(f"Transmitting data through {len(self.relays)} relays")
        for relay in self.relays:
            self.logger.info(f"Relay {relay} transmitting: {data}")
        
        return True