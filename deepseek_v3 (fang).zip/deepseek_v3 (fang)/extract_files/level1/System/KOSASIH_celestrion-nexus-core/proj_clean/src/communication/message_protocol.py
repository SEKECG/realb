import json

class MessageProtocol:
    """Provides functionalities for formatting, parsing, and validating messages."""

    @staticmethod
    def format_message(recipient, message, metadata=None):
        """Formats a message for transmission with optional metadata."""
        message_dict = {
            "recipient": recipient,
            "message": message,
            "metadata": metadata or {}
        }
        return json.dumps(message_dict)

    @staticmethod
    def parse_message(raw_message):
        """Parses a raw message string into a dictionary."""
        try:
            return json.loads(raw_message)
        except json.JSONDecodeError:
            return None

    @staticmethod
    def validate_message(message_dict):
        """Validates the structure of the message."""
        if not isinstance(message_dict, dict):
            return False
        if "recipient" not in message_dict or "message" not in message_dict:
            return False
        return True

    @staticmethod
    def add_metadata(message_dict, key, value):
        """Adds metadata to an existing message dictionary."""
        if not isinstance(message_dict.get("metadata"), dict):
            message_dict["metadata"] = {}
        message_dict["metadata"][key] = value
        return message_dict

    @staticmethod
    def get_metadata(message_dict, key):
        """Retrieves a value from the metadata of a message dictionary."""
        return message_dict.get("metadata", {}).get(key)

    @staticmethod
    def remove_metadata(message_dict, key):
        """Removes a key from the metadata of a message dictionary."""
        if isinstance(message_dict.get("metadata"), dict):
            message_dict["metadata"].pop(key, None)
        return message_dict