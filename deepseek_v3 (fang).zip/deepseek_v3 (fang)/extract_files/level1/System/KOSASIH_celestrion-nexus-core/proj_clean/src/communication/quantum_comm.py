from message_protocol import MessageProtocol
import random

class QuantumComm:
    """
    Simulate quantum communication by creating, measuring, and transmitting messages 
    using entangled quantum pairs, including message formatting, parsing, and validation.
    """
    def __init__(self):
        """Initialize an instance with a list to store entangled pairs and a maximum limit of 10 pairs."""
        self.entangled_pairs = []
        self.max_pairs = 10

    def create_entangled_pair(self):
        """Simulates the creation of an entangled quantum pair."""
        if len(self.entangled_pairs) >= self.max_pairs:
            return None
        pair_id = f"pair_{len(self.entangled_pairs)}"
        self.entangled_pairs.append({"id": pair_id, "state": random.randint(0, 1)})
        return pair_id

    def format_message(self, recipient, message):
        """Formats a message for transmission."""
        return MessageProtocol.format_message(recipient, message)

    def measure_state(self, pair_index):
        """Measures the state of a quantum pair."""
        if 0 <= pair_index < len(self.entangled_pairs):
            return self.entangled_pairs[pair_index]["state"]
        return None

    def parse_message(self, raw_message):
        """Parses a raw message string into a dictionary."""
        return MessageProtocol.parse_message(raw_message)

    def receive_message(self, pair_index):
        """Simulates receiving a message by measuring the state of the entangled pair."""
        state = self.measure_state(pair_index)
        if state is not None:
            return {"status": "received", "state": state}
        return None

    def transmit_message(self, message, pair_index):
        """Transmits a message using the entangled pair."""
        if 0 <= pair_index < len(self.entangled_pairs):
            return {"status": "sent", "message": message, "pair_index": pair_index}
        return None

    def validate_message(self, message_dict):
        """Validates the structure of the message."""
        return MessageProtocol.validate_message(message_dict)