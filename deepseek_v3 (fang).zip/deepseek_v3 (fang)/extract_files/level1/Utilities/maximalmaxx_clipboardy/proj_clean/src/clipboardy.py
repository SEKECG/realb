import os
import json
import re
import tkinter as tk
from tkinter import messagebox
import customtkinter as ctk
import pyperclip
from cryptography.fernet import Fernet
from datetime import datetime

# Constants
PACKAGE_FOLDER = os.path.dirname(os.path.abspath(__file__))
KEY_FILE = os.path.join(PACKAGE_FOLDER, "key.key")
SAVE_FILE = os.path.join(PACKAGE_FOLDER, "clips.json")
SETTINGS_FILE = os.path.join(PACKAGE_FOLDER, "settings.json")

# Global variables
autosave = False
clipsObj = []
cryptKey = None
darkmode = False
lastClip = ""
selected_color = "blue"
selected_type_filter = "all"

def generate_key():
    """Generate and save encryption key."""
    global cryptKey
    cryptKey = Fernet.generate_key()
    with open(KEY_FILE, "wb") as key_file:
        key_file.write(cryptKey)

def load_key():
    """Load encryption key from file."""
    global cryptKey
    if os.path.exists(KEY_FILE):
        with open(KEY_FILE, "rb") as key_file:
            cryptKey = key_file.read()
    else:
        generate_key()

def encrypt_clip(clip):
    """Encrypt clipboard content."""
    fernet = Fernet(cryptKey)
    return fernet.encrypt(clip.encode()).decode()

def decrypt_clip(encrypted_clip):
    """Decrypt encrypted clipboard content."""
    fernet = Fernet(cryptKey)
    return fernet.decrypt(encrypted_clip.encode()).decode()

def determine_content_type(current_clip):
    """Detect content type (URL, Email, etc.) in clipboard content."""
    # URL regex
    url_pattern = re.compile(
        r'^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$'
    )
    # Email regex
    email_pattern = re.compile(
        r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    )
    # IPv4 regex
    ipv4_pattern = re.compile(
        r'^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}'
        r'(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$'
    )
    # IPv6 regex (simplified)
    ipv6_pattern = re.compile(
        r'^([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$'
    )
    # Credit card regex (simplified)
    credit_card_pattern = re.compile(
        r'^[0-9]{4}-?[0-9]{4}-?[0-9]{4}-?[0-9]{4}$'
    )

    if url_pattern.match(current_clip):
        return "URL"
    elif email_pattern.match(current_clip):
        return "Email"
    elif ipv4_pattern.match(current_clip):
        return "IPv4"
    elif ipv6_pattern.match(current_clip):
        return "IPv6"
    elif credit_card_pattern.match(current_clip):
        return "Credit Card"
    else:
        return "Text"

def load_clips():
    """Load saved clipboard clips."""
    global clipsObj
    if os.path.exists(SAVE_FILE):
        with open(SAVE_FILE, "r") as f:
            encrypted_clips = json.load(f)
            clipsObj = []
            for clip in encrypted_clips:
                try:
                    decrypted_content = decrypt_clip(clip["content"])
                    clipsObj.append({
                        "date": clip["date"],
                        "type": clip["type"],
                        "content": decrypted_content
                    })
                except:
                    continue

def save_clips():
    """Save clipboard clips to file."""
    encrypted_clips = []
    for clip in clipsObj:
        encrypted_clips.append({
            "date": clip["date"],
            "type": clip["type"],
            "content": encrypt_clip(clip["content"])
        })
    with open(SAVE_FILE, "w") as f:
        json.dump(encrypted_clips, f)

def load_settings():
    """Load autosave setting from settings file."""
    global autosave, darkmode, selected_color
    if os.path.exists(SETTINGS_FILE):
        with open(SETTINGS_FILE, "r") as f:
            settings = json.load(f)
            autosave = settings.get("autosave", False)
            darkmode = settings.get("darkmode", False)
            selected_color = settings.get("color", "blue")

def save_settings():
    """Save current settings to settings file."""
    settings = {
        "autosave": autosave,
        "darkmode": darkmode,
        "color": selected_color
    }
    with open(SETTINGS_FILE, "w") as f:
        json.dump(settings, f)

def monitor_clipboard():
    """Monitor clipboard changes and save new clips if autosave is enabled."""
    global lastClip
    try:
        current_clip = pyperclip.paste()
        if current_clip != lastClip and current_clip.strip() != "":
            lastClip = current_clip
            if autosave:
                save_clip()
    except:
        pass
    root.after(1000, monitor_clipboard)

def save_clip():
    """Save current clipboard content if available."""
    current_clip = pyperclip.paste()
    if current_clip.strip() == "":
        return

    content_type = determine_content_type(current_clip)
    clipsObj.insert(0, {
        "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "type": content_type,
        "content": current_clip
    })
    save_clips()
    refresh_ui(None)

def delete_clip_from_ui(index):
    """Delete a clip from the list and update UI."""
    if 0 <= index < len(clipsObj):
        clipsObj.pop(index)
        save_clips()
        refresh_ui(None)

def delete_all_clips():
    """Clear all clips and refresh UI."""
    global clipsObj
    if messagebox.askyesno("Confirm", "Delete all clipboard entries?"):
        clipsObj = []
        save_clips()
        refresh_ui(None)

def delete_key():
    """Reset the encryption key and associated data files after user confirmation."""
    if messagebox.askyesno("Danger Zone", 
        "This will delete all saved clips and require a restart. Continue?"):
        global cryptKey, clipsObj
        try:
            os.remove(KEY_FILE)
            os.remove(SAVE_FILE)
            os.remove(SETTINGS_FILE)
            cryptKey = None
            clipsObj = []
            messagebox.showinfo("Info", "Please restart the application")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to reset: {str(e)}")

def toggle_autosave():
    """Enable or disable autosave and save the setting."""
    global autosave
    autosave = not autosave
    save_settings()

def toggle_darkmode():
    """Toggle darkmode."""
    global darkmode
    darkmode = not darkmode
    ctk.set_appearance_mode("dark" if darkmode else "light")
    save_settings()

def apply_color(choice):
    """Apply the chosen color."""
    global selected_color
    selected_color = choice
    save_settings()
    messagebox.showinfo("Info", "Restart application to apply color changes")

def apply_filter(choice):
    """Update type filter based on user selection."""
    global selected_type_filter
    selected_type_filter = choice
    refresh_ui(None)

def search_clips(event):
    """Filter displayed clips based on search input."""
    refresh_ui(None)

def populate_clips_table(frame, clips_to_display):
    """Update the UI table with clipboard clips."""
    # Clear existing widgets
    for widget in frame.winfo_children():
        widget.destroy()

    # Create headers
    headers = ["Date", "Type", "Content", "Actions"]
    for i, header in enumerate(headers):
        label = ctk.CTkLabel(frame, text=header, font=("Arial", 12, "bold"))
        label.grid(row=0, column=i, padx=5, pady=5, sticky="ew")

    # Add clips
    for i, clip in enumerate(clips_to_display, start=1):
        # Date
        date_label = ctk.CTkLabel(frame, text=clip["date"])
        date_label.grid(row=i, column=0, padx=5, pady=5, sticky="w")

        # Type
        type_label = ctk.CTkLabel(frame, text=clip["type"])
        type_label.grid(row=i, column=1, padx=5, pady=5, sticky="w")

        # Content (shortened)
        content = clip["content"]
        if len(content) > 50:
            content = content[:47] + "..."
        content_label = ctk.CTkLabel(frame, text=content)
        content_label.grid(row=i, column=2, padx=5, pady=5, sticky="w")

        # Action buttons
        button_frame = ctk.CTkFrame(frame, fg_color="transparent")
        button_frame.grid(row=i, column=3, padx=5, pady=5, sticky="e")

        copy_btn = ctk.CTkButton(
            button_frame, text="Copy", width=60,
            command=lambda c=clip["content"]: pyperclip.copy(c)
        )
        copy_btn.pack(side="left", padx=2)

        delete_btn = ctk.CTkButton(
            button_frame, text="Delete", width=60,
            command=lambda idx=i-1: delete_clip_from_ui(idx)
        )
        delete_btn.pack(side="left", padx=2)

def refresh_ui(component):
    """Refresh the UI components."""
    global selected_type_filter

    # Filter clips based on search and type
    search_text = search_entry.get().lower()
    filtered_clips = []
    for clip in clipsObj:
        if (selected_type_filter == "all" or clip["type"] == selected_type_filter) and \
           search_text in clip["content"].lower():
            filtered_clips.append(clip)

    # Update table
    populate_clips_table(clips_frame, filtered_clips)

def settings_UI():
    """Create settings UI."""
    settings_window = ctk.CTkToplevel(root)
    settings_window.title("Settings")
    settings_window.geometry("400x400")
    settings_window.resizable(False, False)

    # Appearance settings
    appearance_frame = ctk.CTkFrame(settings_window)
    appearance_frame.pack(pady=10, padx=10, fill="x")

    ctk.CTkLabel(appearance_frame, text="Appearance", font=("Arial", 14, "bold")).pack(anchor="w", pady=(0, 10))

    # Dark mode toggle
    darkmode_var = ctk.BooleanVar(value=darkmode)
    darkmode_switch = ctk.CTkSwitch(
        appearance_frame, text="Dark Mode",
        variable=darkmode_var, command=toggle_darkmode
    )
    darkmode_switch.pack(anchor="w", pady=5)

    # Color theme
    ctk.CTkLabel(appearance_frame, text="Color Theme:").pack(anchor="w", pady=(10, 5))
    color_options = ["blue", "green", "dark-blue"]
    color_menu = ctk.CTkOptionMenu(
        appearance_frame, values=color_options,
        command=apply_color
    )
    color_menu.set(selected_color)
    color_menu.pack(anchor="w", pady=5)

    # Autosave toggle
    autosave_var = ctk.BooleanVar(value=autosave)
    autosave_switch = ctk.CTkSwitch(
        appearance_frame, text="Auto-save new clips",
        variable=autosave_var, command=toggle_autosave
    )
    autosave_switch.pack(anchor="w", pady=5)

    # Danger zone
    danger_frame = ctk.CTkFrame(settings_window, fg_color="transparent")
    danger_frame.pack(pady=10, padx=10, fill="x")

    ctk.CTkLabel(danger_frame, text="Danger Zone", font=("Arial", 14, "bold"), text_color="red").pack(anchor="w", pady=(0, 10))

    # Delete all clips button
    delete_all_btn = ctk.CTkButton(
        danger_frame, text="Delete All Clips", fg_color="red",
        command=delete_all_clips
    )
    delete_all_btn.pack(anchor="w", pady=5)

    # Reset encryption key button
    reset_key_btn = ctk.CTkButton(
        danger_frame, text="Reset Encryption Key", fg_color="red",
        command=delete_key
    )
    reset_key_btn.pack(anchor="w", pady=5)

def UI():
    """Create main UI."""
    global root, search_entry, clips_frame

    # Initialize main window
    root = ctk.CTk()
    root.title("Clipboardy")
    root.geometry("800x600")
    ctk.set_appearance_mode("dark" if darkmode else "light")
    ctk.set_default_color_theme(selected_color)

    # Main container
    main_frame = ctk.CTkFrame(root)
    main_frame.pack(fill="both", expand=True, padx=10, pady=10)

    # Top controls
    controls_frame = ctk.CTkFrame(main_frame, fg_color="transparent")
    controls_frame.pack(fill="x", pady=(0, 10))

    # Search bar
    search_frame = ctk.CTkFrame(controls_frame, fg_color="transparent")
    search_frame.pack(side="left", fill="x", expand=True)

    ctk.CTkLabel(search_frame, text="Search:").pack(side="left", padx=(0, 5))
    search_entry = ctk.CTkEntry(search_frame)
    search_entry.pack(side="left", fill="x", expand=True)
    search_entry.bind("<KeyRelease>", search_clips)

    # Type filter
    filter_frame = ctk.CTkFrame(controls_frame, fg_color="transparent")
    filter_frame.pack(side="left", padx=(10, 0))

    ctk.CTkLabel(filter_frame, text="Filter:").pack(side="left", padx=(0, 5))
    type_options = ["all", "Text", "URL", "Email", "IPv4", "IPv6", "Credit Card"]
    type_menu = ctk.CTkOptionMenu(
        filter_frame, values=type_options,
        command=apply_filter
    )
    type_menu.set(selected_type_filter)
    type_menu.pack(side="left")

    # Action buttons
    button_frame = ctk.CTkFrame(controls_frame, fg_color="transparent")
    button_frame.pack(side="right")

    save_btn = ctk.CTkButton(
        button_frame, text="Save Current Clip",
        command=save_clip
    )
    save_btn.pack(side="left", padx=2)

    settings_btn = ctk.CTkButton(
        button_frame, text="Settings",
        command=settings_UI
    )
    settings_btn.pack(side="left", padx=2)

    # Clips table
    table_container = ctk.CTkFrame(main_frame)
    table_container.pack(fill="both", expand=True)

    # Add scrollable frame
    canvas = ctk.CTkCanvas(table_container)
    scrollbar = ctk.CTkScrollbar(table_container, orientation="vertical", command=canvas.yview)
    scrollable_frame = ctk.CTkFrame(canvas)

    scrollable_frame.bind(
        "<Configure>",
        lambda e: canvas.configure(
            scrollregion=canvas.bbox("all")
        )
    )

    canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)

    canvas.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")

    clips_frame = scrollable_frame

    # Initial UI update
    refresh_ui(None)

    # Start clipboard monitoring
    monitor_clipboard()

    # Start main loop
    root.mainloop()

def main():
    """Initialize and run the application."""
    # Load encryption key
    load_key()

    # Load saved clips
    load_clips()

    # Load settings
    load_settings()

    # Create UI
    UI()

if __name__ == "__main__":
    main()