import logging
from pathlib import Path
from typing import Dict, Any
import yaml

logger = logging.getLogger(__name__)

DEFAULT_CONFIG = {
    "global_rules": Path(__file__).parent / "global_rules.mdc",
    "language_rules_dir": Path(__file__).parent / "language_rules",
    "cursor_dir": Path(".cursor"),
    "rules_dir": Path(".cursor") / "rules",
}

def load_config() -> Dict[str, Any]:
    """Load configuration from YAML file or return defaults.
    
    Returns:
        Dict[str, Any]: Configuration dictionary with all settings
    """
    config_path = Path("crules_config.yaml")
    if config_path.exists():
        try:
            with open(config_path) as f:
                config = yaml.safe_load(f)
                if config:
                    return {**DEFAULT_CONFIG, **config}
        except Exception as e:
            logger.warning(f"Failed to load config file: {e}")
    
    return DEFAULT_CONFIG