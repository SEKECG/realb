import logging
import shutil
from pathlib import Path
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

def setup_directory_structure(verbose, force) -> bool:
    """Create necessary directories and files for crules.
    
    Args:
        verbose: Whether to show verbose output
        force: Whether to overwrite existing files
    """
    config = load_config()
    cursor_manager = CursorDirectoryManager(config)
    cursor_manager.ensure_cursor_structure()

    if verbose:
        logger.info("Setting up directory structure...")

    try:
        copy_predefined_rules(config["language_rules_dir"], verbose, force)
        return True
    except Exception as e:
        logger.error(f"Failed to setup directory structure: {e}")
        return False

def list_available_languages(language_rules_dir) -> None:
    """Display all available language rule files."""
    languages = get_available_languages(language_rules_dir)
    print("Available language rules:")
    for lang in languages:
        print(f"- {lang}")

def check_files_exist(global_rules, language_rules_dir, languages) -> bool:
    """Check if all required files exist."""
    if not Path(global_rules).exists():
        logger.error(f"Global rules file not found: {global_rules}")
        return False

    if languages:
        for lang in languages:
            lang_file = Path(language_rules_dir) / f"{lang}.mdc"
            if not lang_file.exists():
                logger.error(f"Language rules file not found: {lang_file}")
                return False

    return True

def backup_existing_rules(force) -> bool:
    """Backup existing .cursorrules file if it exists."""
    if not Path(".cursorrules").exists():
        return True

    backup_path = Path(".cursorrules.bak")
    if backup_path.exists() and not force:
        logger.warning("Backup file already exists. Use --force to overwrite.")
        return False

    try:
        shutil.copy(".cursorrules", ".cursorrules.bak")
        return True
    except Exception as e:
        logger.error(f"Failed to backup rules: {e}")
        return False

def combine_rules(global_rules, language_rules_dir, languages, delimiter) -> str:
    """Combine global and language-specific rules."""
    with open(global_rules) as f:
        combined = f.read()

    if languages:
        for lang in languages:
            lang_file = Path(language_rules_dir) / f"{lang}.mdc"
            with open(lang_file) as f:
                combined += delimiter + f.read()

    return combined

def write_rules_to_cursor_dir(cursor_manager, global_rules, lang_rules_dir, languages, force) -> bool:
    """Write rules to the .cursor/rules directory.
    
    Args:
        cursor_manager: Instance of CursorDirectoryManager
        global_rules: Path to global rules file
        lang_rules_dir: Path to language rules directory
        languages: List of language identifiers
        force: Whether to force overwrite existing files
        
    Returns:
        bool: True if successful, False otherwise
    """
    try:
        with open(global_rules) as f:
            global_content = f.read()

        if not cursor_manager.create_rule_file("global", global_content, None):
            return False

        if languages:
            for lang in languages:
                lang_file = Path(lang_rules_dir) / f"{lang}.mdc"
                with open(lang_file) as f:
                    lang_content = f.read()
                if not cursor_manager.create_rule_file(lang, lang_content, None):
                    return False

        return True
    except Exception as e:
        logger.error(f"Failed to write rules to cursor directory: {e}")
        return False

def copy_predefined_rules(lang_rules_dir, verbose, force) -> None:
    """Copy predefined language rules to the lang_rules directory."""
    src_dir = Path(__file__).parent / "predefined_rules"
    dst_dir = Path(lang_rules_dir)

    dst_dir.mkdir(exist_ok=True)

    for rule_file in src_dir.glob("*.mdc"):
        dst_file = dst_dir / rule_file.name
        if not dst_file.exists() or force:
            if verbose:
                logger.info(f"Copying {rule_file.name} to {dst_dir}")
            shutil.copy(rule_file, dst_file)

def get_available_languages(language_rules_dir) -> Dict[str, Path]:
    """Get all available language rule files."""
    lang_dir = Path(language_rules_dir)
    return {
        f.stem: f
        for f in lang_dir.glob("*.mdc")
        if f.is_file() and f.stem != "global"
    }

def update_gitignore() -> None:
    """Add .cursorrules and .cursorrules.bak to .gitignore if it exists."""
    gitignore_path = Path(".gitignore")
    if not gitignore_path.exists():
        return

    with open(gitignore_path, "r+") as f:
        content = f.read()
        additions = []
        
        if ".cursorrules" not in content:
            additions.append(".cursorrules")
        if ".cursorrules.bak" not in content:
            additions.append(".cursorrules.bak")
        
        if additions:
            f.write("\n" + "\n".join(additions) + "\n")