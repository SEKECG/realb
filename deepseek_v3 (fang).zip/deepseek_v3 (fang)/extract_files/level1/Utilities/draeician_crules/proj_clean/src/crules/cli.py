import argparse
import logging
from pathlib import Path
from typing import List, Optional

from .config import load_config
from .cursor_ops import CursorDirectoryManager
from .file_ops import (
    backup_existing_rules,
    check_files_exist,
    combine_rules,
    copy_predefined_rules,
    list_available_languages,
    setup_directory_structure,
    update_gitignore,
    write_rules_to_cursor_dir,
)

logger = logging.getLogger(__name__)

def main(
    languages: Optional[List[str]] = None,
    force: bool = False,
    verbose: bool = False,
    show_list: bool = False,
    setup_dirs: bool = False,
    legacy: bool = False,
) -> None:
    """Generate cursor rules files.
    
    By default, creates individual rule files in .cursor/rules directory.
    Use --legacy to generate a single .cursorrules file instead.
    
    Use --setup to initialize or update the rules directory structure.
    Use --force with --setup to update existing rule files.
    Use --list to see available language rules.
    Use --verbose for detailed operation logging.
    """
    config = load_config()
    cursor_manager = CursorDirectoryManager(config)

    if verbose:
        logging.basicConfig(level=logging.INFO)

    if show_list:
        list_available_languages(config["language_rules_dir"])
        return

    if setup_dirs:
        setup_directory_structure(verbose, force)
        return

    if not check_files_exist(
        config["global_rules"], config["language_rules_dir"], languages
    ):
        logger.error("Required files are missing. Run with --setup to initialize.")
        return

    if legacy:
        backup_existing_rules(force)
        combined_rules = combine_rules(
            config["global_rules"], config["language_rules_dir"], languages, "\n\n"
        )
        with open(".cursorrules", "w") as f:
            f.write(combined_rules)
        update_gitignore()
    else:
        cursor_manager.ensure_cursor_structure()
        success = write_rules_to_cursor_dir(
            cursor_manager,
            config["global_rules"],
            config["language_rules_dir"],
            languages,
            force,
        )
        if success:
            cursor_manager.update_gitignore()

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate cursor rules files.")
    parser.add_argument(
        "--languages", nargs="+", help="Language identifiers for rule files"
    )
    parser.add_argument(
        "--force", action="store_true", help="Overwrite existing files"
    )
    parser.add_argument(
        "--verbose", action="store_true", help="Show detailed output"
    )
    parser.add_argument(
        "--list", dest="show_list", action="store_true", help="List available languages"
    )
    parser.add_argument(
        "--setup", dest="setup_dirs", action="store_true", help="Initialize directory structure"
    )
    parser.add_argument(
        "--legacy", action="store_true", help="Generate single .cursorrules file"
    )
    args = parser.parse_args()

    main(
        args.languages,
        args.force,
        args.verbose,
        args.show_list,
        args.setup_dirs,
        args.legacy,
    )