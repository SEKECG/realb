import logging
from pathlib import Path
from typing import List, Optional, Dict

logger = logging.getLogger(__name__)

class CursorDirectoryManager:
    """Manages the .cursor directory structure and rule files."""

    def __init__(self, config):
        """Initialize the cursor directory manager.
        
        Args:
            config: Configuration dictionary containing paths and settings
        """
        self.config = config
        self.cursor_dir = Path(config["cursor_dir"])
        self.rules_dir = Path(config["rules_dir"])

    def create_rule_file(self, name, content, metadata=None) -> bool:
        """Create a rule file with optional metadata.
        
        Args:
            name: Name of the rule file (without extension)
            content: Rule content
            metadata: Optional metadata dictionary
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            file_path = self.rules_dir / f"{name}.mdc"
            with open(file_path, "w") as f:
                if metadata:
                    f.write(f"---\n{yaml.dump(metadata)}---\n")
                f.write(content)
            return True
        except Exception as e:
            logger.error(f"Failed to create rule file: {e}")
            return False

    def ensure_cursor_structure(self) -> None:
        """Create the .cursor directory structure if it doesn't exist."""
        self.cursor_dir.mkdir(exist_ok=True)
        self.rules_dir.mkdir(exist_ok=True)

    def list_rule_files(self) -> List[Path]:
        """List all rule files in the .cursor/rules directory.
        
        Returns:
            List[Path]: List of paths to rule files
        """
        return list(self.rules_dir.glob("*.mdc"))

    def update_gitignore(self) -> None:
        """Update .gitignore to include .cursor/rules/*.mdc."""
        gitignore_path = Path(".gitignore")
        if not gitignore_path.exists():
            return

        with open(gitignore_path, "r+") as f:
            content = f.read()
            if ".cursor/rules/*.mdc" not in content:
                f.write("\n.cursor/rules/*.mdc\n")