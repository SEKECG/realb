import os
import sys
import time
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import base64
from PIL import Image

# Constants
AUTHOR_NAME = "Mahmud Nibir"
AUTHOR_GITHUB = "https://github.com/mahmudnibir"
AUTHOR_PROJECT = "HiddenMessage"
IMAGE_PATH = "input_image.png"
OUTPUT_IMAGE_PATH = "output_image.png"
PASSWORD = "secret_password"

def animated_logo(text):
    """Prints the logo with a typing animation effect."""
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(0.05)
    print()

def print_AUTHOR_info():
    """Display the author's information in a stylized manner."""
    print("\n\033[1;36m" + "="*50)
    print(f"Author: {AUTHOR_NAME}")
    print(f"GitHub: {AUTHOR_GITHUB}")
    print(f"Project: {AUTHOR_PROJECT}")
    print("="*50 + "\033[0m\n")

def generate_key(password):
    """Generate encryption key from password"""
    password = password.encode()
    salt = b'salt_'  # You should use a random salt in production
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100000,
    )
    key = base64.urlsafe_b64encode(kdf.derive(password))
    return key

def encrypt_text(text, password):
    """Encrypt text using AES"""
    key = generate_key(password)
    f = Fernet(key)
    encrypted_text = f.encrypt(text.encode())
    return encrypted_text.decode()

def decrypt_text(encrypted_text, password):
    """Decrypt text using AES"""
    key = generate_key(password)
    f = Fernet(key)
    decrypted_text = f.decrypt(encrypted_text.encode())
    return decrypted_text.decode()

def text_to_bin(text):
    """Convert text to binary"""
    return ''.join(format(ord(i), '08b') for i in text)

def bin_to_text(binary_data):
    """Convert binary to text"""
    return ''.join(chr(int(binary_data[i:i+8], 2)) for i in range(0, len(binary_data), 8))

def hide_text_in_image(IMAGE_PATH, text, OUTPUT_IMAGE_PATH, password):
    """Hide encrypted text inside an image"""
    # Encrypt the text
    encrypted_text = encrypt_text(text, password)
    binary_text = text_to_bin(encrypted_text)
    
    # Open the image
    image = Image.open(IMAGE_PATH)
    pixels = image.load()
    width, height = image.size
    
    # Check if the text can fit in the image
    if len(binary_text) > width * height * 3:
        raise ValueError("Text too large to hide in image")
    
    # Embed the binary text in the LSB of the image pixels
    index = 0
    for x in range(width):
        for y in range(height):
            r, g, b = pixels[x, y][:3]
            
            # Modify the LSB of each channel
            if index < len(binary_text):
                r = (r & 0xFE) | int(binary_text[index])
                index += 1
            if index < len(binary_text):
                g = (g & 0xFE) | int(binary_text[index])
                index += 1
            if index < len(binary_text):
                b = (b & 0xFE) | int(binary_text[index])
                index += 1
            
            pixels[x, y] = (r, g, b)
            
            if index >= len(binary_text):
                break
        if index >= len(binary_text):
            break
    
    # Save the modified image
    image.save(OUTPUT_IMAGE_PATH)
    print(f"Text hidden in image saved as {OUTPUT_IMAGE_PATH}")

def extract_text_from_image(IMAGE_PATH, password):
    """Extract encrypted text from an image"""
    # Open the image
    image = Image.open(IMAGE_PATH)
    pixels = image.load()
    width, height = image.size
    
    # Extract the binary data from LSB of each pixel
    binary_data = []
    for x in range(width):
        for y in range(height):
            r, g, b = pixels[x, y][:3]
            binary_data.append(str(r & 1))
            binary_data.append(str(g & 1))
            binary_data.append(str(b & 1))
    
    # Convert binary to text
    binary_text = ''.join(binary_data)
    # Find the first null terminator (if used) or use the whole binary
    # For simplicity, we'll use the whole binary (in a real app you might have a terminator)
    encrypted_text = bin_to_text(binary_text)
    
    # Decrypt the text
    try:
        decrypted_text = decrypt_text(encrypted_text, password)
        return decrypted_text
    except:
        return "Failed to decrypt. Wrong password or corrupted data."

def main():
    animated_logo("Hidden Message - Text in Image Steganography")
    print_AUTHOR_info()
    
    while True:
        print("\nMenu:")
        print("1. Hide text in image")
        print("2. Extract text from image")
        print("3. Exit")
        choice = input("Enter your choice (1-3): ")
        
        if choice == "1":
            text = input("Enter the text to hide: ")
            image_path = input(f"Enter image path (default: {IMAGE_PATH}): ") or IMAGE_PATH
            output_path = input(f"Enter output image path (default: {OUTPUT_IMAGE_PATH}): ") or OUTPUT_IMAGE_PATH
            password = input(f"Enter password (default: {PASSWORD}): ") or PASSWORD
            try:
                hide_text_in_image(image_path, text, output_path, password)
                print("Text hidden successfully!")
            except Exception as e:
                print(f"Error: {e}")
        
        elif choice == "2":
            image_path = input(f"Enter image path (default: {IMAGE_PATH}): ") or IMAGE_PATH
            password = input(f"Enter password (default: {PASSWORD}): ") or PASSWORD
            try:
                extracted_text = extract_text_from_image(image_path, password)
                print("\nExtracted Text:")
                print(extracted_text)
            except Exception as e:
                print(f"Error: {e}")
        
        elif choice == "3":
            print("Exiting...")
            break
        
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()