import os
import time
import plotext as plt
from datetime import datetime
from .session import SessionMetrics

def plot_metrics_live(get_metrics_func, adapter_name, interval):
    """Continuously plot metrics in real-time

    Args:
        get_metrics_func: Function to get metrics
        adapter_name: Name of the network adapter
        interval: Update interval in seconds"""
    plotter = MetricsPlotter()
    
    plt.title(f"WiFi Signal Strength - {adapter_name}")
    plt.xlabel("Time")
    plt.ylabel("Signal Strength (dBm)")
    plt.clc()
    
    try:
        while True:
            metrics = get_metrics_func()
            if metrics:
                plotter.update_plot(metrics)
                
                plt.cld()
                plt.plot(plotter.signal_strengths, label="Signal Strength")
                plt.show()
                
            time.sleep(interval)
    except KeyboardInterrupt:
        return plotter

class MetricsPlotter:
    """The MetricsPlotter class is designed to monitor, visualize, and save WiFi signal strength metrics over time, including dynamic plotting, real-time updates, and session summary statistics."""
    
    def __init__(self, max_points=100):
        """Initialize an instance with default or specified maximum points, setting up lists for signal strengths and timestamps, initializing min/max seen values, creating a session metrics object, and ensuring a plots directory exists."""
        self.max_points = max_points
        self.signal_strengths = []
        self.timestamps = []
        self.max_seen = -float('inf')
        self.min_seen = float('inf')
        self.session = SessionMetrics()
        
        if not os.path.exists('plots'):
            os.makedirs('plots')

    def update_plot(self, metrics):
        """Convert signal strength to float and ensure it's negative"""
        if metrics.signal_strength is not None:
            signal = -abs(float(metrics.signal_strength))
            self.signal_strengths.append(signal)
            self.timestamps.append(datetime.now().strftime("%H:%M:%S"))
            
            if signal > self.max_seen:
                self.max_seen = signal
            if signal < self.min_seen:
                self.min_seen = signal
                
            if len(self.signal_strengths) > self.max_points:
                self.signal_strengths.pop(0)
                self.timestamps.pop(0)
            
            self.session.add_metrics(metrics)

    def save_plot(self):
        """Save the current plot with averages"""
        if not self.signal_strengths:
            return
            
        plt.clf()
        plt.plot(self.signal_strengths, label="Signal Strength")
        plt.title(f"WiFi Signal Strength - Session Summary")
        plt.xlabel("Time")
        plt.ylabel("Signal Strength (dBm)")
        plt.save_fig(f"plots/session_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png")