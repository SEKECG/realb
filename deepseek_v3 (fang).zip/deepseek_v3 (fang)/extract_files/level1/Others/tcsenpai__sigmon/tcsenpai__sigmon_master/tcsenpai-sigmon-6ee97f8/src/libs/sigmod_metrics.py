class Metrics:
    """Class to store the metrics of the network adapter"""
    
    def __init__(self, signal_strength, bitrate, is_power_save_enabled):
        """Class to store the metrics of the network adapter"""
        self.signal_strength = signal_strength
        self.bitrate = bitrate
        self.is_power_save_enabled = is_power_save_enabled

    def __str__(self):
        """Return a human-readable string representation of the object's attributes, including signal strength, bitrate, and power save status."""
        return (f"Signal Strength: {self.signal_strength} dBm\n"
                f"Bitrate: {self.bitrate} Mb/s\n"
                f"Power Save: {'on' if self.is_power_save_enabled else 'off'}")