from datetime import datetime

class SessionMetrics:
    """To collect, store, and summarize signal strength and bitrate metrics over a session duration."""
    
    def __init__(self):
        """Initialize an instance with empty lists for signal and bitrate readings, and record the current datetime as the start time."""
        self.signal_readings = []
        self.bitrate_readings = []
        self.start_time = datetime.now()

    def add_metrics(self, metrics):
        """Append valid signal strength and bitrate values from a Metrics object to respective reading lists, handling potential invalid values with a warning."""
        if metrics.signal_strength is not None:
            self.signal_readings.append(-abs(float(metrics.signal_strength)))
        if metrics.bitrate is not None:
            self.bitrate_readings.append(float(metrics.bitrate))

    def get_session_summary(self):
        """Generate a summary of a session including average signal strength, average bitrate, duration, and the number of samples collected."""
        duration = datetime.now() - self.start_time
        avg_signal = sum(self.signal_readings) / len(self.signal_readings) if self.signal_readings else 0
        avg_bitrate = sum(self.bitrate_readings) / len(self.bitrate_readings) if self.bitrate_readings else 0
        
        return (f"\nSession Summary:\n"
                f"  Duration: {duration}\n"
                f"  Samples: {len(self.signal_readings)}\n"
                f"  Avg Signal: {avg_signal:.2f} dBm\n"
                f"  Avg Bitrate: {avg_bitrate:.2f} Mb/s\n")