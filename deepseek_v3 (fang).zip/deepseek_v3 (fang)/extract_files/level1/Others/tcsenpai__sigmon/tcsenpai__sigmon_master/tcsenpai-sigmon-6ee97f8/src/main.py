#!/usr/bin/env python3
import argparse
import subprocess
import time
from libs.sigmod_metrics import Metrics
from libs.plotter import plot_metrics_live, MetricsPlotter
from libs.session import SessionMetrics

def get_active_interface():
    """Get the active interface name"""
    try:
        output = subprocess.check_output(["iwconfig"], stderr=subprocess.STDOUT, text=True)
        for line in output.split('\n'):
            if 'IEEE 802.11' in line:
                return line.split()[0]
    except subprocess.CalledProcessError as e:
        print(f"Error getting active interface: {e}")
    return None

def get_metrics(adapter_name):
    """Get the metrics of the network adapter
    
    Execute iwconfig command and return the output"""
    try:
        output = subprocess.check_output(["iwconfig", adapter_name], stderr=subprocess.STDOUT, text=True)
        signal_strength = None
        bitrate = None
        power_save = False
        
        for line in output.split('\n'):
            if 'Signal level=' in line:
                signal_strength = float(line.split('Signal level=')[1].split(' ')[0])
            if 'Bit Rate=' in line:
                bitrate = float(line.split('Bit Rate=')[1].split(' ')[0])
            if 'Power Management:' in line and 'on' in line:
                power_save = True
        
        return Metrics(signal_strength, bitrate, power_save)
    except subprocess.CalledProcessError as e:
        print(f"Error getting metrics: {e}")
        return None

def main():
    parser = argparse.ArgumentParser(description='Monitor WiFi signal strength and metrics')
    parser.add_argument('-i', '--interface', help='Network interface to monitor')
    args = parser.parse_args()

    active_interface = args.interface if args.interface else get_active_interface()
    if not active_interface:
        print("No active WiFi interface found")
        return

    try:
        plotter = MetricsPlotter()
        plot_metrics_live(lambda: get_metrics(active_interface), active_interface, 1)
    except KeyboardInterrupt:
        print("\nMonitoring stopped by user")
        plotter.save_plot()
        print(plotter.session.get_session_summary())

if __name__ == "__main__":
    main()