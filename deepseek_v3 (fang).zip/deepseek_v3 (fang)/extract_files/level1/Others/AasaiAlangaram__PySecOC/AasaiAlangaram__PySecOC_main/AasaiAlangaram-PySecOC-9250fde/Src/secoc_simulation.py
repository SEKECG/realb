import logging
import random
import time
from PyQt5.QtWidgets import (QApplication, QMainWindow, QTableWidget, 
                            QTableWidgetItem, QPushButton, QVBoxLayout, 
                            QWidget, QHeaderView)
from PyQt5.QtCore import QThread, pyqtSignal, Qt
from PyQt5.QtGui import QColor

# Constants
SECRET_KEY = b'secret_key_123456'  # 16 bytes key for HMAC

def setup_logging():
    """Logging setup"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler()
        ]
    )

def generate_mac(message, freshness, key):
    """Generate a MAC for a given message and freshness (timestamp)."""
    # Simple MAC generation using XOR (in real implementation, use HMAC)
    combined = f"{message}{freshness}".encode()
    mac = bytearray()
    for i in range(len(combined)):
        mac.append(combined[i] ^ key[i % len(key)])
    return mac.hex()

def verify_mac(message, freshness, received_mac, key):
    """Verify the MAC for a given message and freshness (timestamp)."""
    expected_mac = generate_mac(message, freshness, key)
    return received_mac == expected_mac

class SenderThread(QThread):
    """Simulate an ECU sender thread that periodically generates and sends CAN messages 
    with freshness values and MACs to a CAN bus, while emitting signals for UI updates."""
    
    new_message_signal = pyqtSignal(list, bool, str)
    
    def __init__(self):
        super().__init__()
        self.last_sent_freshness = None
    
    def run(self):
        """Simulate a sender ECU."""
        while True:
            # Simulate message generation
            message_id = random.randint(0, 0x7FF)  # Standard CAN ID range
            data = bytes([random.randint(0, 255) for _ in range(8)])
            dlc = len(data)
            freshness = int(time.time() * 1000)  # Current timestamp in milliseconds
            self.last_sent_freshness = freshness
            
            # Generate MAC
            mac = generate_mac(data.hex(), freshness, SECRET_KEY)
            
            # Prepare message parts
            message_parts = [
                time.strftime("%H:%M:%S"),  # timestamp
                data.hex(),                 # message content
                hex(message_id),            # message ID
                str(dlc),                   # DLC
                str(freshness),             # freshness value
                mac                         # MAC
            ]
            
            # Emit signal for UI update
            self.new_message_signal.emit(message_parts, False, "Sent")
            
            # Sleep for random interval (0.5-2 seconds)
            time.sleep(random.uniform(0.5, 2))

class ReceiverThread(QThread):
    """Simulate a receiver ECU that processes incoming CAN bus messages, detects replay attacks 
    using freshness values, verifies message authenticity via MAC, and emits signals for 
    authenticated or replayed messages."""
    
    new_message_signal = pyqtSignal(list, bool, str)
    
    def __init__(self):
        super().__init__()
        self.replay_attack_triggered = False
    
    def run(self):
        """Simulate a receiver ECU."""
        last_received_freshness = None
        
        while True:
            # Simulate receiving a message (in real implementation, this would come from CAN bus)
            time.sleep(random.uniform(0.5, 2))  # Simulate processing delay
            
            # Check if we should simulate a replay attack
            if self.replay_attack_triggered:
                # Simulate receiving an old message (replay attack)
                if hasattr(SenderThread, 'last_sent_freshness') and SenderThread.last_sent_freshness:
                    freshness = SenderThread.last_sent_freshness - 10000  # Old timestamp
                    message_id = random.randint(0, 0x7FF)
                    data = bytes([random.randint(0, 255) for _ in range(8)])
                    dlc = len(data)
                    mac = generate_mac(data.hex(), freshness, SECRET_KEY)
                    
                    message_parts = [
                        time.strftime("%H:%M:%S"),
                        data.hex(),
                        hex(message_id),
                        str(dlc),
                        str(freshness),
                        mac
                    ]
                    
                    # Verify MAC (should pass, but freshness check will fail)
                    mac_valid = verify_mac(data.hex(), freshness, mac, SECRET_KEY)
                    freshness_valid = (last_received_freshness is None or 
                                     freshness > last_received_freshness)
                    
                    if mac_valid and not freshness_valid:
                        self.new_message_signal.emit(message_parts, True, "Replay Attack")
                    
                    self.replay_attack_triggered = False
                    continue
            
            # Normal message processing
            message_id = random.randint(0, 0x7FF)
            data = bytes([random.randint(0, 255) for _ in range(8)])
            dlc = len(data)
            freshness = int(time.time() * 1000)
            
            # Generate MAC
            mac = generate_mac(data.hex(), freshness, SECRET_KEY)
            
            # Verify MAC and freshness
            mac_valid = verify_mac(data.hex(), freshness, mac, SECRET_KEY)
            freshness_valid = (last_received_freshness is None or 
                             freshness > last_received_freshness)
            
            if mac_valid and freshness_valid:
                last_received_freshness = freshness
                message_type = "Received"
            else:
                message_type = "Invalid"
            
            message_parts = [
                time.strftime("%H:%M:%S"),
                data.hex(),
                hex(message_id),
                str(dlc),
                str(freshness),
                mac
            ]
            
            self.new_message_signal.emit(message_parts, not freshness_valid, message_type)

class MainWindow(QMainWindow):
    """The MainWindow class provides a graphical interface for simulating and monitoring 
    CAN bus messages, including features for starting/stopping the simulation, triggering 
    replay attacks, and displaying message details in a table format."""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("SecOC Simulation")
        self.setGeometry(100, 100, 800, 600)
        
        # UI Components
        self.tableWidget = QTableWidget()
        self.tableWidget.setColumnCount(7)
        self.tableWidget.setHorizontalHeaderLabels([
            "Timestamp", "Message", "ID", "DLC", "Freshness", "MAC", "Type"
        ])
        self.tableWidget.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        
        self.start_stop_button = QPushButton("Start Simulation")
        self.replay_button = QPushButton("Trigger Replay Attack")
        self.clear_button = QPushButton("Clear")
        
        # Layout
        layout = QVBoxLayout()
        layout.addWidget(self.tableWidget)
        layout.addWidget(self.start_stop_button)
        layout.addWidget(self.replay_button)
        layout.addWidget(self.clear_button)
        
        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)
        
        # Threads
        self.sender_thread = SenderThread()
        self.receiver_thread = ReceiverThread()
        
        # Connect signals
        self.sender_thread.new_message_signal.connect(self.update_table)
        self.receiver_thread.new_message_signal.connect(self.update_table)
        self.start_stop_button.clicked.connect(self.toggle_simulation)
        self.replay_button.clicked.connect(self.trigger_replay_attack)
        self.clear_button.clicked.connect(self.clear_simulation)
        
        # State
        self.replay_attack_triggered = False
    
    def toggle_simulation(self):
        """Start or stop the simulation."""
        if self.sender_thread.isRunning():
            self.sender_thread.terminate()
            self.receiver_thread.terminate()
            self.start_stop_button.setText("Start Simulation")
        else:
            self.sender_thread.start()
            self.receiver_thread.start()
            self.start_stop_button.setText("Stop Simulation")
    
    def trigger_replay_attack(self):
        """Trigger the replay attack when the button is clicked."""
        self.receiver_thread.replay_attack_triggered = True
        self.replay_attack_triggered = True
    
    def clear_simulation(self):
        """Clear the simulation window for easier analysis."""
        self.tableWidget.clearContents()
        self.tableWidget.setRowCount(0)
    
    def update_table(self, message_parts, is_replay_attack, message_type):
        """Update a table widget with message details including timestamp, message content, 
        ID, DLC, freshness value, MAC, and message type, highlighting rows in red if a 
        replay attack is detected."""
        row_position = self.tableWidget.rowCount()
        self.tableWidget.insertRow(row_position)
        
        for i, part in enumerate(message_parts):
            item = QTableWidgetItem(part)
            if is_replay_attack:
                item.setBackground(QColor(255, 200, 200))  # Light red for replay attacks
            self.tableWidget.setItem(row_position, i, item)
        
        # Add message type column
        type_item = QTableWidgetItem(message_type)
        if is_replay_attack:
            type_item.setBackground(QColor(255, 200, 200))
        self.tableWidget.setItem(row_position, 6, type_item)
        
        # Auto-scroll to bottom
        self.tableWidget.scrollToBottom()
    
    def closeEvent(self, event):
        """Handle closing of the application."""
        if self.sender_thread.isRunning():
            self.sender_thread.terminate()
        if self.receiver_thread.isRunning():
            self.receiver_thread.terminate()
        event.accept()

# Main application
if __name__ == "__main__":
    setup_logging()
    app = QApplication([])
    window = MainWindow()
    window.show()
    app.exec_()