# PySecOC - Secure On-Board Communication Simulation

This is a Python-based simulation of the Secure On-Board Communication (SecOC) protocol, which is designed to ensure secure communication within an ECU network, such as for automotive applications.

## Features

- Simulates two ECUs (Electronic Control Units) communicating over a simulated CAN bus
- Implements basic security features:
  - Message Authentication Code (MAC) generation and verification
  - Freshness checks to prevent replay attacks
- Graphical interface for monitoring messages
- Ability to trigger replay attacks for testing

## Requirements

- Python 3.6+
- PyQt5

## Installation

1. Clone the repository
2. Install dependencies:
   ```
   pip install PyQt5
   ```

## Usage

Run the simulation:
```
python secoc_simulation.py
```

The GUI allows you to:
- Start/stop the simulation
- Trigger replay attacks
- Clear the message display
- View message details including MAC and freshness values

## Implementation Details

- MAC generation uses a simple XOR-based approach (in a real implementation, use HMAC)
- Freshness values are based on timestamps
- Replay attacks are detected by checking freshness values