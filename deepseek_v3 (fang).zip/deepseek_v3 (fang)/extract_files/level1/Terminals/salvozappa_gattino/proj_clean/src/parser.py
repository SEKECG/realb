def extract_first_code_block(text):
    """
    Extract the first code block enclosed in triple backticks (```) from a given text string,
    removing any 'bash' specifier if present, and return the content of the code block as a
    stripped string. If no code block is found, return an empty string.
    """
    start = text.find('```')
    if start == -1:
        return ""
    
    end = text.find('```', start + 3)
    if end == -1:
        return ""
    
    code_block = text[start+3:end].strip()
    if code_block.startswith('bash'):
        code_block = code_block[4:].strip()
    
    return code_block