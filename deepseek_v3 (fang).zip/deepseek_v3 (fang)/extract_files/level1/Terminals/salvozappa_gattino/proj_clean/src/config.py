import json
import os
from pathlib import Path

def load_config():
    """
    Load and parse a JSON configuration file located at '~/.config/kitty/gattino/gattino.config.json',
    returning its contents as a dictionary. If the file is not found or contains invalid JSON,
    return an empty dictionary and print an appropriate error message.
    """
    config_path = Path.home() / ".config" / "kitty" / "gattino" / "gattino.config.json"
    try:
        with open(config_path, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"Config file not found at {config_path}")
        return {}
    except json.JSONDecodeError:
        print(f"Invalid JSON in config file at {config_path}")
        return {}