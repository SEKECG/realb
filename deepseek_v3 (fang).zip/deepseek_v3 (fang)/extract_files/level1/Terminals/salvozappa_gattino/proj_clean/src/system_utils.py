import subprocess
from threading import Thread
from time import sleep
from typing import Optional
from .ui import show_spinner

def run_command(command, input=None):
    """
    Execute a shell command with optional input, display a spinner during execution,
    and return the command's output while handling errors.
    """
    try:
        process = subprocess.Popen(
            command,
            shell=True,
            stdin=subprocess.PIPE if input else None,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        
        if input:
            process.stdin.write(input)
            process.stdin.close()
        
        show_spinner(process)
        
        stdout, stderr = process.communicate()
        
        if process.returncode != 0:
            return stderr.strip()
        return stdout.strip()
    except Exception as e:
        return str(e)

def write_file(path, content):
    """
    Write content to a file at the specified path.
    """
    with open(path, 'w') as f:
        f.write(content)