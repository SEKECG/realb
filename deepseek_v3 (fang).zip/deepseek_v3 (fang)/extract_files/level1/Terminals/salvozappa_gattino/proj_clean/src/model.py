def get_prompt(human_language_command):
    """
    Generate a prompt for converting human language to bash command.
    """
    return f"""
    Convert the following human language instruction into a single-line bash command:

    {human_language_command}

    Requirements:
    - The command should accomplish exactly what the instruction specifies
    - Respond with ONLY the bash command enclosed in triple backticks (```)
    - Do not include any additional explanation or text
    - The command should be a single line

    Example response format:
    ```bash
    your_command_here
    ```
    """