import sys
import time
from threading import Thread
from typing import Optional

class Spinner:
    """
    Provide a visual spinner animation in the terminal to indicate ongoing background processes,
    particularly while waiting for a subprocess to complete.
    """
    def __init__(self):
        self.frames = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏']
        self.index = 0

    def next_frame(self):
        """Retrieve the next frame in the sequence."""
        frame = self.frames[self.index]
        self.index = (self.index + 1) % len(self.frames)
        return frame

    def show(self, process):
        """
        Display an animated sequence in the terminal while a subprocess is running,
        updating the animation frame at regular intervals until the process completes.
        """
        while process.poll() is None:
            sys.stdout.write(f"\r{self.next_frame()} Processing... ")
            sys.stdout.flush()
            time.sleep(0.1)
        sys.stdout.write("\r" + " " * 20 + "\r")
        sys.stdout.flush()

def show_spinner(process):
    """Display a spinner while the process is running."""
    spinner = Spinner()
    spinner.show(process)

def print_input_line():
    """Prompt the user for input and return the entered text."""
    return input("\nWhat would you like me to do? > ")

def print_intro():
    """Print introductory ASCII art."""
    print(r"""
 /\_/\  
( o.o ) 
 > ^ <  
    """)
    print("""
   _____       _ _   _             
  / ____|     (_) | (_)            
 | |  __ __ _ _| |_ _ _ __   __ _ 
 | | |_ |/ _` | | __| | '_ \ / _` |
 | |__| | (_| | | |_| | | | | (_| |
  \_____|\__,_|_|\__|_|_| |_|\__, |
                              __/ |
                             |___/ 
    """)