import time
import threading
from collections import defaultdict
import psutil
from scapy.all import *
import pandas as pd
from plotille import Figure

# Global variables
connection2pid = {}
pid2traffic = defaultdict(lambda: [0, 0])  # upload, download
all_macs = {iface.mac for iface in ifaces.values()}
is_program_running = True
global_df = None
global_graph_data = []
printing_thread = None
connections_thread = None

def get_size(bytes):
    """
    Returns size of bytes in a nice format
    """
    for unit in ['', 'K', 'M', 'G', 'T', 'P']:
        if bytes < 1024:
            return f"{bytes:.2f}{unit}B"
        bytes /= 1024

def get_connections():
    """A function that keeps listening for connections on this machine
    and adds them to `connection2pid` global variable"""
    global connection2pid
    while is_program_running:
        # using psutil, we can grab each connection's source and destination ports
        # and their process ID
        for c in psutil.net_connections(kind='inet'):
            if c.laddr and c.raddr and c.pid:
                # if local address, remote address and PID are in the connection
                # construct the key and value for the connection2pid dictionary
                connection2pid[(c.laddr.ip, c.laddr.port, c.raddr.ip, c.raddr.port)] = c.pid
                connection2pid[(c.raddr.ip, c.raddr.port, c.laddr.ip, c.laddr.port)] = c.pid
        # sleep for a second before the next scan
        time.sleep(1)

def process_packet(packet):
    """Track and accumulate network traffic (upload and download) per process ID (PID) 
    based on packet source and destination information."""
    global pid2traffic
    try:
        # get the packet source & destination IP addresses and ports
        packet_connection = (packet.sprintf("{IP:%IP.src%}"), 
                            packet.sprintf("{TCP:%TCP.sport%}"), 
                            packet.sprintf("{IP:%IP.dst%}"), 
                            packet.sprintf("{TCP:%TCP.dport%}"))
    except:
        # if the packet doesn't have TCP or IP layers, skip it
        return
    
    # get the PID responsible for this connection from our `connection2pid` global dictionary
    pid = connection2pid.get(packet_connection)
    if not pid:
        return
    
    # get packet size in bytes
    packet_size = len(packet)
    
    # determine whether the packet is incoming or outgoing
    if packet.src in all_macs:
        # outgoing packet (upload)
        pid2traffic[pid][0] += packet_size
    else:
        # incoming packet (download)
        pid2traffic[pid][1] += packet_size

def print_stats():
    """Simple function that keeps printing the stats"""
    global global_df, global_graph_data
    while is_program_running:
        # sleep for some time before printing again
        time.sleep(1)
        # initialize a list to store the traffic data
        processes = []
        for pid, traffic in pid2traffic.items():
            # `pid` is an integer that represents the process ID
            # `traffic` is a list of two values: total Upload and Download size in bytes
            try:
                # get the process object from psutil
                p = psutil.Process(pid)
                name = p.name()
                create_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(p.create_time()))
            except:
                # if process not found, skip it
                continue
            # calculate upload and download speeds
            upload = traffic[0]
            download = traffic[1]
            # append to the list
            processes.append({
                "pid": pid,
                "name": name,
                "create_time": create_time,
                "upload": upload,
                "download": download,
                "upload_speed": get_size(upload),
                "download_speed": get_size(download),
            })
        
        # construct a pandas DataFrame
        df = pd.DataFrame(processes)
        # set the PID as the index of the dataframe
        df.set_index("pid", inplace=True)
        # sort by total traffic (upload + download)
        df.sort_values(by=["upload", "download"], ascending=False, inplace=True)
        # update the global dataframe
        global_df = df
        # update the global graph data
        if len(processes) > 0:
            global_graph_data.append({
                "time": time.time(),
                "upload": df["upload"].sum() / 1024,  # convert to KB
                "download": df["download"].sum() / 1024,
            })
            # keep only the last 60 seconds of data
            global_graph_data = [x for x in global_graph_data if time.time() - x["time"] <= 60]

def stat(df):
    """Display the first few lines of a pandas DataFrame with specific lines highlighted in different colors for enhanced visibility."""
    print(df.head())

def plot(df):
    """Visualize time-series data of network bandwidth usage (in Kb/s) over a 60-second period for multiple series, using a terminal-based plot with distinct colors for each series."""
    if len(global_graph_data) == 0:
        return
    fig = Figure()
    fig.width = 60
    fig.height = 20
    fig.color_mode = 'byte'
    fig.y_label = 'KB/s'
    fig.x_label = 'Time (s)'
    # get the upload and download data
    times = [x["time"] for x in global_graph_data]
    uploads = [x["upload"] for x in global_graph_data]
    downloads = [x["download"] for x in global_graph_data]
    # plot the data
    fig.plot(times, uploads, label="Upload")
    fig.plot(times, downloads, label="Download")
    print(fig.show(legend=True))

def print_pid2traffic():
    """Monitor and display network traffic statistics (upload/download speeds and totals) per process ID (PID), including real-time speed calculations and visualization of top processes."""
    global printing_thread, connections_thread
    # start the connections thread
    connections_thread = threading.Thread(target=get_connections)
    connections_thread.daemon = True
    connections_thread.start()
    # start the printing thread
    printing_thread = threading.Thread(target=print_stats)
    printing_thread.daemon = True
    printing_thread.start()
    # start sniffing packets
    sniff(prn=process_packet, store=False)
    # set the global variable to False to stop the threads
    is_program_running = False
    # wait for the threads to finish
    connections_thread.join()
    printing_thread.join()

if __name__ == "__main__":
    print_pid2traffic()