import argparse
import logging
from pathlib import Path
from typing import Set, Union

DEFAULT_IGNORE_DIRS = {'node_modules', '__pycache__', '.git', '.vscode', '.idea'}

def is_ignored(path: Union[str, Path], ignore_dirs: Set[str]) -> bool:
    """Check if the path is inside any ignored directory."""
    path_str = str(path)
    return any(f'/{ignore_dir}/' in path_str or path_str.endswith(f'/{ignore_dir}')
               for ignore_dir in ignore_dirs)

def read_file_safely(file_path: Union[str, Path], max_size_mb: int) -> str:
    """Read file contents safely, checking file size and encoding."""
    file_path = Path(file_path)
    if not file_path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")
    
    file_size_mb = file_path.stat().st_size / (1024 * 1024)
    if file_size_mb > max_size_mb:
        raise ValueError(f"File {file_path} exceeds maximum size of {max_size_mb}MB")
    
    try:
        return file_path.read_text(encoding='utf-8')
    except UnicodeDecodeError:
        logging.warning(f"Could not decode {file_path} as UTF-8, trying latin-1")
        return file_path.read_text(encoding='latin-1')

def directory_to_markdown(
    directory_path: Union[str, Path],
    output_file: Union[str, Path],
    file_types: Set[str],
    ignore_dirs: Set[str] = DEFAULT_IGNORE_DIRS,
    recursive: bool = True,
    max_file_size_mb: int = 5
) -> None:
    """
    Traverse directory, read selected files, and write their contents into a markdown file.

    Args:
        directory_path: Directory to traverse.
        output_file: Markdown file to generate.
        file_types: File extensions to include (e.g., {'.py', '.txt'}).
        ignore_dirs: Directory names to ignore.
        recursive: Whether to traverse subdirectories.
        max_file_size_mb: Maximum file size to process in megabytes.
    """
    directory_path = Path(directory_path)
    output_file = Path(output_file)
    
    if not directory_path.exists():
        raise FileNotFoundError(f"Directory not found: {directory_path}")
    
    if not directory_path.is_dir():
        raise NotADirectoryError(f"Path is not a directory: {directory_path}")
    
    with output_file.open('w', encoding='utf-8') as md_file:
        pattern = '**/*' if recursive else '*'
        for file_path in directory_path.glob(pattern):
            if not file_path.is_file():
                continue
                
            if is_ignored(file_path, ignore_dirs):
                logging.debug(f"Ignoring {file_path} (in ignored directory)")
                continue
                
            if file_path.suffix.lower() not in file_types:
                continue
                
            try:
                content = read_file_safely(file_path, max_file_size_mb)
                relative_path = file_path.relative_to(directory_path)
                md_file.write(f"\n## {relative_path}\n\n```{file_path.suffix[1:]}\n")
                md_file.write(content)
                md_file.write("\n```\n")
                logging.info(f"Processed {file_path}")
            except Exception as e:
                logging.error(f"Failed to process {file_path}: {str(e)}")

def main():
    parser = argparse.ArgumentParser(
        description='Convert directory contents to a markdown file.'
    )
    parser.add_argument(
        'directory',
        type=str,
        help='Directory to scan'
    )
    parser.add_argument(
        'output',
        type=str,
        help='Output markdown file'
    )
    parser.add_argument(
        '--extensions',
        nargs='+',
        default=['.py', '.txt', '.md'],
        help='File extensions to include'
    )
    parser.add_argument(
        '--ignore-dirs',
        nargs='+',
        default=DEFAULT_IGNORE_DIRS,
        help='Directories to ignore'
    )
    parser.add_argument(
        '--no-recursive',
        action='store_false',
        dest='recursive',
        help='Disable recursive directory scanning'
    )
    parser.add_argument(
        '--max-size',
        type=int,
        default=5,
        help='Maximum file size to process in MB'
    )
    parser.add_argument(
        '-v', '--verbose',
        action='store_true',
        help='Enable verbose logging'
    )
    
    args = parser.parse_args()
    
    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format='%(levelname)s: %(message)s'
    )
    
    directory_to_markdown(
        directory_path=args.directory,
        output_file=args.output,
        file_types=set(args.extensions),
        ignore_dirs=set(args.ignore_dirs),
        recursive=args.recursive,
        max_file_size_mb=args.max_size
    )

if __name__ == '__main__':
    main()