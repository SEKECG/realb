import csv
import time
from datetime import datetime
import speedtest
from colorama import Fore, Style

def run_speed_test(high, low, serial_number, record_file):
    """
    Measure and record internet speed metrics (download, upload, ping) with status evaluation
    based on predefined thresholds, and save the results to a CSV file.
    """
    st = speedtest.Speedtest()
    
    # Perform speed test
    st.download()
    st.upload()
    ping = st.results.ping
    download_speed = st.results.download / 1_000_000  # Convert to Mbps
    upload_speed = st.results.upload / 1_000_000  # Convert to Mbps
    
    # Determine status
    if download_speed >= high:
        status = "great"
        status_color = Fore.GREEN
    elif download_speed >= low:
        status = "okay"
        status_color = Fore.YELLOW
    else:
        status = "bad"
        status_color = Fore.RED
    
    # Get current timestamp
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # Prepare data for CSV
    data = [
        serial_number,
        timestamp,
        f"{download_speed:.2f}",
        f"{upload_speed:.2f}",
        f"{ping:.2f}",
        status
    ]
    
    # Write to CSV file
    with open(record_file, 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(data)
    
    # Print colored results to terminal
    print(f"{Fore.CYAN}Test #{serial_number} - {timestamp}{Style.RESET_ALL}")
    print(f"Download: {download_speed:.2f} Mbps")
    print(f"Upload: {upload_speed:.2f} Mbps")
    print(f"Ping: {ping:.2f} ms")
    print(f"Status: {status_color}{status}{Style.RESET_ALL}")
    print("-" * 40)

def main():
    """
    Run periodic internet speed tests, compare results against user-defined thresholds,
    and record the data in a CSV file.
    """
    print(f"{Fore.BLUE}SpeedTester - Internet Speed Monitoring Tool{Style.RESET_ALL}")
    print("Press Ctrl+C to stop the monitoring...\n")
    
    # Configuration
    high_threshold = 50  # Mbps - considered "great" speed
    low_threshold = 10   # Mbps - minimum for "okay" speed
    record_file = "speed_records.csv"
    test_interval = 300  # 5 minutes in seconds
    serial_number = 1
    
    # Create CSV file with headers if it doesn't exist
    try:
        with open(record_file, 'x', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(["Test #", "Timestamp", "Download (Mbps)", "Upload (Mbps)", "Ping (ms)", "Status"])
    except FileExistsError:
        pass
    
    # Main loop
    try:
        while True:
            run_speed_test(high_threshold, low_threshold, serial_number, record_file)
            serial_number += 1
            time.sleep(test_interval)
    except KeyboardInterrupt:
        print(f"\n{Fore.BLUE}Monitoring stopped. Results saved to {record_file}{Style.RESET_ALL}")

if __name__ == "__main__":
    main()