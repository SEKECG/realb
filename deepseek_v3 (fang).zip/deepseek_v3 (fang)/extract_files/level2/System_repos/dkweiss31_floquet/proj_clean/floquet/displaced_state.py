import numpy as np
import qutip as qt
from scipy.optimize import curve_fit

class DisplacedState:
    def __init__(self, hilbert_dim, model, state_indices, options):
        self.hilbert_dim = hilbert_dim
        self.model = model
        self.state_indices = state_indices
        self.options = options
        self.exponent_pair_idx_map = self._create_exponent_pair_idx_map()

    def _create_exponent_pair_idx_map(self):
        exponent_pairs = []
        for i in range(self.options.fit_cutoff + 1):
            for j in range(self.options.fit_cutoff + 1):
                if i + j <= self.options.fit_cutoff and (i, j) != (0, 0):
                    exponent_pairs.append((i, j))
        return {pair: idx for idx, pair in enumerate(exponent_pairs)}

    def _coefficient_for_state(self, xydata, state_idx_coefficients, bare_same):
        omega_d, amp = xydata
        coeff = 0.0
        for (i, j), idx in self.exponent_pair_idx_map.items():
            coeff += state_idx_coefficients[idx] * (omega_d**i) * (amp**j)
        return coeff + bare_same

    def _fit_coefficients_factory(self, XYdata, Zdata, p0, bare_same):
        try:
            popt, _ = curve_fit(
                lambda xydata, *coeffs: self._coefficient_for_state(
                    xydata, coeffs, bare_same
                ),
                XYdata,
                Zdata,
                p0=p0,
            )
            return popt
        except RuntimeError:
            return np.zeros(len(p0))

    def _fit_coefficients_for_component(self, omega_d_amp_filtered, floquet_component_filtered, bare_same):
        XYdata = np.array(omega_d_amp_filtered).T
        Zdata = floquet_component_filtered
        p0 = np.zeros(len(self.exponent_pair_idx_map))
        return self._fit_coefficients_factory(XYdata, Zdata, p0, bare_same)

    def bare_state_coefficients(self, state_idx):
        coeffs = np.zeros(len(self.exponent_pair_idx_map) + 1)
        coeffs[-1] = 1.0 if state_idx == 0 else 0.0
        return coeffs

    def displaced_state(self, omega_d, amp, state_idx, coefficients):
        state = qt.Qobj(np.zeros(self.hilbert_dim))
        bare_same = coefficients[-1]
        
        for basis_idx in range(self.hilbert_dim):
            coeff = bare_same if basis_idx == state_idx else 0.0
            for (i, j), idx in self.exponent_pair_idx_map.items():
                coeff += coefficients[idx] * (omega_d**i) * (amp**j)
            state.data[basis_idx, 0] = coeff
            
        return state.unit()

    def displaced_states_fit(self, omega_d_amp_slice, ovlp_with_bare_states, floquet_modes):
        num_states = len(self.state_indices)
        num_coeffs = len(self.exponent_pair_idx_map) + 1
        coefficients = np.zeros((num_states, num_coeffs))
        
        for state_idx in range(num_states):
            mask = ovlp_with_bare_states[:, :, state_idx] > self.options.overlap_cutoff
            omega_d_amp_filtered = []
            floquet_component_filtered = []
            
            for i, (omega_d, amp) in enumerate(omega_d_amp_slice):
                if mask.flat[i]:
                    omega_d_amp_filtered.append((omega_d, amp))
                    floquet_component_filtered.append(floquet_modes.flat[i][state_idx])
            
            if len(omega_d_amp_filtered) > 0:
                bare_same = 1.0 if state_idx == 0 else 0.0
                coeffs = self._fit_coefficients_for_component(
                    omega_d_amp_filtered, floquet_component_filtered, bare_same
                )
                coefficients[state_idx, :-1] = coeffs
                coefficients[state_idx, -1] = bare_same
                
        return coefficients

    def overlap_with_bare_states(self, amp_idx_0, coefficients, floquet_modes):
        num_omega_d = len(self.model.omega_d_values)
        num_amp = len(self.model.drive_amplitudes)
        num_states = len(self.state_indices)
        overlaps = np.zeros((num_omega_d, num_amp, num_states))
        
        for w in range(num_omega_d):
            omega_d = self.model.omega_d_values[w]
            for a in range(amp_idx_0, num_amp):
                amp = self.model.drive_amplitudes[a]
                for s, state_idx in enumerate(self.state_indices):
                    state = self.displaced_state(omega_d, amp, state_idx, coefficients[s])
                    overlaps[w, a, s] = abs((state.dag() * floquet_modes[w, a, s]).data[0, 0])
                    
        return overlaps

    def overlap_with_displaced_states(self, amp_idxs, coefficients, floquet_modes):
        num_omega_d = len(self.model.omega_d_values)
        num_amp = amp_idxs[1] - amp_idxs[0]
        num_states = len(self.state_indices)
        overlaps = np.zeros((num_omega_d, num_amp, num_states))
        
        for w in range(num_omega_d):
            omega_d = self.model.omega_d_values[w]
            for a in range(amp_idxs[0], amp_idxs[1]):
                amp = self.model.drive_amplitudes[a]
                for s, state_idx in enumerate(self.state_indices):
                    state = self.displaced_state(omega_d, amp, state_idx, coefficients[s])
                    overlaps[w, a - amp_idxs[0], s] = abs((state.dag() * floquet_modes[w, a, s]).data[0, 0])
                    
        return overlaps