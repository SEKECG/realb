import numpy as np
from scipy.linalg import eigvalsh

class ChiacToAmp:
    def __init__(self, H0, H1, state_indices, omega_d_values):
        self.H0 = H0
        self.H1 = H1
        self.state_indices = state_indices
        self.omega_d_linspace = omega_d_values

    @staticmethod
    def chi_ell_ellp(energies, H1, E_osc, ell, ellp):
        return np.abs(H1[ell, ellp])**2 / (E_osc - (energies[ellp] - energies[ell]))

    def chi_ell(self, energies, H1, E_osc, ell):
        chi = 0.0
        for ellp in range(len(energies)):
            if ellp != ell:
                chi += self.chi_ell_ellp(energies, H1, E_osc, ell, ellp)
                chi -= self.chi_ell_ellp(energies, H1, E_osc, ellp, ell)
        return chi

    def compute_chis_for_omega_d(self):
        energies = eigvalsh(self.H0)
        chi_diffs = np.zeros_like(self.omega_d_linspace)
        
        for i, omega_d in enumerate(self.omega_d_linspace):
            chi0 = self.chi_ell(energies, self.H1, omega_d, self.state_indices[0])
            chi1 = self.chi_ell(energies, self.H1, omega_d, self.state_indices[1])
            chi_diffs[i] = chi1 - chi0
            
        return chi_diffs

    def amplitudes_for_omega_d(self, chi_ac_linspace):
        chi_diffs = self.compute_chis_for_omega_d()
        amplitudes = np.zeros((len(self.omega_d_linspace), len(chi_ac_linspace)))
        
        for i, omega_d in enumerate(self.omega_d_linspace):
            amplitudes[i] = 2 * np.sqrt(chi_ac_linspace / chi_diffs[i])
            
        return amplitudes

class XiSqToAmp:
    def __init__(self, H0, H1, state_indices, omega_d_linspace):
        self.H0 = H0
        self.H1 = H1
        self.state_indices = state_indices
        self.omega_d_linspace = omega_d_linspace

    def amplitudes_for_omega_d(self, xi_sq_linspace):
        energies = eigvalsh(self.H0)
        alpha = energies[2] - 2 * energies[1] + energies[0]
        amplitudes = np.zeros((len(self.omega_d_linspace), len(xi_sq_linspace)))
        
        for i, omega_d in enumerate(self.omega_d_linspace):
            omega = energies[self.state_indices[1]] - energies[self.state_indices[0]]
            denom = omega_d**2 - omega**2
            amplitudes[i] = np.sqrt(xi_sq_linspace * alpha * denom**2 / (2 * omega_d**2))
            
        return amplitudes