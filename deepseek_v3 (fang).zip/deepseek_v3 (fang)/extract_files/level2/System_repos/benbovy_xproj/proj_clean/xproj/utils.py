from typing import Any, Dict, Hashable, Iterator, Mapping, TypeVar

K = TypeVar('K', bound=Hashable)
V = TypeVar('V')


class Frozen(Mapping[K, V]):
    """Wrapper around an object implementing the mapping interface to make it immutable."""

    __slots__ = ('mapping',)

    def __init__(self, mapping):
        self.mapping = dict(mapping)

    def __contains__(self, key):
        return key in self.mapping

    def __getitem__(self, key):
        return self.mapping[key]

    def __iter__(self):
        return iter(self.mapping)

    def __len__(self):
        return len(self.mapping)

    def __repr__(self):
        return f"{type(self).__name__}({self.mapping!r})"


def FrozenDict(*args, **kwargs):
    """Create an immutable dictionary-like object."""
    return Frozen(dict(*args, **kwargs))