import pyproj
import xarray as xr

T_Xarray_Object = TypeVar('T_Xarray_Object', xr.Dataset, xr.DataArray)


class ProjAccessorMixin:
    """Mixin class that marks XProj support for an Xarray accessor."""

    def _proj_set_crs(self, spatial_ref, crs):
        """Method called when setting a new CRS."""
        raise NotImplementedError


class ProjIndexMixin:
    """Mixin class that marks XProj support for an Xarray index."""

    def _proj_get_crs(self):
        """XProj access to the CRS of the index."""
        raise NotImplementedError

    def _proj_set_crs(self, spatial_ref, crs):
        """Method called when mapping a CRS to index coordinate(s)."""
        raise NotImplementedError

    def _proj_to_crs(self, spatial_ref, crs):
        """Method called when mapping a CRS with coordinate transformation."""
        raise NotImplementedError