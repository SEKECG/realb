import pyproj
import xarray as xr

from .mixins import ProjIndexMixin


def _format_crs(crs, max_width):
    """Format a Coordinate Reference System (CRS) string."""
    crs_str = str(crs)
    if len(crs_str) > max_width:
        crs_str = crs_str[:max_width - 3] + '...'
    return crs_str


class CRSIndex(ProjIndexMixin, xr.indexes.Index):
    """A basic xarray.Index that has a pyproj.crs.CRS attached."""

    def __init__(self, crs):
        self._crs = pyproj.CRS.from_user_input(crs)

    def __repr__(self):
        return f"{type(self).__name__}\n{self._crs}"

    def _repr_inline_(self, max_width):
        return f"{type(self).__name__}({_format_crs(self._crs, max_width - 20)})"

    @property
    def crs(self):
        """Returns the pyproj.crs.CRS object attached to this index."""
        return self._crs

    def equals(self, other):
        """Check if the current CRSIndex object is equal to another."""
        if not isinstance(other, CRSIndex):
            return False
        return self._crs == other._crs

    @classmethod
    def from_variables(cls, variables, options=None):
        """Create a CRSIndex object from a single scalar variable's attributes."""
        if len(variables) != 1:
            raise ValueError("CRSIndex can only be created from a single variable")
        
        var = next(iter(variables.values()))
        if var.dims != (var.name,):
            raise ValueError("CRSIndex can only be created for scalar coordinates")
        
        if options is None:
            if 'crs_wkt' in var.attrs:
                crs = var.attrs['crs_wkt']
            else:
                raise ValueError("No CRS information found in variable attributes")
        else:
            crs = options
        
        return cls(crs)