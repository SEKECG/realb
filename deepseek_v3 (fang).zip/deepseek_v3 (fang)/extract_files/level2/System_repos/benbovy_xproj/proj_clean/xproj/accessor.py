import functools
import warnings
from typing import Any, Hashable, Mapping, TypeVar

import pyproj
import xarray as xr

from .index import CRSIndex
from .mixins import ProjIndexMixin
from .utils import Frozen, FrozenDict

T_AccessorClass = TypeVar('T_AccessorClass')


def register_accessor(accessor_cls):
    """Decorator for registering a geospatial, CRS-dependent Xarray
    (Dataset and/or DataArray) accessor."""
    GeoAccessorRegistry.register_accessor(accessor_cls)
    return accessor_cls


def either_dict_or_kwargs(positional, keyword, func_name):
    """Resolve combination of positional and keyword arguments."""
    if positional is None:
        return keyword
    if not keyword:
        return positional
    raise ValueError(
        f"Cannot specify both '{func_name}' dictionary and keyword arguments"
    )


def is_crs_aware(index):
    """Determine whether a given xarray Index is CRS-aware."""
    return isinstance(index, ProjIndexMixin) or hasattr(index, '_proj_get_crs')


class ProjAccessor:
    """Xarray `.proj` extension entry-point."""

    def __init__(self, obj):
        self._obj = obj
        self._crs_indexes = None
        self._crs_aware_indexes = None

    def __call__(self, coord_name):
        """Select a given CRS by coordinate name."""
        if coord_name in self.crs_indexes:
            crs = self.crs_indexes[coord_name].crs
        elif coord_name in self.crs_aware_indexes:
            crs = self.crs_aware_indexes[coord_name]._proj_get_crs()
        else:
            raise ValueError(f"No CRS found for coordinate '{coord_name}'")
        return CRSProxy(self._obj, coord_name, crs)

    def _cache_all_crs_indexes(self):
        """Cache all CRSIndex objects and CRS-aware Index objects."""
        self._crs_indexes = {}
        self._crs_aware_indexes = {}
        
        for name, index in self._obj.xindexes.items():
            if isinstance(index, CRSIndex):
                self._crs_indexes[name] = index
            elif is_crs_aware(index):
                self._crs_aware_indexes[name] = index

    def _get_crs_index(self, coord_name):
        """Retrieve the CRSIndex associated with a specified coordinate name."""
        if coord_name not in self._obj.coords:
            raise ValueError(f"Coordinate '{coord_name}' not found")
        if coord_name not in self.crs_indexes:
            raise ValueError(
                f"Coordinate '{coord_name}' has no CRSIndex attached"
            )
        return self.crs_indexes[coord_name]

    def _update_crs_info(self, spatial_ref, func):
        """Update the CRS information in an xarray object."""
        if spatial_ref is None:
            spatial_refs = list(self.crs_indexes.keys())
        else:
            spatial_refs = [spatial_ref]

        result = self._obj.copy()
        for ref in spatial_refs:
            crs_index = self._get_crs_index(ref)
            attrs = func(crs_index.crs)
            result.coords[ref].attrs.update(attrs)
        
        return result

    def assert_one_crs_index(self):
        """Raise an AssertionError if no or multiple CRS-indexed coordinates."""
        if not self.crs_indexes:
            raise AssertionError("No CRS-indexed coordinate found")
        if len(self.crs_indexes) > 1:
            raise AssertionError("Multiple CRS-indexed coordinates found")

    def assign_crs(self, spatial_ref_crs=None, allow_override=False, **spatial_ref_crs_kwargs):
        """Assign one or more spatial reference coordinate variables."""
        spatial_ref_crs = either_dict_or_kwargs(
            spatial_ref_crs, spatial_ref_crs_kwargs, 'assign_crs'
        )
        
        result = self._obj.copy()
        for coord_name, crs in spatial_ref_crs.items():
            if coord_name in result.xindexes and not allow_override:
                raise ValueError(
                    f"Coordinate '{coord_name}' already has an index. "
                    "Set allow_override=True to replace it."
                )
            crs = pyproj.CRS.from_user_input(crs)
            result = result.set_xindex(coord_name, CRSIndex(crs))
        
        return result

    def clear_crs_info(self, spatial_ref=None):
        """Clear all attributes of one or all spatial reference coordinates."""
        def clear_func(_):
            return {}
        return self._update_crs_info(spatial_ref, clear_func)

    @property
    def crs(self):
        """Return the coordinate reference system as a pyproj.CRS object."""
        self.assert_one_crs_index()
        return next(iter(self.crs_indexes.values())).crs

    @property
    def crs_aware_indexes(self):
        """Return an immutable dictionary of CRS-aware Index objects."""
        if self._crs_aware_indexes is None:
            self._cache_all_crs_indexes()
        return Frozen(self._crs_aware_indexes)

    @property
    def crs_indexes(self):
        """Return an immutable dictionary of CRSIndex objects."""
        if self._crs_indexes is None:
            self._cache_all_crs_indexes()
        return Frozen(self._crs_indexes)

    def map_crs(self, spatial_ref_coords=None, allow_override=False, transform=False, **spatial_ref_coords_kwargs):
        """Map spatial reference coordinate(s) to other indexed coordinates."""
        spatial_ref_coords = either_dict_or_kwargs(
            spatial_ref_coords, spatial_ref_coords_kwargs, 'map_crs'
        )
        
        result = self._obj.copy()
        for spatial_ref, coord_name in spatial_ref_coords.items():
            if coord_name not in self.crs_aware_indexes:
                raise ValueError(
                    f"Coordinate '{coord_name}' has no CRS-aware index"
                )
            crs = self._get_crs_index(spatial_ref).crs
            index = self.crs_aware_indexes[coord_name]
            
            if not allow_override and index._proj_get_crs() is not None:
                raise ValueError(
                    f"Coordinate '{coord_name}' already has a CRS. "
                    "Set allow_override=True to replace it."
                )
            
            if transform:
                new_index = index._proj_to_crs(spatial_ref, crs)
            else:
                new_index = index._proj_set_crs(spatial_ref, crs)
            
            result = result.set_xindex(coord_name, new_index)
        
        return result

    def write_crs_info(self, spatial_ref=None, func=format_compact_cf):
        """Write CRS information as attributes to one or all spatial reference coordinates."""
        return self._update_crs_info(spatial_ref, func)


class CRSProxy:
    """A proxy for a CRS(-aware) indexed coordinate."""

    def __init__(self, obj, coord_name, crs):
        self._obj = obj
        self._coord_name = coord_name
        self._crs = crs

    @property
    def crs(self):
        """Return the coordinate reference system as a pyproj.CRS object."""
        return self._crs


class GeoAccessorRegistry:
    """A registry of 3rd-party geospatial Xarray accessors."""

    _accessor_names = {
        xr.Dataset: set(),
        xr.DataArray: set(),
    }

    @classmethod
    def get_accessors(cls, xr_obj):
        """Retrieve a list of valid accessor objects."""
        accessors = []
        for accessor_name in cls._accessor_names[type(xr_obj)]:
            if hasattr(xr_obj, accessor_name):
                accessor = getattr(xr_obj, accessor_name)
                if not isinstance(accessor, xr.DataArray):
                    accessors.append(accessor)
        return accessors

    @classmethod
    def register_accessor(cls, accessor_cls):
        """Register an Xarray Dataset or DataArray accessor class."""
        for xr_class in (xr.Dataset, xr.DataArray):
            if hasattr(xr_class, accessor_cls.__name__):
                cls._accessor_names[xr_class].add(accessor_cls.__name__)