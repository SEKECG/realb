import pyproj


def format_compact_cf(crs):
    """Format CRS as a dictionary for minimal compatibility with CF conventions."""
    return {
        'crs_wkt': crs.to_wkt()
    }


def format_full_cf_gdal(crs):
    """Format CRS as a dictionary for full compatibility with CF conventions and GDAL."""
    attrs = crs.to_cf()
    attrs.update({
        'crs_wkt': crs.to_wkt(),
        'spatial_ref': crs.to_wkt()
    })
    return attrs