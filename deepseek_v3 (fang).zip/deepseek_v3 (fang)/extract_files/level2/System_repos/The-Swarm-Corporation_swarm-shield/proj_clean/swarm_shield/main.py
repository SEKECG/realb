import os
import json
import time
import threading
import hashlib
import hmac
import base64
from datetime import datetime
from typing import Dict, List, Tuple, Union
from enum import Enum
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import padding

class EncryptionStrength(Enum):
    STANDARD = 1
    ENHANCED = 2
    MAXIMUM = 3

class SwarmShield:
    def __init__(self, encryption_strength, key_rotation_interval, storage_path):
        self.encryption_strength = encryption_strength
        self.key_rotation_interval = key_rotation_interval
        self.storage_path = storage_path
        self._conv_lock = threading.Lock()
        self._conversations = {}
        
        os.makedirs(storage_path, exist_ok=True)
        self.key_file = os.path.join(storage_path, "keys.bin")
        
        self._initialize_security()
        self._load_conversations()
    
    def _initialize_security(self):
        if os.path.exists(self.key_file):
            with open(self.key_file, 'rb') as f:
                data = f.read()
                self.master_key = data[:32]
                self.salt = data[32:64]
                self.hmac_key = data[64:96]
        else:
            self.master_key = os.urandom(32)
            self.salt = os.urandom(32)
            self.hmac_key = os.urandom(32)
            self._save_keys()
        
        self._rotate_keys(initial=True)
    
    def _save_keys(self):
        with open(self.key_file, 'wb') as f:
            f.write(self.master_key + self.salt + self.hmac_key)
    
    def _rotate_keys(self, initial=False):
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA512(),
            length=32,
            salt=self.salt,
            iterations=100000,
            backend=default_backend()
        )
        self.encryption_key = kdf.derive(self.master_key)
        self.iv = os.urandom(16)
        self.last_rotation = time.time()
        
        if not initial:
            self._save_keys()
    
    def _check_rotation(self):
        if time.time() - self.last_rotation > self.key_rotation_interval:
            self._rotate_keys()
    
    def _load_conversations(self):
        conv_dir = os.path.join(self.storage_path, "conversations")
        if not os.path.exists(conv_dir):
            os.makedirs(conv_dir)
            return
        
        for filename in os.listdir(conv_dir):
            if filename.endswith('.enc'):
                conv_id = filename[:-4]
                with open(os.path.join(conv_dir, filename), 'rb') as f:
                    encrypted_data = f.read()
                
                cipher = Cipher(algorithms.AES(self.encryption_key), modes.CBC(self.iv), backend=default_backend())
                decryptor = cipher.decryptor()
                padded_data = decryptor.update(encrypted_data) + decryptor.finalize()
                
                unpadder = padding.PKCS7(128).unpadder()
                json_data = unpadder.update(padded_data) + unpadder.finalize()
                
                self._conversations[conv_id] = json.loads(json_data.decode())
    
    def _save_conversation(self, conversation_id):
        conv_dir = os.path.join(self.storage_path, "conversations")
        os.makedirs(conv_dir, exist_ok=True)
        
        json_data = json.dumps(self._conversations[conversation_id]).encode()
        
        padder = padding.PKCS7(128).padder()
        padded_data = padder.update(json_data) + padder.finalize()
        
        cipher = Cipher(algorithms.AES(self.encryption_key), modes.CBC(self.iv), backend=default_backend())
        encryptor = cipher.encryptor()
        encrypted_data = encryptor.update(padded_data) + encryptor.finalize()
        
        with open(os.path.join(conv_dir, f"{conversation_id}.enc"), 'wb') as f:
            f.write(encrypted_data)
    
    def create_conversation(self, name):
        conv_id = hashlib.sha256(f"{name}{time.time()}".encode()).hexdigest()
        with self._conv_lock:
            self._conversations[conv_id] = {
                'name': name,
                'created': datetime.now().isoformat(),
                'messages': []
            }
            self._save_conversation(conv_id)
        return conv_id
    
    def add_message(self, conversation_id, agent_name, message):
        self._check_rotation()
        encrypted_msg = self.protect_message(agent_name, message)
        
        with self._conv_lock:
            if conversation_id not in self._conversations:
                raise ValueError("Conversation does not exist")
            
            self._conversations[conversation_id]['messages'].append({
                'agent': agent_name,
                'message': encrypted_msg,
                'timestamp': datetime.now().isoformat()
            })
            self._save_conversation(conversation_id)
    
    def protect_message(self, agent_name, message):
        self._check_rotation()
        timestamp = str(time.time())
        msg_id = hashlib.sha256(f"{agent_name}{message}{timestamp}".encode()).hexdigest()
        
        # AES encryption
        cipher = Cipher(algorithms.AES(self.encryption_key), modes.GCM(self.iv), backend=default_backend())
        encryptor = cipher.encryptor()
        encrypted = encryptor.update(message.encode()) + encryptor.finalize()
        
        # SHA-512 hash
        if self.encryption_strength.value >= EncryptionStrength.ENHANCED.value:
            hash_obj = hashlib.sha512(message.encode())
            message_hash = hash_obj.hexdigest()
        else:
            message_hash = ""
        
        # HMAC
        if self.encryption_strength.value >= EncryptionStrength.MAXIMUM.value:
            hmac_obj = hmac.new(self.hmac_key, message.encode(), hashlib.sha512)
            hmac_digest = hmac_obj.hexdigest()
        else:
            hmac_digest = ""
        
        container = {
            'id': msg_id,
            'agent': agent_name,
            'timestamp': timestamp,
            'encrypted': base64.b64encode(encrypted).decode(),
            'iv': base64.b64encode(self.iv).decode(),
            'tag': base64.b64encode(encryptor.tag).decode(),
            'hash': message_hash,
            'hmac': hmac_digest
        }
        
        return json.dumps(container)
    
    def retrieve_message(self, encrypted_str):
        self._check_rotation()
        container = json.loads(encrypted_str)
        
        # Verify HMAC if present
        if self.encryption_strength.value >= EncryptionStrength.MAXIMUM.value and container['hmac']:
            hmac_obj = hmac.new(self.hmac_key, base64.b64decode(container['encrypted']), hashlib.sha512)
            if not hmac.compare_digest(hmac_obj.hexdigest(), container['hmac']):
                raise ValueError("HMAC verification failed")
        
        # Decrypt
        iv = base64.b64decode(container['iv'])
        encrypted = base64.b64decode(container['encrypted'])
        tag = base64.b64decode(container['tag'])
        
        cipher = Cipher(algorithms.AES(self.encryption_key), modes.GCM(iv, tag), backend=default_backend())
        decryptor = cipher.decryptor()
        decrypted = decryptor.update(encrypted) + decryptor.finalize()
        
        # Verify hash if present
        if self.encryption_strength.value >= EncryptionStrength.ENHANCED.value and container['hash']:
            hash_obj = hashlib.sha512(decrypted)
            if not hmac.compare_digest(hash_obj.hexdigest(), container['hash']):
                raise ValueError("Hash verification failed")
        
        return (container['agent'], decrypted.decode())
    
    def get_messages(self, conversation_id):
        with self._conv_lock:
            if conversation_id not in self._conversations:
                raise ValueError("Conversation does not exist")
            
            messages = []
            for msg in self._conversations[conversation_id]['messages']:
                try:
                    agent, message = self.retrieve_message(msg['message'])
                    messages.append((agent, message, datetime.fromisoformat(msg['timestamp'])))
                except Exception as e:
                    continue
            
            return messages
    
    def delete_conversation(self, conversation_id):
        with self._conv_lock:
            if conversation_id in self._conversations:
                del self._conversations[conversation_id]
                conv_file = os.path.join(self.storage_path, "conversations", f"{conversation_id}.enc")
                if os.path.exists(conv_file):
                    os.remove(conv_file)
    
    def backup_conversations(self, backup_dir=None):
        if backup_dir is None:
            backup_dir = os.path.join(self.storage_path, "backups", datetime.now().strftime("%Y%m%d_%H%M%S"))
        
        os.makedirs(backup_dir, exist_ok=True)
        
        with self._conv_lock:
            for conv_id in self._conversations:
                conv_file = os.path.join(self.storage_path, "conversations", f"{conv_id}.enc")
                if os.path.exists(conv_file):
                    with open(conv_file, 'rb') as src, open(os.path.join(backup_dir, f"{conv_id}.enc"), 'wb') as dst:
                        dst.write(src.read())
        
        return backup_dir
    
    def get_conversation_summary(self, conversation_id):
        with self._conv_lock:
            if conversation_id not in self._conversations:
                raise ValueError("Conversation does not exist")
            
            conv = self._conversations[conversation_id]
            participants = set()
            message_count = len(conv['messages'])
            
            for msg in conv['messages']:
                container = json.loads(msg['message'])
                participants.add(container['agent'])
            
            return {
                'id': conversation_id,
                'name': conv['name'],
                'created': conv['created'],
                'participants': list(participants),
                'message_count': message_count,
                'last_message': conv['messages'][-1]['timestamp'] if message_count > 0 else None
            }
    
    def get_agent_stats(self, agent_name):
        with self._conv_lock:
            stats = {
                'total_messages': 0,
                'conversations': set(),
                'first_message': None,
                'last_message': None
            }
            
            for conv_id, conv in self._conversations.items():
                for msg in conv['messages']:
                    container = json.loads(msg['message'])
                    if container['agent'] == agent_name:
                        stats['total_messages'] += 1
                        stats['conversations'].add(conv_id)
                        timestamp = datetime.fromisoformat(msg['timestamp'])
                        
                        if stats['first_message'] is None or timestamp < stats['first_message']:
                            stats['first_message'] = timestamp
                        
                        if stats['last_message'] is None or timestamp > stats['last_message']:
                            stats['last_message'] = timestamp
            
            stats['conversations'] = list(stats['conversations'])
            return stats
    
    def query_conversations(self, agent_name=None, text=None, start_date=None, end_date=None, limit=None):
        results = []
        
        with self._conv_lock:
            for conv_id, conv in self._conversations.items():
                matches = []
                
                for msg in conv['messages']:
                    try:
                        agent, message = self.retrieve_message(msg['message'])
                        timestamp = datetime.fromisoformat(msg['timestamp'])
                        
                        match = True
                        if agent_name and agent != agent_name:
                            match = False
                        if text and text.lower() not in message.lower():
                            match = False
                        if start_date and timestamp < start_date:
                            match = False
                        if end_date and timestamp > end_date:
                            match = False
                        
                        if match:
                            matches.append({
                                'agent': agent,
                                'message': message,
                                'timestamp': msg['timestamp']
                            })
                    except Exception:
                        continue
                
                if matches:
                    results.append({
                        'conversation_id': conv_id,
                        'conversation_name': conv['name'],
                        'matches': matches[:limit] if limit else matches
                    })
        
        return results
    
    def export_conversation(self, conversation_id, format="json", path=None):
        with self._conv_lock:
            if conversation_id not in self._conversations:
                raise ValueError("Conversation does not exist")
            
            messages = self.get_messages(conversation_id)
            conv = self._conversations[conversation_id]
            
            data = {
                'id': conversation_id,
                'name': conv['name'],
                'created': conv['created'],
                'messages': [{
                    'agent': agent,
                    'message': msg,
                    'timestamp': ts.isoformat()
                } for agent, msg, ts in messages]
            }
            
            if format == "json":
                output = json.dumps(data, indent=2)
            elif format == "text":
                output = f"Conversation: {conv['name']}\nCreated: {conv['created']}\n\n"
                for agent, msg, ts in messages:
                    output += f"[{ts}] {agent}: {msg}\n"
            else:
                raise ValueError("Invalid export format")
            
            if path:
                with open(path, 'w') as f:
                    f.write(output)
                return path
            else:
                return output