from ...node.variable import Variable

__all__ = ['Integer', 'Float', 'Boolean']

class Integer(Variable):
    def __init__(self, value):
        super().__init__(value)

    def __add__(self, other):
        if not isinstance(other, Integer):
            raise TypeError("Operands must be Integer")
        return Integer(self.value + other.value)

    def __mul__(self, other):
        if not isinstance(other, Integer):
            raise TypeError("Operands must be Integer")
        return Integer(self.value * other.value)

class Float(Variable):
    def __init__(self, value):
        super().__init__(value)

    def __add__(self, other):
        if not isinstance(other, Float):
            raise TypeError("Operands must be Float")
        return Float(self.value + other.value)

    def __mul__(self, other):
        if not isinstance(other, Float):
            raise TypeError("Operands must be Float")
        return Float(self.value * other.value)

class Boolean(Variable):
    def __init__(self, value):
        super().__init__(value)

    def __add__(self, other):
        if not isinstance(other, Boolean):
            raise TypeError("Operands must be Boolean")
        return Boolean(self.value or other.value)

    def __mul__(self, other):
        if not isinstance(other, Boolean):
            raise TypeError("Operands must be Boolean")
        return Boolean(self.value and other.value)