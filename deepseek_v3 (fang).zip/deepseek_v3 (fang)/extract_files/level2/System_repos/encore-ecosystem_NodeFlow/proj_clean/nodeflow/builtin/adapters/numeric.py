from ...node.variable import Variable
from ...adapter.abstract import Adapter
from ..variables.numeric import Boolean, Integer, Float

__all__ = [
    'Boolean2Integer', 'Integer2Boolean', 
    'Integer2Float', 'Float2Integer',
    'PyBool2Boolean', 'PyInt2Integer', 'PyFloat2Float'
]

class Boolean2Integer(Adapter):
    def compute(self, variable):
        return Integer(1 if variable.value else 0)

    def get_type_of_source_variable(self):
        return Boolean

    def get_type_of_target_variable(self):
        return Integer

    def is_loses_information(self):
        return False

class Integer2Boolean(Adapter):
    def compute(self, variable):
        return Boolean(bool(variable.value))

    def get_type_of_source_variable(self):
        return Integer

    def get_type_of_target_variable(self):
        return Boolean

    def is_loses_information(self):
        return True

class Integer2Float(Adapter):
    def compute(self, variable):
        return Float(float(variable.value))

    def get_type_of_source_variable(self):
        return Integer

    def get_type_of_target_variable(self):
        return Float

    def is_loses_information(self):
        return False

class Float2Integer(Adapter):
    def compute(self, variable):
        return Integer(int(variable.value))

    def get_type_of_source_variable(self):
        return Float

    def get_type_of_target_variable(self):
        return Integer

    def is_loses_information(self):
        return True

class PyBool2Boolean(Adapter):
    def compute(self, variable):
        return Boolean(variable)

    def get_type_of_source_variable(self):
        return bool

    def get_type_of_target_variable(self):
        return Boolean

    def is_loses_information(self):
        return False

class PyInt2Integer(Adapter):
    def compute(self, variable):
        return Integer(variable)

    def get_type_of_source_variable(self):
        return int

    def get_type_of_target_variable(self):
        return Integer

    def is_loses_information(self):
        return False

class PyFloat2Float(Adapter):
    def compute(self, variable):
        return Float(variable)

    def get_type_of_source_variable(self):
        return float

    def get_type_of_target_variable(self):
        return Float

    def is_loses_information(self):
        return False