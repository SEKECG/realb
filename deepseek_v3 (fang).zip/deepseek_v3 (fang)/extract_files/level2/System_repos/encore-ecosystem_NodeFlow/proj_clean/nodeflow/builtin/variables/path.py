import pathlib
from ...node.variable import Variable

__all__ = ['PathVariable']

class PathVariable(Variable):
    def __init__(self, value):
        if not isinstance(value, pathlib.Path):
            raise TypeError("Value must be a pathlib.Path")
        super().__init__(value.resolve())

    def __truediv__(self, other):
        if not isinstance(other, (str, pathlib.Path)):
            raise TypeError("Can only join with Path or str")
        return PathVariable(self.value / other)