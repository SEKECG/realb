from ...adapter.abstract import Adapter
from ..variables.numeric import Boolean, Integer, Float

__all__ = [
    'PythonicAdapter', 'Boolean2bool', 'Integer2int', 'Float2float',
    'bool2Boolean', 'int2Integer', 'float2Float'
]

class PythonicAdapter(Adapter):
    def is_loses_information(self):
        return False

class Boolean2bool(PythonicAdapter):
    def compute(self, variable):
        return variable.value

    def get_type_of_source_variable(self):
        return Boolean

    def get_type_of_target_variable(self):
        return bool

class Integer2int(PythonicAdapter):
    def compute(self, variable):
        return variable.value

    def get_type_of_source_variable(self):
        return Integer

    def get_type_of_target_variable(self):
        return int

class Float2float(PythonicAdapter):
    def compute(self, variable):
        return variable.value

    def get_type_of_source_variable(self):
        return Float

    def get_type_of_target_variable(self):
        return float

class bool2Boolean(PythonicAdapter):
    def compute(self, variable):
        return Boolean(variable)

    def get_type_of_source_variable(self):
        return bool

    def get_type_of_target_variable(self):
        return Boolean

class int2Integer(PythonicAdapter):
    def compute(self, variable):
        return Integer(variable)

    def get_type_of_source_variable(self):
        return int

    def get_type_of_target_variable(self):
        return Integer

class float2Float(PythonicAdapter):
    def compute(self, variable):
        return Float(variable)

    def get_type_of_source_variable(self):
        return float

    def get_type_of_target_variable(self):
        return Float