from ...node.variable import Variable

__all__ = ['Result']

class Result(Variable):
    def __init__(self, value):
        if not isinstance(value, bool):
            raise TypeError("Result value must be bool")
        super().__init__(value)