from inspect import signature
from collections import OrderedDict
from .abstract import Node
from .variable import Variable

__all__ = ['Function']

class Function(Node):
    def compute(self, args, kwargs):
        raise NotImplementedError()

    def get_parameters(self):
        sig = signature(self.compute)
        params = OrderedDict()
        for name, param in sig.parameters.items():
            if name == 'self':
                continue
            params[name] = Variable
        return params

    def get_return_type(self):
        return Variable