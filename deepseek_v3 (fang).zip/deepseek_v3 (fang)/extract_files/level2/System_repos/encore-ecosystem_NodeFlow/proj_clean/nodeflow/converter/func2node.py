from inspect import signature
from collections import OrderedDict
from ..node.function import Function
from ..node.variable import Variable

__all__ = ['func2node']

class ConvertedFunction(Function):
    def compute(self, args, kwargs):
        raise NotImplementedError()

def func2node(func):
    class WrappedFunction(ConvertedFunction):
        def compute(self, args, kwargs):
            return func(*args, **kwargs)

        def get_parameters(self):
            sig = signature(func)
            params = OrderedDict()
            for name, param in sig.parameters.items():
                params[name] = Variable
            return params

        def get_return_type(self):
            return Variable

    return WrappedFunction()