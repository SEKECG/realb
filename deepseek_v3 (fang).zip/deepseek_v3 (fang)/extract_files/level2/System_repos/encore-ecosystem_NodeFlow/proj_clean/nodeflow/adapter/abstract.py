from typing import Type, Any
from ..node.abstract import Node

__all__ = ['Adapter']

class Adapter:
    def compute(self, variable):
        raise NotImplementedError()

    def get_type_of_source_variable(self) -> Type['Variable']:
        raise NotImplementedError()

    def get_type_of_target_variable(self) -> Type['Variable']:
        raise NotImplementedError()

    def is_loses_information(self) -> bool:
        raise NotImplementedError()