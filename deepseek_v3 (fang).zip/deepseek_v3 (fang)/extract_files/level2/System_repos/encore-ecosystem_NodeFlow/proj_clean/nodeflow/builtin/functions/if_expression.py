from ...node.function import Function
from ..variables.result import Result

def py_if(expression, true_case, false_case):
    return true_case if expression else false_case

class IF(Function):
    def compute(self, args, kwargs):
        condition = args[0]
        true_case = args[1]
        false_case = args[2]
        if not isinstance(condition, Result):
            raise TypeError("Condition must be a Result")
        return true_case if condition.value else false_case

    def get_parameters(self):
        from collections import OrderedDict
        return OrderedDict([
            ('condition', Result),
            ('true_case', Variable),
            ('false_case', Variable)
        ])

    def get_return_type(self):
        from ..node.variable import Variable
        return Variable

__all__ = ['IF', 'py_if']