from typing import Optional, Type, Dict, Set, Tuple
from collections import defaultdict
from ..adapter.pipeline import Pipeline
from ..adapter.abstract import Adapter
from ..node.variable import Variable

__all__ = ['Converter']

class Converter:
    ROOT_CONVERTER: Optional['Converter'] = None

    def __init__(self, adapters=None, sub_converters=None):
        self.graph: Dict[Type[Variable], Dict[Type[Variable], Adapter]] = defaultdict(dict)
        self.sub_converters: Set['Converter'] = set()
        
        if adapters:
            self.register_adapters(adapters)
        if sub_converters:
            self.register_converters(sub_converters)

    def __enter__(self):
        Converter.ROOT_CONVERTER = self
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        Converter.ROOT_CONVERTER = None

    def register_adapter(self, adapter):
        source = adapter.get_type_of_source_variable()
        target = adapter.get_type_of_target_variable()
        self.graph[source][target] = adapter

    def register_adapters(self, adapters):
        for adapter in adapters:
            self.register_adapter(adapter)

    def register_converter(self, converter):
        self.sub_converters.add(converter)

    def register_converters(self, converters):
        for converter in converters:
            self.register_converter(converter)

    def is_support_variable(self, variable_type):
        return variable_type in self.graph

    def get_converting_pipeline(self, source, target) -> Tuple[Optional[Pipeline], bool]:
        if source == target:
            return None, False

        visited = set()
        queue = [(source, Pipeline(), False)]
        
        while queue:
            current_type, current_pipeline, loses_info = queue.pop(0)
            
            if current_type == target:
                return current_pipeline, loses_info
            
            if current_type in visited:
                continue
            visited.add(current_type)
            
            for neighbor, adapter in self.graph.get(current_type, {}).items():
                new_pipeline = Pipeline()
                for a in current_pipeline._pipeline:
                    new_pipeline.add_adapter(a)
                new_pipeline.add_adapter(adapter)
                queue.append((
                    neighbor, 
                    new_pipeline, 
                    loses_info or adapter.is_loses_information()
                ))
        
        for converter in self.sub_converters:
            pipeline, loses_info = converter.get_converting_pipeline(source, target)
            if pipeline:
                return pipeline, loses_info
        
        return None, False

    def convert(self, variable, to_type):
        if isinstance(variable, to_type):
            return variable
        
        pipeline, _ = self.get_converting_pipeline(type(variable), to_type)
        if pipeline:
            return pipeline.compute(variable)
        return None