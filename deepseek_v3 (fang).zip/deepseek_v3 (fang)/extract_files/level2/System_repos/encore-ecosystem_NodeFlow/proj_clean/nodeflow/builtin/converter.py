from ..converter.converter import Converter
from .adapters.numeric import *
from .adapters.pythonic import *

BUILTIN_CONVERTER = Converter()
BUILTIN_CONVERTER.register_adapters([
    Boolean2Integer(), Integer2Boolean(),
    Integer2Float(), Float2Integer(),
    PyBool2Boolean(), PyInt2Integer(), PyFloat2Float(),
    Boolean2bool(), Integer2int(), Float2float(),
    bool2Boolean(), int2Integer(), float2Float()
])

__all__ = ['BUILTIN_CONVERTER']