from typing import Dict
from ..converter.converter import Converter
from ..node.function import Function

__all__ = ['Dispenser']

class Dispenser:
    def __init__(self, **kwargs):
        self.variables_table: Dict[str, object] = kwargs

    def __rshift__(self, other):
        if isinstance(other, Function):
            params = other.get_parameters()
            args = []
            for name, param_type in params.items():
                if name not in self.variables_table:
                    raise ValueError(f"Missing parameter: {name}")
                
                variable = self.variables_table[name]
                if not isinstance(variable, param_type):
                    converter = Converter.ROOT_CONVERTER
                    if converter:
                        converted = converter.convert(variable, param_type)
                        if converted is not None:
                            variable = converted
                    if not isinstance(variable, param_type):
                        raise TypeError(f"Parameter {name} must be {param_type.__name__}")
                args.append(variable)
            
            return other.compute(args, {})
        else:
            return other(self.variables_table)