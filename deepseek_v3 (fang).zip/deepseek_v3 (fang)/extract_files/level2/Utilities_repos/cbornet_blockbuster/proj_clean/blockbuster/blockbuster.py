import builtins
import contextlib
import contextvars
import functools
import importlib
import inspect
import io
import os
import socket
import sqlite3
import ssl
import sys
import threading
import time
import types
from typing import (
    Any,
    Callable,
    Dict,
    Iterable,
    Iterator,
    List,
    Optional,
    Sequence,
    Tuple,
    TypeVar,
    Union,
)

HAS_FORBIDDENFRUIT = False
_T = TypeVar("_T")
_ModuleList = Sequence[Union[str, types.ModuleType]]
_ModuleOrModuleList = Union[str, types.ModuleType, _ModuleList]
blockbuster_skip = contextvars.ContextVar("blockbuster_skip", default=False)


class BlockingError(Exception):
    """Exception raised when a blocking call is detected."""

    def __init__(self, func):
        super().__init__(f"Blocking call detected: {func.__name__}")


class BlockBusterFunction:
    """Wrapper for functions that can block the event loop."""

    def __init__(
        self,
        module,
        func_name,
        scanned_modules=None,
        excluded_modules=None,
        can_block_functions=None,
        can_block_predicate=None,
    ):
        self.module = module
        self.func_name = func_name
        self.full_name = f"{module.__name__}.{func_name}"
        self.original_func = getattr(module, func_name)
        self._scanned_modules = scanned_modules
        self._excluded_modules = excluded_modules
        self.can_block_functions = can_block_functions or []
        self.can_block_predicate = can_block_predicate
        self.activated = False

    def activate(self):
        """Activate blocking detection for this function."""
        if not self.activated:
            setattr(self.module, self.func_name, self._wrapped_func)
            self.activated = True
        return self

    def deactivate(self):
        """Deactivate blocking detection for this function."""
        if self.activated:
            setattr(self.module, self.func_name, self.original_func)
            self.activated = False
        return self

    def can_block_in(self, filename, functions):
        """Allow blocking in specific functions."""
        if isinstance(functions, str):
            functions = [functions]
        self.can_block_functions.append((filename, functions))
        return self

    def _wrapped_func(self, *args, **kwargs):
        if blockbuster_skip.get():
            return self.original_func(*args, **kwargs)

        if self.can_block_predicate and self.can_block_predicate(*args, **kwargs):
            return self.original_func(*args, **kwargs)

        frame = inspect.currentframe()
        try:
            while frame:
                frame_info = inspect.getframeinfo(frame)
                for filename, functions in self.can_block_functions:
                    if frame_info.filename.endswith(filename):
                        if frame_info.function in functions:
                            return self.original_func(*args, **kwargs)
                frame = frame.f_back
        finally:
            del frame

        raise BlockingError(self.original_func)


class BlockBuster:
    """Main class for detecting blocking calls."""

    def __init__(self, scanned_modules=None, excluded_modules=None):
        self.functions: Dict[str, BlockBusterFunction] = {}

        wrapped_functions = [
            *_get_time_wrapped_functions(scanned_modules, excluded_modules),
            *_get_os_wrapped_functions(scanned_modules, excluded_modules),
            *_get_io_wrapped_functions(scanned_modules, excluded_modules),
            *_get_socket_wrapped_functions(scanned_modules, excluded_modules),
            *_get_ssl_wrapped_functions(scanned_modules, excluded_modules),
            *_get_sqlite_wrapped_functions(scanned_modules, excluded_modules),
            *_get_lock_wrapped_functions(scanned_modules, excluded_modules),
            *_get_builtins_wrapped_functions(scanned_modules, excluded_modules),
        ]

        for func_dict in wrapped_functions:
            for name, func in func_dict.items():
                self.functions[name] = func

    def activate(self):
        """Activate all wrapped functions."""
        for func in self.functions.values():
            func.activate()

    def deactivate(self):
        """Deactivate all wrapped functions."""
        for func in self.functions.values():
            func.deactivate()


@contextlib.contextmanager
def blockbuster_ctx(scanned_modules=None, excluded_modules=None) -> Iterator[BlockBuster]:
    """Context manager for using BlockBuster."""
    bb = BlockBuster(scanned_modules, excluded_modules)
    bb.activate()
    try:
        yield bb
    finally:
        bb.deactivate()


def _blocking_error(func) -> BlockingError:
    """Generate a BlockingError with a descriptive message."""
    return BlockingError(func)


def _resolve_module_paths(modules) -> List[str]:
    """Resolve module paths to filesystem paths."""
    paths = []
    if not modules:
        return paths

    if not isinstance(modules, (list, tuple)):
        modules = [modules]

    for module in modules:
        if isinstance(module, str):
            module = importlib.import_module(module)
        if hasattr(module, "__file__"):
            paths.append(module.__file__)
    return paths


def _socket_exclude(sock, _, __) -> bool:
    """Determine if a socket should be excluded based on its blocking mode."""
    return not sock.getblocking()


def _wrap_blocking(
    modules,
    excluded_modules,
    func,
    func_name,
    can_block_functions=None,
    can_block_predicate=None,
):
    """Wrap a blocking function with detection logic."""
    module = inspect.getmodule(func)
    if module is None:
        return func

    wrapped = BlockBusterFunction(
        module,
        func_name,
        scanned_modules=modules,
        excluded_modules=excluded_modules,
        can_block_functions=can_block_functions,
        can_block_predicate=can_block_predicate,
    )
    return wrapped


def _get_time_wrapped_functions(modules, excluded_modules) -> Dict[str, BlockBusterFunction]:
    """Get wrapped time functions."""
    wrapped = {}
    if modules and "time" not in [m.__name__ if hasattr(m, "__name__") else m for m in modules]:
        return wrapped

    time_funcs = ["sleep"]
    for func_name in time_funcs:
        func = getattr(time, func_name)
        wrapped[f"time.{func_name}"] = _wrap_blocking(modules, excluded_modules, func, func_name)
    return wrapped


def _get_os_wrapped_functions(modules, excluded_modules) -> Dict[str, BlockBusterFunction]:
    """Get wrapped OS functions."""
    wrapped = {}
    if modules and "os" not in [m.__name__ if hasattr(m, "__name__") else m for m in modules]:
        return wrapped

    os_funcs = [
        "open", "read", "write", "close", "stat", "listdir", "remove", "rename",
        "mkdir", "rmdir", "chmod", "chown", "link", "symlink", "unlink", "system",
        "popen", "wait", "kill", "getpid", "getppid", "getcwd", "chdir", "fork",
        "execv", "execve", "spawnv", "spawnve", "waitpid", "wait3", "wait4",
    ]
    for func_name in os_funcs:
        if hasattr(os, func_name):
            func = getattr(os, func_name)
            wrapped[f"os.{func_name}"] = _wrap_blocking(modules, excluded_modules, func, func_name)
    return wrapped


def _get_io_wrapped_functions(modules, excluded_modules) -> Dict[str, BlockBusterFunction]:
    """Get wrapped I/O functions."""
    wrapped = {}
    if modules and "io" not in [m.__name__ if hasattr(m, "__name__") else m for m in modules]:
        return wrapped

    io_funcs = ["open"]
    for func_name in io_funcs:
        func = getattr(io, func_name)
        wrapped[f"io.{func_name}"] = _wrap_blocking(modules, excluded_modules, func, func_name)
    return wrapped


def _get_socket_wrapped_functions(modules, excluded_modules) -> Dict[str, BlockBusterFunction]:
    """Get wrapped socket functions."""
    wrapped = {}
    if modules and "socket" not in [m.__name__ if hasattr(m, "__name__") else m for m in modules]:
        return wrapped

    socket_funcs = [
        "socket", "create_connection", "create_server", "send", "recv", "sendall",
        "recvfrom", "sendto", "accept", "connect", "bind", "listen", "shutdown",
        "close", "getaddrinfo", "getnameinfo", "gethostbyname", "gethostbyaddr",
    ]
    for func_name in socket_funcs:
        if hasattr(socket, func_name):
            func = getattr(socket, func_name)
            wrapped[f"socket.{func_name}"] = _wrap_blocking(
                modules,
                excluded_modules,
                func,
                func_name,
                can_block_predicate=_socket_exclude if func_name in ("send", "recv", "sendall", "recvfrom") else None,
            )
    return wrapped


def _get_ssl_wrapped_functions(modules, excluded_modules) -> Dict[str, BlockBusterFunction]:
    """Get wrapped SSL functions."""
    wrapped = {}
    if modules and "ssl" not in [m.__name__ if hasattr(m, "__name__") else m for m in modules]:
        return wrapped

    ssl_funcs = ["wrap_socket", "SSLContext"]
    for func_name in ssl_funcs:
        if hasattr(ssl, func_name):
            func = getattr(ssl, func_name)
            wrapped[f"ssl.{func_name}"] = _wrap_blocking(modules, excluded_modules, func, func_name)
    return wrapped


def _get_sqlite_wrapped_functions(modules, excluded_modules) -> Dict[str, BlockBusterFunction]:
    """Get wrapped SQLite functions."""
    wrapped = {}
    if modules and "sqlite3" not in [m.__name__ if hasattr(m, "__name__") else m for m in modules]:
        return wrapped

    sqlite_funcs = ["connect", "Cursor"]
    for func_name in sqlite_funcs:
        if hasattr(sqlite3, func_name):
            func = getattr(sqlite3, func_name)
            wrapped[f"sqlite3.{func_name}"] = _wrap_blocking(modules, excluded_modules, func, func_name)
    return wrapped


def _get_lock_wrapped_functions(modules, excluded_modules) -> Dict[str, BlockBusterFunction]:
    """Get wrapped lock functions."""
    wrapped = {}
    if modules and "threading" not in [m.__name__ if hasattr(m, "__name__") else m for m in modules]:
        return wrapped

    lock_funcs = ["Lock", "RLock", "Condition", "Semaphore", "Event", "Barrier"]
    for func_name in lock_funcs:
        if hasattr(threading, func_name):
            func = getattr(threading, func_name)
            wrapped[f"threading.{func_name}"] = _wrap_blocking(modules, excluded_modules, func, func_name)
    return wrapped


def _get_builtins_wrapped_functions(modules, excluded_modules) -> Dict[str, BlockBusterFunction]:
    """Get wrapped builtin functions."""
    wrapped = {}
    if modules and "builtins" not in [m.__name__ if hasattr(m, "__name__") else m for m in modules]:
        return wrapped

    builtin_funcs = ["input", "open"]
    for func_name in builtin_funcs:
        func = getattr(builtins, func_name)
        wrapped[f"builtins.{func_name}"] = _wrap_blocking(modules, excluded_modules, func, func_name)
    return wrapped