import os
import platform
import subprocess
from pathlib import Path

import requests
from fastapi import Response

from .constants import CACHE_DIR

TAILWIND_CONFIG = """module.exports = {
  content: ["./src/**/*.{html,js}"],
  theme: {
    extend: {},
  },
  plugins: [],
}
"""

TAILWIND_DAISYCSS_CONFIG = """module.exports = {
  content: ["./src/**/*.{html,js}"],
  theme: {
    extend: {},
  },
  plugins: [require("daisyui")],
}
"""

TAILWIND_SOURCE_CSS = """@tailwind base;
@tailwind components;
@tailwind utilities;
"""

TAILWIND_URI = "/_fh_utils/tailwind.css"

def _get_download_url(version="v3.3.3"):
    system = platform.system().lower()
    arch = platform.machine().lower()
    
    if system == "darwin":
        system = "macos"
    if arch == "x86_64":
        arch = "x64"
    
    return f"https://github.com/tailwindlabs/tailwindcss/releases/download/{version}/tailwindcss-{system}-{arch}"

def _cached_download_tailwind_cli(version="v3.3.3"):
    url = _get_download_url(version)
    cli_path = CACHE_DIR / f"tailwindcss-{version}"
    
    if not cli_path.exists():
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        resp = requests.get(url)
        with open(cli_path, "wb") as f:
            f.write(resp.content)
        os.chmod(cli_path, 0o755)
    
    return cli_path

def tailwind_compile(outpath, cfg, css):
    cli_path = _cached_download_tailwind_cli()
    config_path = Path(outpath).parent / "tailwind.config.js"
    input_path = Path(outpath).parent / "input.css"
    
    with open(config_path, "w") as f:
        f.write(cfg)
    with open(input_path, "w") as f:
        f.write(css)
    
    subprocess.run([
        str(cli_path),
        "-i", str(input_path),
        "-o", str(outpath),
        "-c", str(config_path),
    ], check=True)

def _add(app, cfg, css, uri):
    outpath = Path("static") / "tailwind.css"
    outpath.parent.mkdir(exist_ok=True)
    
    tailwind_compile(outpath, cfg, css)
    
    @app.get(uri)
    async def serve_tailwind():
        with open(outpath, "r") as f:
            content = f.read()
        return Response(content=content, media_type="text/css")

def add_tailwind(app, cfg=TAILWIND_CONFIG, css=TAILWIND_SOURCE_CSS, uri=TAILWIND_URI):
    _add(app, cfg, css, uri)

def add_daisy_and_tailwind(app, cfg=TAILWIND_DAISYCSS_CONFIG, css=TAILWIND_SOURCE_CSS, uri=TAILWIND_URI):
    _add(app, cfg, css, uri)