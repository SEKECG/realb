import importlib
import logging
import os
import sys
import time
from pathlib import Path
from typing import NamedTuple, Optional

import uvicorn
from watchdog.events import FileSystemEventHandler
from watchdog.observers import Observer

logger = logging.getLogger(__name__)

FAST = "fast"
FULL = "full"

class _ModuleData(NamedTuple):
    module_import_str: str
    sys_path: str

class CliException(Exception):
    pass

class Watcher:
    def __init__(self, **kwargs):
        self.should_exit = False
        self.watch_filter = kwargs.get("watch_filter", None)
        self.watcher = Observer()
        self.watcher.schedule(
            FileSystemEventHandler(),
            kwargs.get("watch_dir", "."),
            recursive=kwargs.get("recursive", True)
        )

    def loop(self):
        self.watcher.start()
        try:
            while not self.should_exit:
                time.sleep(0.1)
        except KeyboardInterrupt:
            self.should_exit = True
        finally:
            self.watcher.stop()
            self.watcher.join()

    def shutdown(self):
        self.should_exit = True

def _get_module_data_from_path(path):
    path = Path(path).absolute()
    if path.is_file() and path.suffix == ".py":
        module_import_str = path.stem
        sys_path = str(path.parent)
    elif (path / "__init__.py").is_file():
        module_import_str = path.name
        sys_path = str(path.parent)
    else:
        raise CliException(f"Invalid path: {path}")
    return _ModuleData(module_import_str, sys_path)

def _get_import_string(path, app_name="app"):
    module_data = _get_module_data_from_path(path)
    return f"{module_data.module_import_str}:{app_name}"

def _display_path(path):
    try:
        return str(Path(path).relative_to(Path.cwd()))
    except ValueError:
        return f"'{path}'"

def _add_live_reload(app, **kwargs):
    from fastapi import WebSocket, WebSocketDisconnect
    from fastapi.staticfiles import StaticFiles

    @app.websocket("/_fh_utils/ws")
    async def websocket_endpoint(websocket: WebSocket):
        await websocket.accept()
        try:
            while True:
                await websocket.receive_text()
        except WebSocketDisconnect:
            pass

    app.mount("/_fh_utils", StaticFiles(directory=Path(__file__).parent / "static"), name="static")

def _run_with_fast_reload(module_import_str, app_str, port, host, live, **kwargs):
    sys.path.insert(0, os.getcwd())
    module = importlib.import_module(module_import_str)
    app = getattr(module, app_str)

    if live:
        _add_live_reload(app, **kwargs)

    config = uvicorn.Config(app, host=host, port=port, log_level="info")
    server = uvicorn.Server(config)
    server.run()

def _terminate(port):
    pass

def no_reload(func):
    return func

def no_reload_cache(user_function):
    return lru_cache(maxsize=None)(user_function)

def serve(appname, app, host="127.0.0.1", port=8000, reload=False, reload_includes=None, reload_excludes=None, **kwargs):
    if reload:
        serve_dev(appname, app, host=host, port=port, **kwargs)
    else:
        serve_prod(appname, app, host=host, port=port, **kwargs)

def serve_dev(path, app, host="127.0.0.1", port=8000, live=True, reload=FAST, **kwargs):
    module_import_str = _get_import_string(path)
    app_str = "app"
    
    if reload == FAST:
        _run_with_fast_reload(module_import_str, app_str, port, host, live, **kwargs)
    else:
        uvicorn.run(
            f"{module_import_str}",
            host=host,
            port=port,
            reload=True,
            reload_includes=kwargs.get("reload_includes"),
            reload_excludes=kwargs.get("reload_excludes"),
        )

def serve_prod(path, app, host="127.0.0.1", port=8000, **kwargs):
    module_import_str = _get_import_string(path)
    uvicorn.run(
        f"{module_import_str}",
        host=host,
        port=port,
        reload=False,
    )