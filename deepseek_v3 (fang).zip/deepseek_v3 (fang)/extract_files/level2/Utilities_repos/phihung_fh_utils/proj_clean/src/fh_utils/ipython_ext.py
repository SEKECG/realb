import socket
import threading
from typing import Optional, Tuple

import uvicorn
from IPython.display import HTML, display

PORT_RANGE = (8000, 9000)

class TupleNoPrint(tuple):
    def __repr__(self):
        return ""
    
    def __str__(self):
        return ""

class Server:
    def __init__(self, config):
        self.run = uvicorn.Server(config=config)
        self.running_app = None
        self.should_exit = False
        self.thread = None

    def install_signal_handlers(self):
        self.run.install_signal_handlers()

    def run_in_thread(self):
        self.thread = threading.Thread(target=self.run.run, daemon=True)
        self.thread.start()
        for _ in range(5):
            if self.run.started:
                return
            threading.Event().wait(1)
        raise RuntimeError("Server failed to start")

    def close(self):
        self.run.should_exit = True
        self.thread.join(timeout=5)

class JupyterReloader:
    def __init__(self):
        self.server: Optional[Server] = None

    def load(self, app, page="/", width="100%", height="500px", port=None, host="127.0.0.1"):
        if port is None:
            port = find_available_port(host)
        
        config = uvicorn.Config(app, host=host, port=port, log_level="warning")
        self.server = Server(config)
        self.server.run_in_thread()
        
        iframe = f"""
        <iframe src="http://{host}:{port}{page}" width="{width}" height="{height}" frameborder="0">
        </iframe>
        """
        display(HTML(iframe))
        return TupleNoPrint((host, port))

def find_available_port(host="127.0.0.1"):
    for port in range(*PORT_RANGE):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind((host, port))
                return port
            except OSError:
                continue
    raise RuntimeError("No available ports found")

def load_ipython_extension(ipython):
    reloader = JupyterReloader()
    ipython.register_magic_function(
        lambda line, cell=None: reloader.load(eval(line.split()[0]), *line.split()[1:]),
        magic_name="fh",
        magic_kind="line"
    )