import re
import xml.etree.ElementTree as ET
from functools import lru_cache
from pathlib import Path

import requests

from .constants import CACHE_DIR

cache = lru_cache(maxsize=None)
pat = re.compile(r"width=\"(\d+)\" height=\"(\d+)\"")
xmlns = "http://www.w3.org/2000/svg"
_heroicon_defaults = {"width": 24, "height": 24}

def _parse(svg):
    match = pat.search(svg)
    if match:
        w, h = match.groups()
    else:
        w, h = _heroicon_defaults["width"], _heroicon_defaults["height"]
    svg = re.sub(r"<svg[^>]*>", "", svg)
    svg = re.sub(r"</svg>", "", svg)
    return w, h, svg

def _make(*args, **kwargs):
    width = kwargs.pop("width", 24)
    height = kwargs.pop("height", 24)
    content = kwargs.pop("content", "")
    attrs = " ".join([f'{k}="{v}"' for k, v in kwargs.items()])
    return f'<svg width="{width}" height="{height}" {attrs} xmlns="{xmlns}">{content}</svg>'

@cache
def _get_heroicon(name, variant="outline"):
    url = f"https://raw.githubusercontent.com/tailwindlabs/heroicons/master/24/{variant}/{name}.svg"
    resp = requests.get(url)
    return resp.text

@cache
def _get_phosphor_icon(name, variant="regular"):
    url = f"https://raw.githubusercontent.com/phosphor-icons/core/main/assets/{variant}/{name}.svg"
    resp = requests.get(url)
    return resp.text

@cache
def _get_ionicon(name, variant="outline"):
    url = f"https://raw.githubusercontent.com/ionic-team/ionicons/master/src/svg/{name}-{variant}.svg"
    resp = requests.get(url)
    return resp.text

@cache
def _get_lucide(name, variant=None):
    url = f"https://raw.githubusercontent.com/lucide-icons/lucide/main/icons/{name}.svg"
    resp = requests.get(url)
    return resp.text

@cache
def _get_fa(name, variant="regular"):
    url = f"https://raw.githubusercontent.com/FortAwesome/Font-Awesome/6.x/svgs/{variant}/{name}.svg"
    resp = requests.get(url)
    return resp.text

@cache
def _get_boostrap(name, variant=None):
    url = f"https://raw.githubusercontent.com/twbs/icons/main/icons/{name}.svg"
    resp = requests.get(url)
    return resp.text

@cache
def _get_boxicon(name, variant="regular"):
    url = f"https://raw.githubusercontent.com/atisawd/boxicons/master/svg/{variant}/bx-{name}.svg"
    resp = requests.get(url)
    return resp.text

def HeroIcon(name, variant="outline", **kwargs):
    svg = _get_heroicon(name, variant)
    w, h, content = _parse(svg)
    return _make(content=content, width=w, height=h, **kwargs)

def PhIcon(name, variant="regular", **kwargs):
    svg = _get_phosphor_icon(name, variant)
    w, h, content = _parse(svg)
    return _make(content=content, width=w, height=h, **kwargs)

def IonIcon(name, variant="outline", **kwargs):
    svg = _get_ionicon(name, variant)
    w, h, content = _parse(svg)
    return _make(content=content, width=w, height=h, **kwargs)

def LcIcon(name, variant=None, **kwargs):
    svg = _get_lucide(name, variant)
    w, h, content = _parse(svg)
    return _make(content=content, width=w, height=h, **kwargs)

def FaIcon(name, variant="regular", **kwargs):
    svg = _get_fa(name, variant)
    w, h, content = _parse(svg)
    return _make(content=content, width=w, height=h, **kwargs)

def BsIcon(name, variant=None, **kwargs):
    svg = _get_boostrap(name, variant)
    w, h, content = _parse(svg)
    return _make(content=content, width=w, height=h, **kwargs)

def BoxIcon(name, variant="regular", **kwargs):
    svg = _get_boxicon(name, variant)
    w, h, content = _parse(svg)
    return _make(content=content, width=w, height=h, **kwargs)