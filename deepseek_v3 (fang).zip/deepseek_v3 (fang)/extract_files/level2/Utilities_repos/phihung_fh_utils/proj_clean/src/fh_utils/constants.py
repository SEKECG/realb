from pathlib import Path

CACHE_DIR = Path.home() / ".cache" / "fh_utils"