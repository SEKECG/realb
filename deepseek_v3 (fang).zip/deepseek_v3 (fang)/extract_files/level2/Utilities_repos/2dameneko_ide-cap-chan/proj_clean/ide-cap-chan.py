import argparse
import os
import time
import multiprocessing
from queue import Empty
from typing import Dict, List, Optional, Tuple

from arg_parser import parse_arguments
from image_processor import process_image_worker, get_handler
from utils import measure_gpu_speed, resize_image_proportionally

split_extension = os.path.splitext

def main():
    args = parse_arguments()
    
    # Prepare GPU devices
    gpu_ids = [int(x) for x in args.gpu_ids.split(",")]
    gpu_speeds = {gpu_id: measure_gpu_speed(gpu_id) for gpu_id in gpu_ids}
    sorted_gpus = sorted(gpu_speeds.items(), key=lambda x: x[1], reverse=True)
    
    # Prepare job queue
    job_queue = multiprocessing.Queue()
    result_queue = multiprocessing.Queue()
    
    # Collect image files
    image_exts = {".jpg", ".jpeg", ".png", ".webp"}
    image_files = []
    for root, _, files in os.walk(args.input_dir):
        for file in files:
            ext = split_extension(file)[1].lower()
            if ext in image_exts:
                image_path = os.path.join(root, file)
                caption_path = os.path.splitext(image_path)[0] + args.output_ext
                
                if args.skip_existing and os.path.exists(caption_path):
                    continue
                
                image_files.append(image_path)
    
    # Add jobs to queue
    for image_path in image_files:
        job_queue.put(image_path)
    
    # Start worker processes
    workers = []
    for worker_id, (gpu_id, _) in enumerate(sorted_gpus):
        worker_args = (
            worker_id,
            gpu_id,
            job_queue,
            result_queue,
            args.model_path,
            args.model_type,
            vars(args),
            len(image_files)
        )
        worker = multiprocessing.Process(
            target=process_image_worker,
            args=worker_args
        )
        worker.start()
        workers.append(worker)
    
    # Monitor progress
    processed = 0
    start_time = time.time()
    
    while processed < len(image_files):
        try:
            result = result_queue.get(timeout=1)
            processed += 1
            
            elapsed = time.time() - start_time
            remaining = (len(image_files) - processed) * (elapsed / processed)
            
            print(f"Processed {processed}/{len(image_files)} - "
                  f"ETA: {remaining/60:.1f} minutes - {result}")
        except Empty:
            if all(not worker.is_alive() for worker in workers):
                break
    
    # Clean up
    for worker in workers:
        worker.join()

if __name__ == "__main__":
    main()