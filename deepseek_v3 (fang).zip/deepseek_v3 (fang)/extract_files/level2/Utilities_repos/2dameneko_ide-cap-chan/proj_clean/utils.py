import torch
import time
from PIL import Image

GPU_TEST_ITERATIONS = 100
GPU_TEST_SIZE = 1024

def measure_gpu_speed(device):
    """Measure the speed of a GPU by performing matrix operations."""
    try:
        torch.cuda.set_device(device)
        device = torch.device(f"cuda:{device}")
        
        # Warm up
        a = torch.randn(GPU_TEST_SIZE, GPU_TEST_SIZE, device=device)
        b = torch.randn(GPU_TEST_SIZE, GPU_TEST_SIZE, device=device)
        torch.mm(a, b)
        
        # Benchmark
        start_time = time.time()
        for _ in range(GPU_TEST_ITERATIONS):
            a = torch.randn(GPU_TEST_SIZE, GPU_TEST_SIZE, device=device)
            b = torch.randn(GPU_TEST_SIZE, GPU_TEST_SIZE, device=device)
            torch.mm(a, b)
        elapsed = time.time() - start_time
        
        return GPU_TEST_ITERATIONS / elapsed
    except Exception as e:
        print(f"Error measuring GPU {device} speed: {e}")
        return 0

def resize_image_proportionally(image, max_width, max_height):
    """Resize an image proportionally to fit within the specified dimensions."""
    original_width, original_height = image.size
    ratio = min(max_width / original_width, max_height / original_height)
    new_width = int(original_width * ratio)
    new_height = int(original_height * ratio)
    return image.resize((new_width, new_height), Image.LANCZOS)