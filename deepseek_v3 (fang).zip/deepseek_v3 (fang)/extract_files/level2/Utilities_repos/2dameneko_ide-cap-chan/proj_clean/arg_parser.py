import argparse
from typing import List, Any

def check_mutually_exclusive(args, arg_names):
    """Ensure that only one of the specified arguments in a given set is True."""
    selected = [getattr(args, name) for name in arg_names if getattr(args, name)]
    if len(selected) > 1:
        raise argparse.ArgumentError(None, f"Only one of {', '.join(arg_names)} can be specified")

def parse_arguments():
    """Parse command-line arguments for configuring image caption generation."""
    parser = argparse.ArgumentParser(description="Image Captioning System")
    
    # Model settings
    model_group = parser.add_argument_group("Model Settings")
    model_group.add_argument("--model_type", type=str, required=True,
                            choices=["exllama2", "joycaption", "molmo", "molmo72b", 
                                     "qwen2vl", "pixtral", "idefics3", "llava", 
                                     "minicpmo", "generic"],
                            help="Type of model to use")
    model_group.add_argument("--model_path", type=str, required=True,
                            help="Path to the model or HuggingFace model name")
    model_group.add_argument("--quant_4bit", action="store_true",
                            help="Use 4-bit quantization (NF4)")
    
    # Input/Output settings
    io_group = parser.add_argument_group("Input/Output Settings")
    io_group.add_argument("--input_dir", type=str, required=True,
                         help="Directory containing images to process")
    io_group.add_argument("--output_ext", type=str, default=".txt",
                         help="Extension for output caption files")
    io_group.add_argument("--tag_ext", type=str, default=".tags",
                         help="Extension for output tag files")
    
    # Processing settings
    proc_group = parser.add_argument_group("Processing Settings")
    proc_group.add_argument("--gpu_ids", type=str, default="0",
                           help="Comma-separated list of GPU IDs to use")
    proc_group.add_argument("--max_width", type=int, default=1024,
                           help="Maximum image width")
    proc_group.add_argument("--max_height", type=int, default=1024,
                           help="Maximum image height")
    proc_group.add_argument("--skip_existing", action="store_true",
                           help="Skip images with existing caption files")
    
    # Caption format settings
    format_group = parser.add_argument_group("Caption Format Settings")
    format_group.add_argument("--format", type=str, default="markdown",
                             choices=["json", "markdown", "short", "long", "bbox"],
                             help="Format for generated captions")
    format_group.add_argument("--use_tags", action="store_true",
                             help="Incorporate existing tags from files")
    format_group.add_argument("--add_character_info", action="store_true",
                             help="Include character information in captions")
    format_group.add_argument("--add_character_traits", action="store_true",
                             help="Include character traits in captions")
    
    # Performance settings
    perf_group = parser.add_argument_group("Performance Settings")
    perf_group.add_argument("--batch_size", type=int, default=1,
                           help="Batch size for processing")
    perf_group.add_argument("--max_workers", type=int, default=4,
                           help="Maximum number of worker processes")
    
    args = parser.parse_args()
    
    # Check mutually exclusive arguments
    check_mutually_exclusive(args, ["use_tags", "add_character_info", "add_character_traits"])
    
    return args