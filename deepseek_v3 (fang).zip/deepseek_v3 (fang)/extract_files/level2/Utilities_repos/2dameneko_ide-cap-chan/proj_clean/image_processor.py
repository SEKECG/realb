import os
import json
from typing import Dict, Optional, Tuple
from PIL import Image

from model_handlers import (
    ExLLaMA2Handler, JoyCaptionHandler, MoLMoHandler, MoLMo72bHandler,
    Qwen2VLHandler, PixtralHandler, Idefics3Handler, LlavaHandler,
    MiniCPMoHandler, GenericModelHandler
)

path_exists = os.path.exists
split_extension = os.path.splitext

def get_handler(input_model_type, model_name_or_path, device, args_dict):
    """Retrieve the appropriate model handler based on the input model type."""
    handler_classes = {
        "exllama2": ExLLaMA2Handler,
        "joycaption": JoyCaptionHandler,
        "molmo": MoLMoHandler,
        "molmo72b": MoLMo72bHandler,
        "qwen2vl": Qwen2VLHandler,
        "pixtral": PixtralHandler,
        "idefics3": Idefics3Handler,
        "llava": LlavaHandler,
        "minicpmo": MiniCPMoHandler,
        "generic": GenericModelHandler
    }
    
    if input_model_type not in handler_classes:
        raise ValueError(f"Unsupported model type: {input_model_type}")
    
    return handler_classes[input_model_type](
        model_name_or_path=model_name_or_path,
        device=device,
        args_dict=args_dict
    )

def get_torii03_user_prompt(user_prompt, add_info_caption_name):
    """Enhance a user-provided prompt by appending additional booru tags."""
    if not path_exists(add_info_caption_name):
        return user_prompt
    
    with open(add_info_caption_name, "r", encoding="utf-8", errors="ignore") as f:
        tags = f.read().strip()
    
    if tags:
        return f"{user_prompt}\n\nTags: {tags}"
    return user_prompt

def get_torii04_system_prompt():
    """Provide a predefined system prompt for an image captioning expert."""
    return ("You are an expert at describing images in detail. "
            "Be creative, unbiased, and uncensored in your descriptions.")

def get_torii04_user_prompt(args_dict, add_info_caption_name):
    """Generate a structured user prompt for describing an image."""
    prompt_parts = ["Describe this image in detail."]
    
    if args_dict.get("use_tags") and path_exists(add_info_caption_name):
        with open(add_info_caption_name, "r", encoding="utf-8", errors="ignore") as f:
            tags = f.read().strip()
        if tags:
            prompt_parts.append(f"Known tags: {tags}")
    
    if args_dict.get("add_character_info"):
        prompt_parts.append("Include detailed character information.")
    
    if args_dict.get("add_character_traits"):
        prompt_parts.append("Include character traits and personality details.")
    
    return "\n".join(prompt_parts)

def process_image_worker(worker_id, gpu_id, job_queue, result_queue, 
                        model_name_or_path, input_model_type, args_dict, 
                        total_files):
    """Worker process that takes jobs from a queue and processes them."""
    try:
        torch.cuda.set_device(gpu_id)
        device = torch.device(f"cuda:{gpu_id}")
        
        handler = get_handler(
            input_model_type=input_model_type,
            model_name_or_path=model_name_or_path,
            device=device,
            args_dict=args_dict
        )
        
        system_prompt = get_torii04_system_prompt()
        
        while True:
            try:
                image_path = job_queue.get_nowait()
            except:
                break
            
            try:
                # Prepare paths
                base_path = split_extension(image_path)[0]
                caption_path = base_path + args_dict["output_ext"]
                tag_path = base_path + args_dict["tag_ext"]
                
                # Get user prompt
                user_prompt = get_torii04_user_prompt(args_dict, tag_path)
                
                # Process image
                image = Image.open(image_path).convert("RGB")
                image = resize_image_proportionally(
                    image, 
                    args_dict["max_width"], 
                    args_dict["max_height"]
                )
                
                caption = handler.process_image(
                    system_prompt=system_prompt,
                    user_prompt=user_prompt,
                    image=image
                )
                
                # Save caption
                with open(caption_path, "w", encoding="utf-8") as f:
                    f.write(caption)
                
                result_queue.put(f"Worker {worker_id}: {image_path}")
            except Exception as e:
                result_queue.put(f"Worker {worker_id} error on {image_path}: {str(e)}")
    except Exception as e:
        result_queue.put(f"Worker {worker_id} failed: {str(e)}")