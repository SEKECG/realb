import os
from emoji_codec import EmojiCodec, CompressionMethod, VerificationMethod


class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'


def print_banner():
    print(f"{Colors.BLUE}{Colors.BOLD}")
    print("  ______                 _       _____      _       __ ")
    print(" |  ____|               (_)     / ____|    | |     /_ |")
    print(" | |__   _ __ ___   __ _ _ _ __| |     ___ | |__   _| |")
    print(" |  __| | '_ ` _ \\ / _` | | '__| |    / _ \\| '_ \\ / | |")
    print(" | |____| | | | | | (_| | | |  | |___| (_) | |_) | | |")
    print(" |______|_| |_| |_|\\__,_|_|_|   \\_____\\___/|_.__/  |_|")
    print(f"{Colors.ENDC}")


def print_menu():
    print(f"\n{Colors.BOLD}Main Menu:{Colors.ENDC}")
    print(f"{Colors.GREEN}1{Colors.ENDC} - Quick Encode/Decode")
    print(f"{Colors.GREEN}2{Colors.ENDC} - File Operations")
    print(f"{Colors.GREEN}3{Colors.ENDC} - Batch Processing")
    print(f"{Colors.GREEN}4{Colors.ENDC} - View Recipe Book")
    print(f"{Colors.GREEN}5{Colors.ENDC} - Settings")
    print(f"{Colors.RED}0{Colors.ENDC} - Exit")


def get_valid_input(prompt, valid_options) -> str:
    while True:
        choice = input(prompt).strip()
        if choice in valid_options:
            return choice
        print(f"{Colors.RED}Invalid choice. Please try again.{Colors.ENDC}")


def view_recipe_book():
    print(f"\n{Colors.BOLD}{Colors.HEADER}Recipe Book:{Colors.ENDC}")
    print(f"{Colors.BLUE}Quick (Base-64):{Colors.ENDC} Uses food emojis (🍅🍆🍇)")
    print(f"{Colors.CYAN}Light (Base-128):{Colors.ENDC} Uses activity emojis (🎰🎱🎲)")
    print(f"{Colors.GREEN}Classic (Base-256):{Colors.ENDC} Uses smiley emojis (😀😃😄)")
    print(f"{Colors.YELLOW}Gourmet (Base-1024):{Colors.ENDC} Uses extended emoji set (🤠🤡🤢)")


def handle_quick_operation(codec):
    operation = get_valid_input(
        f"{Colors.BOLD}Choose operation (1-encode, 2-decode):{Colors.ENDC} ",
        ['1', '2']
    )
    text = input("Enter text: ")
    if operation == '1':
        encoded = codec.encode(text)
        print(f"\n{Colors.GREEN}Encoded result:{Colors.ENDC}\n{encoded}")
        stats = codec.get_stats(text, encoded)
        print(f"\nStats: {stats}")
    else:
        decoded = codec.decode(text)
        print(f"\n{Colors.GREEN}Decoded result:{Colors.ENDC}\n{decoded}")


def handle_file_operations(codec):
    operation = get_valid_input(
        f"{Colors.BOLD}Choose operation (1-encode, 2-decode):{Colors.ENDC} ",
        ['1', '2']
    )
    input_path = input("Enter input file path: ")
    output_path = input("Enter output file path: ")
    
    try:
        result = codec.process_file(input_path, output_path, 'encode' if operation == '1' else 'decode')
        print(f"\n{Colors.GREEN}Operation successful:{Colors.ENDC}")
        print(f"Input: {result['input']}")
        print(f"Output: {result['output']}")
    except Exception as e:
        print(f"{Colors.RED}Error:{Colors.ENDC} {str(e)}")


def handle_batch_processing(codec):
    operation = get_valid_input(
        f"{Colors.BOLD}Choose operation (1-encode, 2-decode):{Colors.ENDC} ",
        ['1', '2']
    )
    file_pattern = input("Enter file pattern (e.g., *.txt): ")
    output_dir = input("Enter output directory: ")
    
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    try:
        results = codec.batch_process(file_pattern, output_dir, 'encode' if operation == '1' else 'decode')
        print(f"\n{Colors.GREEN}Batch operation completed:{Colors.ENDC}")
        for result in results:
            print(f"Processed: {result['input']} -> {result['output']}")
    except Exception as e:
        print(f"{Colors.RED}Error:{Colors.ENDC} {str(e)}")


def handle_settings(codec) -> EmojiCodec:
    print(f"\n{Colors.BOLD}Current Settings:{Colors.ENDC}")
    print(f"Recipe: {codec.recipe_type}")
    print(f"Compression: {codec.compression.name}")
    print(f"Verification: {codec.verification.name}")
    
    print(f"\n{Colors.BOLD}Change Settings:{Colors.ENDC}")
    recipe = get_valid_input(
        "Choose recipe (1-quick, 2-light, 3-classic, 4-gourmet): ",
        ['1', '2', '3', '4']
    )
    compression = get_valid_input(
        "Enable compression? (1-yes, 2-no): ",
        ['1', '2']
    )
    verification = get_valid_input(
        "Enable SHA256 verification? (1-yes, 2-no): ",
        ['1', '2']
    )
    
    recipe_map = {'1': 'quick', '2': 'light', '3': 'classic', '4': 'gourmet'}
    return EmojiCodec(
        recipe_type=recipe_map[recipe],
        compression=CompressionMethod.ZLIB if compression == '1' else CompressionMethod.NONE,
        verification=VerificationMethod.SHA256 if verification == '1' else VerificationMethod.NONE
    )


def main():
    print_banner()
    codec = EmojiCodec()
    
    while True:
        print_menu()
        choice = get_valid_input("Enter your choice (0-5): ", ['0', '1', '2', '3', '4', '5'])
        
        if choice == '0':
            print(f"{Colors.BLUE}Goodbye!{Colors.ENDC}")
            break
        elif choice == '1':
            handle_quick_operation(codec)
        elif choice == '2':
            handle_file_operations(codec)
        elif choice == '3':
            handle_batch_processing(codec)
        elif choice == '4':
            view_recipe_book()
        elif choice == '5':
            codec = handle_settings(codec)


if __name__ == "__main__":
    main()