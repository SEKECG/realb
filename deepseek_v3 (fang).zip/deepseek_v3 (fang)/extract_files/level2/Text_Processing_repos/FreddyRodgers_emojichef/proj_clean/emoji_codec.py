import base64
import hashlib
import zlib
from enum import Enum
from typing import Dict, List, Tuple


class CompressionMethod(Enum):
    NONE = 0
    ZLIB = 1


class VerificationMethod(Enum):
    NONE = 0
    SHA256 = 1


class FileHandler:
    @staticmethod
    def read_file(file_path) -> Tuple[bytes, str]:
        with open(file_path, 'rb') as f:
            content = f.read()
        mime_type = 'application/octet-stream'  # Default MIME type
        return content, mime_type

    @staticmethod
    def write_file(file_path, content):
        with open(file_path, 'wb') as f:
            f.write(content)


class EmojiCodec:
    RECIPES = {
        'quick': (64, 0x1F345),  # Base-64, food emojis
        'light': (128, 0x1F3B0),  # Base-128, activity emojis
        'classic': (256, 0x1F600),  # Base-256, smiley emojis
        'gourmet': (1024, 0x1F920)  # Base-1024, extended emoji set
    }

    def __init__(self, recipe_type='classic', compression=CompressionMethod.NONE, verification=VerificationMethod.NONE):
        self.recipe_type = recipe_type
        self.compression = compression
        self.verification = verification
        self._initialize_ingredients()

    def _initialize_ingredients(self):
        base_size, unicode_start = self.RECIPES[self.recipe_type]
        self.base_size = base_size
        self.bits_per_chunk = (base_size - 1).bit_length()
        self.mask = (1 << self.bits_per_chunk) - 1
        self.emoji_map = [chr(unicode_start + i) for i in range(base_size)]
        self.reverse_map = {e: i for i, e in enumerate(self.emoji_map)}

    def _process_data(self, data, compress) -> bytes:
        if compress and self.compression == CompressionMethod.ZLIB:
            return zlib.compress(data)
        return data

    def _unprocess_data(self, data, decompress) -> bytes:
        if decompress and self.compression == CompressionMethod.ZLIB:
            return zlib.decompress(data)
        return data

    def _calculate_hash(self, data) -> str:
        if self.verification == VerificationMethod.SHA256:
            return hashlib.sha256(data).hexdigest()
        return ''

    def _prepare_binary_data(self, data, mime_type=None) -> Dict:
        return {
            'content': base64.b64encode(data).decode('ascii'),
            'mime_type': mime_type,
            'size': len(data),
            'hash': self._calculate_hash(data)
        }

    def _restore_binary_data(self, data) -> bytes:
        prepared = eval(data) if isinstance(data, str) else data
        content = base64.b64decode(prepared['content'].encode('ascii'))
        if self.verification == VerificationMethod.SHA256:
            current_hash = self._calculate_hash(content)
            if current_hash != prepared.get('hash', ''):
                raise ValueError("Data integrity check failed")
        return content

    def _suggest_recipe(self, size) -> str:
        if size < 1024:
            return 'quick'
        elif size < 10240:
            return 'light'
        elif size < 102400:
            return 'classic'
        return 'gourmet'

    def encode(self, data) -> str:
        binary_data = data.encode('utf-8')
        processed = self._process_data(binary_data, True)
        result = []
        bits = 0
        buffer = 0

        for byte in processed:
            buffer = (buffer << 8) | byte
            bits += 8
            while bits >= self.bits_per_chunk:
                bits -= self.bits_per_chunk
                chunk = (buffer >> bits) & self.mask
                result.append(self.emoji_map[chunk])

        if bits > 0:
            chunk = (buffer << (self.bits_per_chunk - bits)) & self.mask
            result.append(self.emoji_map[chunk])

        return ''.join(result)

    def decode(self, emoji_data) -> str:
        buffer = 0
        bits = 0
        result = bytearray()

        for emoji in emoji_data:
            if emoji not in self.reverse_map:
                raise ValueError(f"Invalid emoji character: {emoji}")
            chunk = self.reverse_map[emoji]
            buffer = (buffer << self.bits_per_chunk) | chunk
            bits += self.bits_per_chunk
            while bits >= 8:
                bits -= 8
                result.append((buffer >> bits) & 0xFF)

        processed = bytes(result)
        unprocessed = self._unprocess_data(processed, True)
        return unprocessed.decode('utf-8')

    def encode_binary(self, data, mime_type=None) -> str:
        prepared = self._prepare_binary_data(data, mime_type)
        return self.encode(str(prepared))

    def decode_binary(self, encoded) -> Tuple[bytes, str]:
        prepared_str = self.decode(encoded)
        content = self._restore_binary_data(prepared_str)
        prepared = eval(prepared_str) if isinstance(prepared_str, str) else prepared_str
        return content, prepared.get('mime_type', 'application/octet-stream')

    def get_stats(self, original, encoded) -> Dict[str, float]:
        original_bytes = len(original.encode('utf-8'))
        encoded_length = len(encoded)
        actual_ratio = original_bytes / encoded_length
        theoretical_ratio = 8 / self.bits_per_chunk
        return {
            'original_bytes': original_bytes,
            'encoded_length': encoded_length,
            'actual_ratio': actual_ratio,
            'theoretical_ratio': theoretical_ratio,
            'bits_per_emoji': self.bits_per_chunk
        }

    def process_file(self, input_path, output_path, operation) -> Dict:
        if operation == 'encode':
            content, mime_type = FileHandler.read_file(input_path)
            encoded = self.encode_binary(content, mime_type)
            FileHandler.write_file(output_path, encoded.encode('utf-8'))
            return {'status': 'success', 'operation': 'encode', 'input': input_path, 'output': output_path}
        else:
            content, _ = FileHandler.read_file(input_path)
            decoded, mime_type = self.decode_binary(content.decode('utf-8'))
            FileHandler.write_file(output_path, decoded)
            return {'status': 'success', 'operation': 'decode', 'input': input_path, 'output': output_path}

    def batch_process(self, file_pattern, output_dir, operation) -> List[Dict]:
        import glob
        results = []
        for file_path in glob.glob(file_pattern):
            output_path = f"{output_dir}/{file_path.split('/')[-1]}.emj" if operation == 'encode' else f"{output_dir}/{file_path.split('/')[-1].replace('.emj', '')}"
            results.append(self.process_file(file_path, output_path, operation))
        return results

    def get_file_info(self, file_path) -> Dict:
        content, mime_type = FileHandler.read_file(file_path)
        size = len(content)
        suggested_recipe = self._suggest_recipe(size)
        return {
            'size': size,
            'mime_type': mime_type,
            'suggested_recipe': suggested_recipe
        }