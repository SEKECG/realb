from dataclasses import dataclass
from enum import Enum
from typing import Optional

class ResourceType(Enum):
    """Enumeration of resource types."""
    RESOURCE = "Resource"
    DATASOURCE = "Data Source"
    FUNCTION = "Function"
    GUIDE = "Guide"

@dataclass
class Resource:
    """Represents a OpenTofu resource, datasource, function or guide."""
    type: ResourceType
    name: str
    provider: 'Provider'
    _content: Optional[str] = None

    def __str__(self) -> str:
        from rich.text import Text
        type_color = {
            ResourceType.RESOURCE: "cyan",
            ResourceType.DATASOURCE: "magenta",
            ResourceType.FUNCTION: "green",
            ResourceType.GUIDE: "yellow"
        }.get(self.type, "white")
        return f"[{type_color}]{self.type.value[0]}[/] {self.name}"

    def __rich__(self):
        return str(self)

    def __lt__(self, other: 'Resource') -> bool:
        return self.name < other.name

    def __gt__(self, other: 'Resource') -> bool:
        return self.name > other.name

    def __hash__(self) -> int:
        return hash((self.provider.name, self.type, self.name))

    @property
    def content(self) -> str:
        """Get the content of this resource."""
        if self._content is None:
            # Load content from API/cache
            pass
        return self._content or "No content available"