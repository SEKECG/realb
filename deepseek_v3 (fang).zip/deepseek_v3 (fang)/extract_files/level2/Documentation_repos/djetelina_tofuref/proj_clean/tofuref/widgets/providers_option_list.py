import logging
from typing import Any, Dict

from textual.app import ComposeResult
from textual.binding import Binding
from textual.widgets import OptionList
from textual.widgets.option_list import Option

from ..data.providers import Provider

LOGGER = logging.getLogger(__name__)

class ProvidersOptionList(OptionList):
    """Widget for displaying and selecting providers."""
    BINDINGS = [
        Binding("escape", "close", "Close", show=False),
    ]

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.border_title = "Providers"
        self.border_subtitle = "0 providers"

    def load_index(self) -> Dict[str, Provider]:
        """Load provider index from API/cache."""
        # Implementation would fetch providers
        return {}

    def populate(self, providers: Dict[str, Provider]) -> None:
        """Populate the list with providers."""
        self.clear_options()
        options = []
        for provider in providers.values():
            options.append(Option(provider.display_name, id=provider))
        self.add_options(options)
        self.border_subtitle = f"{len(options)} providers"

    def on_option_selected(self, option: Option) -> None:
        """Handle provider selection."""
        provider = option.id
        self.notify(f"Selected: {provider.display_name}")