VIM_OPTION_LIST_NAVIGATE = [
    ("j", "cursor_down", "Down"),
    ("k", "cursor_up", "Up"),
    ("h", "cursor_left", "Left"),
    ("l", "cursor_right", "Right"),
    ("gg", "home", "Home"),
    ("G", "end", "End"),
]