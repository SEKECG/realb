from typing import Any

from textual.app import ComposeResult
from textual.binding import Binding
from textual.widgets import Input

class SearchInput(Input):
    """Custom search input widget."""
    BINDINGS = [
        Binding("escape", "close", "Close", show=False),
    ]

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(placeholder="Search...", id="search", classes="search", **kwargs)
        self.border_title = "Search"

    def action_close(self) -> None:
        """Close the search input."""
        self.value = ""
        self.post_message(self.Changed(self, ""))
        self.post_message(self.Submitted(self, None))