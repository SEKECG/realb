from typing import Any

from textual.app import ComposeResult
from textual.binding import Binding
from textual.widgets import OptionList
from textual.widgets.option_list import Option

from ..data.providers import Provider
from ..data.resources import Resource, ResourceType

class ResourcesOptionList(OptionList):
    """Widget for displaying and selecting resources."""
    BINDINGS = [
        Binding("escape", "close", "Close", show=False),
    ]

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.border_title = "Resources"
        self.border_subtitle = "No provider selected"
        self.highlighted = None
        self.loading = False

    def load_provider_resources(self, provider: Provider) -> None:
        """Load resources for a provider."""
        self.loading = True
        provider.load_resources()
        self.loading = False

    def populate(self, provider: Provider, resources: list[Resource] = None) -> None:
        """Populate the list with resources."""
        self.clear_options()
        if resources is None:
            resources = []
            if provider.resources:
                resources.extend(provider.resources)
            if provider.datasources:
                resources.extend(provider.datasources)
            if provider.functions:
                resources.extend(provider.functions)
            if provider.guides:
                resources.extend(provider.guides)

        options = []
        for resource in sorted(resources):
            options.append(Option(str(resource), id=resource))
        
        self.add_options(options)
        self.border_subtitle = f"{len(options)} items"
        self.highlighted = 0 if options else None

    def on_option_selected(self, option: Option) -> None:
        """Handle resource selection."""
        resource = option.id
        self.notify(f"Selected: {resource.name}")