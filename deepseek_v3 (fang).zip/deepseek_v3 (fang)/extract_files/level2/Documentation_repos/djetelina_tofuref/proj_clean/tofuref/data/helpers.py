import json as jsonlib
import logging
import re
from pathlib import Path
from typing import Any, Optional, Tuple, Union

LOGGER = logging.getLogger(__name__)
CODEBLOCK_REGEX = re.compile(r"```.*?\n.*?```", re.DOTALL)

def cached_file_path(endpoint: str) -> Path:
    """Generate a file path in the cache directory for a given endpoint."""
    cache_dir = Path.home() / ".cache" / "tofuref"
    cache_dir.mkdir(parents=True, exist_ok=True)
    return cache_dir / endpoint.replace("/", "_")

def get_from_cache(endpoint: str) -> Optional[str]:
    """Retrieve cached content from a specified endpoint."""
    file_path = cached_file_path(endpoint)
    if file_path.exists():
        return file_path.read_text()
    return None

def save_to_cache(endpoint: str, contents: str) -> None:
    """Save the given contents to a cache file."""
    file_path = cached_file_path(endpoint)
    file_path.write_text(contents)

def header_markdown_split(contents: str) -> Tuple[dict, str]:
    """Split YAML header from markdown content."""
    if contents.startswith("---\n"):
        parts = contents.split("---\n", 2)
        if len(parts) == 3:
            try:
                header = jsonlib.loads(parts[1])
                return header, parts[2]
            except jsonlib.JSONDecodeError:
                pass
    return {}, contents

def is_provider_index_expired(file: Path, timeout: int = 31 * 24 * 60 * 60) -> bool:
    """Check if provider index cache is expired."""
    if not file.exists():
        return True
    return (file.stat().st_mtime + timeout) < time.time()

def get_registry_api(
    endpoint: str,
    json: bool = True,
    log_widget: Any = None,
    timeout: int = 10,
) -> Union[dict, str]:
    """Fetch data from OpenTofu registry API."""
    # Implementation would make HTTP requests here
    pass