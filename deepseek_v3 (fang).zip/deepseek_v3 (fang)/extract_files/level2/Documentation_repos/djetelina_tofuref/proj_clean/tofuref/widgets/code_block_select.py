from typing import Any, List

from textual.app import ComposeResult
from textual.binding import Binding
from textual.widgets import OptionList
from textual.widgets.option_list import Option

class CodeBlockSelect(OptionList):
    """Widget for selecting code blocks from documentation."""
    BINDINGS = [
        Binding("escape", "close", "Close", show=False),
    ]

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.border_title = "Code Blocks"
        self.highlighted = None

    def action_close(self) -> None:
        """Close the code block selector."""
        self.remove()

    def set_new_options(self, code_blocks: List[str]) -> None:
        """Set new code block options."""
        options = []
        for i, block in enumerate(code_blocks):
            options.append(Option(f"Block {i+1}", id=block))
        self.clear_options()
        self.add_options(options)
        self.highlighted = 0

    def on_option_selected(self, option: Option) -> None:
        """Handle code block selection."""
        # Copy to clipboard would be implemented here
        self.notify(f"Copied: {option.id[:50]}...")
        self.action_close()