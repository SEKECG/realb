from typing import Any

from textual.app import ComposeResult
from textual.binding import Binding
from textual.widgets import MarkdownViewer

class ContentWindow(MarkdownViewer):
    """Widget for displaying markdown content with navigation."""
    ALLOW_MAXIMIZE = True
    BINDINGS = [
        Binding("t", "toggle_toc", "TOC"),
        Binding("y", "yank", "Yank Code"),
        Binding("up", "up", "Up", show=False),
        Binding("down", "down", "Down", show=False),
        Binding("pageup", "page_up", "Page Up", show=False),
        Binding("pagedown", "page_down", "Page Down", show=False),
        Binding("home", "scroll_home", "Home", show=False),
        Binding("end", "scroll_end", "End", show=False),
    ]

    def __init__(self, content: str = "", **kwargs: Any) -> None:
        super().__init__(content, **kwargs)
        self.show_table_of_contents = False

    def action_toggle_toc(self) -> None:
        """Toggle table of contents visibility."""
        self.show_table_of_contents = not self.show_table_of_contents
        if not self.document.table_of_contents:
            self.border_title = "Empty TOC"
        self.focus()

    def action_yank(self) -> None:
        """Extract code blocks for copying."""
        # Implementation would extract code blocks
        pass

    def update(self, markdown: str) -> None:
        """Update the content with new markdown."""
        self.document.load(markdown)
        self.refresh()

    def go(self, location: str) -> None:
        """Override default link handling."""
        self.notify(f"Link: {location}")