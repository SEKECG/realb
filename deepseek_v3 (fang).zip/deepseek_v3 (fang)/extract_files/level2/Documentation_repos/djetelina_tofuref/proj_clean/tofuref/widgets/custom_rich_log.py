from typing import Any

from rich.text import Text
from textual.widgets import RichLog

class CustomRichLog(RichLog):
    """Custom rich log widget with styling."""
    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.border_title = "Log"
        self.border_subtitle = "v0.1.0"
        self.display = False