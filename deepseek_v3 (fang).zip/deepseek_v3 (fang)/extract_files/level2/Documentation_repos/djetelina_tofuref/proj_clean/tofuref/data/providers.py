from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from .resources import Resource

@dataclass
class Provider:
    """Represents a OpenTofu provider with its metadata and resources."""
    organization: str
    name: str
    description: str
    fork_of: Optional[str] = None
    popularity: int = 0
    versions: List[Dict[str, str]] = None
    resources: List[Resource] = None
    datasources: List[Resource] = None
    functions: List[Resource] = None
    guides: List[Resource] = None
    log_widget: Any = None
    raw_json: Optional[Dict] = None
    _active_version: Optional[str] = None
    _overview: Optional[str] = None

    def __rich__(self):
        from rich.json import JSON
        data = {k: v for k, v in self.__dict__.items() 
                if k not in ("raw_json", "versions")}
        return JSON.from_data(data)

    @property
    def endpoint(self) -> str:
        """Construct registry API endpoint for this provider."""
        return f"{self.organization}/{self.name}/{self.active_version}"

    @property
    def active_version(self) -> str:
        """Get the currently active version."""
        if self._active_version is None and self.versions:
            self._active_version = self.versions[0]["version"]
        return self._active_version

    @active_version.setter
    def active_version(self, value: str) -> None:
        """Set the active version."""
        self._active_version = value

    @property
    def display_name(self) -> str:
        """Get display name in format 'org/name'."""
        return f"{self.organization}/{self.name}"

    @property
    def use_configuration(self) -> str:
        """Generate provider configuration snippet."""
        return f'provider "{self.name}" {{\n  # Configuration options\n}}'

    def overview(self) -> str:
        """Get provider overview documentation."""
        if self._overview is None:
            # Load overview from API/cache
            pass
        return self._overview or "No overview available"

    def load_resources(self) -> None:
        """Load all resources for this provider."""
        # Implementation would fetch resources from API
        pass

    @classmethod
    def from_json(cls, data: Dict) -> "Provider":
        """Create Provider instance from JSON data."""
        return cls(
            organization=data.get("organization"),
            name=data.get("name"),
            description=data.get("description"),
            fork_of=data.get("fork_of"),
            popularity=data.get("popularity", 0),
            versions=data.get("versions", []),
            raw_json=data
        )