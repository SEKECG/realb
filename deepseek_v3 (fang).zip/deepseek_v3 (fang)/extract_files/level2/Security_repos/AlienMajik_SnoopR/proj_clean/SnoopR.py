#!/usr/bin/env python3
"""
SnoopR - Kismet Device Visualization and Analysis Tool
"""

import sqlite3
import json
import os
import glob
import datetime
import math
import collections
import logging
import argparse
import folium
from folium.plugins import MarkerCluster

# Constants
DEVICE_TYPE_MAPPING = {
    0: "Wi-Fi AP",
    1: "Wi-Fi Client",
    2: "Bluetooth",
    3: "Bluetooth LE",
    4: "Zigbee",
    5: "IEEE 802.15.4",
    6: "RFID",
    7: "ADS-B",
    8: "Other"
}

# Known drone identifiers
known_drone_ssids = [
    "DJI",
    "Parrot",
    "Phantom",
    "Mavic",
    "Spark",
    "Inspire",
    "Matrice",
    "Anafi"
]

known_drone_mac_prefixes = [
    "60:60:1F",  # DJI
    "90:03:B7",  # DJI
    "A0:14:3D",  # DJI
    "00:12:1C",  # Parrot
    "00:26:7E",  # Parrot
    "90:03:B7"   # DJI
]

def parse_arguments():
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(description='SnoopR - Kismet Device Visualization and Analysis Tool')
    parser.add_argument('-d', '--directory', help='Directory containing Kismet database file', default='.')
    parser.add_argument('-o', '--output', help='Output HTML map filename', default='snoopr_map.html')
    parser.add_argument('-t', '--threshold', type=float, 
                       help='Movement threshold in miles to consider a device as a snooper', default=0.05)
    parser.add_argument('-v', '--verbose', action='store_true', help='Enable verbose logging')
    return parser.parse_args()

def find_most_recent_kismet_file(directory):
    """Find the most recently modified .kismet file in the specified directory."""
    kismet_files = glob.glob(os.path.join(directory, '*.kismet'))
    if not kismet_files:
        return None
    return max(kismet_files, key=os.path.getmtime)

def is_valid_lat_lon(lat, lon):
    """Validate latitude and longitude values."""
    return (-90 <= lat <= 90) and (-180 <= lon <= 180)

def haversine(lon1, lat1, lon2, lat2):
    """
    Calculate the great circle distance between two points on the Earth (specified in decimal degrees).
    Returns distance in miles.
    """
    # Convert decimal degrees to radians
    lon1, lat1, lon2, lat2 = map(math.radians, [lon1, lat1, lon2, lat2])

    # Haversine formula
    dlon = lon2 - lon1 
    dlat = lat2 - lat1 
    a = math.sin(dlat/2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon/2)**2
    c = 2 * math.asin(math.sqrt(a)) 
    r = 3956  # Radius of Earth in miles
    return c * r

def is_drone(ssid, mac_address):
    """Detect if a device is a known drone by checking SSID or MAC address prefix."""
    if not ssid and not mac_address:
        return False
    
    if ssid:
        ssid_lower = ssid.lower()
        for drone_ssid in known_drone_ssids:
            if drone_ssid.lower() in ssid_lower:
                return True
    
    if mac_address:
        mac_prefix = mac_address[:8].upper()
        for prefix in known_drone_mac_prefixes:
            if mac_prefix.startswith(prefix):
                return True
    
    return False

def sanitize_string(s):
    """Sanitize strings to prevent Jinja2 parsing errors."""
    if not s:
        return ""
    return str(s).replace('"', "'").replace('\n', ' ').replace('\r', '')

def extract_device_detections(kismet_file):
    """
    Extract device detections from the Kismet SQLite database.
    
    Returns:
        dict: Dictionary with MAC addresses as keys and lists of detection dictionaries as values.
    """
    device_detections = collections.defaultdict(list)
    
    try:
        conn = sqlite3.connect(kismet_file)
        cursor = conn.cursor()
        
        # Query devices and their locations
        cursor.execute("""
            SELECT devkey, type, mac, phyname, first_time, last_time, 
                   strongest_signal, min_lat, min_lon, max_lat, max_lon, 
                   avg_lat, avg_lon, device, json
            FROM devices
        """)
        
        for row in cursor.fetchall():
            devkey, devtype, mac, phyname, first_time, last_time, strongest_signal, \
            min_lat, min_lon, max_lat, max_lon, avg_lat, avg_lon, device, json_data = row
            
            # Parse JSON data if available
            device_info = {}
            if json_data:
                try:
                    device_info = json.loads(json_data)
                except json.JSONDecodeError:
                    pass
            
            # Get SSID/name
            ssid = device_info.get('kismet.device.base.name', '')
            if not ssid and device:
                ssid = device
            
            # Determine device type
            device_type = DEVICE_TYPE_MAPPING.get(devtype, "Unknown")
            
            # Create detection dictionary
            detection = {
                'mac': mac,
                'type': device_type,
                'phy': phyname,
                'ssid': sanitize_string(ssid),
                'first_seen': first_time,
                'last_seen': last_time,
                'signal': strongest_signal,
                'min_lat': min_lat,
                'min_lon': min_lon,
                'max_lat': max_lat,
                'max_lon': max_lon,
                'avg_lat': avg_lat,
                'avg_lon': avg_lon,
                'is_drone': is_drone(ssid, mac),
                'device_info': device_info
            }
            
            # Only add if we have valid coordinates
            if is_valid_lat_lon(avg_lat, avg_lon):
                device_detections[mac].append(detection)
        
        conn.close()
    except sqlite3.Error as e:
        logging.error(f"SQLite error: {e}")
    
    return device_detections

def detect_snoopers(device_detections, movement_threshold):
    """
    Detect potential snoopers based on device movement.
    
    Returns:
        List[dict]: List of snooper device dictionaries.
    """
    snoopers = []
    
    for mac, detections in device_detections.items():
        # Sort detections by time
        sorted_detections = sorted(detections, key=lambda x: x['last_seen'])
        
        total_distance = 0
        path_points = []
        
        # Compare consecutive detections
        for i in range(1, len(sorted_detections)):
            prev = sorted_detections[i-1]
            curr = sorted_detections[i]
            
            if not is_valid_lat_lon(prev['avg_lat'], prev['avg_lon']) or \
               not is_valid_lat_lon(curr['avg_lat'], curr['avg_lon']):
                continue
            
            distance = haversine(
                prev['avg_lon'], prev['avg_lat'],
                curr['avg_lon'], curr['avg_lat']
            )
            
            total_distance += distance
            path_points.append((curr['avg_lat'], curr['avg_lon']))
        
        # If total movement exceeds threshold, mark as snooper
        if total_distance > movement_threshold and len(path_points) > 1:
            snooper = sorted_detections[-1].copy()
            snooper['total_distance'] = total_distance
            snooper['path_points'] = path_points
            snoopers.append(snooper)
    
    return snoopers

def extract_alerts_from_kismet(kismet_file):
    """Extract alerts from the Kismet SQLite database."""
    alerts = []
    
    try:
        conn = sqlite3.connect(kismet_file)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT timestamp, header, message, lat, lon, json
            FROM alerts
        """)
        
        for row in cursor.fetchall():
            timestamp, header, message, lat, lon, json_data = row
            
            alert_info = {}
            if json_data:
                try:
                    alert_info = json.loads(json_data)
                except json.JSONDecodeError:
                    pass
            
            alert = {
                'timestamp': timestamp,
                'header': sanitize_string(header),
                'message': sanitize_string(message),
                'lat': lat,
                'lon': lon,
                'alert_info': alert_info
            }
            
            alerts.append(alert)
        
        conn.close()
    except sqlite3.Error as e:
        logging.error(f"SQLite error: {e}")
    
    return alerts

def visualize_devices_snoopers_and_alerts(device_detections, snoopers, alerts, output_map_file):
    """Visualizes devices, snoopers, and alerts on a Folium map."""
    if not device_detections and not snoopers and not alerts:
        logging.warning("No data to visualize")
        return
    
    # Find center of all points
    all_lats = []
    all_lons = []
    
    for detections in device_detections.values():
        for d in detections:
            if is_valid_lat_lon(d['avg_lat'], d['avg_lon']):
                all_lats.append(d['avg_lat'])
                all_lons.append(d['avg_lon'])
    
    for alert in alerts:
        if is_valid_lat_lon(alert['lat'], alert['lon']):
            all_lats.append(alert['lat'])
            all_lons.append(alert['lon'])
    
    if not all_lats or not all_lons:
        logging.error("No valid coordinates found for map center")
        return
    
    center_lat = sum(all_lats) / len(all_lats)
    center_lon = sum(all_lons) / len(all_lons)
    
    # Create map
    m = folium.Map(location=[center_lat, center_lon], zoom_start=15)
    
    # Create feature groups for different elements
    fg_devices = folium.FeatureGroup(name="Devices")
    fg_snoopers = folium.FeatureGroup(name="Snoopers")
    fg_alerts = folium.FeatureGroup(name="Alerts")
    
    # Cluster for regular devices
    device_cluster = MarkerCluster().add_to(fg_devices)
    
    # Add devices to map
    device_colors = {
        "Wi-Fi AP": "blue",
        "Wi-Fi Client": "green",
        "Bluetooth": "purple",
        "Bluetooth LE": "darkpurple",
        "Zigbee": "orange",
        "IEEE 802.15.4": "beige",
        "RFID": "red",
        "ADS-B": "cadetblue",
        "Other": "gray"
    }
    
    for mac, detections in device_detections.items():
        if not detections:
            continue
        
        # Use the most recent detection
        detection = detections[-1]
        lat, lon = detection['avg_lat'], detection['avg_lon']
        
        if not is_valid_lat_lon(lat, lon):
            continue
        
        # Customize icon based on device type
        device_type = detection['type']
        color = device_colors.get(device_type, "gray")
        
        if detection['is_drone']:
            color = "red"
            icon = folium.Icon(color=color, icon="plane", prefix="fa")
        else:
            icon = folium.Icon(color=color)
        
        # Create popup content
        popup_content = f"""
            <b>MAC:</b> {mac}<br>
            <b>Type:</b> {device_type}<br>
            <b>SSID:</b> {detection['ssid']}<br>
            <b>First Seen:</b> {detection['first_seen']}<br>
            <b>Last Seen:</b> {detection['last_seen']}<br>
            <b>Signal:</b> {detection['signal']} dBm
        """
        
        if detection['is_drone']:
            popup_content += "<br><b>DRONE DETECTED</b>"
        
        folium.Marker(
            location=[lat, lon],
            popup=folium.Popup(popup_content, max_width=300),
            icon=icon,
            tooltip=f"{device_type}: {detection['ssid']}"
        ).add_to(device_cluster)
    
    # Add snoopers to map with paths
    for snooper in snoopers:
        lat, lon = snooper['avg_lat'], snooper['avg_lon']
        
        if not is_valid_lat_lon(lat, lon):
            continue
        
        # Create path line
        if len(snooper['path_points']) > 1:
            folium.PolyLine(
                locations=snooper['path_points'],
                color='red',
                weight=2.5,
                opacity=1
            ).add_to(fg_snoopers)
        
        # Create marker
        popup_content = f"""
            <b>Snooper Detected</b><br>
            <b>MAC:</b> {snooper['mac']}<br>
            <b>Type:</b> {snooper['type']}<br>
            <b>SSID:</b> {snooper['ssid']}<br>
            <b>Total Movement:</b> {snooper['total_distance']:.2f} miles<br>
            <b>Last Seen:</b> {snooper['last_seen']}
        """
        
        folium.Marker(
            location=[lat, lon],
            popup=folium.Popup(popup_content, max_width=300),
            icon=folium.Icon(color='red', icon='exclamation-triangle', prefix='fa'),
            tooltip=f"Snooper: {snooper['mac']}"
        ).add_to(fg_snoopers)
    
    # Add alerts to map
    for alert in alerts:
        lat, lon = alert['lat'], alert['lon']
        
        if not is_valid_lat_lon(lat, lon):
            continue
        
        popup_content = f"""
            <b>Alert:</b> {alert['header']}<br>
            <b>Time:</b> {alert['timestamp']}<br>
            <b>Message:</b> {alert['message']}
        """
        
        folium.Marker(
            location=[lat, lon],
            popup=folium.Popup(popup_content, max_width=300),
            icon=folium.Icon(color='orange', icon='exclamation-circle', prefix='fa'),
            tooltip=f"Alert: {alert['header']}"
        ).add_to(fg_alerts)
    
    # Add feature groups to map
    m.add_child(fg_devices)
    m.add_child(fg_snoopers)
    m.add_child(fg_alerts)
    
    # Add layer control
    folium.LayerControl().add_to(m)
    
    # Save map
    m.save(output_map_file)
    logging.info(f"Map saved to {output_map_file}")

def main():
    """Main function to process Kismet data and generate visualization."""
    args = parse_arguments()
    
    # Configure logging
    log_level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(level=log_level, format='%(asctime)s - %(levelname)s - %(message)s')
    
    # Find Kismet database file
    kismet_file = find_most_recent_kismet_file(args.directory)
    if not kismet_file:
        logging.error("No Kismet database file found in directory")
        return
    
    logging.info(f"Processing Kismet file: {kismet_file}")
    
    # Extract device detections
    device_detections = extract_device_detections(kismet_file)
    if not device_detections:
        logging.warning("No device detections found in database")
    else:
        logging.info(f"Found {len(device_detections)} unique devices")
    
    # Detect snoopers
    snoopers = detect_snoopers(device_detections, args.threshold)
    if snoopers:
        logging.info(f"Found {len(snoopers)} potential snoopers")
    else:
        logging.info("No potential snoopers detected")
    
    # Extract alerts
    alerts = extract_alerts_from_kismet(kismet_file)
    if alerts:
        logging.info(f"Found {len(alerts)} alerts")
    else:
        logging.info("No alerts found in database")
    
    # Visualize data
    visualize_devices_snoopers_and_alerts(device_detections, snoopers, alerts, args.output)

if __name__ == "__main__":
    main()