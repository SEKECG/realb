import json
import os
import re
import shutil
import subprocess
import tempfile
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import httpx
from pydantic import BaseModel, ValidationError, validator

# Constants
CODE_FILES_FIELD = "code_files"
CONFIG_FIELD = "config"
DEFAULT_TIMEOUT = 300  # 5 mins in seconds
RULE_FIELD = "rule"
RULE_ID_FIELD = "rule_id"
SEMGREP_API_URL = "https://semgrep.dev/api"
SEMGREP_URL = "https://semgrep.dev"

# Global Variables
_semgrep_lock = threading.Lock()
semgrep_executable: Optional[str] = None
http_client = httpx.Client()

class CodeFile(BaseModel):
    """Represent a code file with its filename and content for storage or processing."""
    filename: str
    content: str

class CodeWithLanguage(BaseModel):
    """Define a data structure to represent a code snippet along with its associated programming language, defaulting to Python if not specified."""
    content: str
    language: str = "python"

class SemgrepScanResult(BaseModel):
    """Store and structure the results of a Semgrep scan, including version information, scan results, errors, scanned file paths, and skipped rules."""
    version: str
    results: List[Dict[str, Any]]
    errors: List[Dict[str, Any]]
    paths: Dict[str, Any]
    skipped_rules: List[str]

def main(transport=None):
    """Entry point for the MCP server

    Supports both stdio and sse transports. For stdio, it will read from stdin and write to stdout.
    For sse, it will start an HTTP server on port 8000.
    """
    # Implementation would depend on the MCP framework being used
    pass

def create_temp_files_from_code_content(code_files):
    """Utility functions for handling code content    Creates temporary files from code content

    Args:
        code_files: List of CodeFile objects

    Returns:
        Path to temporary directory containing the files

    Raises:
        McpError: If there are issues creating or writing to files
    """
    temp_dir = tempfile.mkdtemp()
    try:
        for code_file in code_files:
            file_path = safe_join(temp_dir, code_file.filename)
            with open(file_path, 'w') as f:
                f.write(code_file.content)
        return temp_dir
    except Exception as e:
        shutil.rmtree(temp_dir, ignore_errors=True)
        raise RuntimeError(f"Failed to create temporary files: {str(e)}")

def ensure_semgrep_available():
    """Ensures semgrep is available and sets the global path in a thread-safe manner

    Returns:
        Path to semgrep executable

    Raises:
        McpError: If semgrep is not installed or not found
    """
    global semgrep_executable
    with _semgrep_lock:
        if semgrep_executable is None:
            semgrep_executable = find_semgrep_path()
            if semgrep_executable is None:
                raise RuntimeError("Semgrep not found. Please install semgrep first.")
        return semgrep_executable

def find_semgrep_path():
    """Semgrep utilities    Dynamically find semgrep in PATH or common installation directories
    Returns: Path to semgrep executable or None if not found
    
    Common paths where semgrep might be installed
    """
    common_paths = [
        "/usr/local/bin/semgrep",
        "/usr/bin/semgrep",
        "/opt/homebrew/bin/semgrep",
        os.path.expanduser("~/.local/bin/semgrep"),
    ]
    
    # Check PATH first
    semgrep_path = shutil.which("semgrep")
    if semgrep_path:
        return semgrep_path
    
    # Check common paths
    for path in common_paths:
        if os.path.exists(path):
            return path
    
    return None

def get_abstract_syntax_tree(code, language):
    """Returns the Abstract Syntax Tree (AST) for the provided code file in JSON format

    Use this tool when you need to:
      - get the Abstract Syntax Tree (AST) for the provided code file\
      - get the AST of a file
      - understand the structure of the code in a more granular way
      - see what a parser sees in the code
    """
    semgrep_path = ensure_semgrep_available()
    with tempfile.NamedTemporaryFile(mode='w', suffix='.tmp') as tmp_file:
        tmp_file.write(code)
        tmp_file.flush()
        cmd = [semgrep_path, '--json', '--dump-ast', tmp_file.name, '--lang', language]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=DEFAULT_TIMEOUT)
        if result.returncode != 0:
            raise RuntimeError(f"Failed to get AST: {result.stderr}")
        return result.stdout

def get_semgrep_rule_schema():
    """Specification of the Semgrep rule YAML syntax using JSON schema."""
    return json.dumps({
        "$schema": "http://json-schema.org/draft-07/schema#",
        "title": "Semgrep Rule Schema",
        "type": "object",
        "properties": {
            "rules": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "id": {"type": "string"},
                        "message": {"type": "string"},
                        "pattern": {"type": "string"},
                        "languages": {"type": "array", "items": {"type": "string"}},
                        "severity": {"type": "string", "enum": ["INFO", "WARNING", "ERROR"]}
                    },
                    "required": ["id", "message", "pattern", "languages"]
                }
            }
        },
        "required": ["rules"]
    })

def get_semgrep_rule_yaml(rule_id):
    """Full Semgrep rule in YAML format from the Semgrep registry."""
    try:
        response = http_client.get(f"{SEMGREP_API_URL}/v1/registry/rule/{rule_id}")
        response.raise_for_status()
        return response.text
    except httpx.HTTPError as e:
        raise RuntimeError(f"Failed to fetch rule from registry: {str(e)}")

def get_semgrep_scan_args(temp_dir, config):
    """Builds command arguments for semgrep scan

    Args:
        temp_dir: Path to temporary directory containing the files
        config: Optional Semgrep configuration (e.g. "auto" or absolute path to rule file)

    Returns:
        List of command arguments
    """
    args = [ensure_semgrep_available(), '--json', '--quiet']
    if config:
        args.extend(['--config', config])
    args.append(temp_dir)
    return args

def get_supported_languages():
    """Returns a list of supported languages by Semgrep

    Only use this tool if you are not sure what languages Semgrep supports.
    """
    semgrep_path = ensure_semgrep_available()
    result = subprocess.run([semgrep_path, '--show-supported-languages'], capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError(f"Failed to get supported languages: {result.stderr}")
    return result.stdout.splitlines()

def remove_temp_dir_from_results(results, temp_dir):
    """Clean the results from semgrep by converting temporary file paths back to
    original relative paths

    Args:
        results: SemgrepScanResult object containing semgrep results
        temp_dir: Path to temporary directory used for scanning
    
    Process findings results
    """
    if not isinstance(results, dict):
        return
    
    temp_dir_str = str(temp_dir)
    for result in results.get('results', []):
        if 'path' in result:
            result['path'] = result['path'].replace(temp_dir_str + '/', '')

def run_semgrep(args):
    """Runs semgrep with the given arguments

    Args:
        args: List of command arguments

    Returns:
        Output of semgrep command
    """
    try:
        result = subprocess.run(args, capture_output=True, text=True, timeout=DEFAULT_TIMEOUT)
        if result.returncode != 0 and result.returncode != 1:  # Semgrep returns 1 when findings are found
            raise RuntimeError(f"Semgrep failed: {result.stderr}")
        return result.stdout
    except subprocess.TimeoutExpired:
        raise RuntimeError("Semgrep scan timed out")

def safe_join(base_dir, untrusted_path):
    """Joins a base directory with an untrusted relative path and ensures the final path
    doesn't escape the base directory.

    Args:
        base_dir: The base directory to join the untrusted path to
        untrusted_path: The untrusted relative path to join to the base directory
    
    Absolute, normalized path to the base directory
    """
    base_path = Path(base_dir).resolve()
    full_path = (base_path / untrusted_path).resolve()
    
    if not full_path.is_relative_to(base_path):
        raise ValueError(f"Path {untrusted_path} attempts to escape base directory")
    
    return str(full_path)

def security_check(code_files):
    """Runs a fast security check on code and returns any issues found.

    Use this tool when you need to:
      - scan code for security vulnerabilities
      - verify that code is secure
      - double check that code is secure before committing
      - get a second opinion on code security

    If there are no issues, you can be reasonably confident that the code is secure.
    
    Validate code_files
    """
    validate_code_files(code_files)
    temp_dir = create_temp_files_from_code_content(code_files)
    try:
        args = get_semgrep_scan_args(temp_dir, "p/security")
        output = run_semgrep(args)
        results = json.loads(output)
        remove_temp_dir_from_results(results, temp_dir)
        return json.dumps(results)
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)

def semgrep_rule_schema():
    """Get the schema for a Semgrep rule

    Use this tool when you need to:
      - get the schema required to write a Semgrep rule
      - need to see what fields are available for a Semgrep rule
      - verify what fields are available for a Semgrep rule
      - verify the syntax for a Semgrep rule is correct
    """
    return get_semgrep_rule_schema()

def semgrep_scan(code_files, config):
    """Runs a Semgrep scan on provided code content and returns the findings in JSON format

    Use this tool when you need to:
      - scan code files for security vulnerabilities
      - scan code files for other issues
    
    Validate config
    """
    validate_code_files(code_files)
    config = validate_config(config)
    temp_dir = create_temp_files_from_code_content(code_files)
    try:
        args = get_semgrep_scan_args(temp_dir, config)
        output = run_semgrep(args)
        results = json.loads(output)
        remove_temp_dir_from_results(results, temp_dir)
        return SemgrepScanResult(**results)
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)

def semgrep_scan_with_custom_rule(code_files, rule):
    """Runs a Semgrep scan with a custom rule on provided code content
    and returns the findings in JSON format

    Use this tool when you need to:
      - scan code files for specific security vulnerability not covered by the default Semgrep rules
      - scan code files for specific issue not covered by the default Semgrep rules
    
    Validate code_files
    """
    validate_code_files(code_files)
    temp_dir = create_temp_files_from_code_content(code_files)
    try:
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml') as rule_file:
            rule_file.write(rule)
            rule_file.flush()
            args = get_semgrep_scan_args(temp_dir, rule_file.name)
            output = run_semgrep(args)
            results = json.loads(output)
            remove_temp_dir_from_results(results, temp_dir)
            return SemgrepScanResult(**results)
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)

def validate_absolute_path(path_to_validate, param_name):
    """Path validationValidates an absolute path to ensure it's safe to use"""
    if not os.path.isabs(path_to_validate):
        raise ValueError(f"{param_name} must be an absolute path")
    return path_to_validate

def validate_code_files(code_files):
    """Validates the code_files parameter for semgrep scan using Pydantic validation

    Args:
        code_files: List of CodeFile objects

    Raises:
        McpError: If validation fails
    """
    if not code_files:
        raise ValueError("At least one code file must be provided")
    for code_file in code_files:
        if not isinstance(code_file, dict):
            raise ValueError("Each code file must be a dictionary with 'filename' and 'content' keys")
        if 'filename' not in code_file or 'content' not in code_file:
            raise ValueError("Each code file must have 'filename' and 'content' keys")
        if not isinstance(code_file['filename'], str) or not isinstance(code_file['content'], str):
            raise ValueError("Filename and content must be strings")

def validate_config(config):
    """Validates semgrep configuration parameter
    Allow registry references (p/ci, p/security, etc.)"""
    if not config:
        return None
    if isinstance(config, str):
        if config.startswith('p/') or config == 'auto':
            return config
        if os.path.exists(config):
            return config
    raise ValueError("Invalid semgrep config. Must be a registry reference (e.g. 'p/security') or path to rule file")

def write_custom_semgrep_rule(code, language):
    """Write a custom Semgrep rule for the provided code and language

    Use this prompt when you need to:
      - write a custom Semgrep rule
      - write a Semgrep rule for a specific issue or pattern
    """
    ast = json.loads(get_abstract_syntax_tree(code, language))
    # This would be more sophisticated in a real implementation
    return f"""rules:
- id: custom-rule
  message: Custom rule for {language} code
  pattern: |
    {json.dumps(ast, indent=2)}
  languages: [{language}]
  severity: WARNING
"""