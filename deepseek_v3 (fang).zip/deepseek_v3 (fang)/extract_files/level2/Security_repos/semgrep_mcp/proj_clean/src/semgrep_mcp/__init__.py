__all__ = ['server']

from .server import (
    CodeFile,
    CodeWithLanguage,
    SemgrepScanResult,
    create_temp_files_from_code_content,
    ensure_semgrep_available,
    find_semgrep_path,
    get_abstract_syntax_tree,
    get_semgrep_rule_schema,
    get_semgrep_rule_yaml,
    get_semgrep_scan_args,
    get_supported_languages,
    remove_temp_dir_from_results,
    run_semgrep,
    safe_join,
    security_check,
    semgrep_rule_schema,
    semgrep_scan,
    semgrep_scan_with_custom_rule,
    validate_absolute_path,
    validate_code_files,
    validate_config,
    write_custom_semgrep_rule,
)

__version__ = "0.2.1"

def main():
    """Main entry point for the package."""
    server.main()