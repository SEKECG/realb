import argparse
import json
from typing import Optional

from .extension import Extension, Browser
from .risk import get_risk_report

def analyze(id, browser, output, max_files, max_urls, permissions):
    with Extension(id, browser) as ext:
        report = get_risk_report(ext)
        
        if output == 'json':
            print(json.dumps(report, indent=2))
        else:
            print(f"Extension: {ext.name}")
            print(f"Version: {ext.version}")
            print(f"Author: {ext.author}")
            print(f"Risk Score: {report['risk_score']}")
            
            print("\nPermissions:")
            for perm in report['permissions']:
                print(f"- {perm['permission']} ({perm['risk_level']})")
            
            if not permissions:
                print("\nJavaScript Files:")
                for js in ext.javascript_files[:max_files]:
                    print(f"- {js}")
                
                print("\nReferenced URLs:")
                for url in ext.urls[:max_urls]:
                    print(f"- {url}")

def get_version():
    print("CRX Analyzer v1.0")

def cli():
    parser = argparse.ArgumentParser(description='Chrome/Edge Extension Analyzer')
    subparsers = parser.add_subparsers(dest='command', required=True)

    version_parser = subparsers.add_parser('version', help='Show version')

    analyze_parser = subparsers.add_parser('analyze', help='Analyze extension')
    analyze_parser.add_argument('id', help='Extension ID')
    analyze_parser.add_argument('--browser', choices=['chrome', 'edge'], default='chrome')
    analyze_parser.add_argument('--output', choices=['pretty', 'json'], default='pretty')
    analyze_parser.add_argument('--max-files', type=int, default=10)
    analyze_parser.add_argument('--max-urls', type=int, default=10)
    analyze_parser.add_argument('--permissions', action='store_true', help='Show only permissions')

    args = parser.parse_args()

    if args.command == 'version':
        get_version()
    elif args.command == 'analyze':
        analyze(args.id, args.browser, args.output, args.max_files, args.max_urls, args.permissions)

if __name__ == '__main__':
    cli()