import os
import requests
from typing import Optional

CHROME_VERSION = "110.0.5481.100"
EDGE_VERSION = "110.0.1587.50"
USER_AGENT = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36"

def get_chrome_extension_url(extension_id, chrome_version=CHROME_VERSION):
    return f"https://clients2.google.com/service/update2/crx?response=redirect&prodversion={chrome_version}&x=id%3D{extension_id}%26uc"

def get_edge_extension_url(extension_id, edge_version=EDGE_VERSION):
    return f"https://msedgeextensions.sf.tlu.dl.delivery.mp.microsoft.com/filestreamingservice/files/{extension_id}?P1=1676372400&P2=402&P3=2&P4=Wj5%2F%2F%2B%2Fx%2F%2B%2F%2F%2F%2F%2F%2F%2F%2F%2F%2F8%3D"

def download_extension(url, output_path):
    headers = {'User-Agent': USER_AGENT}
    response = requests.get(url, headers=headers, stream=True)
    response.raise_for_status()
    
    with open(output_path, 'wb') as f:
        for chunk in response.iter_content(chunk_size=8192):
            f.write(chunk)