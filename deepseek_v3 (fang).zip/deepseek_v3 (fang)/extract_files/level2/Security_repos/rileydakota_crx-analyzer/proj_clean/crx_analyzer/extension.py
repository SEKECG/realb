import os
import shutil
import tempfile
import zipfile
import json
import hashlib
from enum import Enum
from typing import Optional, List, Dict, Any

from .download import download_extension, get_chrome_extension_url, get_edge_extension_url
from .models import ChromeManifest

class Browser(Enum):
    CHROME = "chrome"
    EDGE = "edge"

class InvalidExtensionIDError(Exception):
    pass

class Extension:
    def __init__(self, extension_id, browser, working_dir=None):
        self.extension_id = extension_id
        self.browser = Browser(browser)
        self.working_dir = working_dir or tempfile.mkdtemp()
        self.extension_zip_path = os.path.join(self.working_dir, f"{extension_id}.crx")
        self.extension_dir_path = os.path.join(self.working_dir, extension_id)
        
        self.__download_extension()
        self.__unzip_extension()
        self.manifest = self.__get_manifest()
        
    def __enter__(self):
        return self
        
    def __exit__(self, exc_type, exc_value, traceback):
        shutil.rmtree(self.working_dir)
        
    def __download_extension(self):
        if self.browser == Browser.CHROME:
            url = get_chrome_extension_url(self.extension_id)
        else:
            url = get_edge_extension_url(self.extension_id)
            
        download_extension(url, self.extension_zip_path)
        
    def __unzip_extension(self):
        os.makedirs(self.extension_dir_path, exist_ok=True)
        with zipfile.ZipFile(self.extension_zip_path, 'r') as zip_ref:
            zip_ref.extractall(self.extension_dir_path)
            
    def __get_manifest(self) -> ChromeManifest:
        manifest_path = os.path.join(self.extension_dir_path, 'manifest.json')
        with open(manifest_path, 'r') as f:
            return ChromeManifest(**json.load(f))
            
    @property
    def name(self) -> str:
        return self.manifest.name
        
    @property
    def version(self) -> str:
        return self.manifest.version
        
    @property
    def author(self) -> str:
        return self.manifest.author or "Unknown"
        
    @property
    def homepage_url(self) -> str:
        return self.manifest.homepage_url or ""
        
    @property
    def manifest_version(self) -> int:
        return self.manifest.manifest_version
        
    @property
    def permissions(self) -> List[str]:
        return self.manifest.permissions or []
        
    @property
    def javascript_files(self) -> List[str]:
        js_files = []
        for root, _, files in os.walk(self.extension_dir_path):
            for file in files:
                if file.endswith('.js'):
                    js_files.append(os.path.join(root, file))
        return js_files
        
    @property
    def urls(self) -> List[str]:
        urls = set()
        for js_file in self.javascript_files:
            with open(js_file, 'r', errors='ignore') as f:
                content = f.read()
                # Simple URL extraction - would need more sophisticated parsing
                if 'http://' in content or 'https://' in content:
                    urls.update(content.split('http://')[1:])
                    urls.update(content.split('https://')[1:])
        return list(urls)
        
    @property
    def sha256(self) -> str:
        with open(self.extension_zip_path, 'rb') as f:
            return hashlib.sha256(f.read()).hexdigest()