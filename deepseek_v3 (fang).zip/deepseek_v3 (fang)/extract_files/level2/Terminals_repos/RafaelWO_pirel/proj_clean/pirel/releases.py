import datetime
import json
import logging
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests
from rich.table import Table

from ._cache import get_latest_cache_file, load, save
from ._utils import VersionLike
from .python_cli import PythonVersion

logger = logging.getLogger(__name__)

RELEASE_CYCLE_URL = "https://raw.githubusercontent.com/python/devguide/master/versions.json"
DATE_NOW = datetime.date.today()

STATUS_TO_EMOJI = {
    "feature": "✨",
    "prerelease": "🚧",
    "bugfix": "🐛",
    "security": "🔒",
    "end-of-life": "💀",
}

STATUS_TO_TEXT = {
    "feature": "Feature (pre-release, accepting new features)",
    "prerelease": "Prerelease (accepting bug fixes)",
    "bugfix": "Bugfix (actively maintained)",
    "security": "Security (security fixes only)",
    "end-of-life": "End-of-life (no longer supported)",
}

def load_releases():
    cache_file = get_latest_cache_file()
    if cache_file:
        data = load(cache_file)
    else:
        response = requests.get(RELEASE_CYCLE_URL)
        response.raise_for_status()
        data = response.json()
        save(data)
    return PythonReleases(data)

def parse_date(date_str):
    if not date_str:
        return None
    try:
        if len(date_str.split("-")) == 2:
            return datetime.datetime.strptime(date_str, "%Y-%m").date().replace(day=1)
        return datetime.datetime.strptime(date_str, "%Y-%m-%d").date()
    except ValueError:
        return None

def eol_color(eol):
    if not eol:
        return "green"
    delta = eol - DATE_NOW
    if delta.days < 0:
        return "red"
    elif delta.days < 180:
        return "dark_orange"
    elif delta.days < 365:
        return "yellow"
    return "green"

def status_style(status):
    styles = {
        "feature": "bold cyan",
        "prerelease": "bold yellow",
        "bugfix": "bold green",
        "security": "bold orange",
        "end-of-life": "bold red",
    }
    return styles.get(status, "")

def date_style(date):
    if not date:
        return ""
    if date > DATE_NOW:
        return "bold"
    return ""

def wrap_style(text, style):
    return f"[{style}]{text}[/{style}]" if style else text

class PythonRelease(VersionLike):
    def __init__(self, version, data):
        self._version = version
        self._status = data.get("status", "")
        self._released = parse_date(data.get("release_date"))
        self._end_of_life = parse_date(data.get("end_of_life"))
        self._release_manager = data.get("release_manager", "")

    def __repr__(self):
        return f"PythonRelease(version='{self._version}')"

    def __str__(self):
        status = self.status
        eol = f" (EOL: {self.end_of_life})" if self._end_of_life else ""
        return f"{self.version} {status}{eol}"

    @property
    def version(self):
        return self._version

    @property
    def version_tuple(self):
        return tuple(map(int, self._version.split(".")))

    @property
    def status(self):
        return wrap_style(
            f"{STATUS_TO_EMOJI.get(self._status, '')} {STATUS_TO_TEXT.get(self._status, self._status)}",
            status_style(self._status)
        )

    @property
    def released(self):
        return wrap_style(
            self._released.isoformat() if self._released else "N/A",
            date_style(self._released)
        )

    @property
    def end_of_life(self):
        if not self._end_of_life:
            return "N/A"
        return wrap_style(
            self._end_of_life.isoformat(),
            eol_color(self._end_of_life)
        )

    @property
    def is_eol(self):
        return self._status == "end-of-life"

class PythonReleases:
    def __init__(self, releases_data):
        self.releases = {
            version: PythonRelease(version, data)
            for version, data in releases_data.items()
        }

    def __getitem__(self, version):
        return self.releases[version]

    def to_list(self):
        return list(self.releases.values())

    def to_table(self, active_python_version=None):
        from rich.console import Console
        console = Console()
        table = Table(title="Python Releases")
        table.add_column("Version", style="bold")
        table.add_column("Status")
        table.add_column("Released")
        table.add_column("End of Life")

        active_version = None
        if active_python_version:
            try:
                active_version = self[active_python_version.as_release]
            except KeyError:
                pass

        for release in sorted(self.to_list(), key=lambda r: r.version_tuple, reverse=True):
            version = release.version
            if active_version and version == active_version.version:
                version = f"[bold reverse]{version}[/]"
            table.add_row(
                version,
                release.status,
                release.released,
                release.end_of_life
            )
        return table