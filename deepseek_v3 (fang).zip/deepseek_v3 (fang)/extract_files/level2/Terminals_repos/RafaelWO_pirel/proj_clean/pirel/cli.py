import click
from rich.console import Console

from . import CONTEXT
from .logging import setup_logging
from .python_cli import get_active_python_info
from .releases import load_releases

logger = logging.getLogger(__name__)

app = click.Group()

VERBOSE_OPTION = click.option(
    "--verbose", "-v",
    count=True,
    callback=logging_callback,
    is_eager=True,
    expose_value=False,
    help="Increase verbosity (can be used multiple times)"
)

@app.command()
@click.option("--version", is_flag=True, callback=version_callback, expose_value=False, is_eager=True)
@VERBOSE_OPTION
def main(ctx, no_cache, verbose, version):
    """The Python release cycle in your terminal."""
    pass

@app.command()
@VERBOSE_OPTION
def list_releases():
    """Lists all Python releases in a table. Your active Python interpreter is highlighted."""
    print_releases()

@app.command()
@VERBOSE_OPTION
def check_release():
    """Shows release information about your active Python interpreter."""
    active_info = get_active_python_info()
    if not active_info:
        click.echo("No active Python interpreter found", err=True)
        raise click.Abort()
    
    releases = CONTEXT.releases
    try:
        release = releases[active_info.version.as_release]
    except KeyError:
        click.echo(f"Version {active_info.version} not found in release data", err=True)
        raise click.Abort()
    
    console = Console()
    console.print(release)
    
    if release.is_eol:
        raise click.Abort(code=1)

@app.command()
@VERBOSE_OPTION
def ask_random_question():
    """Prompts the user with a random question regarding Python releases."""
    from ._guess import get_random_question
    question = get_random_question(CONTEXT.releases.to_list())
    if question.ask():
        click.echo("Correct!")
    else:
        click.echo(f"Wrong! The correct answer was: {question.correct_answer}")

def print_releases():
    active_info = get_active_python_info()
    active_version = active_info.version.as_release if active_info else None
    releases = CONTEXT.releases
    console = Console()
    console.print(releases.to_table(active_version))

def version_callback(value):
    if not value:
        return
    click.echo(f"pirel {__version__}")
    raise click.Exit()

def logging_callback(ctx, verbosity):
    if ctx.resilient_parsing:
        return
    setup_logging(verbosity)