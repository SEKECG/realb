from abc import ABC, abstractmethod
from typing import Tuple

class VersionLike(ABC):
    @property
    @abstractmethod
    def version_tuple(self) -> Tuple[int, ...]:
        pass

    def __eq__(self, other):
        if not isinstance(other, VersionLike):
            return NotImplemented
        return self.version_tuple == other.version_tuple

    def __lt__(self, other):
        if not isinstance(other, VersionLike):
            return NotImplemented
        return self.version_tuple < other.version_tuple

    def __le__(self, other):
        if not isinstance(other, VersionLike):
            return NotImplemented
        return self.version_tuple <= other.version_tuple

    def __gt__(self, other):
        if not isinstance(other, VersionLike):
            return NotImplemented
        return self.version_tuple > other.version_tuple

    def __ge__(self, other):
        if not isinstance(other, VersionLike):
            return NotImplemented
        return self.version_tuple >= other.version_tuple