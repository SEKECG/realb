import csv
import logging
import random
from pathlib import Path
from typing import List, Optional, Type

from appdirs import user_data_dir
from rich.prompt import Prompt

from .releases import PythonRelease
from . import CONTEXT

logger = logging.getLogger(__name__)

STATS_DIR = Path(user_data_dir("pirel"))
STATS_FILENAME = STATS_DIR / "guess_stats.csv"
STATS_FIELDNAMES = ["question_type", "version", "correct"]

class PirelPrompt(Prompt):
    def __init__(self, prompt, choices, console=None, password=False, case_sensitive=False, show_default=True):
        super().__init__(
            prompt,
            console=console or CONTEXT.rich_console,
            password=password,
            show_default=show_default
        )
        self.choices = choices
        self.case_sensitive = case_sensitive
        self.choice_enum = list(enumerate(choices, 1))
        self.prompt_suffix = "\n" + "\n".join(
            f" {i}) {choice}" for i, choice in self.choice_enum
        )
        self.illegal_choice_message = "Please choose one of the available options"

    def check_choice(self, value):
        try:
            choice_idx = int(value) - 1
            return 0 <= choice_idx < len(self.choices)
        except ValueError:
            return value in self.choices if self.case_sensitive else value.lower() in [c.lower() for c in self.choices]

    def make_prompt(self, default):
        prompt = self.prompt + self.prompt_suffix
        if default is not None and self.show_default:
            prompt += f"\n (default: {default})"
        return prompt

    def process_response(self, value):
        if not self.check_choice(value):
            raise ValueError(self.illegal_choice_message)
        
        try:
            choice_idx = int(value) - 1
            return self.choices[choice_idx]
        except ValueError:
            return value

class Question:
    def __init__(self, releases):
        self.releases = releases
        self.target_release = random.choice(releases)
        self.get_target_field = lambda r: str(r.version)
        self.question = "Which Python version was released on {date}?"

    def __repr__(self):
        return f"{self.__class__.__name__}(version='{self.target_release.version}')"

    @property
    def correct_answer(self):
        return self.get_target_field(self.target_release)

    def build_choices(self):
        choices = [self.correct_answer]
        choices.extend(self.get_target_field(r) for r in self.incorrect_choices())
        random.shuffle(choices)
        return choices

    def incorrect_choices(self):
        return self.generate_incorrect_choices(lambda r: r != self.target_release)

    def generate_incorrect_choices(self, *predicates, k=3, remove_duplicates=True):
        filtered = [r for r in self.releases if all(p(r) for p in predicates)]
        if remove_duplicates:
            seen = set()
            filtered = [r for r in filtered if not (self.get_target_field(r) in seen or seen.add(self.get_target_field(r)))]
        return random.sample(filtered, min(k, len(filtered)))

    def format_question(self):
        return self.question

    def ask(self):
        choices = self.build_choices()
        prompt = PirelPrompt(
            self.format_question(),
            choices=choices,
            console=CONTEXT.rich_console
        )
        answer = prompt()
        correct = answer == self.correct_answer
        store_question_score(self.__class__.__name__, self.target_release.version, correct)
        return correct

class VersionDateQuestion(Question):
    def __init__(self, releases):
        super().__init__(releases)
        self.get_target_field = lambda r: r.released
        self.question = "When was Python {version} released?"

    def format_question(self):
        return self.question.format(version=self.target_release.version)

class DateVersionQuestion(Question):
    def __init__(self, releases):
        super().__init__(releases)
        self.question = "Which Python version was released on {date}?"

    def format_question(self):
        return self.question.format(date=self.target_release.released)

class ReleaseManagerVersionQuestion(Question):
    def __init__(self, releases):
        super().__init__(releases)
        self.get_target_field = lambda r: r._release_manager
        self.question = "Who was the release manager for Python {version}?"

    def format_question(self):
        return self.question.format(version=self.target_release.version)

    def incorrect_choices(self):
        return self.generate_incorrect_choices(
            lambda r: r._release_manager != self.target_release._release_manager,
            remove_duplicates=True
        )

class LatestVersionQuestion(Question):
    def __init__(self, releases):
        super().__init__(releases)
        self.target_release = max(
            [r for r in releases if r._status == "bugfix"],
            key=lambda r: r.version_tuple
        )
        self.question = "What is the latest stable Python version?"

    def incorrect_choices(self):
        return [r for r in self.releases if r.version.startswith("3") and r != self.target_release]

def get_random_question():
    question_classes = [
        VersionDateQuestion,
        DateVersionQuestion,
        ReleaseManagerVersionQuestion,
        LatestVersionQuestion
    ]
    return random.choice(question_classes)(CONTEXT.releases.to_list())

def store_question_score(question, version, score):
    STATS_DIR.mkdir(parents=True, exist_ok=True)
    file_exists = STATS_FILENAME.exists()
    
    with open(STATS_FILENAME, "a", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=STATS_FIELDNAMES)
        if not file_exists:
            writer.writeheader()
        writer.writerow({
            "question_type": question,
            "version": version,
            "correct": score
        })