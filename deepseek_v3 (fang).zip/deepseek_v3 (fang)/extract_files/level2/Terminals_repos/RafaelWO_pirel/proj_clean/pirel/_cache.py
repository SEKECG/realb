import datetime
import json
import logging
from pathlib import Path
from typing import Any, Dict, Optional

from appdirs import user_cache_dir

logger = logging.getLogger(__name__)

CACHE_DIR = Path(user_cache_dir("pirel"))
CACHE_FILE_GLOB = "pirel_cache_*.json"

def filename():
    today = datetime.date.today().isoformat()
    return CACHE_DIR / f"pirel_cache_{today}.json"

def get_latest_cache_file():
    cache_files = sorted(CACHE_DIR.glob(CACHE_FILE_GLOB), reverse=True)
    return cache_files[0] if cache_files else None

def calc_cache_age_days(cache_file):
    date_str = cache_file.stem.split("_")[-1]
    cache_date = datetime.date.fromisoformat(date_str)
    return (datetime.date.today() - cache_date).days

def load(cache_file):
    with open(cache_file) as f:
        return json.load(f)

def save(data):
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    with open(filename(), "w") as f:
        json.dump(data, f)

def clear(clear_all):
    cache_files = CACHE_DIR.glob(CACHE_FILE_GLOB)
    for cache_file in cache_files:
        if clear_all or calc_cache_age_days(cache_file) > 7:
            cache_file.unlink()