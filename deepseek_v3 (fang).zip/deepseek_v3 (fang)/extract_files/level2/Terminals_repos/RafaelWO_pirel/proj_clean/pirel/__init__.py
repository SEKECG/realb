from .cli import CONTEXT
from ._utils import VersionLike

__version__ = "0.1.0"

class PirelContext:
    def __init__(self):
        from rich.console import Console
        self.rich_console = Console(highlight=False)

    @property
    def releases(self):
        from .releases import load_releases
        return load_releases()

CONTEXT = PirelContext()