from dataclasses import dataclass
import re

foreground_colors = {
    'black': '30',
    'red': '31',
    'green': '32',
    'yellow': '33',
    'blue': '34',
    'magenta': '35',
    'cyan': '36',
    'white': '37',
    'bright_black': '90',
    'bright_red': '91',
    'bright_green': '92',
    'bright_yellow': '93',
    'bright_blue': '94',
    'bright_magenta': '95',
    'bright_cyan': '96',
    'bright_white': '97'
}

background_colors = {
    'black': '40',
    'red': '41',
    'green': '42',
    'yellow': '43',
    'blue': '44',
    'magenta': '45',
    'cyan': '46',
    'white': '47',
    'bright_black': '100',
    'bright_red': '101',
    'bright_green': '102',
    'bright_yellow': '103',
    'bright_blue': '104',
    'bright_magenta': '105',
    'bright_cyan': '106',
    'bright_white': '107'
}

reset_color = '\033[0m'

def hex_to_rgb(hex_color):
    hex_color = hex_color.lstrip('#')
    return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))

def is_rgb(color):
    return isinstance(color, tuple) and len(color) == 3 and all(isinstance(c, int) for c in color)

@dataclass
class Color:
    def to_ansi(self, is_background=False):
        if isinstance(self, str):
            if is_background:
                return f'\033[{background_colors.get(self, "")}m'
            return f'\033[{foreground_colors.get(self, "")}m'
        elif is_rgb(self):
            if is_background:
                return f'\033[48;2;{self[0]};{self[1]};{self[2]}m'
            return f'\033[38;2;{self[0]};{self[1]};{self[2]}m'
        return ''

    def to_rgb(self):
        if isinstance(self, str):
            if self.startswith('#'):
                return hex_to_rgb(self)
            elif self in foreground_colors or self in background_colors:
                return None  # Named colors don't have direct RGB equivalents
        elif is_rgb(self):
            return self
        return None