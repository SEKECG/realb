from dataclasses import dataclass

@dataclass
class ModuleParam:
    pass

class Printer:
    def __init__(self, strategy):
        self.strategy = strategy

    def print(self, module, display_depth=None, display_legend=None):
        pass

    def repr_module(self, parent_module, display_depth, indent):
        pass

    def set_strategy(self, strategy, *args, **kwargs):
        self.strategy = strategy(*args, **kwargs)

def _addindent(s_, numSpaces):
    return s_.replace('\n', '\n' + ' ' * numSpaces)

def summarize_repeated_modules(lines):
    pass