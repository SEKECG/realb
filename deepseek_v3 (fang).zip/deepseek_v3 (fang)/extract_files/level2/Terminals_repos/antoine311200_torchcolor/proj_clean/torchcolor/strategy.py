from dataclasses import dataclass
from typing import ClassVar, Dict

@dataclass
class ModuleStyle:
    name_style: "Union[TextStyle,FunctionalStyle]"
    layer_style: "Union[TextStyle,FunctionalStyle]"
    extra_style: "Union[TextStyle,FunctionalStyle]"

class ColorStrategy:
    _registry: ClassVar[Dict[str, "ColorStrategy"]] = {}

    @classmethod
    def get_strategy(cls, key, *args, **kwargs):
        strategy = cls._registry.get(key)
        if not strategy:
            raise ValueError(f"Strategy {key} not found")
        return strategy(*args, **kwargs)

    @classmethod
    def available_strategies(cls):
        return list(cls._registry.keys())

    @classmethod
    def create(cls, key, *args, **kwargs):
        return cls.get_strategy(key, *args, **kwargs)

    @classmethod
    def register(cls, key):
        def decorator(strategy_class):
            cls._registry[key] = strategy_class
            return strategy_class
        return decorator

    def get_style(self, module, params):
        return ModuleStyle(None, None, None)

@ColorStrategy.register('constant')
class ConstantColorStrategy(ColorStrategy):
    def __init__(self, color=''):
        self.color = color

    def get_style(self, module, config):
        return ModuleStyle(None, None, None)

@ColorStrategy.register('layer')
class LayerColorStrategy(ColorStrategy):
    def get_style(self, module):
        return ModuleStyle(None, None, None)

@ColorStrategy.register('trainable')
class TrainableStrategy(ColorStrategy):
    def get_style(self, module, config):
        return ModuleStyle(None, None, None)