from dataclasses import dataclass
from typing import ClassVar, Dict, List
from .color import Color

palette_rainbow = ['red', 'orange', 'yellow', 'green', 'blue', 'indigo', 'violet']
palette_warm_sunset = ['dark_turquoise', 'light_sea_green', 'medium_turquoise', 'turquoise', 'aquamarine', 
                      'forest_green', 'dark_green', 'sea_green', 'dark_sea_green', 'pale_green', 
                      'lavender', 'thistle', 'medium_violet_red', 'dark_orchid', 'blue_violet', 
                      'orange_red', 'saddle_brown', 'brown', 'chocolate', 'gold', 
                      'light_pink', 'powder_blue', 'pale_green', 'lemon_chiffon', 'khaki', 
                      'magenta', 'lime', 'yellow', 'black', 'cyan', 
                      'red', 'black', 'dark_gray', 'gray', 'light_gray', 
                      'white', 'red', 'orange', 'yellow', 'green', 
                      'blue', 'indigo', 'violet']

palette_ocean_breeze = ['forest_green', 'dark_green', 'sea_green', 'dark_sea_green', 'pale_green', 
                       'lavender', 'thistle', 'medium_violet_red', 'dark_orchid', 'blue_violet', 
                       'orange_red', 'saddle_brown', 'brown', 'chocolate', 'gold', 
                       'light_pink', 'powder_blue', 'pale_green', 'lemon_chiffon', 'khaki', 
                       'magenta', 'lime', 'yellow', 'black', 'cyan', 
                       'red', 'black', 'dark_gray', 'gray', 'light_gray', 
                       'white', 'red', 'orange', 'yellow', 'green', 
                       'blue', 'indigo', 'violet']

palette_pastel = ['magenta', 'lime', 'yellow', 'black', 'cyan', 
                 'red', 'black', 'dark_gray', 'gray', 'light_gray', 
                 'white', 'red', 'orange', 'yellow', 'green', 
                 'blue', 'indigo', 'violet']

palette_retro_neon = ['black', 'dark_gray', 'gray', 'light_gray', 'white', 
                     'red', 'orange', 'yellow', 'green', 'blue', 
                     'indigo', 'violet']

palette_forest_greens = ['lavender', 'thistle', 'medium_violet_red', 'dark_orchid', 'blue_violet', 
                        'orange_red', 'saddle_brown', 'brown', 'chocolate', 'gold', 
                        'light_pink', 'powder_blue', 'pale_green', 'lemon_chiffon', 'khaki', 
                        'magenta', 'lime', 'yellow', 'black', 'cyan', 
                        'red', 'black', 'dark_gray', 'gray', 'light_gray', 
                        'white', 'red', 'orange', 'yellow', 'green', 
                        'blue', 'indigo', 'violet']

palette_lavender_dreams = ['orange_red', 'saddle_brown', 'brown', 'chocolate', 'gold', 
                          'light_pink', 'powder_blue', 'pale_green', 'lemon_chiffon', 'khaki', 
                          'magenta', 'lime', 'yellow', 'black', 'cyan', 
                          'red', 'black', 'dark_gray', 'gray', 'light_gray', 
                          'white', 'red', 'orange', 'yellow', 'green', 
                          'blue', 'indigo', 'violet']

palette_autumn_foliage = ['light_pink', 'powder_blue', 'pale_green', 'lemon_chiffon', 'khaki', 
                         'magenta', 'lime', 'yellow', 'black', 'cyan', 
                         'red', 'black', 'dark_gray', 'gray', 'light_gray', 
                         'white', 'red', 'orange', 'yellow', 'green', 
                         'blue', 'indigo', 'violet']

palette_monochrome = ['red', 'orange', 'yellow', 'green', 'blue', 'indigo', 'violet']

@dataclass
class Palette:
    _registry: ClassVar[Dict[str, "Palette"]] = {}
    disable_registry: bool = False

    def __post_init__(self):
        if not self.disable_registry:
            self._registry[self.name] = self

    @classmethod
    def get_palette(cls, name):
        return cls._registry.get(name)

    @classmethod
    def get(cls, name):
        return cls.get_palette(name)

    def __getitem__(self, index):
        return self.colors[index % len(self.colors)]

    def generate_gradient(self, n):
        if n <= 0:
            return []
        if len(self.colors) == 1:
            return [self.colors[0]] * n
        step = (len(self.colors) - 1) / (n - 1)
        return [self.colors[int(i * step)] for i in range(n)]