from .color import Color, reset_color

def print_color(text, text_color=None, bg_color=None):
    color_code = ''
    if text_color:
        color_code += Color(text_color).to_ansi()
    if bg_color:
        color_code += Color(bg_color).to_ansi(is_background=True)
    print(f"{color_code}{text}{reset_color}")

def print_more(*args, **kwargs):
    sep = kwargs.get('sep', ' ')
    end = kwargs.get('end', '\n')
    styled_parts = []
    for arg in args:
        if isinstance(arg, str):
            styled_parts.append(arg)
        else:
            styled_parts.append(str(arg))
    print(sep.join(styled_parts), end=end)