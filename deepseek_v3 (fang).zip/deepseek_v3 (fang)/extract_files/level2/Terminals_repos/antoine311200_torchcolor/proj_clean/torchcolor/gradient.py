from dataclasses import dataclass
from typing import List, Tuple
from .palette import Palette
from .color import Color

GradientChunk = Tuple[int, int, Color]

@dataclass
class Gradient:
    interpolate: bool = True
    repeat: bool = False
    reverse: bool = False
    window_size: int = 10

    def __post_init__(self):
        if self.window_size <= 0:
            raise ValueError("Window size must be positive")

    def _ensure_palette(self, palette):
        if isinstance(palette, Palette):
            return palette
        elif isinstance(palette, str):
            return Palette.get_palette(palette)
        raise ValueError("Invalid palette type")

    def apply(self, text):
        if not text:
            return []
        palette = self._ensure_palette(self.palette)
        colors = palette.generate_gradient(len(text)) if self.interpolate else palette.colors
        if self.reverse:
            colors = colors[::-1]
        chunks = []
        for i, char in enumerate(text):
            color_idx = i % len(colors) if self.repeat else min(i, len(colors)-1)
            chunks.append((i, i+1, colors[color_idx]))
        return chunks