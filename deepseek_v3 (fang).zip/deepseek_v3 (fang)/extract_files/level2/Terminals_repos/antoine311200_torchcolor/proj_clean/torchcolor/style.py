from dataclasses import dataclass
from typing import Union
from .color import Color
from .gradient import Gradient

LAYER_SPLITTER = r'(: )|(\(.*?\))'

KeyType = type
DelimiterType = type
AnyType = type
FunctionalType = type

@dataclass
class TextStyle:
    fg_style: Union[Gradient, Color, str, tuple]
    bg_style: Union[Gradient, Color, str, tuple]
    bold: bool = False
    italic: bool = False
    underline: bool = False
    double_underline: bool = False
    crossed: bool = False
    darken: bool = False

    def __post_init__(self):
        self.fg_style = self._ensure_style(self.fg_style)
        self.bg_style = self._ensure_style(self.bg_style)

    def _ensure_style(self, value):
        if isinstance(value, (Color, Gradient)):
            return value
        elif isinstance(value, str):
            return Color(value)
        elif isinstance(value, tuple) and len(value) == 3:
            return Color(value)
        return None

    def apply(self, text):
        if not text:
            return ''
        styled = text
        if self.fg_style:
            if isinstance(self.fg_style, Gradient):
                pass  # Handle gradient application
            else:
                styled = f"{self.fg_style.to_ansi()}{styled}"
        if self.bg_style:
            if isinstance(self.bg_style, Gradient):
                pass  # Handle gradient application
            else:
                styled = f"{self.bg_style.to_ansi(is_background=True)}{styled}"
        return styled

@dataclass
class FunctionalStyle:
    infer_func: FunctionalType

    def __post_init__(self):
        pass

    def apply(self, text):
        return text

def colorize(text, text_color=None, bg_color=None):
    style = TextStyle(text_color, bg_color)
    return style.apply(text)

def clean_style(text):
    import re
    return re.sub(r'\033\[[0-9;]*m', '', text)

def infer_type(self, value):
    return type(value)