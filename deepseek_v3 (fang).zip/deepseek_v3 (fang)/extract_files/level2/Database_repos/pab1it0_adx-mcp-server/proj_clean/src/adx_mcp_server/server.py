import os
from typing import List, Dict, Any
from azure.identity import WorkloadIdentityCredential, DefaultAzureCredential
from azure.kusto.data import KustoClient, KustoConnectionStringBuilder
from azure.kusto.data.exceptions import KustoServiceError
from azure.kusto.data.helpers import dataframe_from_result_table
from dataclasses import dataclass

@dataclass
class ADXConfig:
    """Store configuration settings for connecting to an Azure Data Explorer (ADX) cluster."""
    cluster_url: str
    database_name: str
    tenant_id: str = None
    client_id: str = None
    token_file_path: str = None

config = ADXConfig(
    cluster_url=os.getenv("ADX_CLUSTER_URL"),
    database_name=os.getenv("ADX_DATABASE_NAME"),
    tenant_id=os.getenv("AZURE_TENANT_ID"),
    client_id=os.getenv("AZURE_CLIENT_ID"),
    token_file_path=os.getenv("AZURE_FEDERATED_TOKEN_FILE")
)

def get_kusto_client() -> KustoClient:
    """Create and return a KustoClient instance with Azure authentication."""
    try:
        if config.tenant_id and config.client_id and config.token_file_path:
            credential = WorkloadIdentityCredential(
                tenant_id=config.tenant_id,
                client_id=config.client_id,
                token_file_path=config.token_file_path
            )
            print("Using Workload Identity authentication")
        else:
            credential = DefaultAzureCredential()
            print("Using Default Azure Credential authentication")
            
        kcsb = KustoConnectionStringBuilder.with_azure_token_credential(
            config.cluster_url,
            credential
        )
        return KustoClient(kcsb)
    except Exception as e:
        raise RuntimeError(f"Failed to create Kusto client: {str(e)}")

def execute_query(query: str) -> List[Dict[str, Any]]:
    """Execute a KQL query against the configured database."""
    client = get_kusto_client()
    try:
        response = client.execute(config.database_name, query)
        return format_query_results(response.primary_results[0])
    except KustoServiceError as e:
        raise RuntimeError(f"Query execution failed: {str(e)}")

def format_query_results(result_set) -> List[Dict[str, Any]]:
    """Convert query results to list of dictionaries."""
    return [dict(zip(result_set.columns_names, row)) for row in result_set]

def list_tables() -> List[Dict[str, Any]]:
    """List all tables in the database."""
    query = f".show tables | project TableName, Folder, Database"
    return execute_query(query)

def get_table_schema(table_name: str) -> List[Dict[str, Any]]:
    """Get schema information for a specific table."""
    query = f".show table {table_name} schema | project ColumnName, ColumnType"
    return execute_query(query)

def sample_table_data(table_name: str, sample_size: int = 100) -> List[Dict[str, Any]]:
    """Sample random rows from a table."""
    query = f"{table_name} | take {sample_size}"
    return execute_query(query)

def get_table_details(table_name: str) -> List[Dict[str, Any]]:
    """Get detailed information about a table."""
    query = f".show table {table_name} details | project Name, RowCount, TotalExtentSize"
    return execute_query(query)