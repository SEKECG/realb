import os
from typing import Dict, Any
from dotenv import load_dotenv
from .server import ADXConfig, get_kusto_client, execute_query, list_tables, get_table_schema, sample_table_data, get_table_details

def setup_environment() -> Dict[str, Any]:
    """Load and validate environment variables for Azure Data Explorer configuration."""
    load_dotenv()
    
    config = {
        "cluster_url": os.getenv("ADX_CLUSTER_URL"),
        "database_name": os.getenv("ADX_DATABASE_NAME"),
        "tenant_id": os.getenv("AZURE_TENANT_ID"),
        "client_id": os.getenv("AZURE_CLIENT_ID"),
        "token_file_path": os.getenv("AZURE_FEDERATED_TOKEN_FILE")
    }
    
    if not config["cluster_url"] or not config["database_name"]:
        raise ValueError("ADX_CLUSTER_URL and ADX_DATABASE_NAME must be set in environment variables")
    
    return config

def run_server() -> None:
    """Main entry point for the Azure Data Explorer MCP Server."""
    try:
        config = setup_environment()
        print(f"Starting ADX MCP Server version {__version__}")
        print(f"Connecting to cluster: {config['cluster_url']}")
        print(f"Using database: {config['database_name']}")
        
        client = get_kusto_client()
        print("Successfully initialized Kusto client")
        
        # Example usage of server functions
        tables = list_tables()
        print(f"Found {len(tables)} tables in database")
        
    except Exception as e:
        print(f"Failed to start server: {str(e)}")
        raise

if __name__ == "__main__":
    run_server()