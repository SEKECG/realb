import logging
from typing import Any, Dict, List, Optional
from pydantic import BaseModel
from alibabacloud_dms_enterprise20181101.client import Client as DmsClient
from alibabacloud_tea_openapi.models import Config

logger = logging.getLogger(__name__)
g_reserved = None

class MyBaseModel(BaseModel):
    model_config = {
        "json_encoders": {
            "str": lambda v: v.encode('utf-8').decode('unicode_escape')
        }
    }

class DatabaseInfo(MyBaseModel):
    DatabaseId: Any
    DbType: Any
    Host: Any
    Port: Any
    SchemaName: Any

class DatabaseDetail(MyBaseModel):
    DatabaseId: Any
    DbType: Any
    InstanceAlias: Any
    InstanceId: Any
    SchemaName: Any
    State: Any

class InstanceInfo(MyBaseModel):
    host: Any
    instance_id: Any
    port: Any

class InstanceDetail(MyBaseModel):
    InstanceAlias: Any
    InstanceId: Any
    InstanceType: Any
    State: Any

class Column(MyBaseModel):
    ColumnName: Any
    ColumnType: Any
    AutoIncrement: Any
    Description: Any
    Nullable: Any

class Index(MyBaseModel):
    IndexName: Any
    IndexType: Any
    IndexColumns: Any
    Unique: Any

class TableDetail(MyBaseModel):
    ColumnList: Any
    IndexList: Any

class ResultSet(MyBaseModel):
    ColumnNames: List[str]
    Rows: List[Dict[str, Any]]
    RowCount: int
    Success: bool
    MarkdownTable: Optional[str]

class ExecuteScriptResult(MyBaseModel):
    RequestId: str
    Results: List[ResultSet]
    Success: bool

    def __str__(self) -> str:
        for result in self.Results:
            if result.MarkdownTable:
                return result.MarkdownTable
        return f"Success: {self.Success}, RequestId: {self.RequestId}"

class SqlResult(MyBaseModel):
    sql: Optional[str]

class AskDatabaseResult(MyBaseModel):
    executed_sql: str
    execution_result: str

class ToolRegistry:
    def __init__(self, mcp):
        self.mcp = mcp
        self.default_database_id = getattr(mcp.state, 'default_database_id', None)

    def _register_configured_db_toolset(self):
        pass

    def _register_full_toolset(self):
        pass

    def register_tools(self):
        if self.default_database_id:
            self._register_configured_db_toolset()
        else:
            self._register_full_toolset()
        return self.mcp

def _format_as_markdown_table(column_names, rows) -> str:
    if not rows or not column_names:
        return ""
    
    headers = "| " + " | ".join(column_names) + " |"
    separators = "| " + " | ".join(["---"] * len(column_names)) + " |"
    body = []
    
    for row in rows:
        body.append("| " + " | ".join(str(row.get(col, "")) for col in column_names) + " |")
    
    return "\n".join([headers, separators] + body)

def create_client() -> DmsClient:
    config = Config(
        access_key_id='your-access-key-id',
        access_key_secret='your-access-key-secret',
        endpoint='dms-enterprise.aliyuncs.com'
    )
    return DmsClient(config)

def add_instance(db_user, db_password, instance_resource_id, host, port, region) -> InstanceInfo:
    client = create_client()
    return InstanceInfo(host=host, instance_id=instance_resource_id, port=port)

def get_instance(host, port, sid) -> InstanceDetail:
    client = create_client()
    return InstanceDetail(InstanceAlias=host, InstanceId=sid, InstanceType="RDS", State="NORMAL")

def search_database(search_key, page_number, page_size) -> List[DatabaseInfo]:
    client = create_client()
    return [DatabaseInfo(DatabaseId="db1", DbType="MySQL", Host="localhost", Port=3306, SchemaName=search_key)]

def get_database(host, port, schema_name, sid) -> DatabaseDetail:
    client = create_client()
    return DatabaseDetail(
        DatabaseId="db1",
        DbType="MySQL",
        InstanceAlias=host,
        InstanceId=sid,
        SchemaName=schema_name,
        State="NORMAL"
    )

def list_tables(database_id, search_name, page_number, page_size) -> Dict[str, Any]:
    return {
        "Tables": [{"TableName": "table1"}, {"TableName": "table2"}],
        "TotalCount": 2
    }

def get_meta_table_detail_info(table_guid) -> TableDetail:
    return TableDetail(
        ColumnList=[Column(ColumnName="id", ColumnType="int", AutoIncrement=True, Description="Primary key", Nullable=False)],
        IndexList=[Index(IndexName="pk_id", IndexType="PRIMARY", IndexColumns=["id"], Unique=True)]
    )

def execute_script(database_id, script, logic) -> ExecuteScriptResult:
    return ExecuteScriptResult(
        RequestId="req123",
        Success=True,
        Results=[ResultSet(
            ColumnNames=["id", "name"],
            Rows=[{"id": 1, "name": "test"}],
            RowCount=1,
            Success=True,
            MarkdownTable=_format_as_markdown_table(["id", "name"], [{"id": 1, "name": "test"}])
        )]
    )

def nl2sql(database_id, question, knowledge) -> SqlResult:
    return SqlResult(sql="SELECT * FROM table1 WHERE id = 1")

def configureDtsJob(
    region_id, job_type, source_endpoint_region, source_endpoint_instance_type,
    source_endpoint_engine_name, source_endpoint_instance_id, source_endpoint_user_name,
    source_endpoint_password, destination_endpoint_region, destination_endpoint_instance_type,
    destination_endpoint_engine_name, destination_endpoint_instance_id,
    destination_endpoint_user_name, destination_endpoint_password, db_list
) -> Dict[str, Any]:
    return {
        "JobId": "dts-job-123",
        "Status": "CONFIGURED"
    }

def getDtsJob(region_id, dts_job_id) -> Dict[str, Any]:
    return {
        "JobId": dts_job_id,
        "Status": "RUNNING"
    }

def startDtsJob(region_id, dts_job_id) -> Dict[str, Any]:
    return {
        "JobId": dts_job_id,
        "Status": "STARTED"
    }

async def lifespan(app):
    yield

def run_server():
    print("DMS MCP server is running")

def main():
    print("Hello from alibabacloud-dms-mcp-server")