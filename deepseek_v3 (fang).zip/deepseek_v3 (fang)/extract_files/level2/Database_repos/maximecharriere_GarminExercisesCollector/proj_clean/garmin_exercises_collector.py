import json
import pickle
import os
import pandas as pd
import requests
from typing import Dict, List, Optional, Any
from googleapiclient.discovery import build
from google.oauth2 import service_account

class GarminExercisesCollector:
    def __init__(self):
        """Initialize the class with default locale, base URLs for exercise data, and empty data structures."""
        self.locale = "en-US"
        self.base_url = "https://connect.garmin.com/modern/proxy/guidedworkout-service/guidedworkout"
        
        self.exercises_url = f"{self.base_url}/exercises"
        self.yoga_url = f"{self.base_url}/yoga"
        self.pilates_url = f"{self.base_url}/pilates"
        self.mobility_url = f"{self.base_url}/mobility"
        self.equipment_url = f"{self.base_url}/equipment"
        self.translations_url = f"{self.base_url}/translations"
        
        self.detailed_data_based_url = "https://connect.garmin.com/modern/proxy/guidedworkout-service/guidedworkout/exercise"
        self.detailed_page_based_url = "https://connect.garmin.com/modern/guidedworkout/exercise"
        
        self.df_exercises = pd.DataFrame()
        self.df_yoga = pd.DataFrame()
        self.df_pilates = pd.DataFrame()
        self.df_mobility = pd.DataFrame()
        
        self.all_muscles = set()
        self.all_equipment = set()
        self.translations = {}

    def fetch_json(self, url: str) -> Optional[Dict]:
        """Fetch JSON data from URL."""
        try:
            response = requests.get(url)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"Error fetching data from {url}: {e}")
            return None

    def fetch_translations(self) -> None:
        """Fetch and parse translations."""
        data = self.fetch_json(self.translations_url)
        if data:
            self.translations = data

    def get_exercise_name(self, category: str, name: str) -> str:
        """Get translated exercise name."""
        translation_key = f"{category}.{name}"
        return self.translations.get(translation_key, name)

    def process_exercises_data(self) -> None:
        """Process Exercises.json data."""
        data = self.fetch_json(self.exercises_url)
        if not data:
            return

        exercises = []
        for exercise in data:
            detailed_data = self.fetch_json(f"{self.detailed_data_based_url}/{exercise['id']}")
            
            exercise_data = {
                'id': exercise['id'],
                'name': self.get_exercise_name('exercises', exercise['name']),
                'original_name': exercise['name'],
                'description': detailed_data.get('description', '') if detailed_data else '',
                'difficulty': exercise.get('difficulty', ''),
                'primary_muscles': [m['name'] for m in exercise.get('primaryMuscles', [])],
                'secondary_muscles': [m['name'] for m in exercise.get('secondaryMuscles', [])],
                'equipment': [],
                'image_url': exercise.get('imageUrl', ''),
                'thumbnail_url': exercise.get('thumbnailUrl', ''),
                'page_url': f"{self.detailed_page_based_url}/{exercise['id']}"
            }
            
            self.all_muscles.update(exercise_data['primary_muscles'])
            self.all_muscles.update(exercise_data['secondary_muscles'])
            exercises.append(exercise_data)
        
        self.df_exercises = pd.DataFrame(exercises)

    def process_yoga_data(self) -> None:
        """Process Yoga.json data."""
        data = self.fetch_json(self.yoga_url)
        if not data:
            return

        exercises = []
        for exercise in data:
            detailed_data = self.fetch_json(f"{self.detailed_data_based_url}/{exercise['id']}")
            
            exercise_data = {
                'id': exercise['id'],
                'name': self.get_exercise_name('yoga', exercise['name']),
                'original_name': exercise['name'],
                'description': detailed_data.get('description', '') if detailed_data else '',
                'difficulty': exercise.get('difficulty', ''),
                'primary_muscles': [m['name'] for m in exercise.get('primaryMuscles', [])],
                'secondary_muscles': [m['name'] for m in exercise.get('secondaryMuscles', [])],
                'equipment': [],
                'image_url': exercise.get('imageUrl', ''),
                'thumbnail_url': exercise.get('thumbnailUrl', ''),
                'page_url': f"{self.detailed_page_based_url}/{exercise['id']}"
            }
            
            self.all_muscles.update(exercise_data['primary_muscles'])
            self.all_muscles.update(exercise_data['secondary_muscles'])
            exercises.append(exercise_data)
        
        self.df_yoga = pd.DataFrame(exercises)

    def process_pilates_data(self) -> None:
        """Process Pilates.json data."""
        data = self.fetch_json(self.pilates_url)
        if not data:
            return

        exercises = []
        for exercise in data:
            detailed_data = self.fetch_json(f"{self.detailed_data_based_url}/{exercise['id']}")
            
            exercise_data = {
                'id': exercise['id'],
                'name': self.get_exercise_name('pilates', exercise['name']),
                'original_name': exercise['name'],
                'description': detailed_data.get('description', '') if detailed_data else '',
                'difficulty': exercise.get('difficulty', ''),
                'primary_muscles': [m['name'] for m in exercise.get('primaryMuscles', [])],
                'secondary_muscles': [m['name'] for m in exercise.get('secondaryMuscles', [])],
                'equipment': [],
                'image_url': exercise.get('imageUrl', ''),
                'thumbnail_url': exercise.get('thumbnailUrl', ''),
                'page_url': f"{self.detailed_page_based_url}/{exercise['id']}"
            }
            
            self.all_muscles.update(exercise_data['primary_muscles'])
            self.all_muscles.update(exercise_data['secondary_muscles'])
            exercises.append(exercise_data)
        
        self.df_pilates = pd.DataFrame(exercises)

    def process_mobility_data(self) -> None:
        """Process Mobility.json data."""
        data = self.fetch_json(self.mobility_url)
        if not data:
            return

        exercises = []
        for exercise in data:
            detailed_data = self.fetch_json(f"{self.detailed_data_based_url}/{exercise['id']}")
            
            exercise_data = {
                'id': exercise['id'],
                'name': self.get_exercise_name('mobility', exercise['name']),
                'original_name': exercise['name'],
                'description': detailed_data.get('description', '') if detailed_data else '',
                'difficulty': exercise.get('difficulty', ''),
                'primary_muscles': [m['name'] for m in exercise.get('primaryMuscles', [])],
                'secondary_muscles': [m['name'] for m in exercise.get('secondaryMuscles', [])],
                'equipment': [],
                'image_url': exercise.get('imageUrl', ''),
                'thumbnail_url': exercise.get('thumbnailUrl', ''),
                'page_url': f"{self.detailed_page_based_url}/{exercise['id']}"
            }
            
            self.all_muscles.update(exercise_data['primary_muscles'])
            self.all_muscles.update(exercise_data['secondary_muscles'])
            exercises.append(exercise_data)
        
        self.df_mobility = pd.DataFrame(exercises)

    def process_equipment_data(self) -> None:
        """Process equipment data and add it to the exercises DataFrame."""
        data = self.fetch_json(self.equipment_url)
        if not data:
            return

        equipment_dict = {eq['id']: eq['name'] for eq in data}
        self.all_equipment.update(equipment_dict.values())

        # Add equipment to exercises
        for df in [self.df_exercises, self.df_yoga, self.df_pilates, self.df_mobility]:
            if not df.empty:
                df['equipment'] = df['id'].apply(
                    lambda x: [equipment_dict[eq_id] for eq_id in 
                             self.fetch_json(f"{self.detailed_data_based_url}/{x}").get('equipment', [])]
                    if self.fetch_json(f"{self.detailed_data_based_url}/{x}") else [])

    def get_spreadsheet_id(self, drive_service) -> Optional[str]:
        """Get ID of existing spreadsheet or None if not found."""
        try:
            with open('spreadsheet_id.pickle', 'rb') as f:
                spreadsheet_id = pickle.load(f)
            
            # Verify the spreadsheet still exists
            try:
                drive_service.files().get(fileId=spreadsheet_id).execute()
                return spreadsheet_id
            except Exception:
                return None
                
        except (FileNotFoundError, EOFError):
            return None

    def clean_spreadsheet(self, sheets_service, spreadsheet_id: str) -> None:
        """Clean spreadsheet by deleting all sheets and creating new ones."""
        spreadsheet = sheets_service.spreadsheets().get(spreadsheetId=spreadsheet_id).execute()
        
        # Delete all existing sheets except the first one
        requests = []
        for sheet in spreadsheet.get('sheets', [])[1:]:
            requests.append({
                'deleteSheet': {
                    'sheetId': sheet['properties']['sheetId']
                }
            })
        
        if requests:
            sheets_service.spreadsheets().batchUpdate(
                spreadsheetId=spreadsheet_id,
                body={'requests': requests}
            ).execute()

    def update_sheet(self, sheets_service, spreadsheet_id: str, sheet_name: str, dataframe) -> None:
        """Update a specific sheet with dataframe data."""
        # Convert dataframe to list of lists
        values = [dataframe.columns.tolist()] + dataframe.values.tolist()
        
        # Clear existing data or create new sheet
        try:
            sheet_id = None
            spreadsheet = sheets_service.spreadsheets().get(spreadsheetId=spreadsheet_id).execute()
            for sheet in spreadsheet.get('sheets', []):
                if sheet['properties']['title'] == sheet_name:
                    sheet_id = sheet['properties']['sheetId']
                    break
            
            if sheet_id is None:
                # Create new sheet
                body = {
                    'requests': [{
                        'addSheet': {
                            'properties': {
                                'title': sheet_name
                            }
                        }
                    }]
                }
                response = sheets_service.spreadsheets().batchUpdate(
                    spreadsheetId=spreadsheet_id,
                    body=body
                ).execute()
                sheet_id = response['replies'][0]['addSheet']['properties']['sheetId']
            
            # Update data
            sheets_service.spreadsheets().values().update(
                spreadsheetId=spreadsheet_id,
                range=f"{sheet_name}!A1",
                valueInputOption='RAW',
                body={'values': values}
            ).execute()
            
            # Apply formatting
            self._apply_sheet_formatting(sheets_service, spreadsheet_id, sheet_id, len(dataframe.columns))
            
        except Exception as e:
            print(f"Error updating sheet {sheet_name}: {e}")

    def _apply_sheet_formatting(self, sheets_service, spreadsheet_id: str, sheet_id: int, num_columns: int) -> None:
        """Apply formatting to the sheet."""
        requests = [
            # Freeze header row
            {
                "updateSheetProperties": {
                    "properties": {
                        "sheetId": sheet_id,
                        "gridProperties": {
                            "frozenRowCount": 1
                        }
                    },
                    "fields": "gridProperties.frozenRowCount"
                }
            },
            # Set header row formatting
            {
                "repeatCell": {
                    "range": {
                        "sheetId": sheet_id,
                        "startRowIndex": 0,
                        "endRowIndex": 1
                    },
                    "cell": {
                        "userEnteredFormat": {
                            "backgroundColor": {
                                "red": 0.2,
                                "green": 0.2,
                                "blue": 0.2
                            },
                            "horizontalAlignment": "CENTER",
                            "textFormat": {
                                "foregroundColor": {
                                    "red": 1.0,
                                    "green": 1.0,
                                    "blue": 1.0
                                },
                                "bold": True
                            }
                        }
                    },
                    "fields": "userEnteredFormat(backgroundColor,textFormat,horizontalAlignment)"
                }
            },
            # Set column widths
            {
                "updateDimensionProperties": {
                    "range": {
                        "sheetId": sheet_id,
                        "dimension": "COLUMNS",
                        "startIndex": 0,
                        "endIndex": num_columns
                    },
                    "properties": {
                        "pixelSize": 150
                    },
                    "fields": "pixelSize"
                }
            },
            # Add filter
            {
                "setBasicFilter": {
                    "filter": {
                        "range": {
                            "sheetId": sheet_id,
                            "startRowIndex": 0,
                            "startColumnIndex": 0,
                            "endColumnIndex": num_columns
                        }
                    }
                }
            }
        ]
        
        sheets_service.spreadsheets().batchUpdate(
            spreadsheetId=spreadsheet_id,
            body={"requests": requests}
        ).execute()

    def compare_data(self, current_data, new_data) -> bool:
        """Compare current sheet data with new data."""
        return current_data.equals(new_data)

    def delete_spreadsheet(self, drive_service) -> None:
        """Delete the Google Spreadsheet and remove local ID file."""
        spreadsheet_id = self.get_spreadsheet_id(drive_service)
        if spreadsheet_id:
            try:
                drive_service.files().delete(fileId=spreadsheet_id).execute()
                if os.path.exists('spreadsheet_id.pickle'):
                    os.remove('spreadsheet_id.pickle')
            except Exception as e:
                print(f"Error deleting spreadsheet: {e}")

    def export_to_google_sheets(self) -> None:
        """Export data to Google Sheets."""
        # Authenticate with Google Sheets API
        creds = service_account.Credentials.from_service_account_file(
            'service_account.json',
            scopes=['https://www.googleapis.com/auth/spreadsheets', 'https://www.googleapis.com/auth/drive']
        )
        
        sheets_service = build('sheets', 'v4', credentials=creds)
        drive_service = build('drive', 'v3', credentials=creds)
        
        # Get or create spreadsheet
        spreadsheet_id = self.get_spreadsheet_id(drive_service)
        if not spreadsheet_id:
            spreadsheet = sheets_service.spreadsheets().create(body={
                'properties': {'title': 'Garmin Exercises'}
            }).execute()
            spreadsheet_id = spreadsheet['spreadsheetId']
            
            # Save the ID for future use
            with open('spreadsheet_id.pickle', 'wb') as f:
                pickle.dump(spreadsheet_id, f)
        
        # Clean the spreadsheet
        self.clean_spreadsheet(sheets_service, spreadsheet_id)
        
        # Update sheets with data
        if not self.df_exercises.empty:
            self.update_sheet(sheets_service, spreadsheet_id, "Exercises", self.df_exercises)
        if not self.df_yoga.empty:
            self.update_sheet(sheets_service, spreadsheet_id, "Yoga", self.df_yoga)
        if not self.df_pilates.empty:
            self.update_sheet(sheets_service, spreadsheet_id, "Pilates", self.df_pilates)
        if not self.df_mobility.empty:
            self.update_sheet(sheets_service, spreadsheet_id, "Mobility", self.df_mobility)
        
        print(f"Data exported to Google Sheets: https://docs.google.com/spreadsheets/d/{spreadsheet_id}")

    def run(self) -> None:
        """Run the entire process."""
        print("Fetching translations...")
        self.fetch_translations()
        
        print("Processing exercises data...")
        self.process_exercises_data()
        
        print("Processing yoga data...")
        self.process_yoga_data()
        
        print("Processing pilates data...")
        self.process_pilates_data()
        
        print("Processing mobility data...")
        self.process_mobility_data()
        
        print("Processing equipment data...")
        self.process_equipment_data()
        
        print("Exporting to Google Sheets...")
        self.export_to_google_sheets()
        
        print("Process completed successfully!")

if __name__ == "__main__":
    collector = GarminExercisesCollector()
    collector.run()