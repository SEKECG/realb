import pandas as pd
import psutil
from scapy.all import *
import threading
import time
from plotille import plot, Figure

all_macs = {}
connection2pid = {}
pid2traffic = pd.DataFrame(columns=['pid', 'name', 'upload', 'download', 'upload_speed', 'download_speed'])
global_df = pd.DataFrame(columns=['Time', 'Process', 'Upload (KB/s)', 'Download (KB/s)'])
global_graph_data = {}
is_program_running = True
connections_thread = None
printing_thread = None

def get_connections():
    while is_program_running:
        for conn in psutil.net_connections():
            if conn.pid and conn.laddr and conn.raddr:
                key = (conn.laddr, conn.raddr)
                if key not in all_macs:
                    all_macs[key] = conn.pid

        time.sleep(1)

def get_size(bytes):
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if bytes < 1024:
            return f'{bytes:.2f}{unit}'
        bytes /= 1024

def plot(df):
    fig = Figure()
    fig.width = 80
    fig.height = 20
    fig.xlabel = "Time (s)"
    fig.ylabel = "KB/s"
    fig.title = "Network Bandwidth Usage"
    fig.plot(
        *zip(*[(i, df['Upload (KB/s)'].iloc[i], df['Download (KB/s)'].iloc[i]) for i in range(len(df))]),
        legend=["Upload", "Download"],
        lc=['red', 'blue']
    )
    print(fig.show())

def print_pid2traffic():
    while is_program_running:
        print("\033c") # Clear the console
        df = pid2traffic.copy()
        df['upload'] = df['upload'].apply(get_size)
        df['download'] = df['download'].apply(get_size)
        print(df)
        if not global_df.empty:
            plot(global_df.tail(60))
        time.sleep(1)

def print_stats():
    while is_program_running:
        stat(global_df)
        time.sleep(1)

def process_packet(packet):
    if packet.haslayer(IP):
        ip_layer = packet[IP]
        src_ip = ip_layer.src
        dst_ip = ip_layer.dst
        src_port = packet[TCP].sport if packet.haslayer(TCP) else packet[UDP].sport if packet.haslayer(UDP) else None
        dst_port = packet[TCP].dport if packet.haslayer(TCP) else packet[UDP].dport if packet.haslayer(UDP) else None
        
        key = ((ip_layer.src, src_port), (ip_layer.dst, dst_port)) if src_port and dst_port else None
        if key and key in all_macs:
            pid = all_macs[key]
            if pid in connection2pid:
                if ip_layer.src == get_if_addr(conf.iface):
                    connection2pid[pid][0] += len(packet)
                else:
                    connection2pid[pid][1] += len(packet)
            else:
                connection2pid[pid] = [len(packet) if ip_layer.src == get_if_addr(conf.iface) else 0, len(packet) if ip_layer.dst == get_if_addr(conf.iface) else 0]


def stat(df):
    if not df.empty:
        print(df.style.highlight_max(subset=['Upload (KB/s)'], color='red').highlight_max(subset=['Download (KB/s)'], color='blue').to_string())


if __name__ == "__main__":
    connections_thread = threading.Thread(target=get_connections)
    printing_thread = threading.Thread(target=print_pid2traffic)
    connections_thread.start()
    printing_thread.start()

    sniff(prn=process_packet, store=0)
    is_program_running = False
    connections_thread.join()
    printing_thread.join()