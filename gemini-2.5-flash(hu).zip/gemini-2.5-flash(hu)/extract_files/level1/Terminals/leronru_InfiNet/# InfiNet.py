import os
import time
import random

def banner():
    print("Welcome to InfiNet!")

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def show_menu():
    print("\nInfiNet Menu:")
    print("1. Network Scan")
    print("2. MITM Attack")
    print("3. DNS Spoofing")
    print("4. Automatic Attack")
    print("5. Show Instructions")
    print("6. Exit")

def show_instructions():
    print("\nInstructions:")
    print("...") # Add instructions here

def network_scan():
    print("\nNetwork Scan initiated...")
    # Add network scanning logic here
    time.sleep(2)
    print("Network scan complete.")

def mitm_attack():
    print("\nMITM Attack initiated...")
    # Add MITM attack logic here
    time.sleep(2)
    print("MITM attack complete.")

def dns_spoofing():
    print("\nDNS Spoofing initiated...")
    # Add DNS spoofing logic here
    time.sleep(2)
    print("DNS spoofing complete.")

def advanced_attack_choice():
    attacks = [network_scan, mitm_attack, dns_spoofing]
    chosen_attack = random.choice(attacks)
    print(f"\nAutomatic attack selected: {chosen_attack.__name__}")
    chosen_attack()


def performance_monitor():
    start_time = time.time()
    # Simulate attack process
    time.sleep(random.uniform(1, 5))
    end_time = time.time()
    duration = end_time - start_time
    print(f"\nAttack duration: {duration:.2f} seconds")
    return duration


def dynamic_report(attack_type, duration, status="Successful"):
    print("\n--- Attack Report ---")
    print(f"Attack Type: {attack_type}")
    print(f"Status: {status}")
    print(f"Duration: {duration:.2f} seconds")
    print("--- End Report ---")


def advanced_logging(attack_type, status, duration):
    log_entry = f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] Attack Type: {attack_type}, Status: {status}, Duration: {duration:.2f} seconds\n"
    with open("infiNet.log", "a") as log_file:
        log_file.write(log_entry)

def main():
    banner()
    while True:
        clear_screen()
        show_menu()
        try:
            choice = int(input("Enter your choice: "))
            if choice == 1:
                duration = performance_monitor()
                dynamic_report("Network Scan", duration)
                advanced_logging("Network Scan", "Successful", duration)
            elif choice == 2:
                duration = performance_monitor()
                dynamic_report("MITM Attack", duration)
                advanced_logging("MITM Attack", "Successful", duration)

            elif choice == 3:
                duration = performance_monitor()
                dynamic_report("DNS Spoofing", duration)
                advanced_logging("DNS Spoofing", "Successful", duration)

            elif choice == 4:
                advanced_attack_choice()
            elif choice == 5:
                show_instructions()
            elif choice == 6:
                print("Exiting InfiNet...")
                break
            else:
                print("Invalid choice. Please try again.")
            input("Press Enter to continue...")
        except ValueError:
            print("Invalid input. Please enter a number.")

if __name__ == "__main__":
    main()