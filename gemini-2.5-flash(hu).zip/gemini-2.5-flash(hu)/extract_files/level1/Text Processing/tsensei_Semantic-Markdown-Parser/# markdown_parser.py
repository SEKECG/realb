from token_encoder.encode import get_token_length
from text_splitter import split_text_into_sentences

class SemanticChunk:
    def __init__(self, content, headers):
        self.content = content
        self.token_length = get_token_length(content)
        self.headers = headers

class TreeElement:
    def __init__(self, header, content, children):
        self.header = header
        self.content = content
        self.token_length = get_token_length(content)
        self.children = children

class SemanticMarkdownParser:
    def combine_chunks(self, chunk1, chunk2):
        combined_content = chunk1.content + " " + chunk2.content
        combined_headers = chunk1.headers + chunk2.headers
        return SemanticChunk(combined_content, combined_headers)

    def format_chunk_with_headers(self, headers, content, include_hashes=False):
        formatted_content = content
        if include_hashes:
            for header in headers:
                formatted_content = f"# {header}\n" + formatted_content
        else:
            formatted_content = "\n".join(headers) + "\n" + formatted_content
        return formatted_content

    def get_full_header_path(self, headers):
        return " > ".join(headers)

    def get_semantic_chunks(self, root, max_tokens=500):
        chunks = self.process_tree_to_chunks(root, max_tokens)
        formatted_chunks = []
        for chunk in chunks:
            formatted_chunk = self.format_chunk_with_headers(chunk.headers, chunk.content)
            formatted_chunks.append(formatted_chunk)
        return formatted_chunks

    def parse_markdown_to_tree(self, markdown_text):
        # Placeholder implementation. Replace with actual markdown parsing logic using llama_index.
        # This example creates a simple tree structure for demonstration.
        if not markdown_text:
            raise ValueError("Markdown text cannot be empty.")
        return TreeElement("Root", markdown_text, [])

    def process_tree_to_chunks(self, root, max_tokens=500, current_headers=None):
        if current_headers is None:
            current_headers = []
        if root.header:
            current_headers.append(root.header)
        chunks = []
        for child in root.children:
            chunks.extend(self.process_tree_to_chunks(child, max_tokens, current_headers.copy()))
        
        if root.content:
            split_content = split_text_into_sentences(root.content, chunk_size=max_tokens)
            for content_chunk in split_content:
                chunks.append(SemanticChunk(content_chunk, current_headers.copy()))
        return chunks