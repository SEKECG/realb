def split_text_into_sentences(text, parent_text=None, chunk_size=500):
    # Placeholder implementation.  Replace with actual sentence splitting logic.
    sentences = text.split('.')
    chunks = []
    current_chunk = ""
    current_token_length = 0
    for sentence in sentences:
        sentence_token_length = len(sentence.split())
        if current_token_length + sentence_token_length <= chunk_size:
            current_chunk += sentence + "."
            current_token_length += sentence_token_length
        else:
            chunks.append(current_chunk)
            current_chunk = sentence + "."
            current_token_length = sentence_token_length
    chunks.append(current_chunk)
    return chunks