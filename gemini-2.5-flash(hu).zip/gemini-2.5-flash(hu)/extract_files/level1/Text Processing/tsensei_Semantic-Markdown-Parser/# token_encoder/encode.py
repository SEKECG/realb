current_dir = None
tokenizer = None
tokenizer_path = None

def get_token_length(content):
    return len(tokenizer.encode(content))

def get_tokens(content):
    return tokenizer.encode(content)