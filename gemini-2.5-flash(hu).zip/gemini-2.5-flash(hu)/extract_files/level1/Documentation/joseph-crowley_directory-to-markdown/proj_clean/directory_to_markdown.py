```python
import os
import pathlib
from argparse import ArgumentParser

DEFAULT_IGNORE_DIRS = {
    'node_modules', '__pycache__', '.git', '.vscode', '.idea'
}

def directory_to_markdown(directory_path, output_file, file_types, ignore_dirs, recursive, max_file_size_mb):
    directory_path = pathlib.Path(directory_path)
    output_file = pathlib.Path(output_file)
    output_file.parent.mkdir(parents=True, exist_ok=True)

    with open(output_file, 'w', encoding='utf-8') as f:
        for root, _, files in os.walk(directory_path):
            root_path = pathlib.Path(root)
            if is_ignored(root_path, ignore_dirs):
                continue

            for file in files:
                file_path = root_path / file
                if file_path.suffix.lower() in file_types:
                    try:
                        content = read_file_safely(file_path, max_file_size_mb)
                        if content:
                            f.write(f"# {file_path}\n\n")
                            f.write(f"```\n{content}\n```\n\n")
                    except Exception as e:
                        print(f"Error processing {file_path}: {e}")

            if not recursive:
                break


def is_ignored(path, ignore_dirs):
    for ignore_dir in ignore_dirs:
        if ignore_dir in path.parts:
            return True
    return False


def read_file_safely(file_path, max_size_mb):
    max_size_bytes = max_size_mb * 1024 * 1024
    if file_path.stat().st_size > max_size_bytes:
        return None

    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return f.read()
    except UnicodeDecodeError:
        try:
            with open(file_path, 'r', encoding='latin-1') as f:
                return f.read()
        except Exception as e:
            print(f"Error reading file {file_path}: {e}")
            return None


if __name__ == "__main__":
    parser = ArgumentParser(description="Directory to Markdown Converter")
    parser.add_argument("directory_path", help="Directory to traverse")
    parser.add_argument("output_file", help="Markdown file to generate")
    parser.add_argument("--file_types", nargs="+", default=['.txt', '.py'], help="File extensions to include")
    parser.add_argument("--ignore_dirs", nargs="+", default=DEFAULT_IGNORE_DIRS, help="Directory names to ignore")
    parser.add_argument("--recursive", action="store_true", help="Traverse subdirectories")
    parser.add_argument("--max_file_size_mb", type=int, default=10, help="Maximum file size to process in megabytes")
    args = parser.parse_args()

    directory_to_markdown(args.directory_path, args.output_file, set(args.file_types), set(args.ignore_dirs), args.recursive, args.max_file_size_mb)

```