class MessageProtocol:
    @staticmethod
    def add_metadata(message_dict, key, value):
        message_dict[key] = value

    @staticmethod
    def format_message(recipient, message, metadata=None):
        msg = {"recipient": recipient, "message": message}
        if metadata:
            msg.update(metadata)
        return msg

    @staticmethod
    def get_metadata(message_dict, key):
        return message_dict.get(key)

    @staticmethod
    def parse_message(raw_message):
        #Simulate parsing
        return {"message": raw_message}

    @staticmethod
    def remove_metadata(message_dict, key):
        if key in message_dict:
            del message_dict[key]

    @staticmethod
    def validate_message(message_dict):
        # Simulate validation
        return "message" in message_dict