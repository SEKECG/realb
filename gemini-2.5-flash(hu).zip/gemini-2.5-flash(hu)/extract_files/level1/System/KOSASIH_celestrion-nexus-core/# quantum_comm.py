from message_protocol import MessageProtocol

class QuantumComm:
    def __init__(self):
        self.entangled_pairs = []
        self.max_pairs = 10

    def create_entangled_pair(self):
        if len(self.entangled_pairs) < self.max_pairs:
            self.entangled_pairs.append(True)  # Simulate pair creation

    def format_message(self, recipient, message):
        return MessageProtocol.format_message(recipient, message)

    def measure_state(self, pair_index):
        # Simulate measurement
        return self.entangled_pairs[pair_index]

    def parse_message(self, raw_message):
        return MessageProtocol.parse_message(raw_message)

    def receive_message(self, pair_index):
        #Simulate receiving
        print(f"Message received from pair {pair_index}")

    def transmit_message(self, message, pair_index):
        #Simulate transmission
        print(f"Message transmitted through pair {pair_index}")

    def validate_message(self, message_dict):
        return MessageProtocol.validate_message(message_dict)