class EntanglementManager:
    def __init__(self):
        self.active_pairs = []
        self.quantum_comm = QuantumComm()

    def establish_connection(self):
        self.quantum_comm.create_entangled_pair()

    def list_active_pairs(self):
        print(self.active_pairs)

    def receive_message(self, pair_index):
        self.quantum_comm.receive_message(pair_index)

    def remove_pair(self, pair_index):
        if 0 <= pair_index < len(self.active_pairs):
            del self.active_pairs[pair_index]

    def send_message(self, message, pair_index):
        self.quantum_comm.transmit_message(message, pair_index)