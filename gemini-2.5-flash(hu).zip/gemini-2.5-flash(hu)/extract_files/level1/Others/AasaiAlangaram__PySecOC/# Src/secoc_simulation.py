import logging
import time
import threading
from PyQt5.QtWidgets import QApplication, QMainWindow, QTableWidgetItem, QVBoxLayout, QWidget, QPushButton
from PyQt5.QtCore import QTimer, pyqtSignal

SECRET_KEY = b'mysecretkey'  # Replace with a strong, randomly generated key
app = None
can_bus = []
freshness_manager = {}
stop_event = threading.Event()
window = None


def generate_mac(message, freshness, key):
    # Replace with actual MAC generation logic using the key
    return f"MAC_{message}_{freshness}"


def setup_logging():
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


def verify_mac(message, freshness, received_mac, key):
    # Replace with actual MAC verification logic using the key
    generated_mac = generate_mac(message, freshness, key)
    return generated_mac == received_mac


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.clear_button = QPushButton("Clear")
        self.receiver_thread = ReceiverThread()
        self.replay_attack_triggered = False
        self.replay_button = QPushButton("Replay Attack")
        self.sender_thread = SenderThread()
        self.start_stop_button = QPushButton("Start")
        self.tableWidget = None  # Initialize later after creating the table

        # ... (Rest of the UI setup) ...

    def clear_simulation(self):
        self.tableWidget.clearContents()

    def closeEvent(self, event):
        stop_event.set()
        self.receiver_thread.join()
        self.sender_thread.join()
        event.accept()


    def toggle_simulation(self):
        if self.start_stop_button.text() == "Start":
            self.start_stop_button.setText("Stop")
            self.receiver_thread.start()
            self.sender_thread.start()
        else:
            self.start_stop_button.setText("Start")
            stop_event.set()


    def trigger_replay_attack(self):
        self.replay_attack_triggered = True

    def update_table(self, message_parts, is_replay_attack, message_type):
        # ... (Update table logic) ...
        pass


class ReceiverThread(threading.Thread):
    new_message_signal = pyqtSignal(list, bool, str)
    def __init__(self):
        super().__init__()
        self.replay_attack_triggered = False

    def run(self):
        while not stop_event.is_set():
            # ... (Receive message logic) ...
            pass


class SenderThread(threading.Thread):
    new_message_signal = pyqtSignal(list, bool, str)
    def __init__(self):
        super().__init__()
        self.last_sent_freshness = 0

    def run(self):
        while not stop_event.is_set():
            # ... (Send message logic) ...
            pass

def main():
    global app, window
    setup_logging()
    app = QApplication([])
    window = MainWindow()
    window.show()
    app.exec_()

if __name__ == "__main__":
    main()