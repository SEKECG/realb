import sys
from contextlib import contextmanager
from functools import wraps
from types import TracebackType
from typing import Any, Callable, ContextVar, Iterator, Iterable, Tuple, Type

HAS_FORBIDDENFRUIT = sys.version_info >= (3, 11)
_ModuleList = Iterable
_ModuleOrModuleList = Any
_T = Type


blockbuster_skip = ContextVar("blockbuster_skip", default=False)


class BlockingError(Exception):
    def __init__(self, func):
        self.func = func
        super().__init__(f"Blocking call detected: {func}")


class BlockBusterFunction:
    def __init__(self, module, func_name, scanned_modules, excluded_modules,
                 can_block_functions=None, can_block_predicate=None):
        self._excluded_modules = excluded_modules
        self._scanned_modules = scanned_modules
        self.activated = True
        self.can_block_functions = can_block_functions or []
        self.can_block_predicate = can_block_predicate
        self.full_name = f"{module}.{func_name}"
        self.func_name = func_name
        self.module = module
        self.original_func = getattr(module, func_name)

    def activate(self):
        self.activated = True
        return self

    def can_block_in(self, filename, functions):
        if isinstance(functions, str):
            functions = (functions,)
        self.can_block_functions.append((filename, functions))
        return self

    def deactivate(self):
        self.activated = False
        return self


class BlockBuster:
    def __init__(self, scanned_modules=None, excluded_modules=None):
        self.functions = self._wrap_blocking(scanned_modules, excluded_modules)

    def activate(self):
        for func in self.functions.values():
            func.activate()

    def deactivate(self):
        for func in self.functions.values():
            func.deactivate()

    def _wrap_blocking(self, scanned_modules, excluded_modules):
        wrapped = {}
        for getter in (
            self._get_time_wrapped_functions,
            self._get_os_wrapped_functions,
            self._get_io_wrapped_functions,
            self._get_socket_wrapped_functions,
            self._get_ssl_wrapped_functions,
            self._get_sqlite_wrapped_functions,
            self._get_lock_wrapped_functions,
            self._get_builtins_wrapped_functions,
        ):
            wrapped.update(getter(scanned_modules, excluded_modules))
        return wrapped

    def _get_time_wrapped_functions(self, modules, excluded_modules):
        return {"time.sleep": self._wrap_time_sleep(modules, excluded_modules)}

    def _get_os_wrapped_functions(self, modules, excluded_modules):
        return {"os.system": self._wrap_os_system(modules, excluded_modules)}

    def _get_io_wrapped_functions(self, modules, excluded_modules):
        return {}

    def _get_socket_wrapped_functions(self, modules, excluded_modules):
        return {}

    def _get_ssl_wrapped_functions(self, modules, excluded_modules):
        return {}

    def _get_sqlite_wrapped_functions(self, modules, excluded_modules):
        return {}

    def _get_lock_wrapped_functions(self, modules, excluded_modules):
        return {}

    def _get_builtins_wrapped_functions(self, modules, excluded_modules):
        return {}

    def _wrap_time_sleep(self, modules, excluded_modules):
        return BlockBusterFunction(
            module="time", func_name="sleep", scanned_modules=modules,
            excluded_modules=excluded_modules)

    def _wrap_os_system(self, modules, excluded_modules):
        return BlockBusterFunction(
            module="os", func_name="system", scanned_modules=modules,
            excluded_modules=excluded_modules)


    def _resolve_module_paths(self, modules):
        return []

    def _socket_exclude(self, sock, _, __):
        return False

    def _blocking_error(self, func):
        return BlockingError(func)

    @contextmanager
    def _run_with_skip(self, skip):
        token = blockbuster_skip.set(skip)
        try:
            yield
        finally:
            blockbuster_skip.reset(token)

    @staticmethod
    def blockbuster_ctx(scanned_modules=None, excluded_modules=None):
        @contextmanager
        def inner():
            instance = BlockBuster(scanned_modules, excluded_modules)
            instance.activate()
            try:
                yield instance
            finally:
                instance.deactivate()

        return inner()