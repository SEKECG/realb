import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

class MyBaseModel:
    model_config = {"json_encoders": {str: lambda v: v}}

class AskDatabaseResult(MyBaseModel):
    executed_sql: str
    execution_result: str

class Column(MyBaseModel):
    AutoIncrement: Any
    ColumnName: Any
    ColumnType: Any
    Description: Any
    Nullable: Any

class DatabaseDetail(MyBaseModel):
    DatabaseId: Any
    DbType: Any
    InstanceAlias: Any
    InstanceId: Any
    SchemaName: Any
    State: Any

class DatabaseInfo(MyBaseModel):
    DatabaseId: Any
    DbType: Any
    Host: Any
    Port: Any
    SchemaName: Any

class ExecuteScriptResult(MyBaseModel):
    RequestId: str
    Results: List["ResultSet"]
    Success: bool

    def __str__(self):
        if self.Success and self.Results:
            return "\n".join(str(result) for result in self.Results)
        elif self.Success:
            return "Script executed successfully."
        else:
            return "Script execution failed."

class Index(MyBaseModel):
    IndexColumns: Any
    IndexName: Any
    IndexType: Any
    Unique: Any

class InstanceDetail(MyBaseModel):
    InstanceAlias: Any
    InstanceId: Any
    InstanceType: Any
    State: Any

class InstanceInfo(MyBaseModel):
    host: Any
    instance_id: Any
    port: Any

class ResultSet(MyBaseModel):
    ColumnNames: List[str]
    MarkdownTable: Optional[str]
    RowCount: int
    Rows: List[Dict[str, Any]]
    Success: bool

class SqlResult(MyBaseModel):
    sql: Optional[str]

class TableDetail(MyBaseModel):
    ColumnList: Any
    IndexList: Any

class ToolRegistry:
    def __init__(self, mcp):
        self.mcp = mcp
        self.default_database_id = mcp.state.default_database_id if hasattr(mcp.state, 'default_database_id') else None

    def _register_configured_db_toolset(self):
        pass

    def _register_full_toolset(self):
        pass

    def register_tools(self):
        pass


g_reserved = {}
logger = logging.getLogger(__name__)

def _format_as_markdown_table(column_names, rows):
    pass

def add_instance(db_user, db_password, instance_resource_id, host, port, region):
    pass

def configureDtsJob(region_id, job_type, source_endpoint_region, source_endpoint_instance_type, source_endpoint_engine_name, source_endpoint_instance_id, source_endpoint_user_name, source_endpoint_password, destination_endpoint_region, destination_endpoint_instance_type, destination_endpoint_engine_name, destination_endpoint_instance_id, destination_endpoint_user_name, destination_endpoint_password, db_list):
    pass

def create_client():
    pass

def execute_script(database_id, script, logic):
    pass

def getDtsJob(region_id, dts_job_id):
    pass

def get_database(host, port, schema_name, sid):
    pass

def get_dts_client(region_id):
    pass

def get_instance(host, port, sid):
    pass

def get_meta_table_detail_info(table_guid):
    pass

async def lifespan(app):
    pass

def list_tables(database_id, search_name, page_number, page_size):
    pass

def nl2sql(database_id, question, knowledge):
    pass

def run_server():
    pass

def search_database(search_key, page_number, page_size):
    pass

def startDtsJob(region_id, dts_job_id):
    pass

def main():
    pass