import re
from dataclasses import dataclass, field
from typing import Union, Dict, Callable
from .color import Color
from .gradient import Gradient

LAYER_SPLITTER = re.compile(r"(\(.*?\))")
KeyType = str
DelimiterType = str
AnyType = str
FunctionalType = Callable

@dataclass
class TextStyle:
    """Text style dataclass with foreground and background colors/gradients and additional properties
    such as underline, italic and so on."""
    fg_style: Union[Gradient, Color, str] = ""
    bg_style: Union[Gradient, Color, str] = ""
    bold: bool = False
    italic: bool = False
    underline: bool = False
    double_underline: bool = False
    crossed: bool = False
    darken: bool = False

    def __post_init__(self):
        """Ensure that the foreground and background style are converted into a Color or Gradient object"""
        pass

    def _ensure_style(self, value):
        """Convert any non Color or Gradient object into a Color assuming an hexadecimal code, RGB tuple or preset string color
        has been specified.

        Args:
            value (Union[Gradient, Color, str, tuple[int, int, int]]): A color value either as a Gradient, Color, rgb tuple, preset or hex code

        Returns:
            Union[Color, Gradient]: Converted style
        """
        pass

    def apply(self, text):
        """Apply the style properties to the given text

        Args:
            text (str): A string

        Returns:
            str: Stylised text
        """
        pass

@dataclass
class FunctionalStyle:
    """Functional styling class that can split a string with regular expression
    and infer each match to a specific style."""
    pattern: str
    styles: Dict[Union[KeyType, DelimiterType], TextStyle] = field(default_factory=dict)
    infer_func: Callable[[AnyType], Union[TextStyle, None]] = None

    def __post_init__(self):
        """Ensure that the styles dictionary is a default dict to avoid any inference issue"""
        pass

    def apply(self, text):
        """Apply the functional style to the text.

        The method uses the splitting regex pattern to separate the text into
        multiple matched strings and their delimiters.
        Then, infer the string to link the corresponding style.

        Args:
            text (str): A string

        Returns:
            str: Stylised string
        """
        pass

def colorize(text, text_color=None, bg_color=None):
    """Colorize the console text with a foreground and background color

    Args:
        text (str): String text to colorize
        text_color (str, optional): Color of the text foreground. Defaults to None.
        bg_color (str, optional): Color of the text background. Defaults to None.

    Returns:
        str: Formatted console ANSI escape code for colorizing text
    """
    pass

def clean_style(text):
    """Remove ANSI escape sequences from a given text string to clean up any style or color formatting."""
    pass

def infer_type(self, value):
    """Naive type inference that is sufficient for nn.Layer parsing"""
    pass