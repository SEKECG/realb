from typing import ClassVar, Dict, List
from dataclasses import dataclass, field
from .color import Color

palette_autumn_foliage = []
palette_forest_greens = []
palette_lavender_dreams = []
palette_monochrome = []
palette_ocean_breeze = []
palette_pastel = []
palette_rainbow = []
palette_retro_neon = []
palette_warm_sunset = []

@dataclass
class Palette:
    """Palette dataclass that stores a palette name and a list of colors"""
    name: str
    colors: List[Color]
    _registry: ClassVar[Dict[str, "Palette"]] = field(default_factory=dict)
    disable_registry: bool = False

    @classmethod
    def get_palette(cls, name):
        """Retrieve a palette by name."""
        pass

    def __getitem__(self, index):
        """Get a color by index, cycling through the palette."""
        pass

    def __post_init__(self):
        """Automatically register the new palette."""
        pass

    def generate_gradient(self, n):
        """Generate a gradient of `n` colors, ensuring the first and last colors are from the palette."""
        pass

    @classmethod
    def get(cls, name):
        """Retrieve a palette by name."""
        pass