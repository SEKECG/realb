from dataclasses import dataclass, field
from typing import List, Union

@dataclass
class GradientChunk:
    pass

@dataclass
class Gradient:
    """Dataclass handling Gradient style from a given color palette and different display properties."""
    palette: Union["Palette", str]
    interpolate: bool = True
    repeat: bool = True
    reverse: bool = False
    window_size: int = 1

    def __post_init__(self):
        pass

    def _ensure_palette(self, palette):
        """Ensure that the palette property is of type Palette otherwise get the palette by its name if it exists.

        Args:
            palette (Union[Palette, str]): A color palette or the name of a registered palette

        Returns:
            Palette: A color palette
        """
        pass

    def apply(self, text):
        """Apply the gradient effect to a text using a palette of colors.

        Args:
            palette (Palette): Palette of colors to use.
            text (str): Text to colorize.
            repeat (bool): Whether to repeat colors from the palette. Defaults to True.

        Returns:
            List[GradientChunk]: A list of gradient chunk with start and end index with the proper color to apply.
        """
        pass

from .palette import Palette #Import needed for type hinting