from dataclasses import dataclass, field
from typing import ClassVar, Dict, Callable, Union, List
from .style import TextStyle, FunctionalStyle, ModuleStyle

@dataclass
class ModuleStyle:
    """Dataclass for styling a module representative string

    Each module is usually printed as (name): layer(extra_information)
    As such, we provide a different style for each of these 3 blocks"""
    name_style: Union[TextStyle, FunctionalStyle]
    layer_style: Union[TextStyle, FunctionalStyle]
    extra_style: Union[TextStyle, FunctionalStyle]


class ColorStrategy:
    """Styling strategy that allocate the corresponding module style to a given module based on registered pattern"""
    _registry: ClassVar[Dict[str, Callable]] = field(default_factory=dict)

    @classmethod
    def get_strategy(cls, key, *args, **kwargs):
        """        Retrieve a color strategy instance based on its string key.

        Args:
            key (str): The key name of the strategy.
            *args: Positional arguments for the strategy's constructor.
            **kwargs: Keyword arguments for the strategy's constructor.

        Returns:
            ColorStrategy: An instance of the corresponding strategy.

        Raises:
            ValueError: If the key is not registered.
        """
        pass

    @classmethod
    def available_strategies(cls):
        """Return a list of all available strategy keys."""
        pass

    @classmethod
    def create(cls, key, *args, **kwargs):
        """Factory method to create an instance of a registered strategy by key."""
        pass

    def get_style(self, module, params):
        """Return the appropriate color for the module based on some properties given by the strategy

        Args:
            module (Module): A Pytorch module
            params (dict): A dictionary with special parameters of the tree module node

        Returns:
            str: Color of the module
        """
        pass

    @classmethod
    def register(cls, key):
        """Decorator to register a strategy with a specific string key."""
        pass

@ColorStrategy.register("constant")
@dataclass
class ConstantColorStrategy(ColorStrategy):
    """Provide a color strategy that applies a constant color and predefined styling to module names, including double underline and italic formatting."""
    color: Union[str, tuple[int, int, int]] = ""

    def __init__(self, color=""):
        """Provide a color strategy that applies a constant color and predefined styling to module names, including double underline and italic formatting.Initialize an instance with a specified color, which can be either a string or a tuple of integers representing RGB values. If no color is provided, it defaults to an empty string."""
        pass

    def get_style(self, module, config):
        """Retrieve the style configuration for a specified module, including text color, gradient, and text decoration settings."""
        pass

@ColorStrategy.register("layer")
@dataclass
class LayerColorStrategy(ColorStrategy):
    """Define a strategy for determining the color style of a layer based on the given module."""
    def get_style(self, module):
        """Define a strategy for determining the color style of a layer based on the given module.Retrieve the style configuration or attributes associated with the specified module."""
        pass

@ColorStrategy.register("trainable")
@dataclass
class TrainableStrategy(ColorStrategy):
    """Styling strategy that handles trainable, non-trainable and mixed trainable layers/modules"""
    def get_style(self, module, config):
        """Styling strategy that handles trainable, non-trainable and mixed trainable layers/modulesDetermine the visual style of a module based on its parameter properties (requires_grad) and configuration (is_root), returning a ModuleStyle object with appropriate text coloring (red, green, yellow, or none)."""
        pass