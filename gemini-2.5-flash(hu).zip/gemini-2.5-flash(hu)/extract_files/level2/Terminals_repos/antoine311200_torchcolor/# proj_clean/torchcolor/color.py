import re
from dataclasses import dataclass

background_colors = {}
foreground_colors = {}
reset_color = "\033[0m"

@dataclass
class Color:
    """Color dataclass with rgb and hexadecimal convertion as well as ANSI convertion for terminal printing"""
    def to_ansi(self, is_background):
        """Convert a color to ANSI Escape Code based on whether it is a preset or rgb/hex, background or foreground color."""
        pass

    def to_rgb(self):
        """Convert a color value (either as a tuple or a hex string) to an RGB tuple representation, ensuring the input is valid and properly formatted."""
        pass

def hex_to_rgb(hex_color):
    """Convert a hex color string (e.g., "#RRGGBB") to an RGB tuple."""
    pass

def is_rgb(color):
    """Check whether a color is a valid rgb tuple"""
    pass