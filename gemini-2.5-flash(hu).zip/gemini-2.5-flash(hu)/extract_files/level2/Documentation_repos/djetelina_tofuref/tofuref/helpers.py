import re
from pathlib import Path
import logging
import json

CODEBLOCK_REGEX = re.compile(r"```(.*?)\n(.*?)```", re.DOTALL)
LOGGER = logging.getLogger(__name__)
jsonlib = json


def cached_file_path(endpoint):
    return Path("./.cache") / endpoint.replace("/", "_")


def get_from_cache(endpoint):
    file = cached_file_path(endpoint)
    if file.exists() and not is_provider_index_expired(file):
        with open(file, "r") as f:
            return f.read()
    return None


def get_registry_api(endpoint, json=True, log_widget=None, timeout=10):
    cached = get_from_cache(endpoint)
    if cached:
        LOGGER.info(f"Using cached response for {endpoint}")
        if json:
            return jsonlib.loads(cached)
        return cached

    try:
        import requests

        url = f"https://registry.opentofu.org/{endpoint}"
        response = requests.get(url, timeout=timeout)
        response.raise_for_status()
        if log_widget:
            log_widget.update(f"GET {url}")
        if json:
            data = response.json()
            save_to_cache(endpoint, jsonlib.dumps(data, indent=2))
            return data
        save_to_cache(endpoint, response.text)
        return response.text
    except requests.exceptions.RequestException as e:
        LOGGER.exception(f"Error fetching {endpoint}: {e}")
        return None


def header_markdown_split(contents):
    match = re.match(r"---\n(.*?)\n---\n", contents, re.DOTALL)
    if match:
        header = jsonlib.loads(match.group(1))
        markdown = contents[match.end():]
        return header, markdown
    return {}, contents


def is_provider_index_expired(file, timeout=None):
    import os
    import time

    try:
        timestamp = os.path.getmtime(file)
        now = time.time()
        return now - timestamp > 30 * 24 * 3600
    except FileNotFoundError:
        return True


def save_to_cache(endpoint, contents):
    file = cached_file_path(endpoint)
    file.parent.mkdir(parents=True, exist_ok=True)
    with open(file, "w") as f:
        f.write(contents)