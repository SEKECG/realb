from textual.reactive import var
from textual.widgets import Static, Footer, Header
from textual.binding import Binding
from rich.syntax import Syntax
from rich.markdown import Markdown
from rich.panel import Panel
from rich.text import Text
from typing import List, Dict


class CodeBlockSelect(Static):
    BINDINGS = [
        Binding("j", "action_down", "Down"),
        Binding("k", "action_up", "Up"),
        Binding("enter", "action_close", "Select"),
        Binding("escape", "action_close", "Close"),
    ]

    highlighted = var(0)
    border_title = "Code Blocks"

    def __init__(self, **kwargs):
        super().__init__(
            "", name="code_block_selector", id="code_block_selector", classes="code-block-selector"
        )
        self.border_title = kwargs.get("title", self.border_title)

    def action_close(self):
        self.post_message(CodeBlockSelect.Closed(self))

    def on_option_selected(self, option):
        pass

    def set_new_options(self, code_blocks: Dict[str, List[str]]):
        markdown_blocks = []
        for section, blocks in code_blocks.items():
            markdown_blocks.append(f"### {section}")
            for i, code_block in enumerate(blocks):
                markdown_blocks.append(f"```\n{code_block}\n```")
        self.update(Markdown("\n".join(markdown_blocks)))
        self.highlighted = 0

    class Closed(Static.Closed):
        pass