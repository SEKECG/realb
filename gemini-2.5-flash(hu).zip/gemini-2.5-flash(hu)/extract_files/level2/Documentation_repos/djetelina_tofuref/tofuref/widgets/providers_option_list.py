from textual.reactive import var
from textual.widgets import Static, Footer, Header
from textual.binding import Binding
from rich.syntax import Syntax
from rich.markdown import Markdown
from rich.panel import Panel
from rich.text import Text
from typing import List, Dict
from ..providers import Provider
from ..helpers import LOGGER


class ProvidersOptionList(Static):
    BINDINGS = [
        Binding("j", "action_down", "Down"),
        Binding("k", "action_up", "Up"),
        Binding("enter", "on_option_selected", "Select"),
    ]

    border_subtitle = var("")
    border_title = "Providers"

    def __init__(self, **kwargs):
        super().__init__(
            "", name="nav-providers", id="nav-providers", classes="nav-selector bordered"
        )
        self.border_title = kwargs.get("title", self.border_title)

    def load_index(self):
        pass

    def on_option_selected(self, option):
        pass

    def populate(self, providers: List[Provider]):
        self.border_subtitle = f"{len(providers)} providers"
        self.update(Markdown("\n".join([f"- {p.display_name}" for p in providers])))