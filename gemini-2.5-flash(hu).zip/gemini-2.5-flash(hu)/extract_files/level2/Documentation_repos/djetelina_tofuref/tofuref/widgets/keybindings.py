VIM_OPTION_LIST_NAVIGATE = {
    "j": "down",
    "k": "up",
    "gg": "home",
    "G": "end",
    "ctrl+d": "page_down",
    "ctrl+u": "page_up",
    "enter": "select",
}