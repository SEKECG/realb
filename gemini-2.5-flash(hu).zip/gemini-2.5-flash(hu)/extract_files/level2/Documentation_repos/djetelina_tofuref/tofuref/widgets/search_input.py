from textual.reactive import var
from textual.widgets import Input
from textual.binding import Binding


class SearchInput(Input):
    BINDINGS = [Binding("escape", "action_close", "Close")]

    border_title = "Search"

    def __init__(self, **kwargs):
        super().__init__(placeholder="Search...", id="search", classes="search")
        self.border_title = kwargs.get("title", self.border_title)

    def action_close(self):
        self.value = ""
        self.post_message(SearchInput.Changed(self, self.value))
        self.post_message(SearchInput.Submitted(self, None))
        self.parent.focus()