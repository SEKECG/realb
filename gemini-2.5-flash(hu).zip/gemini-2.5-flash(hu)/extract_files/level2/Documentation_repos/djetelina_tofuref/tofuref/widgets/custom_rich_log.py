from textual.widgets import Static, Footer, Header
from textual.reactive import var
from textual.binding import Binding
from rich.panel import Panel
from rich.text import Text
from typing import List, Dict


class CustomRichLog(Static):
    display = var(False)
    border_title = "Log"
    border_subtitle = "v0.1.0"

    def __init__(self, **kwargs):
        super().__init__(
            "", name="log", id="log", classes="log bordered", style="on black"
        )
        self.border_title = kwargs.get("title", self.border_title)
        self.border_subtitle = kwargs.get("subtitle", self.border_subtitle)
        self.display = False