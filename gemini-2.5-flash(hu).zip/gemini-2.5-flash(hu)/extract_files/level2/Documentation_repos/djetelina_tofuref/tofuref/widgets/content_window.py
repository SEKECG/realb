from textual.reactive import var
from textual.widgets import Static, Footer, Header
from textual.binding import Binding
from rich.syntax import Syntax
from rich.markdown import Markdown
from rich.panel import Panel
from rich.text import Text
from typing import List, Dict


class ContentWindow(Static):
    ALLOW_MAXIMIZE = True
    BINDINGS = [
        Binding("j", "action_down", "Down"),
        Binding("k", "action_up", "Up"),
        Binding("ctrl+d", "action_page_down", "Page down"),
        Binding("ctrl+u", "action_page_up", "Page up"),
        Binding("g", "action_scroll_home", "Go to top"),
        Binding("G", "action_scroll_end", "Go to bottom"),
        Binding("y", "action_yank", "Yank code"),
        Binding("t", "action_toggle_toc", "Toggle Table of Contents"),
    ]

    show_table_of_contents = var(False)
    content = var("")

    def __init__(self, content, **kwargs):
        super().__init__(
            content, name="content_window", id="content", classes="content bordered"
        )
        self.content = content

    def action_down(self):
        pass

    def action_page_down(self):
        pass

    def action_page_up(self):
        pass

    def action_scroll_end(self):
        pass

    def action_scroll_home(self):
        pass

    def action_toggle_toc(self):
        pass

    def action_up(self):
        pass

    def action_yank(self):
        pass

    def go(self, location):
        pass

    def update(self, markdown):
        self.content = markdown