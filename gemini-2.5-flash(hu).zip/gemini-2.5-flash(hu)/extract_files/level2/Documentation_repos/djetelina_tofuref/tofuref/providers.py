from .resources import Resource, ResourceType
from .helpers import get_registry_api, LOGGER
import json


class Provider:
    def __init__(self, data, log_widget):
        self.raw_json = data
        self.log_widget = log_widget
        self._endpoint = None
        self._active_version = None
        self._overview = None
        self.load_resources()

    def _endpoint_getter(self):
        if self.active_version:
            return f"{self.raw_json['organization']}/{self.raw_json['name']}/{self.active_version}"
        return f"{self.raw_json['organization']}/{self.raw_json['name']}"

    @property
    def active_version(self):
        if self._active_version is None and self.versions:
            self._active_version = self.versions[0]['id']
        return self._active_version

    @active_version.setter
    def active_version(self, value):
        self._active_version = value
        self.load_resources()

    @property
    def display_name(self):
        return f"{self.raw_json['organization']}/{self.raw_json['name']}"

    @property
    def fork_of(self):
        return self.raw_json.get('fork_of')

    @property
    def use_configuration(self):
        return self.raw_json.get('use_configuration', '')

    def __rich__(self):
        return json.dumps({k: v for k, v in self.__dict__.items() if k not in ('raw_json', 'versions')})

    def load_resources(self):
        endpoint = self._endpoint_getter() + "/index.json"
        index = get_registry_api(endpoint, log_widget=self.log_widget)
        if index:
            self.resources = []
            self.datasources = []
            self.functions = []
            self.guides = []
            for resource_type, resources in index.items():
                for resource_data in resources:
                    resource = Resource.from_json(resource_data, self)
                    self.resources.append(resource)
                    if resource.type == ResourceType.RESOURCE:
                        self.resources.append(resource)
                    elif resource.type == ResourceType.DATASOURCE:
                        self.datasources.append(resource)
                    elif resource.type == ResourceType.FUNCTION:
                        self.functions.append(resource)
                    elif resource.type == ResourceType.GUIDE:
                        self.guides.append(resource)

    def overview(self):
        if self._overview is None:
            endpoint = self._endpoint_getter() + "/overview.md"
            self._overview = get_registry_api(endpoint)
        return self._overview

    @classmethod
    def from_json(cls, data, log_widget):
        return cls(data, log_widget)

    @property
    def versions(self):
        return self.raw_json.get('versions', [])