import logging
from textual.app import App, ComposeResult
from textual.widgets import Footer, Header
from textual.binding import Binding
from rich.logging import RichHandler
from .widgets import (
    ProvidersOptionList,
    ResourcesOptionList,
    ContentWindow,
    CustomRichLog,
    SearchInput,
    CodeBlockSelect,
)
from .providers import Provider
from .helpers import get_registry_api, LOGGER as helpers_logger

logging.basicConfig(
    level="INFO",
    format="%(message)s",
    datefmt="[%X]",
    handlers=[RichHandler(rich_tracebacks=True)],
)
LOGGER = logging.getLogger(__name__)


class TofuRefApp(App):
    BINDINGS = [
        Binding("d", "action_down", "Down"),
        Binding("u", "action_up", "Up"),
        Binding("j", "action_down", "Down"),
        Binding("k", "action_up", "Up"),
        Binding("g", "action_scroll_home", "Go to top"),
        Binding("G", "action_scroll_end", "Go to bottom"),
        Binding("ctrl+d", "action_page_down", "Page down"),
        Binding("ctrl+u", "action_page_up", "Page up"),
        Binding("f", "action_fullscreen", "Fullscreen"),
        Binding("s", "action_search", "Search"),
        Binding("l", "action_log", "Log"),
        Binding("p", "action_providers", "Providers"),
        Binding("r", "action_resources", "Resources"),
        Binding("v", "action_version", "Version"),
        Binding("enter", "action_use", "Select"),
        Binding("y", "action_content", "Yank code"),
        Binding("escape", "action_close", "Close"),
    ]
    CSS_PATH = "tofurf.tcss"
    ESCAPE_TO_MINIMIZE = True
    TITLE = "TofuRef"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.providers = {}
        self.active_provider = None
        self.active_resource = None
        self.search = ""
        self.content_markdown = ""
        self.fullscreen_mode = False
        self.log_widget = None
        self.code_block_selector = None
        self.navigation_providers = None
        self.navigation_resources = None

    def compose(self) -> ComposeResult:
        yield Header()
        yield CustomRichLog(name="log", id="log", classes="bordered", border_title="Log")
        yield SearchInput(id="search", classes="search")
        yield ProvidersOptionList(id="nav-providers", classes="nav-selector bordered", border_title="Providers")
        yield ResourcesOptionList(id="nav-resources", classes="nav-selector bordered", border_title="Resources")
        yield ContentWindow(id="content", classes="content bordered", content="")
        yield Footer()

    def on_ready(self):
        self._preload()

    def _preload(self):
        self.log_widget = self.query_one(CustomRichLog)
        self.navigation_providers = self.query_one(ProvidersOptionList)
        self.navigation_resources = self.query_one(ResourcesOptionList)
        self.code_block_selector = self.query_one(CodeBlockSelect)

        index = get_registry_api("providers/index.json", log_widget=self.log_widget)
        if index:
            for provider_data in index:
                provider = Provider.from_json(provider_data, self.log_widget)
                self.providers[provider.display_name] = provider
            self.navigation_providers.populate(list(self.providers.values()))

    def action_down(self):
        self.query_one(ResourcesOptionList).action_down()
        self.query_one(ProvidersOptionList).action_down()

    def action_up(self):
        self.query_one(ResourcesOptionList).action_up()
        self.query_one(ProvidersOptionList).action_up()

    def action_search(self):
        self.query_one(SearchInput).focus()

    def action_fullscreen(self):
        self.fullscreen_mode = not self.fullscreen_mode
        self.query_one(CustomRichLog).action_fullscreen()
        self.query_one(ContentWindow).action_fullscreen()
        self.query_one(ProvidersOptionList).action_fullscreen()
        self.query_one(ResourcesOptionList).action_fullscreen()

    def action_log(self):
        self.query_one(CustomRichLog).toggle()

    def action_providers(self):
        self.query_one(ProvidersOptionList).action_fullscreen()

    def action_resources(self):
        self.query_one(ResourcesOptionList).action_fullscreen()

    def action_content(self):
        self.query_one(ContentWindow).action_yank()

    def action_use(self):
        self.query_one(ResourcesOptionList).on_option_selected(self.query_one(ResourcesOptionList).highlighted)

    def action_version(self):
        pass

    def change_provider_version(self, event):
        pass

    def option_list_option_selected(self, event):
        pass

    def search_input_changed(self, event):
        pass

    def search_input_submitted(self, event):
        pass

    def get_system_commands(self, screen) -> list[SystemCommand]:
        yield SystemCommand("toggle_log", "l", "Toggle log")