from enum import Enum
from rich import print
from rich.console import Console
from rich.text import Text

console = Console()


class ResourceType(Enum):
    RESOURCE = "resource"
    DATASOURCE = "datasource"
    FUNCTION = "function"
    GUIDE = "guide"


class Resource:
    def __init__(self, data, provider):
        self.provider = provider
        self.type = ResourceType(data['type'])
        self.name = data['name']
        self._content = None

    def __rich__(self):
        return Text.assemble(
            Text(f"{self.type.name}: ", style="cyan"), Text(self.name)
        )

    def __str__(self):
        return f"{self.type.name.title()}: {self.name}"

    def __lt__(self, other):
        return self.name < other.name

    def __gt__(self, other):
        return self.name > other.name

    def __hash__(self):
        return hash((self.provider.display_name, self.type, self.name))

    @property
    def content(self):
        if self._content is None:
            endpoint = self.provider._endpoint_getter() + f"/{self.type.value}/{self.name}.md"
            self._content = self.provider.log_widget.get_registry_api(endpoint)

        return self._content

    @classmethod
    def from_json(cls, data, provider):
        return cls(data, provider)