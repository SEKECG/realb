import subprocess
import json
import tempfile
import os
from pathlib import Path
import sys

__version__ = "0.2.1"

CODE_FILES_FIELD = "code_files"
CONFIG_FIELD = "config"
RULE_FIELD = "rule"
RULE_ID_FIELD = "rule_id"
SEMGREP_URL = "https://semgrep.dev/api/rules"
SEMGREP_API_URL = "https://semgrep.dev/api/v1"
DEFAULT_TIMEOUT = 5 * 60  # 5 mins in seconds

_semgrep_lock = None
semgrep_executable = None
http_client = None


class CodeFile:
    def __init__(self, filename, content):
        self.filename = filename
        self.content = content


class CodeWithLanguage:
    def __init__(self, content, language="python"):
        self.content = content
        self.language = language


class SemgrepScanResult:
    def __init__(self, version, results, errors, paths, skipped_rules):
        self.version = version
        self.results = results
        self.errors = errors
        self.paths = paths
        self.skipped_rules = skipped_rules


def main(transport=None):
    pass


def create_temp_files_from_code_content(code_files):
    pass


def ensure_semgrep_available():
    pass


def find_semgrep_path():
    pass


def get_abstract_syntax_tree(code, language):
    pass


def get_semgrep_rule_schema():
    pass


def get_semgrep_rule_yaml(rule_id):
    pass


def get_semgrep_scan_args(temp_dir, config):
    pass


def get_supported_languages():
    pass


def remove_temp_dir_from_results(results, temp_dir):
    pass


def run_semgrep(args):
    pass


def safe_join(base_dir, untrusted_path):
    pass


def security_check(code_files):
    pass


def semgrep_rule_schema():
    pass


def semgrep_scan(code_files, config):
    pass


def semgrep_scan_with_custom_rule(code_files, rule):
    pass


def validate_absolute_path(path_to_validate, param_name):
    pass


def validate_code_files(code_files):
    pass


def validate_config(config):
    pass


def write_custom_semgrep_rule(code, language):
    pass