import sys
from crx_analyzer.extension import Extension, Browser
from crx_analyzer.risk import get_risk_report

def analyze(id, browser, output, max_files, max_urls, permissions):
    try:
        with Extension(id, browser) as extension:
            report = get_risk_report(extension)
            if output == "pretty":
                print(report)
            elif output == "json":
                import json
                print(json.dumps(report, indent=2))
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)

def cli():
    import argparse
    parser = argparse.ArgumentParser(description="Chrome/Edge Extension Analyzer")
    parser.add_argument("id", help="Extension ID")
    parser.add_argument("browser", choices=["chrome", "edge"], help="Browser")
    parser.add_argument("--output", choices=["pretty", "json"], default="pretty", help="Output format")
    parser.add_argument("--max-files", type=int, default=10, help="Max number of JavaScript files to display")
    parser.add_argument("--max-urls", type=int, default=10, help="Max number of URLs to display")
    parser.add_argument("--permissions", action="store_true", help="Show only permissions and metadata")
    args = parser.parse_args()
    analyze(args.id, args.browser, args.output, args.max_files, args.max_urls, args.permissions)

def get_version():
    print("0.1.0")

if __name__ == "__main__":
    cli()