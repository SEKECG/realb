import hashlib
import json
import os
import tempfile
import zipfile
from urllib.request import urlopen, Request
from crx_analyzer.download import get_chrome_extension_url, get_edge_extension_url
from crx_analyzer.models import ChromeManifest

class Browser:
    CHROME = "chrome"
    EDGE = "edge"

class InvalidExtensionIDError(Exception):
    pass

class Extension:
    def __init__(self, extension_id, browser, working_dir=None):
        self.extension_id = extension_id
        self.browser = browser
        self.working_dir = working_dir or tempfile.mkdtemp()
        self.extension_zip_path = os.path.join(self.working_dir, f"{extension_id}.zip")
        self.extension_dir_path = os.path.join(self.working_dir, extension_id)
        self.__download_extension()
        self.__unzip_extension()
        self.manifest = self.__get_manifest()

    def __download_extension(self):
        if self.browser == Browser.CHROME:
            url = get_chrome_extension_url(self.extension_id)
        elif self.browser == Browser.EDGE:
            url = get_edge_extension_url(self.extension_id)
        else:
            raise ValueError("Unsupported browser")
        
        req = Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urlopen(req) as response, open(self.extension_zip_path, 'wb') as f:
            f.write(response.read())
        
        with open(self.extension_zip_path, "rb") as f:
            self.sha256 = hashlib.sha256(f.read()).hexdigest()

    def __unzip_extension(self):
        with zipfile.ZipFile(self.extension_zip_path, 'r') as zip_ref:
            zip_ref.extractall(self.extension_dir_path)

    def __get_manifest(self):
        manifest_path = os.path.join(self.extension_dir_path, "manifest.json")
        with open(manifest_path, "r") as f:
            manifest_data = json.load(f)
        return ChromeManifest(**manifest_data)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        import shutil
        shutil.rmtree(self.working_dir)

    @property
    def name(self):
        return self.manifest.name

    @property
    def version(self):
        return self.manifest.version

    @property
    def author(self):
        return self.manifest.author

    @property
    def homepage_url(self):
        return self.manifest.homepage_url

    @property
    def manifest_version(self):
        return self.manifest.manifest_version

    @property
    def permissions(self):
        return self.manifest.permissions

    @property
    def javascript_files(self):
        js_files = []
        for root, _, files in os.walk(self.extension_dir_path):
            for file in files:
                if file.endswith(".js"):
                    js_files.append(os.path.join(root, file))
        return js_files

    @property
    def urls(self):
        urls = set()
        for js_file in self.javascript_files:
            with open(js_file, "r") as f:
                for line in f:
                    # Basic URL extraction - improve as needed
                    if "http://" in line or "https://" in line:
                        parts = line.split('"')
                        for part in parts:
                            if part.startswith("http"):
                                urls.add(part)
        return list(urls)