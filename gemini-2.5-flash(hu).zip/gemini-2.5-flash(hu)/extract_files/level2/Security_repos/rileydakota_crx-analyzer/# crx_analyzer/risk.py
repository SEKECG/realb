from crx_analyzer.models import RiskLevel, RiskReport
from enum import Enum

class RiskLevel(Enum):
    NONE = "None"
    LOW = "Low"
    MEDIUM = "Medium"
    HIGH = "High"
    CRITICAL = "Critical"

permissions_risk_map = {
    "alarms": RiskLevel.NONE,
    "fontSettings": RiskLevel.NONE,
    "activeTab": RiskLevel.LOW,
    "background": RiskLevel.LOW,
    "bookmarks": RiskLevel.MEDIUM,
    "downloads": RiskLevel.MEDIUM,
    "clipboardRead": RiskLevel.HIGH,
    "history": RiskLevel.HIGH,
    "cookies": RiskLevel.CRITICAL,
    "debugger": RiskLevel.CRITICAL,
}

risk_score_map = {
    RiskLevel.NONE: 0,
    RiskLevel.LOW: 10,
    RiskLevel.MEDIUM: 25,
    RiskLevel.HIGH: 50,
    RiskLevel.CRITICAL: 100,
}

def get_risk_level(permission):
    return permissions_risk_map.get(permission, RiskLevel.LOW)

def get_risk_score(risk_level):
    return risk_score_map[risk_level]


def get_risk_report(extension):
    permissions = extension.permissions
    report = RiskReport()
    report.name = extension.name
    report.version = extension.version
    report.author = extension.author
    report.homepage_url = extension.homepage_url
    report.permissions = [{'permission': p, 'risk_level': get_risk_level(p).value, 'risk_score': get_risk_score(get_risk_level(p))} for p in permissions]
    report.risk_score = sum(p['risk_score'] for p in report.permissions)
    report.javascript_files = extension.javascript_files[:10]  # Limit to 10 files
    report.urls = extension.urls[:10]  # Limit to 10 URLs
    return report