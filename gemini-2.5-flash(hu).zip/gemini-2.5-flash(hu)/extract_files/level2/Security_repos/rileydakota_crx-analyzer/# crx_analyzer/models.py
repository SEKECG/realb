from enum import Enum
from typing import List, Optional, Union, Dict, Any
from pydantic import BaseModel

class RiskLevel(Enum):
    NONE = "None"
    LOW = "Low"
    MEDIUM = "Medium"
    HIGH = "High"
    CRITICAL = "Critical"

class ChromePermission(Enum):
    ACCESSIBILITY_FEATURES_MODIFY = "accessibilityFeatures.modify"
    ACCESSIBILITY_FEATURES_READ = "accessibilityFeatures.read"
    ACTIVE_TAB = "activeTab"
    ALARMS = "alarms"
    AUDIO = "audio"
    BACKGROUND = "background"
    BOOKMARKS = "bookmarks"
    BROWSING_DATA = "browsingData"
    CERTIFICATE_PROVIDER = "certificateProvider"
    CLIPBOARD_READ = "clipboardRead"
    CLIPBOARD_WRITE = "clipboardWrite"
    CONTENT_SETTINGS = "contentSettings"
    CONTEXT_MENUS = "contextMenus"
    COOKIES = "cookies"
    DEBUGGER = "debugger"
    DECLARATIVE_CONTENT = "declarativeContent"
    DECLARATIVE_NET_REQUEST = "declarativeNetRequest"
    DECLARATIVE_NET_REQUEST_FEEDBACK = "declarativeNetRequestFeedback"
    DECLARATIVE_NET_REQUEST_WITH_HOST_ACCESS = "declarativeNetRequestWithHostAccess"
    DECLARATIVE_WEB_REQUEST = "declarativeWebRequest"
    DESKTOP_CAPTURE = "desktopCapture"
    DISPLAY_SOURCE = "displaySource"
    DNS = "dns"
    DOCUMENT_SCAN = "documentScan"
    DOWNLOADS = "downloads"
    DOWNLOADS_OPEN = "downloads.open"
    DOWNLOADS_UI = "downloads.UI"
    ENTERPRISE_DEVICE_ATTRIBUTES = "enterprise.deviceAttributes"
    ENTERPRISE_HARDWARE_PLATFORM = "enterprise.hardwarePlatform"
    ENTERPRISE_NETWORKING_ATTRIBUTES = "enterprise.networkingAttributes"
    ENTERPRISE_PLATFORM_KEYS = "enterprise.platformKeys"
    EXPERIMENTAL = "experimental"
    FAVICON = "favicon"
    FILE_BROWSER_HANDLER = "fileBrowserHandler"
    FILE_SYSTEM_PROVIDER = "fileSystemProvider"
    FONT_SETTINGS = "fontSettings"
    GCM = "gcm"
    GEOLOCATION = "geolocation"
    HISTORY = "history"
    IDENTITY = "identity"
    IDENTITY_EMAIL = "identity.email"
    IDLE = "idle"
    LOGIN_STATE = "loginState"
    MANAGEMENT = "management"
    NATIVE_MESSAGING = "nativeMessaging"
    NOTIFICATIONS = "notifications"
    OFFSCREEN = "offscreen"
    PAGE_CAPTURE = "pageCapture"
    PLATFORM_KEYS = "platformKeys"
    POWER = "power"
    PRINTER_PROVIDER = "printerProvider"
    PRINTING = "printing"
    PRINTING_METRICS = "printingMetrics"
    PRIVACY = "privacy"
    PROCESSES = "processes"
    PROXY = "proxy"
    READING_LIST = "readingList"
    RUNTIME = "runtime"
    SCRIPTING = "scripting"
    SEARCH = "search"
    SESSIONS = "sessions"
    SIDE_PANEL = "sidePanel"
    STORAGE = "storage"
    SYSTEM_CPU = "system.cpu"
    SYSTEM_DISPLAY = "system.display"
    SYSTEM_MEMORY = "system.memory"
    SYSTEM_STORAGE = "system.storage"
    TABS = "tabs"
    TAB_CAPTURE = "tabCapture"
    TAB_GROUPS = "tabGroups"
    TOP_SITES = "topSites"
    TTS = "tts"
    TTS_ENGINE = "ttsEngine"
    UNLIMITED_STORAGE = "unlimitedStorage"
    VPN_PROVIDER = "vpnProvider"
    WALLPAPER = "wallpaper"
    WEB_AUTHENTICATION_PROXY = "webAuthenticationProxy"
    WEB_NAVIGATION = "webNavigation"
    WEB_REQUEST = "webRequest"
    WEB_REQUEST_BLOCKING = "webRequestBlocking"


class HttpUrl(BaseModel):
    url: str

class CrossOriginPolicy(BaseModel):
    policy: str

class BackgroundConfig(BaseModel):
    persistent: bool
    scripts: Optional[List[str]]
    service_worker: Optional[str]


class ExternallyConnectable(BaseModel):
    accepts_tls_channel_id: Optional[bool]
    ids: Optional[List[str]]
    matches: Optional[List[str]]

class FileSystemProviderCapabilities(BaseModel):
    configurable: bool
    multiple_mounts: bool
    source: str

class ImportConfig(BaseModel):
    pass

class IncognitoMode(Enum):
    NOT_ALLOWED = "not_allowed"
    SPANNING = "spanning"
    SPLIT = "split"

class OmniboxConfig(BaseModel):
    keyword: str

class OptionsUI(BaseModel):
    chrome_style: bool

class SidePanel(BaseModel):
    default_path: Optional[str]

class Storage(BaseModel):
    pass

class ChromeManifest(BaseModel):
    action: Optional[Dict[str,Any]]
    author: Optional[str]
    automation: Optional[Any]
    background: Optional[BackgroundConfig]
    chrome_settings_overrides: Optional[Dict[str,Any]]
    chrome_url_overrides: Optional[Dict[str,Any]]
    commands: Optional[Dict[str,Any]]
    content_capabilities: Optional[Any]
    content_scripts: Optional[List[Dict[str,Any]]]
    content_security_policy: Optional[Union[Dict[str,str],str]]
    converted_from_user_script: Optional[Any]
    cross_origin_embedder_policy: Optional[CrossOriginPolicy]
    cross_origin_opener_policy: Optional[CrossOriginPolicy]
    current_locale: Optional[str]
    declarative_net_request: Optional[Any]
    default_locale: Optional[str]
    description: Optional[str]
    devtools_page: Optional[str]
    differential_fingerprint: Optional[Any]
    event_rules: Optional[List[Dict[str,Any]]]
    externally_connectable: Optional[ExternallyConnectable]
    file_browser_handlers: Optional[List[Any]]
    file_system_provider_capabilities: Optional[FileSystemProviderCapabilities]
    homepage_url: Optional[str]
    host_permissions: Optional[List[str]]
    icons: Optional[Dict[str,str]]
    import_: Optional[List[ImportConfig]]
    incognito: Optional[IncognitoMode]
    input_components: Optional[Any]
    key: Optional[str]
    manifest_version: int
    minimum_chrome_version: Optional[str]
    nacl_modules: Optional[List[Any]]
    natively_connectable: Optional[Any]
    oauth2: Optional[Any]
    offline_enabled: Optional[bool]
    omnibox: Optional[OmniboxConfig]
    optional_host_permissions: Optional[List[str]]
    optional_permissions: Optional[List[Union[ChromePermission,str]]]
    options_page: Optional[str]
    options_ui: Optional[OptionsUI]
    permissions: Optional[List[Union[ChromePermission,str]]]
    platforms: Optional[Any]
    replacement_web_app: Optional[Any]
    requirements: Optional[Dict[str,Any]]
    sandbox: Optional[Dict[Any,Any]]
    short_name: Optional[str]
    side_panel: Optional[SidePanel]
    storage: Optional[Storage]
    system_indicator: Optional[Any]
    tts_engine: Optional[Dict[str,Any]]
    update_url: Optional[HttpUrl]
    version: Optional[str]
    version_name: Optional[str]
    web_accessible_resources: Optional[List[Union[Dict[str,Any],str]]]

class PermissionRiskMapping(BaseModel):
    pass


class RiskReport(BaseModel):
    name: str
    version: str
    author: str
    homepage_url: str
    permissions: List[Dict[str, Any]]
    risk_score: int
    javascript_files: List[str]
    urls: List[str]