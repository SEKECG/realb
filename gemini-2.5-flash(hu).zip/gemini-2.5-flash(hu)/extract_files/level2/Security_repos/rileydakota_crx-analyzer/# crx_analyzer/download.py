import requests

CHROME_VERSION = "114"
EDGE_VERSION = "114"
USER_AGENT = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36"

def download_extension(url, output_path):
    response = requests.get(url, stream=True, headers={'User-Agent': USER_AGENT})
    response.raise_for_status()
    with open(output_path, 'wb') as f:
        for chunk in response.iter_content(chunk_size=8192):
            f.write(chunk)

def get_chrome_extension_url(extension_id, chrome_version=CHROME_VERSION):
    return f"https://clients2.google.com/service/update2/crx?response=redirect&os=mac&arch=arm64&prodversion={chrome_version}&acceptformat=crx2,crx3&x=id%3D{extension_id}"

def get_edge_extension_url(extension_id, edge_version=EDGE_VERSION):
    # Replace with actual Edge extension download URL construction
    return f"https://edge.microsoft.com/extension/{extension_id}"