from typing import Any, Mapping, Hashable
import xarray as xr
from .index import CRSIndex
from .mixins import ProjAccessorMixin, ProjIndexMixin
from .utils import Frozen

T_AccessorClass = Any

def register_accessor(accessor_cls):
    return accessor_cls

def either_dict_or_kwargs(positional, keyword, func_name):
    pass

def is_crs_aware(index):
    pass

class ProjAccessor(ProjAccessorMixin):
    def __init__(self, obj):
        self.crs = None
        self.crs_aware_indexes = Frozen()
        self.crs_indexes = Frozen()
        self._cache_all_crs_indexes()

    def __call__(self, coord_name):
        return CRSProxy(self.obj, coord_name, self._get_crs_index(coord_name).crs)

    def _cache_all_crs_indexes(self):
        pass

    def _get_crs_index(self, coord_name):
        pass

    def _update_crs_info(self, spatial_ref, func):
        pass

    def assert_one_crs_index(self):
        pass

    def assign_crs(self, spatial_ref_crs, allow_override, **spatial_ref_crs_kwargs):
        pass

    def clear_crs_info(self, spatial_ref):
        pass

    @property
    def crs(self):
        pass

    @property
    def crs_aware_indexes(self):
        pass

    @property
    def crs_indexes(self):
        pass

    def map_crs(self, spatial_ref_coords, allow_override, transform, **spatial_ref_coords_kwargs):
        pass

    def write_crs_info(self, spatial_ref, func):
        pass

class CRSProxy:
    def __init__(self, obj, coord_name, crs):
        self.crs = crs

    @property
    def crs(self):
        pass

class GeoAccessorRegistry:
    def __init__(self):
        self._accessor_names = {}

    def get_accessors(self, cls, xr_obj):
        pass

    def register_accessor(self, cls, accessor_cls):
        pass