from typing import Any, Dict
import pyproj

def format_compact_cf(crs):
    return {"crs_wkt": crs.to_wkt()}

def format_full_cf_gdal(crs):
    return {"crs_wkt": crs.to_wkt(), "spatial_ref": crs.to_cf()}