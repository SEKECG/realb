from typing import Any, Union
import pyproj
import xarray as xr

T_Xarray_Object = Union[xr.Dataset, xr.DataArray]

class ProjAccessorMixin:
    def _proj_set_crs(self, spatial_ref, crs):
        pass

class ProjIndexMixin:
    def _proj_get_crs(self):
        pass

    def _proj_set_crs(self, spatial_ref, crs):
        pass

    def _proj_to_crs(self, spatial_ref, crs):
        pass