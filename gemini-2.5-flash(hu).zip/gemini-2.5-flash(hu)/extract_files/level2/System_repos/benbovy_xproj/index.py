from typing import Any, Union
import pyproj
import xarray as xr
from .utils import Frozen

def _format_crs(crs, max_width):
    pass

class CRSIndex(xr.Index):
    def __init__(self, crs):
        self.crs = pyproj.CRS.from_user_input(crs)

    def __repr__(self):
        return f"{self.__class__.__name__}\n{repr(self.crs)}"

    def _repr_inline_(self, max_width):
        pass

    @property
    def crs(self):
        return self._crs

    def equals(self, other):
        return self.crs == other.crs

    @classmethod
    def from_variables(cls, variables, options):
        pass