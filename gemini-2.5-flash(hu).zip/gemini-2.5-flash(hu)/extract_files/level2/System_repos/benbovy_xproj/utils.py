from typing import Any, Mapping, Iterator, Generic, TypeVar
from types import MappingProxyType

K = TypeVar('K')
V = TypeVar('V')

class Frozen(Generic[K, V]):
    __slots__ = ('mapping',)

    def __init__(self, mapping):
        self.mapping = mapping

    def __contains__(self, key):
        return key in self.mapping

    def __getitem__(self, key):
        return self.mapping[key]

    def __iter__(self):
        return iter(self.mapping)

    def __len__(self):
        return len(self.mapping)

    def __repr__(self):
        return f'{self.__class__.__name__}({repr(self.mapping)})'


def FrozenDict(*args, **kwargs):
    return Frozen(MappingProxyType(dict(*args, **kwargs)))