import os
import json
from datetime import datetime, timedelta
from threading import Lock
from cryptography.fernet import Fernet
from hashlib import pbkdf2_hmac, sha512
import hmac

class EncryptionStrength:
    STANDARD = "standard"
    ENHANCED = "enhanced"
    MAXIMUM = "maximum"

class SwarmShield:
    def __init__(self, encryption_strength, key_rotation_interval, storage_path):
        self._conv_lock = Lock()
        self._conversations = {}
        self.encryption_strength = encryption_strength
        self.key_rotation_interval = key_rotation_interval
        self.storage_path = storage_path
        self.key_file = os.path.join(storage_path, "keys.json")
        self.encryption_key = None
        self.hmac_key = None
        self.master_key = None
        self.salt = None
        self.iv = None
        self.last_rotation = None
        os.makedirs(storage_path, exist_ok=True)
        self._initialize_security()
        self._load_conversations()


    def _check_rotation(self):
        if self.last_rotation:
            if datetime.now() > self.last_rotation + timedelta(seconds=self.key_rotation_interval):
                self._rotate_keys()

    def _initialize_security(self):
        if os.path.exists(self.key_file):
            with open(self.key_file, 'r') as f:
                keys = json.load(f)
                self.master_key = keys['master_key']
                self.salt = keys['salt']
                self.hmac_key = keys['hmac_key']
        else:
            self.salt = os.urandom(16)
            self.master_key = pbkdf2_hmac('sha512', b"mysecret", self.salt, 100000)
            self.hmac_key = os.urandom(32)
            self._save_keys()
        self.encryption_key = Fernet(self.master_key)
        self.iv = os.urandom(16)

    def _load_conversations(self):
        for filename in os.listdir(self.storage_path):
            if filename.endswith(".json"):
                filepath = os.path.join(self.storage_path, filename)
                with open(filepath, 'r') as f:
                    try:
                        conv_data = json.load(f)
                        conv_id = filename[:-5]
                        self._conversations[conv_id] = conv_data
                    except json.JSONDecodeError:
                        pass


    def _rotate_keys(self, initial=False):
        self.salt = os.urandom(16)
        self.master_key = pbkdf2_hmac('sha512', b"mysecret", self.salt, 100000)
        self.hmac_key = os.urandom(32)
        self.encryption_key = Fernet(self.master_key)
        self.iv = os.urandom(16)
        self.last_rotation = datetime.now()
        self._save_keys()


    def _save_conversation(self, conversation_id):
        filepath = os.path.join(self.storage_path, f"{conversation_id}.json")
        with open(filepath, 'w') as f:
            json.dump(self._conversations[conversation_id], f)

    def _save_keys(self):
        keys = {'master_key': self.master_key.decode('utf-8'), 'salt': self.salt.hex(), 'hmac_key': self.hmac_key.hex()}
        with open(self.key_file, 'w') as f:
            json.dump(keys, f)

    def add_message(self, conversation_id, agent_name, message):
        self._check_rotation()
        with self._conv_lock:
            if conversation_id not in self._conversations:
                self._conversations[conversation_id] = []
            encrypted_message = self.protect_message(agent_name, message)
            self._conversations[conversation_id].append({"agent": agent_name, "message": encrypted_message, "timestamp": datetime.now().isoformat()})
            self._save_conversation(conversation_id)

    def backup_conversations(self, backup_dir=None):
        if backup_dir is None:
            backup_dir = os.path.join(self.storage_path, f"backup_{datetime.now().strftime('%Y%m%d%H%M%S')}")
        os.makedirs(backup_dir, exist_ok=True)
        for filename in os.listdir(self.storage_path):
            if filename.endswith(".json") and filename != "keys.json":
                src = os.path.join(self.storage_path, filename)
                dst = os.path.join(backup_dir, filename)
                os.copy(src, dst)
        return backup_dir

    def create_conversation(self, name):
        conversation_id = str(len(self._conversations))
        self._conversations[conversation_id] = []
        self._save_conversation(conversation_id)
        return conversation_id

    def delete_conversation(self, conversation_id):
        with self._conv_lock:
            if conversation_id in self._conversations:
                del self._conversations[conversation_id]
                os.remove(os.path.join(self.storage_path, f"{conversation_id}.json"))

    def export_conversation(self, conversation_id, format, path=None):
        if conversation_id not in self._conversations:
            return None
        data = self._conversations[conversation_id]
        if format == "json":
            export_data = data
        elif format == "text":
            export_data = "\n".join([f"{item['agent']}: {self.retrieve_message(item['message'])[1]}" for item in data])
        else:
            return None
        if path:
            with open(path, 'w') as f:
                if format == "json":
                    json.dump(export_data, f, indent=4)
                else:
                    f.write(export_data)
        return export_data

    def get_agent_stats(self, agent_name):
        count = 0
        for conv in self._conversations.values():
            count += sum(1 for msg in conv if msg['agent'] == agent_name)
        return {'agent': agent_name, 'message_count': count}


    def get_conversation_summary(self, conversation_id):
        if conversation_id not in self._conversations:
            return {}
        conv = self._conversations[conversation_id]
        participants = set(msg['agent'] for msg in conv)
        return {'conversation_id': conversation_id, 'participants': list(participants), 'message_count': len(conv)}


    def get_messages(self, conversation_id):
        if conversation_id not in self._conversations:
            return []
        messages = []
        for msg in self._conversations[conversation_id]:
            agent_name, message = self.retrieve_message(msg['message'])
            messages.append((agent_name, message, datetime.fromisoformat(msg['timestamp'])))
        return messages

    def protect_message(self, agent_name, message):
        message_data = {"agent": agent_name, "message": message, "timestamp": datetime.now().isoformat()}
        message_json = json.dumps(message_data).encode()
        encrypted = self.encryption_key.encrypt(message_json)
        if self.encryption_strength == EncryptionStrength.ENHANCED or self.encryption_strength == EncryptionStrength.MAXIMUM:
            hashed = sha512(encrypted).hexdigest()
            if self.encryption_strength == EncryptionStrength.MAXIMUM:
                hmac_digest = hmac.new(self.hmac_key, encrypted, sha512).hexdigest()
                return json.dumps({"encrypted": encrypted.hex(), "hash": hashed, "hmac": hmac_digest}).encode()
            else:
                return json.dumps({"encrypted": encrypted.hex(), "hash": hashed}).encode()
        else:
            return json.dumps({"encrypted": encrypted.hex()}).encode()




    def query_conversations(self, agent_name=None, text=None, start_date=None, end_date=None, limit=None):
        results = []
        for conv_id, conv_data in self._conversations.items():
            for msg in conv_data:
                decrypted_msg = self.retrieve_message(msg['message'])
                if (agent_name is None or msg['agent'] == agent_name) and \
                   (text is None or text in decrypted_msg[1]) and \
                   (start_date is None or datetime.fromisoformat(msg['timestamp']) >= start_date) and \
                   (end_date is None or datetime.fromisoformat(msg['timestamp']) <= end_date):
                    results.append({"conversation_id": conv_id, "agent": msg['agent'], "message": decrypted_msg[1], "timestamp": msg['timestamp']})
                    if limit and len(results) >= limit:
                        return results
        return results

    def retrieve_message(self, encrypted_str):
        try:
            encrypted_data = json.loads(encrypted_str)
            encrypted = bytes.fromhex(encrypted_data['encrypted'])
            decrypted = self.encryption_key.decrypt(encrypted)
            message_data = json.loads(decrypted)
            if self.encryption_strength == EncryptionStrength.ENHANCED or self.encryption_strength == EncryptionStrength.MAXIMUM:
                hashed = sha512(encrypted).hexdigest()
                if self.encryption_strength == EncryptionStrength.MAXIMUM:
                    hmac_digest = hmac.new(self.hmac_key, encrypted, sha512).hexdigest()
                    if hmac_digest != encrypted_data["hmac"]:
                        raise ValueError("HMAC verification failed")
                if hashed != encrypted_data["hash"]:
                    raise ValueError("Hash verification failed")
            return message_data["agent"], message_data["message"]
        except (KeyError, ValueError):
            return None, None