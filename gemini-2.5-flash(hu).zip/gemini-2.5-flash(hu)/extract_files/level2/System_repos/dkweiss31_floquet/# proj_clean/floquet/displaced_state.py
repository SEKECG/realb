import numpy as np
import qutip as qt
from scipy.optimize import curve_fit

class DisplacedState:
    """Class providing methods for computing displaced states.

    Parameters:
        hilbert_dim: Hilbert space dimension
        model: Model including the Hamiltonian, drive amplitudes, frequencies,
            state indices
        state_indices: States of interest
        options: Options used
    """
    exponent_pair_idx_map = None
    hilbert_dim = None
    model = None
    options = None
    state_indices = None

    def __init__(self, hilbert_dim, model, state_indices, options):
        self.hilbert_dim = hilbert_dim
        self.model = model
        self.state_indices = state_indices
        self.options = options
        self.exponent_pair_idx_map = self._create_exponent_pair_idx_map()


    def _coefficient_for_state(self, xydata, state_idx_coefficients, bare_same):
        return np.array([1])

    def _create_exponent_pair_idx_map(self):
        return {}

    def _fit_coefficients_factory(self, XYdata, Zdata, p0, bare_same):
        return np.array([1])

    def _fit_coefficients_for_component(self, omega_d_amp_filtered, floquet_component_filtered, bare_same):
        return np.array([1])

    def bare_state_coefficients(self, state_idx):
        return np.array([1])

    def displaced_state(self, omega_d, amp, state_idx, coefficients):
        return qt.Qobj(np.array([1]))

    def displaced_states_fit(self, omega_d_amp_slice, ovlp_with_bare_states, floquet_modes):
        return np.array([1])

    def overlap_with_bare_states(self, amp_idx_0, coefficients, floquet_modes):
        return np.array([1])

    def overlap_with_displaced_states(self, amp_idxs, coefficients, floquet_modes):
        return np.array([1])