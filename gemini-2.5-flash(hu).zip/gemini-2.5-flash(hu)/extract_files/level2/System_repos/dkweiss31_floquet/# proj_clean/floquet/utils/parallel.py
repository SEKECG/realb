import multiprocessing

def parallel_map(num_cpus, func, parameters):
    with multiprocessing.Pool(processes=num_cpus) as pool:
        results = pool.map(func, parameters)
    return results