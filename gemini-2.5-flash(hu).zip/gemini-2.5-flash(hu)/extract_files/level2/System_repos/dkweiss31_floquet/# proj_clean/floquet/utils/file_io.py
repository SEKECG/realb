import os
import h5py
import numpy as np
from pathlib import Path

class Serializable:
    """Mixin class for reading and writing to file using h5py."""

    def __str__(self):
        return "\n".join([f"{k}: {v}" for k, v in self.__dict__.items() if v is not None])

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        for k, v in self.__dict__.items():
            if k == "params_to_save":
                continue
            other_v = other.__dict__[k]
            if isinstance(v, np.ndarray) and isinstance(other_v, np.ndarray):
                if not np.allclose(v, other_v):
                    return False
            elif v != other_v:
                return False
        return True

    def __new__(cls, *args, **kwargs):
        instance = super().__new__(cls)
        instance.params_to_save = []
        return instance


    def serialize(self):
        initdata = {}
        for k in self.params_to_save:
            v = self.__dict__[k]
            if isinstance(v, np.ndarray):
                initdata[k] = v.tolist()
            elif isinstance(v, (list, tuple)):
                initdata[k] = [x.tolist() if isinstance(x, np.ndarray) else x for x in v]
            else:
                initdata[k] = v
        return initdata

    def write_to_file(self, filepath, data_dict):
        with h5py.File(filepath, "w") as hf:
            initdata = self.serialize()
            hf.attrs["__class__"] = str(self.__class__)
            for k, v in initdata.items():
                hf.attrs[k] = v
            for k, v in data_dict.items():
                hf.create_dataset(k, data=v)


def generate_file_path(extension, file_name, path):
    i = 0
    while True:
        file_path = Path(path) / f"{i:04d}_{file_name}.{extension}"
        if not file_path.exists():
            file_path.parent.mkdir(parents=True, exist_ok=True)
            return str(file_path)
        i += 1

def read_from_file(filepath):
    with h5py.File(filepath, "r") as hf:
        cls_name = hf.attrs["__class__"]
        cls = eval(cls_name)
        initdata = {k: hf.attrs[k] for k in hf.attrs if k != "__class__"}
        data_dict = {k: hf[k][()] for k in hf}
        new_class_instance = cls(**initdata)
        return new_class_instance, data_dict

def get_init_params(obj):
    return list(obj.__dict__.keys())