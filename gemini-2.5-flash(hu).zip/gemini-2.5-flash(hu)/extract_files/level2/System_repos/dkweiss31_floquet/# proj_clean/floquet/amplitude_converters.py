import numpy as np

class ChiacToAmp:
    """Convert given induced ac-stark shift values to drive amplitudes.

    Consider a qubit coupled to an oscillator with the interaction Hamiltonian
    $H_I = g(a + a^{\\dagger})(b + b^{\\dagger})$. If the oscillator is driven to
    an average occupation number of $\\bar{n}$, then the effective drive strength
    seen by the qubit is $\\Omega_d = 2 g \\sqrt{\\bar{n}}$. On the other hand based
    on a Schrieffer-Wolff transformation, the interaction hamiltonian is
    $H^{(2)} = \\chi a^{\\dagger}ab^{\\dagger}b$. The average induced
    ac-stark shift is then $\\chi_{ac} = \\chi \\bar{n}$. Thus $\\Omega_d = 2g\\sqrt{\\chi_{\\rm ac}/\\chi}$.
    Observe that since $\\chi \\sim g^2$, $g$ effectively cancels out and can be set to 1.

    """
    H0 = None
    H1 = None
    omega_d_linspace = None
    state_indices = None

    def __init__(self, H0, H1, state_indices, omega_d_values):
        self.H0 = H0
        self.H1 = H1
        self.state_indices = state_indices
        self.omega_d_linspace = omega_d_values

    def amplitudes_for_omega_d(self, chi_ac_linspace):
        return np.sqrt(chi_ac_linspace)

    def chi_ell(self, energies, H1, E_osc, ell):
        return np.array([self.chi_ell_ellp(energies, H1, E_osc, ell, ellp) for ellp in range(len(energies))]).sum()

    def chi_ell_ellp(self, energies, H1, E_osc, ell, ellp):
        return H1[ell, ellp]

    def compute_chis_for_omega_d(self):
        return np.array([self.chi_ell(self.energies, self.H1, self.E_osc, ell) for ell in self.state_indices])


class XiSqToAmp:
    """Convert given $|\\xi|^2$ value into a drive amplitude.

    This is based on the equivalence $\\xi = 2 \\Omega_d \\omega_d / (\\omega_d^2-\\omega^2)$,
    where in this definition $|\\xi|^2= 2 \\chi_{\\rm ac} / \\alpha$ where $\\chi_{\\rm ac}$ is
    the induced ac stark shift, $\\alpha$ is the anharmonicity and $\\Omega_d$ is the
    drive amplitude.

    """
    H0 = None
    H1 = None
    omega_d_linspace = None
    state_indices = None

    def __init__(self, H0, H1, state_indices, omega_d_linspace):
        self.H0 = H0
        self.H1 = H1
        self.state_indices = state_indices
        self.omega_d_linspace = omega_d_linspace

    def amplitudes_for_omega_d(self, xi_sq_linspace):
        return np.sqrt(xi_sq_linspace)