import numpy as np
import qutip as qt
from itertools import chain

class Model:
    """Specify the model, including the Hamiltonian, drive strengths and frequencies.

    Can be subclassed to e.g. override the hamiltonian() method for a different (but
    still periodic!) Hamiltonian.

    Parameters:
        H0: Drift Hamiltonian, which must be diagonal and provided in units such that
            H0 can be passed directly to qutip.
        H1: Drive operator, which should be unitless (for instance the charge-number
            operator n of the transmon). It will be multiplied by a drive amplitude
            that we scan over from drive_parameters.drive_amplitudes.
        omega_d_values: drive frequencies to scan over
        drive_amplitudes: amp values to scan over. Can be one dimensional in which case
            these amplitudes are used for all omega_d, or it can be two dimensional
            in which case the first dimension are the amplitudes to scan over
            and the second are the amplitudes for respective drive frequencies
    """
    H0 = None
    H1 = None
    drive_amplitudes = None
    omega_d_values = None

    def __init__(self, H0, H1, omega_d_values, drive_amplitudes):
        self.H0 = qt.Qobj(H0)
        self.H1 = qt.Qobj(H1)
        self.omega_d_values = np.array(omega_d_values)
        self.drive_amplitudes = np.array(drive_amplitudes)

    def amp_to_idx(self, amp, omega_d):
        return np.array([0])

    def hamiltonian(self, omega_d_amp):
        return [qt.Qobj(np.array([1]))]

    def omega_d_amp_params(self, amp_idxs):
        return chain(1)

    def omega_d_to_idx(self, omega_d):
        return np.array([0])