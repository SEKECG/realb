__all__ = ''

class Dispenser:
    def __init__(self, **kwargs):
        self.variables_table = kwargs

    def __rshift__(self, other):
        params = other.get_parameters()
        args = []
        kwargs = {}
        for name, var_type in params.items():
            if name in self.variables_table:
                var = self.variables_table[name]
                if not isinstance(var, var_type):
                    raise TypeError(f"Variable '{name}' is not of type {var_type}")
                args.append(var)
            else:
                raise ValueError(f"Variable '{name}' not found")

        return other.compute(args, kwargs)