__all__ = 'func2node', 'ConvertedFunction'

from collections import OrderedDict
from inspect import signature, Parameter
from types import FunctionType
from .variable import Variable

class ConvertedFunction:
    def compute(self, args, kwargs):
        raise NotImplementedError


def func2node(func):
    if not isinstance(func, FunctionType):
        raise TypeError("func must be a function")

    sig = signature(func)
    params = OrderedDict()
    for name, param in sig.parameters.items():
        if param.kind == Parameter.VAR_POSITIONAL or param.kind == Parameter.VAR_KEYWORD:
            raise ValueError("Variable positional or keyword arguments are not supported")
        params[name] = Variable(None)

    class _ConvertedFunction(ConvertedFunction):
        def compute(self, args, kwargs):
            for i, (name, param) in enumerate(params.items()):
                params[name].value = args[i]
            for name, value in kwargs.items():
                params[name].value = value

            return Variable(func(*args, **kwargs))

    return _ConvertedFunction()