__all__ = ''

from ...adapter.abstract import Adapter
from ..variables.numeric import Boolean, Float, Integer

class Boolean2bool(Adapter):
    def compute(self, variable):
        return variable.value

class Float2float(Adapter):
    def compute(self, variable):
        return variable.value

class Integer2int(Adapter):
    def compute(self, variable):
        return variable.value

class PythonicAdapter(Adapter):
    def is_loses_information(self):
        return False

class bool2Boolean(Adapter):
    def compute(self, variable):
        return Boolean(variable.value)

class float2Float(Adapter):
    def compute(self, variable):
        return Float(variable.value)

class int2Integer(Adapter):
    def compute(self, variable):
        return Integer(variable.value)