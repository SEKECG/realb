__all__ = 'Result'

from .numeric import Boolean

class Result(Boolean):
    def __init__(self, value):
        if not isinstance(value, bool):
            raise TypeError("Result must be a boolean")
        super().__init__(value)