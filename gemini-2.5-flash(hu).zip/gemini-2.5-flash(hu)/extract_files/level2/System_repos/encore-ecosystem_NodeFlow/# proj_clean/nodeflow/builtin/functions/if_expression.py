__all__ = 'IF'

IF = lambda expression, true_case, false_case: true_case if expression else false_case

def py_if(expression, true_case, false_case):
    return true_case if expression else false_case