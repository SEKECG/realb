__all__ = 'Result'

from .node.variable import Variable

class Result(Variable):
    def __init__(self, value):
        if not isinstance(value, bool):
            raise TypeError("Result must be a boolean")
        super().__init__(value)