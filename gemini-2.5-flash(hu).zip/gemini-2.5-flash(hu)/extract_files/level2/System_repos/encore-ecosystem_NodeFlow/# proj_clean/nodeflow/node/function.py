__all__ = 'Function'

from collections import OrderedDict
from inspect import signature
from types import FunctionType
from .abstract import Node
from ..builtin.variables.numeric import Integer, Float, Boolean
from ..builtin.variables.path import PathVariable
from ..builtin.variables.result import Result

class Function(Node):
    def compute(self, args, kwargs):
        raise NotImplementedError

    def get_parameters(self):
        sig = signature(self.compute)
        params = OrderedDict()
        for name, param in sig.parameters.items():
            if param.kind == Parameter.VAR_POSITIONAL or param.kind == Parameter.VAR_KEYWORD:
                raise ValueError("Variable positional or keyword arguments are not supported")
            if param.annotation is Parameter.empty:
                raise ValueError(f"Parameter '{name}' has no type annotation")
            params[name] = param.annotation
        return params

    def get_return_type(self):
        sig = signature(self.compute)
        if sig.return_annotation is Parameter.empty:
            raise ValueError("compute method has no return type annotation")
        return sig.return_annotation