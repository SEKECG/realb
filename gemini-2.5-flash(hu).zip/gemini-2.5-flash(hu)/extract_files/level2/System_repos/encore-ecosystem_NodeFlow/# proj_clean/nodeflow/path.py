__all__ = ''

import pathlib

class PathVariable:
    def __init__(self, value):
        self.value = pathlib.Path(value).resolve()

    def __truediv__(self, other):
        return self.value / other