__all__ = 'Converter'

from collections import defaultdict, deque
from typing import Optional, Type
from ..adapter.pipeline import Pipeline
from ..builtin.adapters import numeric, pythonic

class Converter:
    ROOT_CONVERTER = None
    def __init__(self, adapters=None, sub_converters=None):
        self.graph = defaultdict(list)
        self.sub_converters = []
        if adapters:
            self.register_adapters(adapters)
        if sub_converters:
            self.register_converters(sub_converters)

    def __enter__(self):
        self.__class__.ROOT_CONVERTER = self
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.__class__.ROOT_CONVERTER = None

    def convert(self, variable, to_type):
        pipeline, loose_info = self.get_converting_pipeline(type(variable), to_type)
        if pipeline:
            return pipeline.compute(variable)
        return None

    def get_converting_pipeline(self, source, target):
        queue = deque([(source, [], False)])
        visited = {source}
        while queue:
            curr, path, loose = queue.popleft()
            if curr == target:
                return Pipeline(), loose
            for adapter in self.graph[curr]:
                if adapter.get_type_of_target_variable() not in visited:
                    new_path = path + [adapter]
                    new_loose = loose or adapter.is_loses_information()
                    queue.append((adapter.get_type_of_target_variable(), new_path, new_loose))
                    visited.add(adapter.get_type_of_target_variable())
        return None, False

    def is_support_variable(self, variable_type):
        return variable_type in self.graph

    def register_adapter(self, adapter):
        source_type = adapter.get_type_of_source_variable()
        self.graph[source_type].append(adapter)

    def register_adapters(self, adapters):
        for adapter in adapters:
            self.register_adapter(adapter)

    def register_converter(self, converter):
        self.sub_converters.append(converter)

    def register_converters(self, converters):
        for converter in converters:
            self.register_converter(converter)