__all__ = 'Integer', 'Float', 'Boolean'

class Integer:
    def __init__(self, value):
        self.value = value

    def __add__(self, other):
        return Integer(self.value + other.value)

    def __mul__(self, other):
        return Integer(self.value * other.value)

class Float:
    def __init__(self, value):
        self.value = value

    def __add__(self, other):
        return Float(self.value + other.value)

    def __mul__(self, other):
        return Float(self.value * other.value)


class Boolean:
    def __init__(self, value):
        self.value = value

    def __add__(self, other):
        return Boolean(self.value or other.value)

    def __mul__(self, other):
        return Boolean(self.value and other.value)