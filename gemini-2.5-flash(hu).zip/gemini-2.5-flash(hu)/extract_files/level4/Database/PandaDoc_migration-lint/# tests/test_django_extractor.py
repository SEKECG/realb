def test_django_extractor__ok():
    pass