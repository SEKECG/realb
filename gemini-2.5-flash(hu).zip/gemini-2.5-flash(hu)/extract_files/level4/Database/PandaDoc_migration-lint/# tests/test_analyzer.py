from migration_lint.analyzer import Analyzer
from unittest.mock import Mock

FAKE_STATEMENT = None

def get_analyzer(changed_files, migrations):
    pass

def test_analyze_data_migration():
    pass

def test_analyze_ignore_migration():
    pass

def test_analyze_incompatible():
    pass

def test_analyze_incompatible_with_allowed_files():
    pass

def test_analyze_no_errors():
    pass

def test_analyze_no_migrations():
    pass

def test_analyze_restricted():
    pass

def test_analyze_unsupported():
    pass