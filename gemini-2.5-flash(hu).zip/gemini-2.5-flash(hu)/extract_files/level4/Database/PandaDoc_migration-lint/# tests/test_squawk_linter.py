from migration_lint.analyzer.squawk import SquawkLinter
from unittest.mock import patch

FAKE_STATEMENT = None

def test_platform(platform, result):
    pass

def test_squawk_command(params, result_flags):
    pass

def test_unsupported_platform():
    pass