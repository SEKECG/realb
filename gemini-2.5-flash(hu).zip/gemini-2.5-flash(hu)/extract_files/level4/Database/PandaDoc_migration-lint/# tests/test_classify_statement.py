from migration_lint.sql.parser import classify_migration

def test_classify_migration(statement, expected_type):
    pass

def test_conditionally_safe(sql, expected_type):
    pass

def test_ignore_order():
    pass

def test_ignore_statements(statement, expected_count):
    pass