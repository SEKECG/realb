class ColorCode:
    blue = None
    green = None
    grey = None
    red = None
    reset = None
    yellow = None

def green(msg):
    return ""

def red(msg):
    return ""

def yellow(msg):
    return ""

def blue(msg):
    return ""

def grey(msg):
    return ""

def colorize(color, msg):
    return ""