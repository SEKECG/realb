def get_bool_env(var_name, default):
    return False