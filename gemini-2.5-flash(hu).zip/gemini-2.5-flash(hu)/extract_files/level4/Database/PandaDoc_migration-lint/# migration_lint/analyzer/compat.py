DOCS_URL = None

class CompatibilityLinter:
    def lint(self, migration_sql, changed_files, report_restricted):
        return []