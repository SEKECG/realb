class SquawkLinter:
    def __init__(self, config_path, pg_version):
        self.config_path = config_path
        self.ignored_rules = None
        self.pg_version = pg_version
        self.squawk = None

    def lint(self, migration_sql, changed_files):
        return []

    def squawk_command(self, migration_sql):
        return ""