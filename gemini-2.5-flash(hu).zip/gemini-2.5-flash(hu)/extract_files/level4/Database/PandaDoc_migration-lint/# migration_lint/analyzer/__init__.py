fh = None
fh_formatter = None
logger = None