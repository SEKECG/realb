CLASSIFICATION_LINK = None
IGNORE_LINK = None
MANUALLY_IGNORE_ANNOTATION = None

class Analyzer:
    def __init__(self, loader, extractor, linters):
        self.extractor = extractor
        self.linters = linters
        self.loader = loader

    def analyze(self):
        pass

class BaseLinter:
    def lint(self, migration_sql, changed_files):
        return []