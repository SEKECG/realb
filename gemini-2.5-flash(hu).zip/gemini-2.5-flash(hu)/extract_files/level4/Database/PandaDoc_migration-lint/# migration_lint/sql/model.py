class ConditionalMatch:
    pass

class KeywordLocator:
    type: str

class SegmentLocator:
    children: list
    ignore_order: bool
    inverted: bool
    only_with: ConditionalMatch
    raw: str