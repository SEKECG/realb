from typing import Sequence, Tuple

def classify_migration(raw_sql):
    return []

def classify_statement(statement, context):
    pass