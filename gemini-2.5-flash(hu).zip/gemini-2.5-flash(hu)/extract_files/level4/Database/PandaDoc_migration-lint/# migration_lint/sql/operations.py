def find_matching_segment(segment, locator, min_position, context):
    pass