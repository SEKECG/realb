class StatementType:
    UNSUPPORTED = None
    RESTRICTED = None
    BACKWARD_INCOMPATIBLE = None
    DATA_MIGRATION = None
    BACKWARD_COMPATIBLE = None
    IGNORED = None
    colorized = None

    @property
    def colorized(self):
        pass