from migration_lint.analyzer import Analyzer
from migration_lint.extractor import Extractor
from migration_lint.source_loader import SourceLoader
from migration_lint.analyzer.squawk import SquawkLinter
from migration_lint.sql.parser import classify_migration

def main(loader_type, extractor_type, squawk_config_path, squawk_pg_version, **kwargs):
    loader = SourceLoader.get(loader_type)()
    extractor = Extractor.get(extractor_type)()
    linters = [SquawkLinter(squawk_config_path, squawk_pg_version)]
    analyzer = Analyzer(loader, extractor, linters)
    analyzer.analyze()