class Command:
    def add_arguments(self, parser):
        pass

    def handle(self, loader_type, squawk_config_path, squawk_pg_version, options):
        pass