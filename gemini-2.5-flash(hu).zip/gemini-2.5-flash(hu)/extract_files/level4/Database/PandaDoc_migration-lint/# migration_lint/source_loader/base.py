class BaseSourceLoader:
    def __init__(self, only_new_files, **kwargs):
        self.only_new_files = only_new_files

    def get_changed_files(self):
        return []

class SourceLoader:
    source_loaders = {}

    @classmethod
    def names(mcls):
        return list(mcls.source_loaders.keys())

    @classmethod
    def get(mcls, name):
        return mcls.source_loaders.get(name)

    @classmethod
    def __new__(mcls, name, bases, classdict):
        if name != "BaseSourceLoader":
            if not hasattr(classdict, "NAME"):
                raise ValueError("NAME attribute is required")
            mcls.source_loaders[classdict["NAME"]] = super().__new__(mcls)
        return super().__new__(mcls)