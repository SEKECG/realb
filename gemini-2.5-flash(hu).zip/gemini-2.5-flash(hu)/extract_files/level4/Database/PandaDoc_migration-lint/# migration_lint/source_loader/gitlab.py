class GitlabBranchLoader:
    NAME = None
    base_url = None
    branch = None
    default_branch = None
    gitlab_api_key = None
    project_id = None

    def __init__(self, branch, project_id, gitlab_api_key, gitlab_instance, **kwargs):
        pass

    def get_changed_files(self):
        return []

class GitlabMRLoader:
    NAME = None
    base_url = None
    gitlab_api_key = None
    mr_id = None
    project_id = None

    def __init__(self, mr_id, project_id, gitlab_api_key, gitlab_instance, **kwargs):
        pass

    def get_changed_files(self):
        return []