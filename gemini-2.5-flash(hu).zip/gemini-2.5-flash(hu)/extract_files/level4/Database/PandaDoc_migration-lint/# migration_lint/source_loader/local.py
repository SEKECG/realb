class LocalLoader:
    NAME = None

    def get_changed_files(self):
        return []