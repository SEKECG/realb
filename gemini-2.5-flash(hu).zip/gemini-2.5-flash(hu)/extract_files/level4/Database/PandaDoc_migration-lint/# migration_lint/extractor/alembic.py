class AlembicExtractor:
    NAME = None
    command = None
    migration_path = None

    def __init__(self, **kwargs):
        pass

    def _get_migrations_sql(self):
        pass

    def extract_sql(self, migration_path):
        return ""

    def is_allowed_with_backward_incompatible_migration(self, path):
        return False

    def is_migration(self, path):
        return False