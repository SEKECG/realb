class BaseExtractor:
    def __init__(self, **kwargs):
        self.ignore_extractor_fail = None
        self.ignore_extractor_not_found = None

    def extract_sql(self, migration_path):
        return ""

    def is_allowed_with_backward_incompatible_migration(self, path):
        return False

    def is_migration(self, path):
        return False

    def create_metadata(self, changed_files):
        return MigrationsMetadata()

class Extractor:
    extractors = {}

    @classmethod
    def get(mcls, name):
        return mcls.extractors.get(name)

    @classmethod
    def __new__(mcls, name, bases, classdict):
        if name != "BaseExtractor":
            if not hasattr(classdict, "NAME"):
                raise ValueError("NAME attribute is required")
            mcls.extractors[classdict["NAME"]] = super().__new__(mcls)
        return super().__new__(mcls)

    @classmethod
    def names(mcls):
        return list(mcls.extractors.keys())