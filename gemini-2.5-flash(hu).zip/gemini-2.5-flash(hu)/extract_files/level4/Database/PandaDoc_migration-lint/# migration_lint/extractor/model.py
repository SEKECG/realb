from typing import Optional

class SourceDiff:
    path: str
    old_path: str
    diff: Optional[str] = None

    def __post_init__(self):
        if not self.old_path:
            self.old_path = self.path

class ExtendedSourceDiff:
    allowed_with_backward_incompatible: bool

    @classmethod
    def of_source_diff(cls, source_diff, allowed_with_backward_incompatible):
        return cls()

class Migration:
    pass

class MigrationsMetadata:
    changed_files: list
    migrations: list