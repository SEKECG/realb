class DjangoExtractor:
    NAME = None
    command = None
    skip_lines = None

    def __init__(self, **kwargs):
        pass

    def extract_sql(self, migration_path):
        return ""

    def is_allowed_with_backward_incompatible_migration(self, path):
        return False

    def is_migration(self, path):
        return False