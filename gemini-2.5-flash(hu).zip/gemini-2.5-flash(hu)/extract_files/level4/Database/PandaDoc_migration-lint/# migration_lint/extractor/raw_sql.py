class RawSqlExtractor:
    NAME = None

    def is_allowed_with_backward_incompatible_migration(self, path):
        return False

    def is_migration(self, path):
        return False

    def extract_sql(self, migration_path):
        return ""