class DjangoManagementExtractor:
    NAME = None

    def extract_sql(self, migration_path):
        return ""