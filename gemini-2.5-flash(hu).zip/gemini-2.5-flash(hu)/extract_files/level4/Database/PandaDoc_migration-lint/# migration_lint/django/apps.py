class MigrationLintDjangoConfig:
    label = None
    name = None