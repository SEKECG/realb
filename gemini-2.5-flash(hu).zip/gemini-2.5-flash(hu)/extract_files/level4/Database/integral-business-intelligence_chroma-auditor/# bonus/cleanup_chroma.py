import logging
import os
import uuid
from typing import Dict, List, Tuple

import chromadb

class ChromaCollectionManager:
    def __init__(self, persist_directory):
        self.client = chromadb.Client(path=persist_directory)
        self.logger = logging.getLogger(__name__)
        self.persist_directory = persist_directory

    def _get_all_uuid_directories(self):
        all_dirs = []
        for item in os.listdir(self.persist_directory):
            item_path = os.path.join(self.persist_directory, item)
            if os.path.isdir(item_path) and uuid.UUID(item, version=4):
                all_dirs.append(item_path)
        return all_dirs

    def _get_collection_uuid_mapping(self):
        collections = self.client.get_collections()
        mapping = {}
        for collection_name in collections:
            collection = self.client.get_collection(name=collection_name)
            persist_dir = collection.metadata.get("persist_directory")
            if persist_dir:
                mapping[collection_name] = persist_dir
        return mapping

    def create_collection(self, collection_name):
        try:
            self.client.create_collection(name=collection_name)
            return True
        except Exception as e:
            self.logger.error(f"Error creating collection {collection_name}: {e}")
            return False

    def delete_collection(self, collection_name):
        try:
            self.client.delete_collection(name=collection_name)
            return True
        except Exception as e:
            self.logger.error(f"Error deleting collection {collection_name}: {e}")
            return False

    def delete_collections(self, collection_names):
        results = {}
        for name in collection_names:
            results[name] = self.delete_collection(name)
        return results

    def delete_orphaned_uuid_dirs(self):
        all_uuid_dirs = self._get_all_uuid_directories()
        collection_mapping = self._get_collection_uuid_mapping()
        orphaned_dirs = [d for d in all_uuid_dirs if d not in collection_mapping.values()]
        deleted_count = 0
        for dir_path in orphaned_dirs:
            try:
                os.rmdir(dir_path)
                deleted_count += 1
            except OSError as e:
                self.logger.error(f"Error deleting orphaned directory {dir_path}: {e}")
        return deleted_count, orphaned_dirs

    def get_collection_info(self, collection_name):
        try:
            collection = self.client.get_collection(name=collection_name)
            return collection.metadata
        except Exception as e:
            self.logger.error(f"Error getting collection info for {collection_name}: {e}")
            return {}

    def list_collections(self):
        return self.client.list_collections()

    def list_collections_with_uuids(self):
        collections_with_uuids = []
        orphaned_dirs = []
        all_uuid_dirs = self._get_all_uuid_directories()
        collection_mapping = self._get_collection_uuid_mapping()

        for collection_name, uuid_dir in collection_mapping.items():
            collections_with_uuids.append({"name": collection_name, "uuid_dir": uuid_dir})

        orphaned_dirs = [d for d in all_uuid_dirs if d not in collection_mapping.values()]
        return collections_with_uuids, orphaned_dirs


def main():
    logging.basicConfig(level=logging.INFO)
    persist_directory = "chroma_db"  # Replace with your persistence directory
    manager = ChromaCollectionManager(persist_directory)

    # Example usage:
    manager.create_collection("my_collection")
    manager.list_collections()
    manager.delete_collection("my_collection")
    deleted_count, orphaned_dirs = manager.delete_orphaned_uuid_dirs()
    print(f"Deleted {deleted_count} orphaned directories: {orphaned_dirs}")
    collections_with_uuids, orphaned = manager.list_collections_with_uuids()
    print(f"Collections with UUIDs: {collections_with_uuids}, Orphaned: {orphaned}")

if __name__ == "__main__":
    main()