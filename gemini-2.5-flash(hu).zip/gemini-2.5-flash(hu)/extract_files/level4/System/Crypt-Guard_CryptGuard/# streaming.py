import os
import multiprocessing
from .argon_utils import generate_key_from_password, get_argon2_parameters_for_encryption
from .chunk_crypto import encrypt_chunk, decrypt_chunk
from .metadata import encrypt_meta_json, decrypt_meta_json
from .config import CHUNK_SIZE, STREAMING_THRESHOLD
from .utils import generate_unique_filename
import json

def calculate_optimal_workers(file_size):
    num_cores = multiprocessing.cpu_count()
    return min(num_cores, max(1, file_size // (CHUNK_SIZE * 10)))

def encrypt_data_streaming(file_path, password, file_type, original_ext, key_file_hash, chunk_size=CHUNK_SIZE):
    salt = os.urandom(16)
    argon_params = get_argon2_parameters_for_encryption()
    key = generate_key_from_password(password, salt, argon_params, key_file_hash)
    if key is None:
        return None
    meta = {
        'salt': salt.hex(),
        'file_type': file_type,
        'original_ext': original_ext,
        'version': 1
    }
    enc_path = generate_unique_filename('encrypted', '.enc')
    meta_path = enc_path.replace('.enc', '.meta')
    with open(file_path, 'rb') as infile, open(enc_path, 'wb') as outfile:
        chunk_index = 0
        while True:
            chunk = infile.read(chunk_size)
            if not chunk:
                break
            encrypted_chunk = encrypt_chunk(chunk, key.deobfuscate(), b'', chunk_index)
            outfile.write(encrypted_chunk)
            chunk_index += 1
    encrypt_meta_json(meta_path, meta, password)
    return enc_path

def decrypt_data_streaming(enc_path, password):
    meta_path = enc_path.replace('.enc', '.meta')
    meta = decrypt_meta_json(meta_path, password)
    if meta is None:
        return None
    salt = bytes.fromhex(meta['salt'])
    argon_params = get_argon2_parameters_for_encryption()
    key = generate_key_from_password(password, salt, argon_params, None)
    if key is None:
        return None
    with open(enc_path, 'rb') as infile:
        decrypted_data = b''
        offset = 0
        chunk_index = 0
        while True:
            chunk = infile.read(CHUNK_SIZE)
            if not chunk:
                break
            decrypted_chunk, offset = decrypt_chunk(chunk, key.deobfuscate(), offset, b'', chunk_index)
            decrypted_data += decrypted_chunk
            chunk_index += 1
    return decrypted_data