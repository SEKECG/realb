import secrets
from .secure_bytes import SecureBytes

class KeyObfuscator:
    def __init__(self, key_bytes):
        self._key = SecureBytes(key_bytes)
        self._mask = SecureBytes(length=len(key_bytes))
        self._obfuscated = None
        self._parts = None

    def __del__(self):
        self.clear()

    def clear(self):
        if self._key:
            self._key.wipe()
        if self._mask:
            self._mask.wipe()
        self._obfuscated = None
        self._parts = None

    def deobfuscate(self):
        if self._obfuscated is None:
            return None
        self._key.clear()
        self._key._data = bytearray(len(self._obfuscated))
        for i in range(len(self._obfuscated)):
            self._key._data[i] = self._obfuscated[i] ^ self._mask._data[i]
        self._obfuscated = None
        self._mask.wipe()
        return self._key.to_bytes()

    def obfuscate(self):
        if self._key is None or len(self._key) == 0:
            return
        self._obfuscated = bytearray(len(self._key))
        for i in range(len(self._key)):
            self._obfuscated[i] = self._key._data[i] ^ self._mask._data[i]
        self._parts = self._obfuscated
        self._key.wipe()
        return self._obfuscated