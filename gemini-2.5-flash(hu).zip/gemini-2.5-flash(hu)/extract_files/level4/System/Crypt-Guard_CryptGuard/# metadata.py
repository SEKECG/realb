import json
import os
from .argon_utils import generate_key_from_password, get_argon2_parameters_for_encryption
from .hidden_volume import encrypt_data_raw_chacha, decrypt_data_raw_chacha
from .config import META_ARGON_PARAMS, META_SALT_SIZE, META_VERSION, SIGN_METADATA
import hmac
import hashlib

def encrypt_meta_json(meta_path, meta_plain, user_password):
    salt = os.urandom(META_SALT_SIZE)
    argon_params = META_ARGON_PARAMS
    key = generate_key_from_password(user_password, salt, argon_params, None)
    if key is None:
        return False
    enc_dict = encrypt_data_raw_chacha(json.dumps(meta_plain).encode(), key.deobfuscate(), argon_params, None)
    enc_dict['salt'] = salt.hex()
    enc_dict['version'] = META_VERSION
    if SIGN_METADATA:
        signature = hmac.new(key.deobfuscate(), json.dumps(enc_dict).encode(), hashlib.sha256).hexdigest()
        enc_dict['signature'] = signature
    with open(meta_path, 'wb') as f:
        f.write(json.dumps(enc_dict).encode())
    return True

def decrypt_meta_json(meta_path, user_password):
    with open(meta_path, 'r') as f:
        enc_dict = json.load(f)
    salt = bytes.fromhex(enc_dict['salt'])
    argon_params = META_ARGON_PARAMS
    key = generate_key_from_password(user_password, salt, argon_params, None)
    if key is None:
        return None
    try:
        meta_plain = decrypt_data_raw_chacha(enc_dict, key.deobfuscate(), None)
        if SIGN_METADATA:
            signature = hmac.new(key.deobfuscate(), json.dumps(enc_dict).encode(), hashlib.sha256).hexdigest()
            if signature != enc_dict['signature']:
                return None
        return json.loads(meta_plain)
    except Exception as e:
        return None