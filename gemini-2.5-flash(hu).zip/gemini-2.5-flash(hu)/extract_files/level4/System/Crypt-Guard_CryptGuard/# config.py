DEFAULT_ARGON_PARAMS = {
    'time_cost': 4,
    'memory_cost': 1024 * 1024 * 64,  # 64MB
    'parallelism': 4,
    'hash_len': 32,
    'salt_len': 16,
}

USE_RS = False
ARGON_MEMORY_COST = 1024 * 1024 * 64 #64MB
ARGON_MEMORY_COST_BALANCED = 1024 * 1024 * 128 #128MB
ARGON_MEMORY_COST_FAST = 1024 * 1024 * 64 #64MB
ARGON_MEMORY_COST_SECURE = 1024 * 1024 * 256 #256MB
ARGON_PARALLELISM = 4
ARGON_PARALLELISM_BALANCED = 4
ARGON_PARALLELISM_FAST = 4
ARGON_PARALLELISM_SECURE = 4
ARGON_TIME_COST = 4
ARGON_TIME_COST_BALANCED = 4
ARGON_TIME_COST_FAST = 4
ARGON_TIME_COST_SECURE = 4
CHUNK_SIZE = 1024 * 1024 #1MB default chunk size
MAX_ATTEMPTS = 3
MAX_CHUNK_SIZE = 1024 * 1024 * 100 #100MB
META_ARGON_PARAMS = {
    'time_cost': 3,
    'memory_cost': 1024 * 1024 * 32, #32MB
    'parallelism': 2,
    'hash_len': 32,
    'salt_len': 16,
}
META_SALT_SIZE = 16 #bytes for metadata salt
META_VERSION = 1 #current metadata format version
RS_PARITY_BYTES = 16 #Reed-Solomon parity bytes by default
SIGN_METADATA = True #enable HMAC signature in metadata (optional)
SINGLE_SHOT_SUBCHUNK_SIZE = 1024 * 1024 #1MB, adjustable
STREAMING_THRESHOLD = 1024 * 1024 * 10 #10MB threshold for streaming mode

def set_use_rs(value):
    global USE_RS
    USE_RS = value