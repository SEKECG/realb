import os
from .argon_utils import generate_key_from_password, get_argon2_parameters_for_encryption
from .chunk_crypto import encrypt_chunk, decrypt_chunk
from .metadata import encrypt_meta_json, decrypt_meta_json
from .config import CHUNK_SIZE, SINGLE_SHOT_SUBCHUNK_SIZE
from .utils import generate_unique_filename
import json

def encrypt_data_single(data, password, file_type, original_ext, key_file_hash, subchunk_size=SINGLE_SHOT_SUBCHUNK_SIZE):
    salt = os.urandom(16)
    argon_params = get_argon2_parameters_for_encryption()
    key = generate_key_from_password(password, salt, argon_params, key_file_hash)
    if key is None:
        return None
    meta = {
        'salt': salt.hex(),
        'file_type': file_type,
        'original_ext': original_ext,
        'multi_sub_block': False,
        'version': 1
    }
    if len(data) > subchunk_size:
        meta['multi_sub_block'] = True
        chunks = []
        for i in range(0, len(data), subchunk_size):
            chunk = data[i:i + subchunk_size]
            encrypted_chunk = encrypt_chunk(chunk, key.deobfuscate(), b'', i)
            chunks.append(encrypted_chunk)
        encrypted_data = b''.join(chunks)
    else:
        encrypted_data = encrypt_chunk(data, key.deobfuscate(), b'', 0)
    enc_path = generate_unique_filename('encrypted', '.enc')
    meta_path = enc_path.replace('.enc', '.meta')
    encrypt_meta_json(meta_path, meta, password)
    with open(enc_path, 'wb') as f:
        f.write(encrypted_data)
    return enc_path

def decrypt_data_single(enc_path, password):
    meta_path = enc_path.replace('.enc', '.meta')
    meta = decrypt_meta_json(meta_path, password)
    if meta is None:
        return None
    salt = bytes.fromhex(meta['salt'])
    argon_params = get_argon2_parameters_for_encryption()
    key = generate_key_from_password(password, salt, argon_params, None)
    if key is None:
        return None
    with open(enc_path, 'rb') as f:
        encrypted_data = f.read()
    if meta['multi_sub_block']:
        decrypted_data = b''
        offset = 0
        for i in range(0, len(encrypted_data), CHUNK_SIZE):
            chunk = encrypted_data[i:i + CHUNK_SIZE]
            decrypted_chunk, offset = decrypt_chunk(chunk, key.deobfuscate(), offset, b'', i)
            decrypted_data += decrypted_chunk
        return decrypted_data
    else:
        decrypted_data = decrypt_chunk(encrypted_data, key.deobfuscate(), 0, b'', 0)[0]
        return decrypted_data