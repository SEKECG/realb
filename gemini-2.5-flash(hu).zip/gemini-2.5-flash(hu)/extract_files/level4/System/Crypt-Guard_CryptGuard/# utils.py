import os
import time
import secrets
import platform

def generate_unique_filename(prefix, extension):
    timestamp = str(int(time.time()))
    random_hex = secrets.token_hex(4)
    filename = f"{prefix}_{timestamp}_{random_hex}{extension}"
    return filename

def clear_screen():
    if platform.system() == "Windows":
        os.system('cls')
    else:
        os.system('clear')

def generate_ephemeral_token(n_bits):
    token = secrets.token_hex(n_bits // 4)
    return token

def generate_random_number(n_bits):
    return secrets.randbits(n_bits)