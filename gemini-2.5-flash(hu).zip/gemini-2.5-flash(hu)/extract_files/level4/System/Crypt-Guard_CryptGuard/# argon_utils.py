import os
from argon2 import Argon2Id
from .key_obfuscator import KeyObfuscator
from .config import DEFAULT_ARGON_PARAMS

def generate_key_from_password(password, salt, params, extra):
    try:
        kdf = Argon2Id(**params)
        key = kdf.hash(password, salt=salt, extra=extra)
        return KeyObfuscator(key)
    except Exception as e:
        print(f"Argon2 key derivation failed: {e}")
        return None

def get_argon2_parameters_for_encryption():
    return DEFAULT_ARGON_PARAMS.copy()