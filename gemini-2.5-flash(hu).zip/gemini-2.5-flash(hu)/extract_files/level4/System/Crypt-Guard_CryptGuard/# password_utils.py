import hashlib
import getpass
from .secure_bytes import secure_password_prompt, secure_string_to_bytes, wipe_sensitive_data
import os

ZXC_AVAILABLE = False

def validate_password(password):
    if len(password) < 12:
        return False
    return True

def get_single_password():
    while True:
        password = secure_password_prompt("Enter password: ").to_bytes()
        password_confirm = secure_password_prompt("Confirm password: ").to_bytes()
        if password == password_confirm and validate_password(password):
            return password
        else:
            print("Passwords do not match or do not meet requirements.")
            wipe_sensitive_data(password)
            wipe_sensitive_data(password_confirm)

def get_combined_password():
    pass

def choose_auth_method():
    pass

def validate_key_file(expected_hash):
    pass

def get_file_hash(file_path):
    hasher = hashlib.sha256()
    with open(file_path, 'rb') as file:
        while True:
            chunk = file.read(4096)
            if not chunk:
                break
            hasher.update(chunk)
    return hasher.hexdigest()