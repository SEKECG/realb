import os
import json
from .argon_utils import generate_key_from_password, get_argon2_parameters_for_encryption
from .chunk_crypto import encrypt_chunk, decrypt_chunk
from .config import CHUNK_SIZE
from .utils import generate_unique_filename
import base64

def read_file_data(file_path):
    with open(file_path, 'rb') as f:
        data = f.read()
    return data

def encrypt_data_raw_chacha(data, key, argon_params, extra):
    cipher = ChaCha20Poly1305(key)
    nonce = os.urandom(12)
    ciphertext = cipher.encrypt(nonce, data, extra)
    return {'nonce': base64.b64encode(nonce).decode(), 'ciphertext': base64.b64encode(ciphertext).decode(), 'params': argon_params}

def decrypt_data_raw_chacha(enc_dict, key, extra):
    cipher = ChaCha20Poly1305(key)
    nonce = base64.b64decode(enc_dict['nonce'])
    ciphertext = base64.b64decode(enc_dict['ciphertext'])
    plaintext = cipher.decrypt(nonce, ciphertext, extra)
    return plaintext

def encrypt_hidden_volume():
    pass

def decrypt_file(encrypted_file, outer_password):
    pass

def change_real_volume_password():
    pass