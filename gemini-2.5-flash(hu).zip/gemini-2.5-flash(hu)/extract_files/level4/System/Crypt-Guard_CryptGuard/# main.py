import os
from .file_chooser import select_file_for_encryption, select_files_for_decryption
from .single_shot import encrypt_data_single, decrypt_data_single
from .streaming import encrypt_data_streaming, decrypt_data_streaming, calculate_optimal_workers, STREAMING_THRESHOLD
from .hidden_volume import encrypt_hidden_volume, decrypt_file
from .password_utils import get_single_password, get_combined_password, choose_auth_method, validate_key_file
from .utils import clear_screen, generate_ephemeral_token
from .config import CHUNK_SIZE, MAX_CHUNK_SIZE, STREAMING_THRESHOLD
import sys

def calculate_optimal_chunk_size(file_size):
    if file_size < STREAMING_THRESHOLD:
        return CHUNK_SIZE
    else:
        return min(MAX_CHUNK_SIZE, file_size // calculate_optimal_workers(file_size))

def ask_chunk_size(file_size):
    optimal_size = calculate_optimal_chunk_size(file_size)
    while True:
        try:
            chunk_size = int(input(f"Enter chunk size (optimal: {optimal_size}): "))
            if CHUNK_SIZE <= chunk_size <= MAX_CHUNK_SIZE:
                return chunk_size
            else:
                print(f"Chunk size must be between {CHUNK_SIZE} and {MAX_CHUNK_SIZE}")
        except ValueError:
            print("Invalid input. Please enter an integer.")

def encrypt_with_dialog():
    file_path = select_file_for_encryption()
    if not file_path:
        return
    file_size = os.path.getsize(file_path)
    chunk_size = ask_chunk_size(file_size)
    password = get_single_password()
    if file_size > STREAMING_THRESHOLD:
        encrypt_data_streaming(file_path, password, 'file', os.path.splitext(file_path)[1], None, chunk_size)
    else:
        with open(file_path, 'rb') as f:
            data = f.read()
        encrypt_data_single(data, password, 'file', os.path.splitext(file_path)[1], None)

def decrypt_with_dialog():
    file_paths = select_files_for_decryption()
    if not file_paths:
        return
    enc_path = file_paths[0]
    password = get_single_password()
    decrypt_data_single(enc_path, password)

def encrypt_text():
    pass

def encrypt_multiple_files():
    pass

def reencrypt_file():
    pass

def decrypt_menu():
    pass

def generate_ephemeral_token_menu():
    while True:
        try:
            n_bits = int(input("Enter the number of bits for the token: "))
            token = generate_ephemeral_token(n_bits)
            print(f"Generated token: {token}")
            save_token = input("Save token to file? (y/n): ")
            if save_token.lower() == 'y':
                file_path = input("Enter file path to save token: ")
                with open(file_path, 'w') as f:
                    f.write(token)
            break
        except ValueError:
            print("Invalid input. Please enter an integer.")

def list_encrypted_files():
    pass

def main_menu():
    while True:
        clear_screen()
        print("CRYPTGUARD Main Menu:")
        print("1. Encryption Options")
        print("2. File Settings")
        print("3. Performance Settings")
        print("4. Exit")
        choice = input("Enter your choice: ")
        if choice == '1':
            encryption_options_menu()
        elif choice == '2':
            encrypted_file_settings_menu()
        elif choice == '3':
            performance_settings_menu()
        elif choice == '4':
            sys.exit(0)
        else:
            print("Invalid choice. Please try again.")

def encryption_options_menu():
    pass

def encrypted_file_settings_menu():
    pass

def performance_settings_menu():
    pass

def security_profile_menu():
    pass

def menu_file_dialog():
    pass

if __name__ == "__main__":
    main_menu()