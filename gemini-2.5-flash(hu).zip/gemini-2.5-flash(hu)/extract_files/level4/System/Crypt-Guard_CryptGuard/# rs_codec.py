import reedsolo

rs_codec = reedsolo.RSCodec(16)

def rs_encode_data(data, block_size, parity_bytes):
    encoded_data = rs_codec.encode(data)
    return encoded_data

def rs_decode_data(data, parity_bytes):
    decoded_data = rs_codec.decode(data)
    return decoded_data