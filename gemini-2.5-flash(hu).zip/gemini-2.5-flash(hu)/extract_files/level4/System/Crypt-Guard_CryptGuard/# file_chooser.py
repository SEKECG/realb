import tkinter as tk
from tkinter import filedialog

tk = tk

def select_file_for_encryption():
    root = tk.Tk()
    root.withdraw()
    file_path = filedialog.askopenfilename()
    return file_path

def select_files_for_decryption():
    root = tk.Tk()
    root.withdraw()
    file_paths = filedialog.askopenfilenames(filetypes=[('Encrypted files', '*.enc'), ('Metadata files', '*.meta')])
    return file_paths