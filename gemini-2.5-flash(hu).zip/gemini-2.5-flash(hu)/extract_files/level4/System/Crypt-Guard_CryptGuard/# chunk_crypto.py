from chacha20poly1305 import ChaCha20Poly1305
from .rs_codec import rs_encode_data, rs_decode_data
from .config import USE_RS

def encrypt_chunk(chunk, key, aad, chunk_index):
    cipher = ChaCha20Poly1305(key)
    nonce = os.urandom(12)
    ciphertext = cipher.encrypt(nonce, chunk, aad + chunk_index.to_bytes(4, 'big'))
    if USE_RS:
        ciphertext = rs_encode_data(ciphertext, block_size=1024, parity_bytes=16)
    return ciphertext

def decrypt_chunk(data, key, offset, aad, chunk_index):
    cipher = ChaCha20Poly1305(key)
    if USE_RS:
        data = rs_decode_data(data, parity_bytes=16)
    nonce = data[:12]
    ciphertext = data[12:]
    plaintext = cipher.decrypt(nonce, ciphertext, aad + chunk_index.to_bytes(4, 'big'))
    return plaintext, offset + len(plaintext)