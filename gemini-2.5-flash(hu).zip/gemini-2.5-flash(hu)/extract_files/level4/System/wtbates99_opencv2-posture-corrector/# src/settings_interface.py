from PyQt5.QtWidgets import QDialog, QVBoxLayout, QTabWidget, QWidget, QLabel, QComboBox, QSpinBox, QPushButton, QGridLayout, QCheckBox, QLineEdit, QTableWidget, QTableWidgetItem, QHeaderView
from PyQt5.QtCore import Qt
from src.util__settings import CUSTOMIZABLE_SETTINGS, update_setting, get_setting
import cv2

class SettingsInterface(QDialog):
    def __init__(self, parent):
        super().__init__(parent)
        self.setWindowTitle("Settings")
        self.tabs = QTabWidget()
        self.camera_tab = QWidget()
        self.general_tab = QWidget()
        self.tracking_tab = QWidget()
        self.tabs.addTab(self.camera_tab, "Camera")
        self.tabs.addTab(self.general_tab, "General")
        self.tabs.addTab(self.tracking_tab, "Tracking")
        self.button_box = QVBoxLayout()
        ok_button = QPushButton("OK")
        ok_button.clicked.connect(self.accept)
        cancel_button = QPushButton("Cancel")
        cancel_button.clicked.connect(self.reject)
        self.button_box.addWidget(ok_button)
        self.button_box.addWidget(cancel_button)
        main_layout = QVBoxLayout()
        main_layout.addWidget(self.tabs)
        main_layout.addLayout(self.button_box)
        self.setLayout(main_layout)
        self.init_camera_tab()
        self.init_general_tab()
        self.init_tracking_tab()

    def accept(self):
        update_setting("camera_id", self.camera_combo.currentIndex())
        update_setting("fps", self.fps_spinbox.value())
        update_setting("width", self.width_spinbox.value())
        update_setting("height", self.height_spinbox.value())
        update_setting("model_complexity", self.model_complexity_spinbox.value())
        update_setting("notification_cooldown", self.cooldown_spinbox.value())
        update_setting("poor_posture_threshold", self.poor_posture_spinbox.value())
        update_setting("posture_message", self.posture_message_lineedit.text())
        update_setting("db_enabled", self.db_logging_checkbox.isChecked())
        update_setting("db_write_interval", self.db_write_interval_spinbox.value())
        super().accept()

    def add_tracking_interval(self):
        label = self.new_interval_label_edit.text()
        minutes = self.new_interval_spinbox.value()
        CUSTOMIZABLE_SETTINGS["tracking_intervals"].append({"label": label, "minutes": minutes})
        self.populate_tracking_table()

    def get_available_cameras(self, max_index=10):
        cameras = []
        for i in range(max_index):
            cap = cv2.VideoCapture(i)
            if cap.isOpened():
                cameras.append(f"Camera {i}")
                cap.release()
        return cameras

    def init_camera_tab(self):
        layout = QGridLayout()
        self.camera_combo = QComboBox()
        self.camera_combo.addItems(self.get_available_cameras())
        self.camera_combo.setCurrentIndex(get_setting("camera_id"))
        self.fps_spinbox = QSpinBox()
        self.fps_spinbox.setValue(get_setting("fps"))
        self.width_spinbox = QSpinBox()
        self.width_spinbox.setValue(get_setting("width"))
        self.height_spinbox = QSpinBox()
        self.height_spinbox.setValue(get_setting("height"))
        self.model_complexity_spinbox = QSpinBox()
        self.model_complexity_spinbox.setValue(get_setting("model_complexity"))
        layout.addWidget(QLabel("Camera:"), 0, 0)
        layout.addWidget(self.camera_combo, 0, 1)
        layout.addWidget(QLabel("FPS:"), 1, 0)
        layout.addWidget(self.fps_spinbox, 1, 1)
        layout.addWidget(QLabel("Width:"), 2, 0)
        layout.addWidget(self.width_spinbox, 2, 1)
        layout.addWidget(QLabel("Height:"), 3, 0)
        layout.addWidget(self.height_spinbox, 3, 1)
        layout.addWidget(QLabel("Model Complexity:"), 4, 0)
        layout.addWidget(self.model_complexity_spinbox, 4, 1)
        self.camera_tab.setLayout(layout)

    def init_general_tab(self):
        layout = QGridLayout()
        self.cooldown_spinbox = QSpinBox()
        self.cooldown_spinbox.setValue(get_setting("notification_cooldown"))
        self.poor_posture_spinbox = QSpinBox()
        self.poor_posture_spinbox.setValue(get_setting("poor_posture_threshold"))
        self.posture_message_lineedit = QLineEdit()
        self.posture_message_lineedit.setText(get_setting("posture_message"))
        self.db_logging_checkbox = QCheckBox("Enable Database Logging")
        self.db_logging_checkbox.setChecked(get_setting("db_enabled"))
        self.db_write_interval_spinbox = QSpinBox()
        self.db_write_interval_spinbox.setValue(get_setting("db_write_interval"))
        layout.addWidget(QLabel("Notification Cooldown (seconds):"), 0, 0)
        layout.addWidget(self.cooldown_spinbox, 0, 1)
        layout.addWidget(QLabel("Poor Posture Threshold (%):"), 1, 0)
        layout.addWidget(self.poor_posture_spinbox, 1, 1)
        layout.addWidget(QLabel("Posture Message:"), 2, 0)
        layout.addWidget(self.posture_message_lineedit, 2, 1)
        layout.addWidget(self.db_logging_checkbox, 3, 0, 1, 2)
        layout.addWidget(QLabel("Database Write Interval (seconds):"), 4, 0)
        layout.addWidget(self.db_write_interval_spinbox, 4, 1)
        self.general_tab.setLayout(layout)

    def init_tracking_tab(self):
        layout = QVBoxLayout()
        self.tracking_table = QTableWidget()
        self.tracking_table.setColumnCount(2)
        self.tracking_table.setHorizontalHeaderLabels(["Label", "Minutes"])
        self.tracking_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.populate_tracking_table()
        self.new_interval_label_edit = QLineEdit()
        self.new_interval_spinbox = QSpinBox()
        self.add_interval_button = QPushButton("Add Interval")
        self.add_interval_button.clicked.connect(self.add_tracking_interval)
        self.remove_interval_button = QPushButton("Remove Interval")
        self.remove_interval_button.clicked.connect(self.remove_tracking_interval)
        layout.addWidget(self.tracking_table)
        layout.addWidget(QLabel("New Interval:"))
        layout.addWidget(self.new_interval_label_edit)
        layout.addWidget(self.new_interval_spinbox)
        layout.addWidget(self.add_interval_button)
        layout.addWidget(self.remove_interval_button)
        self.tracking_tab.setLayout(layout)

    def populate_tracking_table(self):
        self.tracking_table.setRowCount(len(CUSTOMIZABLE_SETTINGS["tracking_intervals"]))
        for i, interval in enumerate(CUSTOMIZABLE_SETTINGS["tracking_intervals"]):
            self.tracking_table.setItem(i, 0, QTableWidgetItem(interval["label"]))
            self.tracking_table.setItem(i, 1, QTableWidgetItem(str(interval["minutes"])))

    def remove_tracking_interval(self):
        selected_rows = sorted(set(index.row() for index in self.tracking_table.selectedIndexes()), reverse=True)
        for row in selected_rows:
            del CUSTOMIZABLE_SETTINGS["tracking_intervals"][row]
        self.populate_tracking_table()