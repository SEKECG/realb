import sqlite3

class Database:
    def __init__(self, db_path):
        self.conn = sqlite3.connect(db_path)
        self.cursor = self.conn.cursor()
        self.posture_landmarks = []  # Placeholder for landmark names
        self._create_tables()

    def _create_tables(self):
        self.create_table("posture_scores", [
            ("timestamp", "TEXT"),
            ("score", "REAL")
        ])
        self.create_table("pose_landmarks", [
            ("timestamp", "TEXT"),
            ("landmarks", "TEXT")
        ])

    def close(self):
        self.conn.close()

    def create_table(self, table_name, columns):
        query = f"CREATE TABLE IF NOT EXISTS {table_name} ({', '.join([f'{col} {data_type}' for col, data_type in columns])})"
        self.cursor.execute(query)
        self.conn.commit()

    def insert(self, table_name, values):
        placeholders = ", ".join(["?"] * len(values[0]))
        query = f"INSERT INTO {table_name} VALUES ({placeholders})"
        self.cursor.executemany(query, values)
        self.conn.commit()

    def save_pose_data(self, landmarks, score):
        timestamp = datetime.datetime.now().isoformat()
        self.insert("posture_scores", [(timestamp, score)])
        self.insert("pose_landmarks", [(timestamp, str(landmarks))])

import datetime