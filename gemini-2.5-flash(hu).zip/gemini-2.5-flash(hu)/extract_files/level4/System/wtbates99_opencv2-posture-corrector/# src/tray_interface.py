import sys
from PyQt5.QtWidgets import QApplication, QSystemTrayIcon, QMenu, QWidget, QLabel
from PyQt5.QtGui import QIcon, QPixmap
from PyQt5.QtCore import QTimer, QThread, pyqtSignal, QObject
import signal
import time
from src.pose_detector import PoseDetector
from src.webcam import Webcam
from src.notifications import Notifications
from src.util__settings import get_setting, update_setting, save_user_settings, CUSTOMIZABLE_SETTINGS
from src.database import Database
from src.util__create_score_icon import create_score_icon
import os

class PostureTrackerTray(QSystemTrayIcon):
    def __init__(self):
        super().__init__()
        self.icon_path = os.path.join(os.path.dirname(__file__), "icon.png") # Placeholder for icon path
        self.setIcon(QIcon(self.icon_path))
        self.current_score = 0
        self.scores = []
        self.tracking_enabled = False
        self.tracking_interval = 0
        self.last_tracking_time = 0
        self.db_enabled = get_setting("db_enabled")
        self.db = Database("posture.db") if self.db_enabled else None
        self.last_db_save = 0
        self.detector = None
        self.frame_reader = None
        self.video_window = None
        self.video_label = None
        self.notifier = Notifications(self.icon_path)
        self.timer = QTimer()
        self.interval_timer = QTimer()
        self.interval_menu = None
        self.interval_menu_action = None
        self.toggle_tracking_action = None
        self.toggle_video_action = None
        self.settings_action = None
        self._initialize_application()
        self._initialize_components()
        self._setup_tray_menu()
        self._setup_timers()
        self._setup_signal_handling()
        self.show()

    def _create_interval_menu(self, parent_menu):
        self.interval_menu = QMenu("Tracking Interval", parent_menu)
        for interval in CUSTOMIZABLE_SETTINGS["tracking_intervals"]:
            action = self.interval_menu.addAction(f"{interval['label']} ({interval['minutes']} minutes)")
            action.triggered.connect(lambda checked, minutes=interval['minutes']: self.set_interval(minutes))
        self.interval_menu_action = parent_menu.addMenu(self.interval_menu)

    def _create_video_window(self):
        self.video_window = QWidget()
        self.video_label = QLabel(self.video_window)
        self.video_label.resize(get_setting("width"), get_setting("height"))
        self.video_window.setWindowTitle("Posture Tracker")
        self.video_window.show()
        self.toggle_video_action.setChecked(True)

    def _initialize_application(self):
        self.app = QApplication(sys.argv)
        self.app.setQuitOnLastWindowClosed(False)

    def _initialize_components(self):
        self.frame_reader = Webcam()
        self.detector = PoseDetector()
        self.frame_reader.start(self.update_tracking)

    def _save_to_db(self, average_score):
        if self.db_enabled and time.time() - self.last_db_save > get_setting("db_write_interval"):
            self.db.save_pose_data(self.frame_reader.get_latest_pose_results(), average_score)
            self.last_db_save = time.time()

    def _setup_signal_handling(self):
        signal.signal(signal.SIGINT, self.signal_handler)
        signal.signal(signal.SIGTERM, self.signal_handler)

    def _setup_timers(self):
        self.timer.timeout.connect(self.update_tracking)
        self.timer.start(1000 // get_setting("fps"))
        self.interval_timer.timeout.connect(self.check_interval)
        self.interval_timer.start(60000) # Check every minute

    def _setup_tray_menu(self):
        menu = QMenu()
        self.toggle_tracking_action = menu.addAction("Start Tracking")
        self.toggle_tracking_action.setCheckable(True)
        self.toggle_tracking_action.triggered.connect(self.toggle_tracking)
        self.toggle_video_action = menu.addAction("Show Video")
        self.toggle_video_action.setCheckable(True)
        self.toggle_video_action.triggered.connect(self.toggle_video)
        self._create_interval_menu(menu)
        self.settings_action = menu.addAction("Settings")
        self.settings_action.triggered.connect(self.open_settings)
        menu.addAction("Quit").triggered.connect(self.quit_application)
        self.setContextMenu(menu)

    def _start_tracking(self):
        self.tracking_enabled = True
        self.last_tracking_time = time.time()

    def _stop_tracking(self):
        self.tracking_enabled = False

    def _update_video_display(self, frame):
        if self.video_window:
            height, width, channel = frame.shape
            bytesPerLine = 3 * width
            qt_image = QPixmap.fromImage(QImage(frame.data, width, height, bytesPerLine, QImage.Format_RGB888))
            self.video_label.setPixmap(qt_image)

    def check_interval(self):
        if self.tracking_interval > 0 and time.time() - self.last_tracking_time >= self.tracking_interval * 60:
            self.stop_interval_tracking()

    def on_video_window_closed(self):
        self.video_window = None
        self.toggle_video_action.setChecked(False)

    def open_settings(self):
        from src.settings_interface import SettingsInterface
        dialog = SettingsInterface(None)
        if dialog.exec_() == 1:
            self.reload_settings()

    def quit_application(self):
        self.frame_reader.stop()
        self.frame_reader.wait()
        if self.db:
            self.db.close()
        if os.path.exists("posture_tracker.lock"):
            os.remove("posture_tracker.lock")
        self.app.quit()

    def reload_settings(self):
        save_user_settings()
        self.app.quit()
        self.app = QApplication(sys.argv)
        self._initialize_components()
        self._setup_timers()

    def set_interval(self, minutes):
        self.tracking_interval = minutes
        self.notifier.set_interval_message(f"Tracking interval set to {minutes} minutes.")
        self.start_interval_tracking()

    def signal_handler(self, signum, frame):
        self.quit_application()

    def start_interval_tracking(self):
        self.last_tracking_time = time.time()
        if not self.tracking_enabled:
            self.toggle_tracking()
        QTimer.singleShot(self.tracking_interval * 60 * 1000, self.stop_interval_tracking)

    def stop_interval_tracking(self):
        if self.tracking_enabled:
            self.toggle_tracking()

    def toggle_tracking(self):
        if self.tracking_enabled:
            self._stop_tracking()
            self.toggle_tracking_action.setText("Start Tracking")
        else:
            self._start_tracking()
            self.toggle_tracking_action.setText("Stop Tracking")

    def toggle_video(self):
        if self.video_window:
            self.video_window.close()
        else:
            self._create_video_window()

    def update_tracking(self):
        frame, score, results = self.detector.process_frame(self.frame_reader.get_latest_frame())
        self.current_score = score
        self.scores.append(score)
        self._update_video_display(frame)
        average_score = self.scores[-1] # Placeholder for average score calculation
        self.notifier.check_and_notify(average_score)
        self._save_to_db(average_score)
        icon = create_score_icon(self.current_score)
        self.setIcon(QIcon(icon))