import json

POSTURE_LANDMARKS = [] # Placeholder
CUSTOMIZABLE_SETTINGS = {
    "camera_id": 0,
    "fps": 30,
    "width": 640,
    "height": 480,
    "model_complexity": 1,
    "notification_cooldown": 5,
    "poor_posture_threshold": 50,
    "posture_message": "Improve your posture!",
    "db_enabled": False,
    "db_write_interval": 60,
    "tracking_intervals": []
}
IMMUTABLE_SETTINGS = {} # Placeholder
USER_SETTINGS_FILE = "user_settings.json"

def get_setting(key):
    if key in CUSTOMIZABLE_SETTINGS:
        return CUSTOMIZABLE_SETTINGS[key]
    elif key in IMMUTABLE_SETTINGS:
        return IMMUTABLE_SETTINGS[key]
    else:
        raise KeyError(f"Setting '{key}' not found.")

def save_user_settings():
    with open(USER_SETTINGS_FILE, "w") as f:
        json.dump(CUSTOMIZABLE_SETTINGS, f, indent=4)

def load_user_settings():
    try:
        with open(USER_SETTINGS_FILE, "r") as f:
            loaded_settings = json.load(f)
            CUSTOMIZABLE_SETTINGS.update(loaded_settings)
    except FileNotFoundError:
        pass

def update_setting(key, value):
    if key in CUSTOMIZABLE_SETTINGS:
        CUSTOMIZABLE_SETTINGS[key] = value
    else:
        raise KeyError(f"Setting '{key}' is immutable or does not exist.")