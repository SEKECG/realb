import cv2
from PyQt5.QtCore import QThread, pyqtSignal
import time

class Webcam(QThread):
    frame_ready = pyqtSignal(object)

    def __init__(self):
        super().__init__()
        self.camera_id = 0
        self.fps = 30
        self.cap = None
        self.is_running = False
        self._latest_frame = None
        self._latest_score = 0
        self._latest_pose_results = None
        self._callback = None
        self.frame_time = 0

    def __del__(self):
        self.stop()
        self.wait()

    def _capture_loop(self):
        while self.is_running:
            start_time = time.time()
            ret, frame = self.cap.read()
            if ret:
                self._latest_frame = frame
                if self._callback:
                    self._callback(frame)
                self.frame_ready.emit(frame)
            self.frame_time = time.time() - start_time
            time.sleep(max(0, 1/self.fps - self.frame_time))

    def get_latest_frame(self):
        return self._latest_frame

    def get_latest_pose_results(self):
        return self._latest_pose_results

    def start(self, callback):
        self.cap = cv2.VideoCapture(0)
        self._callback = callback
        self.is_running = True
        super().start()

    def stop(self):
        self.is_running = False
        if self.cap:
            self.cap.release()