import time
from src.util__send_notification import send_notification
from src.util__settings import get_setting

class Notifications:
    def __init__(self, icon_path):
        self.icon_path = icon_path
        self.notification_cooldown = get_setting("notification_cooldown")
        self.poor_posture_threshold = get_setting("poor_posture_threshold")
        self.posture_message = get_setting("posture_message")
        self.interval_message = ""
        self.last_notification_time = 0

    def check_and_notify(self, posture_score):
        if posture_score < self.poor_posture_threshold and time.time() - self.last_notification_time > self.notification_cooldown:
            send_notification(self.posture_message, "Poor Posture Detected", self.icon_path)
            self.last_notification_time = time.time()

    def set_interval_message(self, message):
        self.interval_message = message
        send_notification(self.interval_message, "Interval Changed", self.icon_path)