import platform
import plyer

def send_notification(message, title, icon_path):
    if platform.system() == "Darwin":
        plyer.notification.notify(
            title=title,
            message=message,
            app_icon=icon_path
        )
    elif platform.system() == "Linux":
        plyer.notification.notify(
            title=title,
            message=message,
            app_icon=icon_path
        )
    elif platform.system() == "Windows":
        plyer.notification.notify(
            title=title,
            message=message,
            app_icon=icon_path
        )