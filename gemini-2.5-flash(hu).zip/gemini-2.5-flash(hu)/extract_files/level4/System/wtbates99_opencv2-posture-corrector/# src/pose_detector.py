import cv2
import mediapipe as mp
import numpy as np
from src.util__settings import get_setting

class PoseDetector:
    def __init__(self, min_detection_confidence=None, min_tracking_confidence=None, frame_width=None, frame_height=None):
        self.mp_pose = mp.solutions.pose
        self.mp_draw = mp.solutions.drawing_utils
        self.pose = self.mp_pose.Pose(
            min_detection_confidence=min_detection_confidence or get_setting("min_detection_confidence"),
            min_tracking_confidence=min_tracking_confidence or get_setting("min_tracking_confidence")
        )
        self.posture_landmarks = get_setting("POSTURE_LANDMARKS")
        self.frame_width = frame_width or get_setting("width")
        self.frame_height = frame_height or get_setting("height")
        self.ideal_spine_vector = np.array([0, 1])
        self.ideal_neck_vector = np.array([0, 1])
        self.weights = [0.3, 0.7] # Placeholder for weights
        self.score_thresholds = [60, 80] # Placeholder for score thresholds

    def _calculate_posture_score(self, landmarks):
        if landmarks:
            spine_vector = np.array([landmarks[self.posture_landmarks[1]].x - landmarks[self.posture_landmarks[0]].x, landmarks[self.posture_landmarks[1]].y - landmarks[self.posture_landmarks[0]].y])
            neck_vector = np.array([landmarks[self.posture_landmarks[2]].x - landmarks[self.posture_landmarks[1]].x, landmarks[self.posture_landmarks[2]].y - landmarks[self.posture_landmarks[1]].y])
            spine_angle = self.angle_between(self.ideal_spine_vector, spine_vector)
            neck_angle = self.angle_between(self.ideal_neck_vector, neck_vector)
            score = (1 - (spine_angle / 180)) * self.weights[0] + (1 - (neck_angle / 180)) * self.weights[1]
            return max(0, min(100, score * 100))
        return 0

    def _detect_pose(self, frame):
        results = self.pose.process(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
        return results

    def _draw_landmarks(self, frame, results):
        self.mp_draw.draw_landmarks(frame, results.pose_landmarks, self.mp_pose.POSE_CONNECTIONS)

    def _draw_posture_feedback(self, frame, score):
        cv2.putText(frame, f"Posture Score: {int(score)}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0) if score > self.score_thresholds[0] else (0, 0, 255), 2)

    def _preprocess_frame(self, frame):
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        frame = cv2.resize(frame, (self.frame_width, self.frame_height))
        lab = cv2.cvtColor(frame, cv2.COLOR_BGR2LAB)
        lab[:, :, 0] = clahe.apply(lab[:, :, 0])
        frame = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)
        return frame

    def angle_between(self, v1, v2):
        dot_product = np.dot(v1, v2)
        mag_v1 = np.linalg.norm(v1)
        mag_v2 = np.linalg.norm(v2)
        angle = np.degrees(np.arccos(dot_product / (mag_v1 * mag_v2)))
        return angle

    def process_frame(self, frame):
        frame = self._preprocess_frame(frame)
        results = self._detect_pose(frame)
        self._draw_landmarks(frame, results)
        score = self._calculate_posture_score(results.pose_landmarks.landmark)
        self._draw_posture_feedback(frame, score)
        return frame, score, results