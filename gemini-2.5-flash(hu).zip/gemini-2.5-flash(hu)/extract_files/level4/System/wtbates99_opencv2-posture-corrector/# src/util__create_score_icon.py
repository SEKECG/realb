from PIL import Image, ImageDraw, ImageFont
import numpy as np

def create_score_icon(score):
    size = 64
    radius = size // 2
    color = (0, 255, 0) if score > 80 else (255, 255, 0) if score > 60 else (255, 0, 0)
    alpha = int(255 * (score / 100))
    image = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(image)
    draw.ellipse((0, 0, size - 1, size - 1), fill=(color[0], color[1], color[2], alpha))
    font = ImageFont.load_default()
    text = str(int(score))
    text_width, text_height = font.getsize(text)
    draw.text((radius - text_width // 2, radius - text_height // 2), text, font=font, fill=(255, 255, 255, 255))
    return image