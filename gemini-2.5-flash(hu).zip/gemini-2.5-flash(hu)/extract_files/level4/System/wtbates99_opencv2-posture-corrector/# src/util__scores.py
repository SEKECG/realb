import time

class Scores:
    WINDOW_SIZE = 5 # Placeholder
    SCORE_THRESHOLD = 50 # Placeholder

    def __init__(self):
        self.buffer_size = self.WINDOW_SIZE
        self.scores = [0] * self.buffer_size
        self.timestamps = [0] * self.buffer_size
        self.current_index = 0
        self.is_buffer_full = False

    def add_score(self, score):
        self.scores[self.current_index] = score
        self.timestamps[self.current_index] = time.time()
        self.current_index = (self.current_index + 1) % self.buffer_size
        self.is_buffer_full = self.is_buffer_full or self.current_index == 0

    def get_average_score(self):
        if not self.is_buffer_full:
            valid_scores = [s for s in self.scores if s != 0]
            if valid_scores:
                return sum(valid_scores) / len(valid_scores)
            else:
                return 0.0
        else:
            return sum(self.scores) / self.buffer_size