import sys
import os
from pathlib import Path
from src.tray_interface import PostureTrackerTray

def kill_existing_instance(lock_file):
    lock_file_path = Path(lock_file)
    if lock_file_path.exists():
        with open(lock_file_path, "r") as f:
            try:
                pid = int(f.read())
                os.kill(pid, 0) # Check if process exists
                os.kill(pid, 9) # Kill process
            except (OSError, ValueError):
                pass
        lock_file_path.unlink()

def main():
    lock_file = "posture_tracker.lock"
    kill_existing_instance(lock_file)
    Path(lock_file).touch()
    with open(lock_file, "w") as f:
        f.write(str(os.getpid()))

    app = PostureTrackerTray()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()