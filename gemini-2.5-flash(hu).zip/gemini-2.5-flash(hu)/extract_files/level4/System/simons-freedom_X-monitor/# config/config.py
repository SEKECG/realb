class Config:
    def __init__(self, monitor=None, llm=None, trader=None, telegram=None, dingtalk=None):
        self.monitor = monitor
        self.llm = llm
        self.trader = trader
        self.telegram = telegram
        self.dingtalk = dingtalk

class DingTalkConfig:
    def __init__(self, token, secret):
        self.token = token
        self.secret = secret

class LlmConfig:
    pass

class MonitorConfig:
    pass

class TelegramConfig:
    pass

class TraderConfig:
    def __init__(self, default_trade_amount_usd, enabled, gas_price_multiplier, high_confidence_amount_usd, max_price_change_1h, max_trade_amount_usd, medium_confidence_amount_usd, min_confidence, min_liquidity_usd, min_volume_usd, private_keys, router_addresses, rpc_urls, slippage_tolerance):
        self.default_trade_amount_usd = default_trade_amount_usd
        self.enabled = enabled
        self.gas_price_multiplier = gas_price_multiplier
        self.high_confidence_amount_usd = high_confidence_amount_usd
        self.max_price_change_1h = max_price_change_1h
        self.max_trade_amount_usd = max_trade_amount_usd
        self.medium_confidence_amount_usd = medium_confidence_amount_usd
        self.min_confidence = min_confidence
        self.min_liquidity_usd = min_liquidity_usd
        self.min_volume_usd = min_volume_usd
        self.private_keys = private_keys or {}
        self.router_addresses = router_addresses or {}
        self.rpc_urls = rpc_urls or {}
        self.slippage_tolerance = slippage_tolerance

    def __post_init__(self):
        pass

cfg = None

def load_config():
    pass