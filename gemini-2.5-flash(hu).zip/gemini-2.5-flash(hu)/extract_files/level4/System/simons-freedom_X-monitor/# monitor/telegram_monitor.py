from pyrogram import Client
from monitor.base import BaseMonitor

class TelegramMonitor(BaseMonitor):
    def __init__(self, api_id, api_hash, target_chat_id):
        super().__init__()
        self.api_id = api_id
        self.api_hash = api_hash
        self.client = Client(":memory:", api_id=api_id, api_hash=api_hash)
        self.target_list = []
        self.monitor_targets = [target_chat_id]
        self._build_target_list()
        self._register_handlers()

    def _build_target_list(self):
        pass

    def _client_main(self):
        pass

    def _handle_message(self, message):
        pass

    def _register_handlers(self):
        pass

    def _show_login_info(self, me):
        pass

    def parse_message(self, message):
        pass

    def start(self):
        pass