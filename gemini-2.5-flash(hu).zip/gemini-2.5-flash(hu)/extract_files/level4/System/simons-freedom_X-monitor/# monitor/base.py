from core.analyzer import LlmAnalyzer, TokenSearcher
from core.trader import ChainTrader

class BaseMonitor:
    def __init__(self):
        self.analyzer = LlmAnalyzer(api_key="YOUR_API_KEY")
        self.token_searcher = TokenSearcher(max_retries=3, retry_delay=5)
        self.trader = ChainTrader()
        self._init_trader()

    def _analyze_message(self, msg):
        pass

    def _format_token_notification(self, token_names, search_results, tweet_author, tweet_content):
        pass

    def _init_trader(self):
        pass

    def _search_tokens(self, token_names):
        pass

    def _should_trade(self, token):
        pass

    def process_message(self, message):
        pass