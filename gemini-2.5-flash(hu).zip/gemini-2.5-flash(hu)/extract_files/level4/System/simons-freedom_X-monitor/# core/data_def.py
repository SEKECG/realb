from typing import Optional

class Msg:
    pass

class PushMsg:
    def __init__(self, tweet=None):
        self.tweet = tweet

class Tweet:
    pass

class User:
    pass