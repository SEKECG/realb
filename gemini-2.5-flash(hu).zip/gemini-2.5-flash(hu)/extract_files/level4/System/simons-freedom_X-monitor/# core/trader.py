from typing import Optional, Dict

class ChainBase:
    def __init__(self, chain_id, config):
        self.chain_id = chain_id
        self.config = config
        self.client = None
        self.initialized = False

    def buy_token(self, token_address, amount_usd, private_key):
        pass

    def get_explorer_url(self, tx_hash):
        pass

    def initialize(self):
        pass

class ChainTrader:
    BASE_CHAIN_CONFIG = None
    def __init__(self):
        self.chain_config = None
        self.chains = {}

    def buy_token(self, chain, token_address, amount_usd):
        pass

    def get_tx_explorer_url(self, chain, tx_hash):
        pass

    def initialize_chains(self):
        pass

class EvmChain(ChainBase):
    def __init__(self, chain_id, config):
        super().__init__(chain_id, config)
        self.web3 = None
        self.router_abi = None
        self.erc20_abi = None

    def buy_token(self, token_address, amount_usd, private_key):
        pass

    def initialize(self):
        pass

class SolanaChain(ChainBase):
    def __init__(self, chain_id, config):
        super().__init__(chain_id, config)
        self.client = None
        self.jupiter_api = None
        self.initialized = False

    def _get_jupiter_quote(self, input_mint, output_mint, amount):
        pass

    def _get_jupiter_swap_tx(self, quote, user_public_key):
        pass

    def buy_token(self, token_address, amount_usd, private_key):
        pass

    def initialize(self):
        pass

def get_token_prices():
    pass