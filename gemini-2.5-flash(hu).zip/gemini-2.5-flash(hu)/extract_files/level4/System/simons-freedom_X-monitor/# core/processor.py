class TwitterLinkProcessor:
    @staticmethod
    def extract_image_url(tweet_text):
        pass

    @staticmethod
    def ensure_playwright_browser():
        pass

    @staticmethod
    def expand_short_url(short_url):
        pass

    @staticmethod
    def extract_image_with_playwright(url):
        pass

    @staticmethod
    def extract_image_with_selenium(url):
        pass

    @staticmethod
    def extract_short_url(tweet_text):
        pass