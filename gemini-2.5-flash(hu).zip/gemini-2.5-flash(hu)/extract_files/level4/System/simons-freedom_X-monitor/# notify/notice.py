from notify.dingding import DingTalkRobot

_robot = None

def send_warn_action_card(title, text, btn_orientation, btns):
    pass

def send_notice_msg(content, title="系统通知", btn_info=None):
    pass

def _get_robot():
    pass