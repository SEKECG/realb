import requests
import hmac
import hashlib
import json
from urllib.parse import urlencode

class DingTalkRobot:
    def __init__(self, robot_id, secret):
        self.robot_id = robot_id
        self.secret = secret
        self.headers = {'Content-Type': 'application/json;charset=utf-8'}
        self.start_time = 0
        self.times = 0

    def __post(self, data):
        pass

    def __spliceUrl(self):
        pass

    def is_not_null_and_blank_str(self, content):
        pass

    def send_action_card(self, title, markdown_msg, btnOrientation="0", btn_info=None):
        pass

    def send_image(self, title, image_url, is_at_all=False, at_mobiles=None):
        pass

    def send_json(self, msg, is_at_all=False, at_mobiles=None):
        pass

    def send_markdown(self, title, markdown_msg, is_at_all=False, at_mobiles=None):
        pass

    def send_msg(self, mssg):
        pass

    def send_text(self, msg, is_at_all=False, at_mobiles=None):
        pass