from config.config import load_config, Config
from monitor.telegram_monitor import TelegramMonitor
from monitor.webhook_monitor import WebhookMonitor
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def main():
    config = load_config()
    if config.monitor:
        if config.monitor.driver == "telegram":
            monitor = TelegramMonitor(api_id=config.telegram.api_id, api_hash=config.telegram.api_hash, target_chat_id=config.telegram.target_chat_id)
            monitor.start()
        elif config.monitor.driver == "webhook":
            monitor = WebhookMonitor(host=config.monitor.host, port=config.monitor.port)
            monitor.start()
        else:
            logging.error("Unsupported monitor driver.")
    else:
        logging.error("No monitor config found.")

if __name__ == "__main__":
    main()