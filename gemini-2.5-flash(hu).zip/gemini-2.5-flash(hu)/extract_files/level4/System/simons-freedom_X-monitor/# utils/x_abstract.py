from bs4 import BeautifulSoup
import requests
from datetime import datetime

key = None
result = None
tweet_url = None
value = None

def get_tweet_details(url):
    pass

def extract_author(soup):
    pass

def extract_content(soup):
    pass

def extract_time(soup):
    pass