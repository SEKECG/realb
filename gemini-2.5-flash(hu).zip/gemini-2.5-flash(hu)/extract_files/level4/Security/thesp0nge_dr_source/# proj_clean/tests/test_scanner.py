import tempfile
import shutil
import os
from dr_source.core.scanner import Scanner
from dr_source.core.codebase import Codebase, FileObject
from dr_source.core.detectors import SQLInjectionDetector, XSSDetector

def test_scanner_integration():
    pass