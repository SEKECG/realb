from dr_source.core.detectors.jndi_injection import JNDIInjectionDetector
from dr_source.core.codebase import FileObject

def test_jndi_injection_detector_regex():
    pass