from dr_source.core.detectors.open_redirect import OpenRedirectDetector
from dr_source.core.codebase import FileObject

def test_open_redirect_detector_regex():
    pass