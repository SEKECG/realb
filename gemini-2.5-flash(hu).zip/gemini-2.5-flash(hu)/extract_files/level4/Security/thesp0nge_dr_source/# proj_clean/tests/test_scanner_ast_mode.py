def test_scanner_ast_mode():
    pass