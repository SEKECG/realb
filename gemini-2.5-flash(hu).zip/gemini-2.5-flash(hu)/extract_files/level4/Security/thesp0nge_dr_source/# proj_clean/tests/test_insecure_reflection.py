from dr_source.core.detectors.insecure_reflection import InsecureReflectionDetector
from dr_source.core.codebase import FileObject

def test_insecure_reflection_detector_regex():
    pass