from dr_source.core.detectors.insecure_cookie import InsecureCookieDetector
from dr_source.core.codebase import FileObject

def test_insecure_cookie_detector_regex():
    pass