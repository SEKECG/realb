from dr_source.core.detectors.hardcoded_credentials import HardcodedCredentialsDetector
from dr_source.core.codebase import FileObject

def test_hardcoded_credentials_detector():
    pass