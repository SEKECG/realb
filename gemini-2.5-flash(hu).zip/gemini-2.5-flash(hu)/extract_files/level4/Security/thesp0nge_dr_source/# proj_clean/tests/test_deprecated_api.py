from dr_source.core.detectors.deprecated_api import DeprecatedAPIDetector

def test_deprecated_api_detector_regex():
    pass