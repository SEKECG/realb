from dr_source.core.detectors.file_inclusion import FileInclusionDetector
from dr_source.core.codebase import FileObject

def test_file_inclusion_detector_regex():
    pass