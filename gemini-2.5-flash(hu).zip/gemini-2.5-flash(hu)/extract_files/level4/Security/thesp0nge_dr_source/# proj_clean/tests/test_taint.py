def test_taint_propagation():
    pass