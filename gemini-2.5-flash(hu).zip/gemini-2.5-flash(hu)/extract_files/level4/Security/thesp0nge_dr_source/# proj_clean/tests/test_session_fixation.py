from dr_source.core.detectors.session_fixation import SessionFixationDetector
from dr_source.core.codebase import FileObject

def test_session_fixation_detector_ast():
    pass

def test_session_fixation_detector_regex():
    pass