from dr_source.core.detectors.information_disclosure import InformationDisclosureDetector
from dr_source.core.codebase import FileObject

def test_information_disclosure_detector_regex():
    pass