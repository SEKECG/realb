import argparse
import logging
from dr_source.core.scanner import Scanner
from dr_source.core.codebase import Codebase
from dr_source.core.db import ScanDatabase
from dr_source.reports.ascii import ASCIIReport
from dr_source.reports.sarif import SARIFReport
from dr_source.core.detection_rules import DetectionRules

def get_version():
    return "0.1.0"

def main(target_path, ast, init_db, history, compare, export, where_used, verbose, output, debug, show_trace, show_version):
    pass