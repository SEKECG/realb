import logging
import re

logger = logging.getLogger(__name__)

class SessionFixationDetector:
    REGEX_GETSESSION = r"request\.getSession\(\)"
    REGEX_SAFE = r"changeSessionId\(\)|invalidate\(\)"

    def _collect_identifiers(self, expr):
        pass

    def detect(self, file_object):
        pass

    def detect_ast_from_tree(self, file_object, ast_tree):
        pass