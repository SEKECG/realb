import logging
import re

logger = logging.getLogger(__name__)

class InsecureCookieDetector:
    REGEX_PATTERNS = [
        r"Cookie\s*\.\s*setSecure\(false\)",
        r"Cookie\s*\.\s*setHttpOnly\(false\)",
    ]

    def detect(self, file_object):
        pass

    def detect_ast_from_tree(self, file_object, ast_tree):
        return self.detect(file_object)