import logging

logger = logging.getLogger(__name__)

class ASCIIReport:
    def generate(self, results):
        pass