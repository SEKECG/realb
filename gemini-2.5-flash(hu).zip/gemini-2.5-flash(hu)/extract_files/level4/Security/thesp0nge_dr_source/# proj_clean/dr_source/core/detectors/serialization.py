import logging

logger = logging.getLogger(__name__)

class SerializationDetector:
    BUILTIN_AST_SINK = ["ObjectInputStream.readObject"]
    BUILTIN_REGEX_PATTERNS = [r"ObjectInputStream\s*\.\s*readObject\s*\(.*?\)"]

    def __init__(self):
        self.ast_mode = False
        self.ast_sink = self.BUILTIN_AST_SINK
        self.regex_patterns = self.BUILTIN_REGEX_PATTERNS

    def detect(self, file_object):
        pass

    def detect_ast_from_tree(self, file_object, ast_tree):
        pass