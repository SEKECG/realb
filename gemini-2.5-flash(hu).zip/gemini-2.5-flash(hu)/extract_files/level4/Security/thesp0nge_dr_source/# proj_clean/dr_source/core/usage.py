import logging
import javalang

logger = logging.getLogger(__name__)

def where_is_it_used(codebase, target_class):
    pass

def find_usage_in_file(file_obj, target_class):
    pass