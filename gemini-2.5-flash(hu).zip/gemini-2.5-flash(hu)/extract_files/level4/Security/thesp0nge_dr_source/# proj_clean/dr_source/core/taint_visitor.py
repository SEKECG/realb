import logging

logger = logging.getLogger(__name__)

class TaintVisitor:
    source_member = "getParameter"
    source_qualifier = "request"
    tainted = {}

    def __init__(self):
        pass

    def collect_identifiers(self, expr):
        pass

    def get_vulnerabilities(self, ast_tree, sink_list):
        pass

    def is_tainted(self, expr):
        pass

    def visit(self, node):
        pass