import logging

logger = logging.getLogger(__name__)

class CryptoDetector:
    BUILTIN_REGEX_PATTERNS = [
        r"MessageDigest\.getInstance\s*\(\s*\"MD5\"\s*\)",
        r"Cipher\.getInstance\s*\(\s*\"DES\"\s*\)",
        r"SecretKeyFactory\.getInstance\s*\(\s*\"DES\"\s*\)",
    ]

    def __init__(self):
        self.ast_mode = False
        self.regex_patterns = self.BUILTIN_REGEX_PATTERNS

    def detect(self, file_object):
        pass

    def detect_ast_from_tree(self, file_object, ast_tree):
        pass