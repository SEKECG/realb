import logging

def setup_logging(debug):
    pass