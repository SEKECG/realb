class BaseDetector:
    def detect(self, file_object):
        pass