import concurrent.futures
import tqdm
import logging

logger = logging.getLogger(__name__)

class Scanner:
    def __init__(self, codebase, ast_mode=False):
        self.ast_mode = ast_mode
        self.codebase = codebase
        self.detectors = []

    def scan(self):
        pass

    def scan_file(self, file_obj):
        pass