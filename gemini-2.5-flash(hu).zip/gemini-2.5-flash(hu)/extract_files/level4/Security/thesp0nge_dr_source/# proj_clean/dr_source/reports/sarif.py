import logging

logger = logging.getLogger(__name__)

class SARIFReport:
    def generate(self, results):
        pass