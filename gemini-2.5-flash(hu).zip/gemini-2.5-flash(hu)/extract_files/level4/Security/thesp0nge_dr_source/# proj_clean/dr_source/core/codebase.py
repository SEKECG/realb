import os

class Codebase:
    def __init__(self, root_path):
        self.files = []
        self.root_path = root_path

    def load_files(self):
        pass

class FileObject:
    def __init__(self, path, content):
        self.content = content
        self.path = path