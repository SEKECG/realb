import logging

logger = logging.getLogger(__name__)

class XSSDetector:
    BUILTIN_AST_SINK = ["response.getWriter().print"]
    BUILTIN_REGEX_PATTERNS = [r"response\.getWriter\(\)\.print\s*\(.*?\)"]

    def __init__(self):
        self.ast_mode = False
        self.ast_sink = self.BUILTIN_AST_SINK
        self.regex_patterns = self.BUILTIN_REGEX_PATTERNS

    def detect(self, file_object):
        pass

    def detect_ast_from_tree(self, file_object, ast_tree):
        pass