import typer
from src.commands import *
from src.lib.welcome import display_welcome

app = typer.Typer()

@app.callback()
def callback(ctx):
    display_welcome(app)

app.add_typer(daily.app)
app.add_typer(edit.app)
app.add_typer(list_problems.app)
app.add_typer(login.app)
app.add_typer(profile.app)
app.add_typer(show.app)
app.add_typer(solution.app)
app.add_typer(submit.app)
app.add_typer(test.app)

def main():
    app()

if __name__ == "__main__":
    main()