def show(problem, save, compact):
    pass

def _save_problem_to_file(question_data):
    pass