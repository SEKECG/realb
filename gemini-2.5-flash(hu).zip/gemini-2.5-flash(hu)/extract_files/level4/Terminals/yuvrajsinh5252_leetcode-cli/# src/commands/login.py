def login():
    pass

def logout():
    pass