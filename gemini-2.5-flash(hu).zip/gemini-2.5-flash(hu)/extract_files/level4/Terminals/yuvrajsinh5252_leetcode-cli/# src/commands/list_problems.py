status_map = {}

def list_problems(difficulty, status, tag, category_slug):
    pass