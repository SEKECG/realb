def edit(problem, lang, editor):
    pass