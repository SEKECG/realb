def submit(problem, file, lang, force):
    pass