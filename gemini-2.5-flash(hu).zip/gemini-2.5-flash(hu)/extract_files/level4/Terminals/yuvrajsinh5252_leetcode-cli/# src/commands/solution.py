def solutions(problem, best):
    pass