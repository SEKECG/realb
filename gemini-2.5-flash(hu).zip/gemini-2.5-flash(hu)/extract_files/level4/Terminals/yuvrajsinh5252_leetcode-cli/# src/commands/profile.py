def profile():
    pass