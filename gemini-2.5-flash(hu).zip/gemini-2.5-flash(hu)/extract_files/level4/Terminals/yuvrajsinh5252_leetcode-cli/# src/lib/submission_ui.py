console = None

def create_submission_progress():
    pass

def display_auth_error():
    pass

def display_exception_error(e):
    pass

def display_file_not_found_error(file):
    pass

def display_language_detection_error(extension):
    pass

def display_language_detection_message(lang):
    pass

def display_problem_not_found_error(problem):
    pass

def display_submission_canceled():
    pass

def display_submission_details(problem, problem_name, lang, file):
    pass

def display_submission_results(result, is_test):
    pass

def _build_content_parts(result, status, run_success, status_style):
    pass

def _determine_status(result, is_test):
    pass

def _display_error_details(result, status, status_code):
    pass

def _display_general_error(result, run_success, status):
    pass

def _display_memory_warning(result):
    pass

def _display_output_comparison(result, status, run_success):
    pass

def _display_stdout(result):
    pass

def _format_test_case_stats(result):
    pass

def _get_status_styling(status, status_code, run_success, is_test, result):
    pass