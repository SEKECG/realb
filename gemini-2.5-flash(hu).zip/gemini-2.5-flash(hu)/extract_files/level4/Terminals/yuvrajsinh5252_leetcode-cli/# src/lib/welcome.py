console = None

def display_welcome(app):
    pass

def get_leetcode_ascii():
    pass