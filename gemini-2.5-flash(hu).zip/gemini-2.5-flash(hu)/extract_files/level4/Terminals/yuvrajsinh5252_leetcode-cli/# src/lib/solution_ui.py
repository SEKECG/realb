COLUMNS = []
COLUMN_WIDTHS = []
LEETCODE_BASE_URL = ""
MAX_TAGS = 0
STYLES = {}
console = None

class SolutionUI:
    def __init__(self, fetched_solution):
        self.COLUMNS = []
        self.COLUMN_WIDTHS = []
        self.LEETCODE_BASE_URL = ""
        self.MAX_TAGS = 0
        self.STYLES = {}
        self.solution = {}
        self.solutions = []
        self.total_solutions = 0

    def _format_author(self, author_data):
        pass

    def _format_date(self, date_str):
        pass

    def _format_number(self, number):
        pass

    def _format_reactions(self, reactions):
        pass

    def _format_tags(self, tags):
        pass

    def _open_solution_url(self, solution_node):
        pass

    def _truncate_text(self, text, max_length):
        pass

    def handle_solution_selection(self, index):
        pass

    def show_solution(self):
        pass