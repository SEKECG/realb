COLORS = {}
STYLES = {}
console = None

class ProblemDetails:
    def __init__(self, problem_data):
        self.content = ""
        self.difficulty = ""
        self.problem_number = ""
        self.similar_questions = []
        self.stats = {}
        self.title = ""
        self.topics = []

    def _create_header(self):
        pass

    def _format_markdown(self, content):
        pass

    def _format_similar_questions(self):
        pass

    def _format_stats(self):
        pass

    def _format_topics(self):
        pass

    def display_additional_info(self):
        pass

    def display_probelm(self):
        pass

    def display_stats(self):
        pass