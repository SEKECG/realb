import json
import os
from typing import Optional

class SessionManager:
    config_dir = ""
    config_file = ""

    def load_session(self):
        pass

    def __init__(self):
        self._ensure_config_dir()

    def _ensure_config_dir(self):
        pass

    def clear_session(self):
        pass

    def save_session(self, csrftoken, session_token, user_name):
        pass