import requests

class Auth:
    BASE_URL = ""
    is_authenticated = False
    session = None
    session_manager = None

    def get_session(self):
        return requests.Session()

    def __init__(self):
        self._load_saved_session()

    def _load_saved_session(self):
        pass

    def login_with_session(self, csrf_token, leetcode_session):
        pass

    def verify_csrf_token(self, csrf_token):
        pass