import requests
from src.server.config import SUBMISSION_RESULT_TIMEOUT, TEST_RESULT_TIMEOUT

class SolutionManager:
    BASE_URL = ""
    session = None

    def __init__(self, session):
        self._clean_session_cookies()

    def _clean_session_cookies(self):
        pass

    def _format_output(self, output):
        pass

    def _get_csrf_token(self):
        pass

    def _get_result_with_polling(self, submission_id, timeout, is_test):
        pass

    def _prepare_request_headers(self, title_slug, csrf_token):
        pass

    def _prepare_solution(self, title_slug, code, lang):
        pass

    def _resolve_question_slug(self, question_identifier):
        pass

    def get_problem_solutions(self, question_identifier, best):
        pass

    def get_question_data(self, question_identifier):
        pass

    def submit_solution(self, title_slug, code, lang):
        pass

    def test_solution(self, title_slug, code, lang, full):
        pass