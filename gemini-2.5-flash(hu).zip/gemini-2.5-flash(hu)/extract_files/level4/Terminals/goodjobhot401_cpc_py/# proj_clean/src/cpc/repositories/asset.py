import sqlite3
from src.cpc.database.dml.asset import ASSET_SQL
from src.cpc.middlewares.db_connect import db_connection

class ASSET_REPOSITORIES:
    def __init__(self, conn):
        self.conn = conn
        self.cursor = conn.cursor()
        self.asset_sql = ASSET_SQL()

    @db_connection
    def add_asset(self, conn, user_id, symbol_list):
        for symbol, amount in symbol_list.items():
            self.cursor.execute(self.asset_sql.add_asset_sql(), (user_id, symbol, amount))

    @db_connection
    def remove_asset(self, conn, user_id, symbol_list):
        for symbol in symbol_list:
            self.cursor.execute(self.asset_sql.remove_asset_sql(), (user_id, symbol))

    @db_connection
    def update_asset(self, conn, user_id, symbol_list):
        for symbol, amount in symbol_list.items():
            self.cursor.execute(self.asset_sql.update_asset_sql(), (amount, user_id, symbol))