class ASSET_SQL:
    def add_asset_sql(self):
        pass

    def remove_asset_sql(self):
        pass

    def update_asset_sql(self):
        pass