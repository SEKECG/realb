import sqlite3
from src.cpc.common.config import DB_PATH
from src.cpc.database.dml.init import init

def db_connection(func):
    def wrapper(*args, **kwargs):
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        try:
            init_tables(conn)
            result = func(conn, *args, **kwargs)
            conn.commit()
            return result
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()
    return wrapper

def init_tables(conn):
    cursor = conn.cursor()
    cursor.execute(init.USER_TABLE_SQL)
    cursor.execute(init.FAVORITE_TABLE_SQL)
    cursor.execute(init.ASSET_TABLE_SQL)
    conn.commit()