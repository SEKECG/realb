import requests
import hmac
import hashlib
import time
from src.cpc.common.config import MEXC_HOST

class TOOL:
    def __init__(self, api_key, secret_key):
        self.api_key = api_key
        self.secret_key = secret_key
        self.headers = {'Content-Type': 'application/json'}

    def _get_server_time(self):
        url = f"{MEXC_HOST}/api/v3/time"
        response = requests.get(url)
        return response.json()['serverTime']

    def _sign_v3(self, req_time, sign_params):
        query_string = '&'.join([f"{k}={v}" for k, v in sorted(sign_params.items())])
        message = f"{req_time}{query_string}"
        signature = hmac.new(self.secret_key.encode(), message.encode(), hashlib.sha256).hexdigest()
        return signature

    def public_request(self, method, url, params):
        response = requests.request(method, url, params=params)
        return response.json()

    def sign_request(self, method, url, params):
        req_time = str(int(time.time() * 1000))
        sign_params = {'api_key': self.api_key, 'req_time': req_time, **params}
        sign_params['signature'] = self._sign_v3(req_time, sign_params)
        response = requests.request(method, url, params=sign_params, headers=self.headers)
        return response.json()


class mexc_market:
    def __init__(self):
        self.api = TOOL("", "") # Replace with actual API key and secret
        self.hosts = {"spot": "https://www.mexc.com"}
        self.method = "GET"

    def get_24hr_ticker(self, params):
        url = f"{self.hosts['spot']}/open/api/v2/market/ticker/24hr"
        return self.api.public_request(self.method, url, params)

    def get_ETF_info(self, params):
        url = f"{self.hosts['spot']}/open/api/v2/market/etf"
        return self.api.public_request(self.method, url, params)

    def get_aggtrades(self, params):
        url = f"{self.hosts['spot']}/open/api/v2/market/aggTrades"
        return self.api.public_request(self.method, url, params)

    def get_avgprice(self, params):
        url = f"{self.hosts['spot']}/open/api/v2/market/avgPrice"
        return self.api.public_request(self.method, url, params)

    def get_bookticker(self, params):
        url = f"{self.hosts['spot']}/open/api/v2/market/depth"
        return self.api.public_request(self.method, url, params)

    def get_deals(self, params):
        url = f"{self.hosts['spot']}/open/api/v2/market/deals"
        return self.api.public_request(self.method, url, params)

    def get_defaultSymbols(self):
        url = f"{self.hosts['spot']}/open/api/v2/market/symbols"
        return self.api.public_request(self.method, url, {})

    def get_depth(self, params):
        url = f"{self.hosts['spot']}/open/api/v2/market/depth"
        return self.api.public_request(self.method, url, params)

    def get_exchangeInfo(self, params):
        url = f"{self.hosts['spot']}/open/api/v2/market/exchangeInfo"
        return self.api.public_request(self.method, url, params)

    def get_kline(self, params):
        url = f"{self.hosts['spot']}/open/api/v2/market/kline"
        return self.api.public_request(self.method, url, params)

    def get_ping(self):
        url = f"{self.hosts['spot']}/open/api/v2/market/ping"
        return self.api.public_request(self.method, url, {})

    def get_price(self, params):
        url = f"{self.hosts['spot']}/open/api/v2/market/ticker/price"
        return self.api.public_request(self.method, url, params)

    def get_timestamp(self):
        url = f"{self.hosts['spot']}/open/api/v2/market/time"
        return self.api.public_request(self.method, url, {})