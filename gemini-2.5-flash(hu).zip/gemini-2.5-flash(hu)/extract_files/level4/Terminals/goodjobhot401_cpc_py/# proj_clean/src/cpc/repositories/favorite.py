import sqlite3
from src.cpc.database.dml.favorite import FAVORITE_SQL
from src.cpc.middlewares.db_connect import db_connection

class FAVORITE_REPOSITORIES:
    def __init__(self, conn):
        self.conn = conn
        self.cursor = conn.cursor()
        self.favorite_sql = FAVORITE_SQL()

    @db_connection
    def add_favorite(self, conn, user_id, symbol_list):
        for symbol in symbol_list:
            self.cursor.execute(self.favorite_sql.add_favorite_sql(), (user_id, symbol))

    @db_connection
    def remove_favorite(self, conn, user_id, symbol_list):
        for symbol in symbol_list:
            self.cursor.execute(self.favorite_sql.remove_favorite_sql(), (user_id, symbol))