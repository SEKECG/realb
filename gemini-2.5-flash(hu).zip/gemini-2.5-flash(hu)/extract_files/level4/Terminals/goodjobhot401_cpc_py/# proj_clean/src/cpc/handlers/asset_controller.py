from src.cpc.services.asset import ASSET_SERVICE

class ASSET:
    def __init__(self, conn):
        self.asset_service = ASSET_SERVICE(conn)

    def add_asset(self, asset_list):
        try:
            self.asset_service.add_asset(asset_list)
        except Exception as e:
            print(f"Error adding asset: {e}")

    def update_asset(self, asset_list):
        try:
            self.asset_service.update_asset(asset_list)
        except Exception as e:
            print(f"Error updating asset: {e}")

    def remove_asset(self, asset_list):
        try:
            self.asset_service.remove_asset(asset_list)
        except Exception as e:
            print(f"Error removing asset: {e}")