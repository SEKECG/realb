class FAVORITE_SQL:
    def add_favorite_sql(self):
        pass

    def remove_favorite_sql(self):
        pass