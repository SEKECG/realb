import argparse
from src.cpc.middlewares.db_connect import db_connection
from src.cpc.handlers.user_controller import USER
from src.cpc.handlers.asset_controller import ASSET
from src.cpc.handlers.favorite_controller import FAVORITE
from src.cpc.handlers.symbol_controller import SYMBOL
from src.cpc.handlers.price_controller import PRICE
from src.cpc.handlers.kline_controller import KLINE
import sqlite3

def main():
    parser = argparse.ArgumentParser(description="Cryptocurrency Portfolio Tracker")
    subparsers = parser.add_subparsers(dest='command')

    # User commands
    user_parser = subparsers.add_parser('user', help='Manage user profiles')
    user_parser.add_argument('action', choices=['create', 'switch', 'update', 'remove', 'show', 'list'])
    user_parser.add_argument('name', nargs='?', help='User name')
    user_parser.add_argument('user_id', nargs='?', type=int, help='User ID')

    # Asset commands
    asset_parser = subparsers.add_parser('asset', help='Manage cryptocurrency holdings')
    asset_parser.add_argument('action', choices=['add', 'update', 'remove'])
    asset_parser.add_argument('asset_list', nargs='+', help='Asset list (symbol amount)')

    # Favorite commands
    favorite_parser = subparsers.add_parser('favorite', help='Manage watchlist')
    favorite_parser.add_argument('action', choices=['add', 'remove'])
    favorite_parser.add_argument('favorite_list', nargs='+', help='Favorite list')

    # Symbol commands
    symbol_parser = subparsers.add_parser('symbols', help='List/filter available trading pairs')
    symbol_parser.add_argument('query', nargs='?', help='Filter query')

    # Price commands
    price_parser = subparsers.add_parser('price', help='Get price details for specified pairs')
    price_parser.add_argument('symbols', nargs='+', help='Symbols')

    # Kline commands
    kline_parser = subparsers.add_parser('kline', help='Display candlestick charts')
    kline_parser.add_argument('symbol', help='Symbol')
    kline_parser.add_argument('--interval', default='1h', help='Interval')
    kline_parser.add_argument('--limit', type=int, default=30, help='Limit')

    args = parser.parse_args()

    @db_connection
    def run(conn):
        user_handler = USER(conn)
        asset_handler = ASSET(conn)
        favorite_handler = FAVORITE(conn)
        symbol_handler = SYMBOL()
        price_handler = PRICE()
        kline_handler = KLINE()

        if args.command == 'user':
            if args.action == 'create':
                user_handler.create_user(args.name)
            elif args.action == 'switch':
                user_handler.switch_user(args.user_id)
            elif args.action == 'update':
                user_handler.update_user(args.user_id, args.name)
            elif args.action == 'remove':
                user_handler.remove_user(args.user_id)
            elif args.action == 'show':
                user_handler.get_user(True)
            elif args.action == 'list':
                user_handler.get_users()

        elif args.command == 'asset':
            if args.action == 'add':
                asset_list = dict(item.split('=') for item in args.asset_list)
                asset_handler.add_asset(asset_list)
            elif args.action == 'update':
                asset_list = dict(item.split('=') for item in args.asset_list)
                asset_handler.update_asset(asset_list)
            elif args.action == 'remove':
                asset_handler.remove_asset(args.asset_list)

        elif args.command == 'favorite':
            if args.action == 'add':
                favorite_handler.add_favorite(args.favorite_list)
            elif args.action == 'remove':
                favorite_handler.remove_favorite(args.favorite_list)

        elif args.command == 'symbols':
            symbol_handler.filter_symbols(args.query)

        elif args.command == 'price':
            price_handler.get_price_detail(args.symbols)

        elif args.command == 'kline':
            kline_handler.get_kline(args.symbol, args.interval, args.limit)

    run(sqlite3.connect('')) # Replace '' with actual db path


if __name__ == "__main__":
    main()