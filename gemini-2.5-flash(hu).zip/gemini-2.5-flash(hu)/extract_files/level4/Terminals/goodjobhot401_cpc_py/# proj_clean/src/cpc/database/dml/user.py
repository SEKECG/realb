class USER_SQL:
    def auto_choose_user(self):
        pass

    def create_user(self):
        pass

    def get_asset_sql(self):
        pass

    def get_favorite_sql(self):
        pass

    def get_user(self):
        pass

    def get_users(self):
        pass

    def is_taget_sql(self):
        pass

    def remove_all_target(self):
        pass

    def remove_asset_sql(self):
        pass

    def remove_favorite_sql(self):
        pass

    def remove_user_sql(self):
        pass

    def switch_target_user(self):
        pass

    def update_user(self, fields):
        pass