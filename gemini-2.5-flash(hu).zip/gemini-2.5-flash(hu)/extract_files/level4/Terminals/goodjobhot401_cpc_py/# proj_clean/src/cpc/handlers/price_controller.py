from src.cpc.services.price import PRICE_SERVICE

class PRICE:
    def __init__(self):
        self.price_service = PRICE_SERVICE()

    def get_price_detail(self, symbols):
        try:
            self.price_service.get_price_detail(symbols)
        except Exception as e:
            print(f"Error getting price detail: {e}")