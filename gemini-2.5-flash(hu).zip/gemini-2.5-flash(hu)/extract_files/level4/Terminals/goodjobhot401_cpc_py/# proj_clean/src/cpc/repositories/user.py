import sqlite3
from src.cpc.database.dml.user import USER_SQL
from src.cpc.middlewares.db_connect import db_connection

class USER_REPOSITORIES:
    def __init__(self, conn):
        self.conn = conn
        self.cursor = conn.cursor()
        self.user_sql = USER_SQL()

    @db_connection
    def create_default_user(self, conn):
        self.cursor.execute(self.user_sql.create_user(), ("default", 1))
        return self.cursor.lastrowid

    @db_connection
    def _auto_choose_user(self, conn):
        self.cursor.execute(self.user_sql.auto_choose_user())

    @db_connection
    def _auto_switch_user(self, conn):
        self._remove_all_target(conn)
        self._auto_choose_user(conn)

    @db_connection
    def _is_user_target(self, conn):
        self.cursor.execute(self.user_sql.is_taget_sql())
        return len(self.cursor.fetchall()) == 1

    @db_connection
    def _remove_all_target(self, conn):
        self.cursor.execute(self.user_sql.remove_all_target())

    @db_connection
    def create_user(self, conn, name, target=0):
        self.cursor.execute(self.user_sql.create_user(), (name, target))
        user_id = self.cursor.lastrowid
        if target == 1:
            self._remove_all_target(conn)
        return user_id

    @db_connection
    def get_user(self, conn):
        self.cursor.execute(self.user_sql.get_user())
        user = self.cursor.fetchone()
        if user:
            return dict(user)
        return None

    @db_connection
    def get_users(self, conn):
        self.cursor.execute(self.user_sql.get_users())
        users = self.cursor.fetchall()
        if users:
            return [dict(user) for user in users]
        return None

    @db_connection
    def remove_user(self, conn, user_id):
        self.cursor.execute(self.user_sql.remove_user(), (user_id,))
        if not self._is_user_target(conn):
            self._auto_switch_user(conn)

    @db_connection
    def switch_user(self, conn, user_id):
        if user_id:
            self.cursor.execute(self.user_sql.switch_target_user(), (user_id,))
        else:
            self._auto_switch_user(conn)

    @db_connection
    def update_user(self, conn, user_id, name):
        if name:
            self.cursor.execute(self.user_sql.update_user(), (name, user_id))