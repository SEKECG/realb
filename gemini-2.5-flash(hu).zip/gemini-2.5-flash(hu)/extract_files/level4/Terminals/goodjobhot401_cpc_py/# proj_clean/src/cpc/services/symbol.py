from src.cpc.helpers.mexc import mexc_market
from rich.console import Console
from rich.table import Table

class SYMBOL_SERVICE:
    def __init__(self):
        self.mexc_market = mexc_market()
        self.console = Console()

    def filter_symbols(self, query):
        symbols = self.mexc_market.get_defaultSymbols()
        filtered_symbols = [symbol for symbol in symbols if query in symbol['symbol']]
        table = Table(title="Symbols")
        table.add_column("Symbol")
        for symbol in filtered_symbols:
            table.add_row(symbol['symbol'])
        self.console.print(table)