from src.cpc.services.user import USER_SERVICE

class USER:
    def __init__(self, conn):
        self.user_service = USER_SERVICE(conn)

    def get_user(self, print_table):
        try:
            self.user_service.get_user(print_table)
        except Exception as e:
            print(f"Error getting user: {e}")

    def get_users(self):
        try:
            self.user_service.get_users()
        except Exception as e:
            print(f"Error getting users: {e}")

    def create_user(self, name):
        try:
            self.user_service.create_user(name)
        except Exception as e:
            print(f"Error creating user: {e}")

    def switch_user(self, user_id):
        try:
            self.user_service.switch_user(user_id)
        except Exception as e:
            print(f"Error switching user: {e}")

    def update_user(self, user_id, name):
        try:
            self.user_service.update_user(user_id, name)
        except Exception as e:
            print(f"Error updating user: {e}")

    def remove_user(self, user_id):
        try:
            self.user_service.remove_user(user_id)
        except Exception as e:
            print(f"Error removing user: {e}")

    def get_position_ratio(self, sort, reverse):
        try:
            self.user_service.get_position_ratio(sort, reverse)
        except Exception as e:
            print(f"Error getting position ratio: {e}")

    def create_default_user(self):
        try:
            self.user_service.create_default_user()
        except Exception as e:
            print(f"Error creating default user: {e}")