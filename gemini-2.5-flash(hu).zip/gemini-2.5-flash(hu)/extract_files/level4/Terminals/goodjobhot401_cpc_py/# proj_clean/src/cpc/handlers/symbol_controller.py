from src.cpc.services.symbol import SYMBOL_SERVICE

class SYMBOL:
    def __init__(self):
        self.symbol_service = SYMBOL_SERVICE()

    def filter_symbols(self, query):
        try:
            self.symbol_service.filter_symbols(query)
        except Exception as e:
            print(f"Error filtering symbols: {e}")