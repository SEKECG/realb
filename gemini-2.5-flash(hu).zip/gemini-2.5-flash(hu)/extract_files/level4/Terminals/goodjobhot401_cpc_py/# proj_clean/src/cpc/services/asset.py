from src.cpc.repositories.asset import ASSET_REPOSITORIES
from src.cpc.repositories.user import USER_REPOSITORIES

class ASSET_SERVICE:
    def __init__(self, conn):
        self.asset_repository = ASSET_REPOSITORIES(conn)
        self.user_repository = USER_REPOSITORIES(conn)

    def add_asset(self, asset_list):
        user_id = self.user_repository.get_user()['id']
        self.asset_repository.add_asset(user_id, asset_list)

    def remove_asset(self, asset_list):
        user_id = self.user_repository.get_user()['id']
        self.asset_repository.remove_asset(user_id, asset_list)

    def update_asset(self, asset_list):
        user_id = self.user_repository.get_user()['id']
        self.asset_repository.update_asset(user_id, asset_list)