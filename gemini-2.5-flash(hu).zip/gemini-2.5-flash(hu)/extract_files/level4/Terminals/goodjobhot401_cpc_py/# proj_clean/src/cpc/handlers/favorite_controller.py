from src.cpc.services.favorite import FAVORITE_SERVICE

class FAVORITE:
    def __init__(self, conn):
        self.favorite_service = FAVORITE_SERVICE(conn)

    def add_favorite(self, favorite_list):
        try:
            self.favorite_service.add_favorite(favorite_list)
        except Exception as e:
            print(f"Error adding favorite: {e}")

    def remove_favorite(self, favorite_list):
        try:
            self.favorite_service.remove_favorite(favorite_list)
        except Exception as e:
            print(f"Error removing favorite: {e}")