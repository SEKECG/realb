from src.cpc.services.kline import KLINE_SERVICE

class KLINE:
    def __init__(self):
        self.kline_service = KLINE_SERVICE()

    def get_kline(self, symbol, interval, limit):
        try:
            self.kline_service.get_kline(symbol, interval, limit)
        except Exception as e:
            print(f"Error getting kline: {e}")