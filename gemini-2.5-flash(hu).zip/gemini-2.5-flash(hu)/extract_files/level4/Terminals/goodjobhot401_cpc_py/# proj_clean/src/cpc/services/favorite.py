from src.cpc.repositories.favorite import FAVORITE_REPOSITORIES
from src.cpc.repositories.user import USER_REPOSITORIES

class FAVORITE_SERVICE:
    def __init__(self, conn):
        self.favorite_repository = FAVORITE_REPOSITORIES(conn)
        self.user_repository = USER_REPOSITORIES(conn)

    def add_favorite(self, favorite_list):
        user_id = self.user_repository.get_user()['id']
        self.favorite_repository.add_favorite(user_id, favorite_list)

    def remove_favorite(self, favorite_list):
        user_id = self.user_repository.get_user()['id']
        self.favorite_repository.remove_favorite(user_id, favorite_list)