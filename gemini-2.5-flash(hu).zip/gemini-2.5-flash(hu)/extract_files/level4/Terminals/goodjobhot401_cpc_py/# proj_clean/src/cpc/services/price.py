from src.cpc.helpers.mexc import mexc_market
from src.cpc.common.const import PRICE_DETAIL_ROW_MAP
from rich.console import Console
from rich.table import Table

class PRICE_SERVICE:
    def __init__(self):
        self.mexc_market = mexc_market()
        self.console = Console()

    def get_price_detail(self, symbols):
        params = {'symbols': ','.join(symbols)}
        price_data = self.mexc_market.get_24hr_ticker(params)
        table = Table(title="Price Details")
        for key in PRICE_DETAIL_ROW_MAP:
            table.add_column(key)
        for item in price_data:
            row = [item[key] for key in PRICE_DETAIL_ROW_MAP]
            table.add_row(*row)
        self.console.print(table)