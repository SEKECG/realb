import plotext as plt
from src.cpc.helpers.mexc import mexc_market

class KLINE_SERVICE:
    def __init__(self):
        self.mexc_market = mexc_market()

    def _plot_candlesticks(self, klines_data, symbol, interval, test):
        plt.candlesticks(klines_data, markersize=2)
        plt.title(f"{symbol} {interval}")
        plt.xlabel("Time")
        plt.ylabel("Price")
        if test:
            plt.show()
        else:
            plt.show()

    def get_kline(self, symbol, interval, limit, test=False):
        params = {'symbol': symbol, 'interval': interval, 'limit': limit}
        klines_data = self.mexc_market.get_kline(params)
        self._plot_candlesticks(klines_data, symbol, interval, test)