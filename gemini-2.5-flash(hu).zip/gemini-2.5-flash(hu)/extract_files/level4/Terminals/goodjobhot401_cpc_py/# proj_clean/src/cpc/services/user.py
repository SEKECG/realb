from src.cpc.repositories.user import USER_REPOSITORIES
from src.cpc.repositories.asset import ASSET_REPOSITORIES
from src.cpc.repositories.favorite import FAVORITE_REPOSITORIES
from rich.console import Console
from rich.table import Table

class USER_SERVICE:
    def __init__(self, conn):
        self.repository = USER_REPOSITORIES(conn)
        self.asset_repository = ASSET_REPOSITORIES(conn)
        self.favorite_repository = FAVORITE_REPOSITORIES(conn)
        self.console = Console()

    def create_default_user(self):
        self.repository.create_default_user()

    def create_user(self, name):
        self.repository.create_user(name, 1)

    def get_position_ratio(self, sort, reverse, pie=False):
        user_data = self.repository.get_user()
        if user_data:
            assets = self.asset_repository.get_assets(user_data['id'])
            #Implementation for position ratio calculation and display

    def get_user(self, print_table):
        user_data = self.repository.get_user()
        if print_table:
            #Implementation for printing user data in a table
        else:
            return user_data

    def get_users(self):
        users = self.repository.get_users()
        if users:
            table = Table(title="Users")
            table.add_column("ID")
            table.add_column("Name")
            table.add_column("Target")
            for user in users:
                table.add_row(str(user['id']), user['name'], str(user['target']))
            self.console.print(table)

    def remove_user(self, user_id):
        self.repository.remove_user(user_id)

    def switch_user(self, user_id):
        self.repository.switch_user(user_id)

    def update_user(self, user_id, name):
        self.repository.update_user(user_id, name)