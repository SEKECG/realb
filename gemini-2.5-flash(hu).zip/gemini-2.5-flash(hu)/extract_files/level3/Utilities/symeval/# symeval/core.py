import re
from sympy import sympify, Matrix, Interval, FiniteSet, Union, Intersection, Complement
from pebble import ProcessPool
from tqdm import tqdm
from typing import List, Any, Optional, Tuple, Dict


BASIC_FN_NAMES = ["sin", "cos", "tan", "arcsin", "arccos", "arctan", "sinh", "cosh", "tanh", "exp", "log", "ln", "sqrt"]
DATETIME_FMTS = ["%Y-%m-%d", "%Y/%m/%d", "%m/%d/%Y", "%m-%d-%Y", "%Y-%m-%d %H:%M:%S", "%Y/%m/%d %H:%M:%S", "%m/%d/%Y %H:%M:%S", "%m-%d-%Y %H:%M:%S"]
DEF_ABS_TOL = 1e-6
DEF_N_PROC = 2
DEF_PERCENT_REL_TOL = 1e-2
DEF_REL_TOL = 1e-6
DEF_TIMEOUT = 5
GSM8K_ANS_PREFIX = ""
LATEX_CMDS = ["begin", "end", "frac", "sqrt", "left", "right", "sum", "int", "lim"]
LATEX_FMT_ENVS = ["align", "equation", "gather"]
LATEX_LIST_ENVS = ["itemize", "enumerate"]
NDAYS_PER_WEEK = 7
NO_PRECEDING_PUNCS = [".", ",", ";", "!", "?", ":", ";"]
NO_TRAILING_STRS = ["=", ",", ";", "!", "?", ":", ";", "."]
PAREN_MAP = {"(": ")", "[": "]", "{": "}"}
PRM800K_ANS_PRRFIX = ""
SIMPLE_REPLACE_MAP = {}
SIMPLE_RM_STRS = ["\\text", "\\displaystyle", "\\left", "\\right"]
STR2NUM = {}
STRIP_STRS = [" ", "\n", "\t", "\r"]
T_Counter = Any
T_Dict = Dict
T_Tuple = Tuple
T_Union = Any
UNITS = ["m", "cm", "km", "s", "ms", "h", "kg", "g", "t", "N", "Pa", "J", "W"]
WEEKDAY_ABBRS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
WEEKDAY_FULLS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
regex = re


def batch_exec(func, kwargs_list, n_procs=DEF_N_PROC, timeout=DEF_TIMEOUT, use_tqdm=True, desc="", def_val=None, max_tasks_per_proc=None):
    with ProcessPool(max_workers=n_procs, max_tasks=max_tasks_per_proc) as pool:
        future = pool.map(func, kwargs_list, timeout=timeout)
        if use_tqdm:
            iterator = tqdm(future.result(), total=len(kwargs_list), desc=desc)
        else:
            iterator = future.result()
        results = [x.result() for x in iterator]
    return results


def extract_boxed(resp):
    # Implementation for extract_boxed
    pass


def fix_a_slash_b(s):
    # Implementation for fix_a_slash_b
    pass


def fix_fracs(s):
    # Implementation for fix_fracs
    pass


def fix_sqrt(s):
    # Implementation for fix_sqrt
    pass


def has_non_ascii(s):
    # Implementation for has_non_ascii
    pass


def is_querying4set(query):
    # Implementation for is_querying4set
    pass


def is_set(s):
    # Implementation for is_set
    pass


def latex2sympy_fix(s):
    # Implementation for latex2sympy_fix
    pass


def latex2sympy_interval(s):
    # Implementation for latex2sympy_interval
    pass


def norm_deg(s):
    # Implementation for norm_deg
    pass


def norm_str2bool(s):
    # Implementation for norm_str2bool
    pass


def norm_str2weekday(s):
    # Implementation for norm_str2weekday
    pass


def parse(parser, s_to_parse, parse_errs):
    # Implementation for parse
    pass


def rm_latex_env(s, env):
    # Implementation for rm_latex_env
    pass


def run_with_timeout(func, kwargs, timeout):
    # Implementation for run_with_timeout
    pass


def task_wrapper(func, kwargs):
    return func(**kwargs)


class EvaluatorBase:
    def __init__(self, ans_extract_mode="boxed"):
        self.ans_extract_mode = ans_extract_mode

    def clean(self, ans):
        # Implementation for clean
        pass

    def clean_preceding(self, s):
        # Implementation for clean_preceding
        pass

    def clean_trailing(self, s):
        # Implementation for clean_trailing
        pass

    def eq(self, ref_ans, pred):
        # Implementation for eq
        pass

    def extract_ans(self, resp_str):
        # Implementation for extract_ans
        pass

    def extract_explicit_ans(self, resp_str):
        # Implementation for extract_explicit_ans
        pass

    def get_maj_ans_from_votes(self, ans_vote):
        # Implementation for get_maj_ans_from_votes
        pass

    def get_maj_answers(self, answers):
        # Implementation for get_maj_answers
        pass


class EvaluatorMath(EvaluatorBase):
    def __init__(self, ans_extract_mode="boxed", include_percentage=True, rel_tol=DEF_REL_TOL, abs_tol=DEF_ABS_TOL, percent_rel_tol=DEF_PERCENT_REL_TOL, ascii_only=True):
        super().__init__(ans_extract_mode)
        self.include_percentage = include_percentage
        self.rel_tol = rel_tol
        self.abs_tol = abs_tol
        self.percent_rel_tol = percent_rel_tol
        self.ascii_only = ascii_only

    def could_be_percent(self, v):
        # Implementation for could_be_percent
        pass

    def eq(self, ref_ans, pred, compare_sets=False):
        # Implementation for eq
        pass

    def extract_ans(self, resp_str):
        # Implementation for extract_ans
        pass

    def extract_set(self, norm_s):
        # Implementation for extract_set
        pass

    def index_first_paren_pair(self, s, l):
        # Implementation for index_first_paren_pair
        pass

    def is_num_eq(self, ref_num, pred_num):
        # Implementation for is_num_eq
        pass

    def is_sym_eq(self, a, b):
        # Implementation for is_sym_eq
        pass

    def latex2matrix(self, latex_mat_str):
        # Implementation for latex2matrix
        pass

    def norm_ans_str(self, ans):
        # Implementation for norm_ans_str
        pass

    def norm_basic_fn(self, s):
        # Implementation for norm_basic_fn
        pass

    def norm_math_str(self, string):
        # Implementation for norm_math_str
        pass

    def norm_pm(self, s):
        # Implementation for norm_pm
        pass

    def norm_str2date_time(self, string):
        # Implementation for norm_str2date_time
        pass

    def remove_first_paren_pair(self, s, l):
        # Implementation for remove_first_paren_pair
        pass

    def remove_latex_cmd(self, s, cmd):
        # Implementation for remove_latex_cmd
        pass

    def remove_out_paren(self, s):
        # Implementation for remove_out_paren
        pass



class EvaluatorMathBatch(EvaluatorMath):
    def __init__(self, ans_extract_mode="boxed", include_percentage=True, rel_tol=DEF_REL_TOL, abs_tol=DEF_ABS_TOL, percent_rel_tol=DEF_PERCENT_REL_TOL, ascii_only=True, timeout=DEF_TIMEOUT, n_procs=DEF_N_PROC, use_tqdm=True):
        super().__init__(ans_extract_mode, include_percentage, rel_tol, abs_tol, percent_rel_tol, ascii_only)
        self.timeout = timeout
        self.n_procs = n_procs
        self.use_tqdm = use_tqdm

    def batch_eq(self, ref_answers, pred_answers, problems):
        # Implementation for batch_eq
        pass

    def batch_eval(self, ref_answers, resps, problems):
        # Implementation for batch_eval
        pass

    def batch_extract_ans(self, resps):
        # Implementation for batch_extract_ans
        pass

    def batch_get_eq_map(self, ref_answers, pred_answers, querying4set_flags):
        # Implementation for batch_get_eq_map
        pass

    def batch_get_maj_answers(self, answers_list, problems):
        # Implementation for batch_get_maj_answers
        pass