```python
import asyncio
import logging
from contextlib import ExitStack
from typing import Callable, Dict, List

from langchain.tools import BaseTool

McpServerCleanupFn = Callable[[], None]
McpServersConfig = Dict[str, Dict]
SingleMcpServerConfig = Dict


class McpServerCommandBasedConfig:
    pass


class McpServerUrlBasedConfig:
    pass


Transport = tuple


def fix_schema(schema):
    return schema


def init_logger():
    logger = logging.getLogger(__name__)
    if not logger.handlers:
        logger.addHandler(logging.StreamHandler())
    return logger


async def spawn_mcp_server_and_get_transport(server_name, server_config, exit_stack, logger):
    return (None, None)


async def get_mcp_server_tools(server_name, transport, exit_stack, logger):
    return []


async def convert_mcp_to_langchain_tools(server_configs, logger=None):
    if logger is None:
        logger = init_logger()
    tools = []
    async def cleanup():
        pass
    return tools, cleanup

```