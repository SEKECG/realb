import os
import json
import time

class SaveResults:
    def __init__(self, save_results_var, entry, shodan_tree, subdomain_tree, ports_tree, asn_tree, headers_tree, javascript_tree, links_tree, whois_tree):
        self.save_results_var = save_results_var
        self.entry = entry
        self.shodan_tree = shodan_tree
        self.subdomain_tree = subdomain_tree
        self.ports_tree = ports_tree
        self.asn_tree = asn_tree
        self.headers_tree = headers_tree
        self.javascript_tree = javascript_tree
        self.links_tree = links_tree
        self.whois_tree = whois_tree

    def save_scan_results(self, scan_type, results):
        if self.save_results_var.get() == "1":
            timestamp = time.strftime("%Y%m%d-%H%M%S")
            filename = f"results/{scan_type}-{timestamp}.json"
            os.makedirs(os.path.dirname(filename), exist_ok=True)
            with open(filename, "w") as f:
                json.dump(results, f, indent=4)