import customtkinter as ctk
import threading
import time
from modules.tooltip import ToolTip
from scripts.shodan_api import shodan_scan, host_info, get_api_key, get_ip_from_domain, scan_single_ip
from modules.save_results import SaveResults
import json
import requests

ctk.set_appearance_mode("dark")  # Modes: "System" (standard), "Dark", "Light"
ctk.set_default_color_theme("blue")  # Themes: "blue" (standard), "green", "dark-blue"


class ReconX:
    def __init__(self):
        self.window = ctk.CTk()
        self.window.geometry("1200x800")
        self.window.title("ReconX")

        self.is_scanning = False
        self.waiting_frames = ["/", "-", "\\", "|"]
        self.current_frame = 0

        self.logo_image = ctk.CTkImage(light_image=None, dark_image=None)
        self.home_image = ctk.CTkImage(light_image=None, dark_image=None)
        self.subdomains_image = ctk.CTkImage(light_image=None, dark_image=None)
        self.ports_image = ctk.CTkImage(light_image=None, dark_image=None)
        self.asn_image = ctk.CTkImage(light_image=None, dark_image=None)
        self.headers_image = ctk.CTkImage(light_image=None, dark_image=None)
        self.javascript_image = ctk.CTkImage(light_image=None, dark_image=None)
        self.links_image = ctk.CTkImage(light_image=None, dark_image=None)
        self.whois_image = ctk.CTkImage(light_image=None, dark_image=None)
        self.shodan_image = ctk.CTkImage(light_image=None, dark_image=None)
        self.start_image = ctk.CTkImage(light_image=None, dark_image=None)
        self.stop_image = ctk.CTkImage(light_image=None, dark_image=None)
        self.clear_image = ctk.CTkImage(light_image=None, dark_image=None)
        self.settings_image = ctk.CTkImage(light_image=None, dark_image=None)

        self.frame = ctk.CTkFrame(master=self.window)
        self.frame_top = ctk.CTkFrame(master=self.frame)
        self.menu_frame = ctk.CTkFrame(master=self.frame)
        self.status_frame = ctk.CTkFrame(master=self.frame)
        self.thread_settings_frame = ctk.CTkFrame(master=self.menu_frame)
        self.proxy_controls_frame = ctk.CTkFrame(master=self.menu_frame)
        self.shodan_controls_frame = ctk.CTkFrame(master=self.menu_frame)
        self.ua_controls_frame = ctk.CTkFrame(master=self.menu_frame)
        self.start_port_frame = ctk.CTkFrame(master=self.menu_frame)

        self.entry = ctk.CTkEntry(master=self.frame_top)
        self.shodan_entry = ctk.CTkEntry(master=self.shodan_controls_frame)
        self.proxy_entry = ctk.CTkEntry(master=self.proxy_controls_frame)
        self.ua_entry = ctk.CTkEntry(master=self.ua_controls_frame)
        self.startport_entry = ctk.CTkEntry(master=self.start_port_frame)
        self.endport_entry = ctk.CTkEntry(master=self.start_port_frame)
        self.thread_entry = ctk.CTkEntry(master=self.thread_settings_frame)

        self.home_label = ctk.CTkLabel(master=self.frame_top, text="Enter Domain/IP")
        self.threads_label = ctk.CTkLabel(master=self.thread_settings_frame, text="Threads")
        self.proxy_label = ctk.CTkLabel(master=self.proxy_controls_frame, text="Proxy")
        self.user_agent_label = ctk.CTkLabel(master=self.ua_controls_frame, text="User-Agent")

        self.button = ctk.CTkButton(master=self.frame_top, text="Start Scan", command=self.start_scan)
        self.stop_button = ctk.CTkButton(master=self.frame_top, text="Stop Scan", command=self.stop_scan)
        self.clear_button = ctk.CTkButton(master=self.frame_top, text="Clear Results", command=self.clear_textbox)
        self.home_button = ctk.CTkButton(master=self.menu_frame, text="Home", command=lambda: self.switch_tab("Home"))
        self.subdomains_button = ctk.CTkButton(master=self.menu_frame, text="Subdomains", command=lambda: self.switch_tab("Subdomains"))
        self.ports_button = ctk.CTkButton(master=self.menu_frame, text="Ports", command=lambda: self.switch_tab("Ports"))
        self.asn_button = ctk.CTkButton(master=self.menu_frame, text="ASN", command=self.asn_thread)
        self.headers_button = ctk.CTkButton(master=self.menu_frame, text="Headers", command=self.headers_thread)
        self.javascript_button = ctk.CTkButton(master=self.menu_frame, text="Javascript", command=self.javascript_thread)
        self.links_button = ctk.CTkButton(master=self.menu_frame, text="Links", command=self.links_thread)
        self.whois_button = ctk.CTkButton(master=self.menu_frame, text="WHOIS", command=self.whois_thread)
        self.shodan_button = ctk.CTkButton(master=self.menu_frame, text="Shodan", command=self.shodan_thread)
        self.settings_button = ctk.CTkButton(master=self.menu_frame, text="Settings")

        self.progress_bar = ctk.CTkProgressBar(master=self.status_frame)
        self.progress_label = ctk.CTkLabel(master=self.status_frame, text="Status: Idle")

        self.tabview = ctk.CTkTabview(master=self.frame)
        self.port_services_tabview = ctk.CTkTabview(master=self.frame)

        self.subdomain_tree = ctk.CTkTreeview(master=self.tabview, show="headings")
        self.ports_tree = ctk.CTkTreeview(master=self.port_services_tabview, show="headings")
        self.services_tree = ctk.CTkTreeview(master=self.port_services_tabview, show="headings")
        self.asn_tree = ctk.CTkTreeview(master=self.tabview, show="headings")
        self.headers_tree = ctk.CTkTreeview(master=self.tabview, show="headings")
        self.javascript_tree = ctk.CTkTreeview(master=self.tabview, show="headings")
        self.links_tree = ctk.CTkTreeview(master=self.tabview, show="headings")
        self.whois_tree = ctk.CTkTreeview(master=self.tabview, show="headings")
        self.shodan_tree = ctk.CTkTreeview(master=self.tabview, show="headings")

        self.subdomain_scrollbar = ctk.CTkScrollbar(master=self.tabview, orientation="vertical", command=self.subdomain_tree.xview)
        self.ports_scrollbar = ctk.CTkScrollbar(master=self.port_services_tabview, orientation="vertical", command=self.ports_tree.xview)
        self.services_scrollbar = ctk.CTkScrollbar(master=self.port_services_tabview, orientation="vertical", command=self.services_tree.xview)
        self.asn_scrollbar = ctk.CTkScrollbar(master=self.tabview, orientation="vertical", command=self.asn_tree.xview)
        self.headers_scrollbar = ctk.CTkScrollbar(master=self.tabview, orientation="vertical", command=self.headers_tree.xview)
        self.javascript_scrollbar = ctk.CTkScrollbar(master=self.tabview, orientation="vertical", command=self.javascript_tree.xview)
        self.links_scrollbar = ctk.CTkScrollbar(master=self.tabview, orientation="vertical", command=self.links_tree.xview)
        self.whois_scrollbar = ctk.CTkScrollbar(master=self.tabview, orientation="vertical", command=self.whois_tree.xview)
        self.shodan_scrollbar = ctk.CTkScrollbar(master=self.tabview, orientation="vertical", command=self.shodan_tree.xview)

        self.menu = ctk.CTkMenu(self.window)
        self.window.config(menu=self.menu)

        self.save_results_var = ctk.StringVar(value="0")
        self.save_results = SaveResults(self.save_results_var, self.entry, self.shodan_tree, self.subdomain_tree, self.ports_tree, self.asn_tree, self.headers_tree, self.javascript_tree, self.links_tree, self.whois_tree)

        self.proxy_tooltip = ToolTip(self.proxy_entry, "Enter proxy in format: http://ip:port")
        self.thread_tooltip = ToolTip(self.thread_entry, "Enter number of threads")
        self.ua_tooltip = ToolTip(self.ua_entry, "Enter custom user agent")

        self.place_widgets()
        self.window.mainloop()

    def place_widgets(self):
        self.frame.pack(pady=20, padx=60, fill="both", expand=True)
        self.frame_top.pack(pady=10, padx=10, fill="x")
        self.menu_frame.pack(pady=10, padx=10, fill="x")
        self.status_frame.pack(pady=10, padx=10, fill="x")
        self.tabview.pack(pady=10, padx=10, fill="both", expand=True)
        self.port_services_tabview.pack(pady=10, padx=10, fill="both", expand=True)

        self.home_label.pack(side="left", padx=10)
        self.entry.pack(side="left", padx=10)
        self.button.pack(side="left", padx=10)
        self.stop_button.pack(side="left", padx=10)
        self.clear_button.pack(side="left", padx=10)

        self.thread_settings_frame.pack(pady=5)
        self.threads_label.pack(side="left", padx=10)
        self.thread_entry.pack(side="left", padx=10)

        self.proxy_controls_frame.pack(pady=5)
        self.proxy_label.pack(side="left", padx=10)
        self.proxy_entry.pack(side="left", padx=10)

        self.shodan_controls_frame.pack(pady=5)
        self.shodan_entry.pack(side="left", padx=10)
        self.shodan_button.pack(side="left", padx=10)

        self.ua_controls_frame.pack(pady=5)
        self.user_agent_label.pack(side="left", padx=10)
        self.ua_entry.pack(side="left", padx=10)

        self.start_port_frame.pack(pady=5)
        self.startport_entry.pack(side="left", padx=10)
        self.endport_entry.pack(side="left", padx=10)
        self.ports_button.pack(side="left", padx=10)

        self.home_button.pack(side="left", padx=10)
        self.subdomains_button.pack(side="left", padx=10)
        self.asn_button.pack(side="left", padx=10)
        self.headers_button.pack(side="left", padx=10)
        self.javascript_button.pack(side="left", padx=10)
        self.links_button.pack(side="left", padx=10)
        self.whois_button.pack(side="left", padx=10)
        self.settings_button.pack(side="left", padx=10)

        self.progress_bar.pack(side="left", padx=10)
        self.progress_label.pack(side="left", padx=10)

        self.tabview.add("Subdomains")
        self.tabview.add("ASN")
        self.tabview.add("Headers")
        self.tabview.add("Javascript")
        self.tabview.add("Links")
        self.tabview.add("WHOIS")
        self.tabview.add("Shodan")

        self.port_services_tabview.add("Ports")
        self.port_services_tabview.add("Services")

        self.subdomain_tree.pack(side="left", fill="both", expand=True)
        self.subdomain_scrollbar.pack(side="right", fill="y")
        self.ports_tree.pack(side="left", fill="both", expand=True)
        self.ports_scrollbar.pack(side="right", fill="y")
        self.services_tree.pack(side="left", fill="both", expand=True)
        self.services_scrollbar.pack(side="right", fill="y")
        self.asn_tree.pack(side="left", fill="both", expand=True)
        self.asn_scrollbar.pack(side="right", fill="y")
        self.headers_tree.pack(side="left", fill="both", expand=True)
        self.headers_scrollbar.pack(side="right", fill="y")
        self.javascript_tree.pack(side="left", fill="both", expand=True)
        self.javascript_scrollbar.pack(side="right", fill="y")
        self.links_tree.pack(side="left", fill="both", expand=True)
        self.links_scrollbar.pack(side="right", fill="y")
        self.whois_tree.pack(side="left", fill="both", expand=True)
        self.whois_scrollbar.pack(side="right", fill="y")
        self.shodan_tree.pack(side="left", fill="both", expand=True)
        self.shodan_scrollbar.pack(side="right", fill="y")

    def animate_waiting(self):
        while self.is_scanning:
            self.progress_label.configure(text=f"Scanning... {self.waiting_frames[self.current_frame]}")
            self.current_frame = (self.current_frame + 1) % len(self.waiting_frames)
            time.sleep(0.2)

    def start_scan(self):
        self.is_scanning = True
        threading.Thread(target=self.animate_waiting).start()
        self.check_selected()

    def stop_scan(self):
        self.is_scanning = False
        self.progress_label.configure(text="Status: Idle")

    def check_selected(self):
        if self.tabview.get() == "Subdomains":
            self.subdomain_thread()
        elif self.tabview.get() == "ASN":
            self.asn_thread()
        elif self.tabview.get() == "Headers":
            self.headers_thread()
        elif self.tabview.get() == "Javascript":
            self.javascript_thread()
        elif self.tabview.get() == "Links":
            self.links_thread()
        elif self.tabview.get() == "WHOIS":
            self.whois_thread()
        elif self.tabview.get() == "Shodan":
            self.shodan_thread()
        elif self.port_services_tabview.get() == "Ports":
            self.ports_thread()

    def clear_textbox(self):
        if self.tabview.get() == "Subdomains":
            self.subdomain_tree.delete(*self.subdomain_tree.get_children())
        elif self.tabview.get() == "ASN":
            self.asn_tree.delete(*self.asn_tree.get_children())
        elif self.tabview.get() == "Headers":
            self.headers_tree.delete(*self.headers_tree.get_children())
        elif self.tabview.get() == "Javascript":
            self.javascript_tree.delete(*self.javascript_tree.get_children())
        elif self.tabview.get() == "Links":
            self.links_tree.delete(*self.links_tree.get_children())
        elif self.tabview.get() == "WHOIS":
            self.whois_tree.delete(*self.whois_tree.get_children())
        elif self.tabview.get() == "Shodan":
            self.shodan_tree.delete(*self.shodan_tree.get_children())
        elif self.port_services_tabview.get() == "Ports":
            self.ports_tree.delete(*self.ports_tree.get_children())
            self.services_tree.delete(*self.services_tree.get_children())
        self.progress_label.configure(text="Status: Idle")

    def get_subdomains(self):
        domain = self.entry.get()
        # Implement subdomain enumeration logic here
        results = []  # Replace with actual results
        self.save_results.save_scan_results("subdomains", results)
        return results

    def subdomain_thread(self):
        threading.Thread(target=lambda: self.update_treeview(self.get_subdomains(), self.subdomain_tree)).start()

    def get_asn_info(self):
        domain = self.entry.get()
        # Implement ASN lookup logic here
        results = []  # Replace with actual results
        self.save_results.save_scan_results("asn", results)
        return results

    def asn_thread(self):
        threading.Thread(target=lambda: self.update_treeview(self.get_asn_info(), self.asn_tree)).start()

    def get_headers(self):
        domain = self.entry.get()
        # Implement HTTP header analysis logic here
        results = []  # Replace with actual results
        self.save_results.save_scan_results("headers", results)
        return results

    def headers_thread(self):
        threading.Thread(target=lambda: self.update_treeview(self.get_headers(), self.headers_tree)).start()

    def get_javascript_files(self):
        domain = self.entry.get()
        # Implement JavaScript file discovery logic here
        results = []  # Replace with actual results
        self.save_results.save_scan_results("javascript", results)
        return results

    def javascript_thread(self):
        threading.Thread(target=lambda: self.update_treeview(self.get_javascript_files(), self.javascript_tree)).start()

    def get_links(self):
        domain = self.entry.get()
        # Implement link extraction logic here
        results = []  # Replace with actual results
        self.save_results.save_scan_results("links", results)
        return results

    def links_thread(self):
        threading.Thread(target=lambda: self.update_treeview(self.get_links(), self.links_tree)).start()

    def whois(self):
        domain = self.entry.get()
        # Implement WHOIS lookup logic here
        results = []  # Replace with actual results
        self.save_results.save_scan_results("whois", results)
        return results

    def whois_thread(self):
        threading.Thread(target=lambda: self.update_treeview(self.whois(), self.whois_tree)).start()

    def shodan(self):
        api_key = self.shodan_entry.get()
        domain = self.entry.get()
        try:
            results = shodan_scan(domain, api_key)
            self.save_results.save_scan_results("shodan", results)
            return results
        except Exception as e:
            print(f"Error during Shodan scan: {e}")
            return []

    def shodan_thread(self):
        threading.Thread(target=lambda: self.update_treeview(self.shodan(), self.shodan_tree)).start()

    def scan_port(self, host, port):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(1)
                if s.connect_ex((host, port)) == 0:
                    service = socket.getservbyport(port)
                    return port, service
        except Exception as e:
            print(f"Error scanning port {port}: {e}")
        return None

    def scan_ports(self):
        host = self.entry.get()
        start_port = int(self.startport_entry.get())
        end_port = int(self.endport_entry.get())
        ports_results = []
        services_results = []
        for port in range(start_port, end_port + 1):
            result = self.scan_port(host, port)
            if result:
                ports_results.append(result[0])
                services_results.append(result[1])
        self.save_results.save_scan_results("ports", ports_results)
        self.save_results.save_scan_results("services", services_results)
        return ports_results, services_results

    def ports_thread(self):
        ports_results, services_results = self.scan_ports()
        self.update_treeview(ports_results, self.ports_tree)
        self.update_treeview(services_results, self.services_tree)

    def update_treeview(self, results, treeview):
        treeview.delete(*treeview.get_children())
        for item in results:
            treeview.insert("", "end", values=(item,))
        self.is_scanning = False
        self.progress_label.configure(text="Status: Idle")

    def switch_tab(self, tab_name):
        if tab_name == "Home":
            self.tabview.select(0)
        elif tab_name == "Subdomains":
            self.tabview.select(0)
        elif tab_name == "ASN":
            self.tabview.select(1)
        elif tab_name == "Headers":
            self.tabview.select(2)
        elif tab_name == "Javascript":
            self.tabview.select(3)
        elif tab_name == "Links":
            self.tabview.select(4)
        elif tab_name == "WHOIS":
            self.tabview.select(5)
        elif tab_name == "Shodan":
            self.tabview.select(6)
        elif tab_name == "Ports":
            self.port_services_tabview.select(0)

    def update_status(self):
        pass

    def is_valid_domain(self, domain):
        domain = domain.strip()
        if not domain:
            return False
        try:
            requests.get(f"http://{domain}")
            return True
        except requests.exceptions.RequestException:
            return False

    def format_complex_value(self, value):
        if isinstance(value, dict):
            return json.dumps(value, indent=4)
        elif isinstance(value, list):
            return json.dumps(value, indent=4)
        else:
            return str(value)

    def process_subdomain(self, subdomain):
        return subdomain

    def process_link(self, link):
        return link

    def process_whois_data(self, key, value):
        return f"{key}: {value}"

    def download_script(self, base_url, script_url):
        try:
            url = f"{base_url}/{script_url}"
            response = requests.get(url)
            response.raise_for_status()  # Raise HTTPError for bad responses (4xx or 5xx)
            return url, "Downloaded"
        except requests.exceptions.RequestException as e:
            return url, f"Error: {e}"

    def save_current_results(self):
        pass


if __name__ == "__main__":
    reconx = ReconX()