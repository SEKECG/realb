import shodan

def get_api_key(api_key):
    return shodan.Shodan(api_key)

def get_ip_from_domain(domain):
    try:
        ip = socket.gethostbyname(domain)
        return ip
    except socket.gaierror:
        return None

def scan_single_ip(ip, api_key):
    api = get_api_key(api_key)
    try:
        results = api.host(ip)
        return results
    except shodan.APIError as e:
        print(f"Error: {e}")
        return {}

def shodan_scan(domain, api_key):
    ip = get_ip_from_domain(domain)
    if ip:
        return scan_single_ip(ip, api_key)
    else:
        return []

def host_info(domain, api_key):
    api = get_api_key(api_key)
    try:
        results = api.host(domain)
        return results
    except shodan.APIError as e:
        print(f"Error: {e}")
        return {}

import socket