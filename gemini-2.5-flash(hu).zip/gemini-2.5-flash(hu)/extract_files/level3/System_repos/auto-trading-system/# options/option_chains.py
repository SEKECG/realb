import pandas as pd

EXISTING_OPTION_CHAINS_COLUMNS = []
OPTION_CHAINS_COLUMNS = []

class OptionChains:
    def __init__(self, option_chains_json):
        pass

    def filter_option_candidates(self):
        pass

    def get_call_option_candidates_from_min_strike_price_and_min_premium_percentage(self, min_strike_price, min_premium, min_premium_percentage):
        pass

    def get_delta_from_option_symbol(self, option_symbol):
        pass

    def get_option_candidates_from_expiration_date_and_delta_range(self, min_expiration_date, min_delta, max_delta, min_premium_percentage, min_premium, option_type):
        pass

    def get_put_option_candidates_from_max_strike_price_and_min_premium(self, max_strike_price, min_premium):
        pass

    def get_theta_from_option_symbol(self, option_symbol):
        pass