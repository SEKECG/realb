import pandas as pd
from options.option_chains import OptionChains

PRICE_HISTORY_COLUMNS = []

class Stocks:
    def __init__(self, position_json):
        pass

    def create_a_stock_order(self, ticker, quantity, price, instruction):
        pass

    def get_option_chains(self, client):
        pass

    def get_price_history(self, client, start_date, end_date):
        pass

    def initialize_from_quote_json(self, ticker, quote_json):
        pass