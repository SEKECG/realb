import datetime
import pandas as pd
from configs.utils import OptionType, OptionInstruction

class Options:
    def __init__(self, position_json):
        pass

    def create_a_rollout_order(self, new_expiration_date, new_strike_price, new_option_price):
        pass

    def create_an_option_order(self, ticker, expiration_date, strike_price, option_price, quantity, option_type, instruction):
        pass

    def create_btc_order(self):
        pass

    def form_an_option_symbol(self, ticker, expiration_date, strike_price, option_type):
        pass

    def is_gain_larger_than_50_percent(self):
        pass

    def is_losing(self):
        pass

    def is_winning(self, max_delta_for_btc):
        pass

    def set_delta(self, delta):
        pass

    def set_stock_price(self, stock_price):
        pass

    def set_theta(self, theta):
        pass
    
    def sto_after_a_win(self, option_chains, min_expiration_weeks, min_delta, max_delta, min_premium_percentage, min_premium):
        pass

    def sto_after_btc_a_loss(self, option_chains):
        pass

    def sto_an_option_order(self, ticker, option_chains, quantity, option_type, min_expiration_weeks, min_delta, max_delta, min_premium_percentage, min_premium, cost_basis):
        pass