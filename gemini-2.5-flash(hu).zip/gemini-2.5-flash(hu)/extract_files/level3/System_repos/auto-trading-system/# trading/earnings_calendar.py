import json
import requests
from datetime import datetime, timedelta

class EarningsCalendar:
    def __init__(self):
        pass

    def generate_earnings_calendar_from_yahoo_finance(self, symbol_list):
        pass

    def get_earning_tickers(self, date):
        pass