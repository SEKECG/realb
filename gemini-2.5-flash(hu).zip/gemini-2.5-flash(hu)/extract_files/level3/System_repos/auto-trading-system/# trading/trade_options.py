import pandas as pd
from configs.config import *
from configs.utils import TradeReason, OptionInstruction, StockInstruction
from options.options import Options
from options.stocks import Stocks
from options.option_chains import OptionChains

ORDER_COLUMNS = []

class TradeOptions:
    def __init__(self):
        pass

    def constrain_to_current_positions(self, account_number, ticker_list):
        pass

    def display_all_orders(self):
        pass

    def get_existing_tickers(self):
        pass

    def process_losing_trades(self, account_number, options, ticker_to_stock_map):
        pass

    def process_positions(self, account_number, positions):
        pass

    def process_winning_trades(self, account_number, options, ticker_to_stock_map):
        pass

    def selL_cc_and_csp(self, account_number, ticker_to_stock_map, trade_reason):
        pass

    def sto_given_tickers(self, account_number, tickers_to_sell_dict, trade_reason):
        pass

    def trade_all_accounts(self):
        pass

    def trade_an_order(self, account_number, order, option_profit, trade_reason):
        pass