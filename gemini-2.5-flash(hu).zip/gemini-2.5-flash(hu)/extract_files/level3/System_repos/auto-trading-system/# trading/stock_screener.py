class StockScreener:
    def __init__(self, client, tickers_to_scan):
        pass

    def day_change_larger_than_x_percent(self, x_percent):
        pass

    def month_change_larger_than_x_percent(self, x_percent):
        pass

    def run(self, day_change, week_change, month_change):
        pass

    def week_change_larger_than_x_percent(self, x_percent):
        pass