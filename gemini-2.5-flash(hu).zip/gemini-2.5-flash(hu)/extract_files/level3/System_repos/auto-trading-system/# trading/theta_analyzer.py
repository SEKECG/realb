import matplotlib.pyplot as plt
from configs.utils import theta_scatter_plot

class ThetaAnalyzer:
    def __init__(self, client, options, ticker_to_stock_map):
        pass

    def scatter_plot(self):
        pass