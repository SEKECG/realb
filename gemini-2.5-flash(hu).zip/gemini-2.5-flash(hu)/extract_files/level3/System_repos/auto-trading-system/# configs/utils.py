import enum
import matplotlib.pyplot as plt
import os

TOP_LEVEL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def sum_of_option_strike_prices(call_option_tickers, option_type):
    pass

def theta_scatter_plot(ax, deltas, theta_decay_percentages, expiration_dates, strike_prices, tickers, subtitle):
    pass

class OptionInstruction(enum.Enum):
    BUY_TO_CLOSE = "BUY_TO_CLOSE"
    BUY_TO_OPEN = "BUY_TO_OPEN"
    SELL_TO_CLOSE = "SELL_TO_CLOSE"
    SELL_TO_OPEN = "SELL_TO_OPEN"

class OptionType(enum.Enum):
    CALL = "CALL"
    PUT = "PUT"

class StockInstruction(enum.Enum):
    BUY = "BUY"
    SELL = "SELL"

class TradeReason(enum.Enum):
    BTC_FROM_LOSING = "BTC_FROM_LOSING"
    BTC_FROM_WINNING = "BTC_FROM_WINNING"
    ROLLOUT_FROM_LOSING = "ROLLOUT_FROM_LOSING"
    ROLLOUT_FROM_WINNING = "ROLLOUT_FROM_WINNING"
    STO_FROM_EARNINGS = "STO_FROM_EARNINGS"
    STO_FROM_LARGE_PRICE_CHANGE = "STO_FROM_LARGE_PRICE_CHANGE"
    STO_FROM_LOSING = "STO_FROM_LOSING"
    STO_FROM_THE_WHEEL = "STO_FROM_THE_WHEEL"
    STO_FROM_WINNING = "STO_FROM_WINNING"
    STO_FROM_other = "STO_FROM_other"