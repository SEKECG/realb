from trading.theta_analyzer import ThetaAnalyzer
from trading.trade_options import TradeOptions

theta_analyzer = None
trade_options = None

if __name__ == "__main__":
    pass