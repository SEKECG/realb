from .client import APIClient
from .models import ConfigNodeRequest, ConfigNodeResponse, NodesInfoResponse

class DucoPy:
    """A Python client for interacting with a Duco API, providing methods to manage nodes, configurations, actions, and retrieve system information and logs."""

    def __init__(self, base_url, verify=True):
        """Initialize an instance of the class with a base URL and optional SSL verification setting, creating an APIClient object for handling API requests."""
        self.client = APIClient(base_url, verify)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def close(self):
        """Close the client connection to release resources and terminate the session."""
        self.client.close()

    def raw_get(self, endpoint, params=None):
        """Perform a raw GET request to a specified endpoint with optional parameters and return the response as a dictionary."""
        return self.client.raw_get(endpoint, params)

    def get_nodes(self):
        """Retrieve information about all nodes from the client."""
        return self.client.get_nodes()

    def get_node_info(self, node_id):
        """Retrieve information about a specific node identified by its node_id from a client service."""
        return self.client.get_node_info(node_id)

    def get_config_nodes(self):
        """Retrieve the configuration nodes from the client."""
        return self.client.get_config_nodes()

    def get_config_node(self, node_id):
        """Retrieve the configuration details of a specific node identified by its node_id from the client's configuration service."""
        return self.client.get_config_node(node_id)

    def update_config_node(self, node_id, config):
        """Update the configuration of a specified node by sending a PATCH request to the client with the provided node ID and configuration data."""
        return self.client.patch_config_node(node_id, config)

    def get_actions_node(self, node_id, action=None):
        """Retrieve actions associated with a specific node, optionally filtered by a particular action type, from a client service."""
        return self.client.get_actions_node(node_id, action)

    def get_action(self, action=None):
        """Retrieve an action's details from the client, optionally filtered by a specific action name."""
        return self.client.get_action(action)

    def change_action_node(self, action, value, node_id):
        """Send a request to modify an action node's properties (action, value) identified by node_id and return the response."""
        return self.client.post_action_node(action, value, node_id)

    def get_api_info(self):
        """Retrieve API information from the client and return it as a dictionary."""
        return self.client.get_api_info()

    def get_info(self, module, submodule=None, parameter=None):
        """Retrieve information about a module, submodule, or specific parameter from a client's configuration or state as a dictionary."""
        return self.client.get_info(module, submodule, parameter)

    def get_logs(self):
        """Retrieve logs from the client and return them as a dictionary."""
        return self.client.get_logs()