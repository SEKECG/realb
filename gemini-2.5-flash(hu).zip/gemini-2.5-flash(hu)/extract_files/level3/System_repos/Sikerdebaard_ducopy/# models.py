import sys
from pydantic import BaseModel, Field, validator, ValidationError
from typing import Optional, Union, List, Dict
from .utils import extract_val

PYDANTIC_V2 = sys.version_info >= (3, 8)


def unified_validator(*uargs, **ukwargs):
    """A unified validator decorator for Pydantic 1.x and 2.x.
    Ensures that user-defined validators run before field-level validation,
    allowing data transformations to occur first (e.g. extracting `.Val`).
    """
    def decorator(func):
        if PYDANTIC_V2:
            return validator(*uargs, **ukwargs)(func)
        else:
            return validator(*uargs, **ukwargs)(func)
    return decorator

class ParameterConfig(BaseModel):
    """Define and validate a configuration structure for parameters with optional constraints (min, max, increment) and ensure required keys are present."""
    Id: Optional[int] = Field(None, alias='Id')
    Min: Optional[int] = Field(None, alias='Min')
    Max: Optional[int] = Field(None, alias='Max')
    Inc: Optional[int] = Field(None, alias='Inc')

    @classmethod
    def ensure_keys(cls, values):
        """Ensure a dictionary contains all specified keys, setting missing keys to None."""
        keys = {'Id', 'Min', 'Max', 'Inc'}
        result = {}
        for key in keys:
            result[key] = values.get(key, None)
        return result

    @unified_validator('Id', 'Min', 'Max', 'Inc')
    def ensure_values(cls, value):
        if value is None:
            return None
        return value

class NodeConfig(BaseModel):
    """Define a configuration model for a node with parameters related to flow levels, CO2/RH settings, and operational modes, using Pydantic's BaseModel for validation and serialization."""
    SerialBoard: str = Field(..., alias='SerialBoard')
    SerialDuco: str = Field(..., alias='SerialDuco')
    Name: Optional[ParameterConfig] = Field(None, alias='Name')
    FlowMax: Optional[ParameterConfig] = Field(None, alias='FlowMax')
    FlowLvlSwitch: Optional[ParameterConfig] = Field(None, alias='FlowLvlSwitch')
    FlowLvlAutoMin: Optional[ParameterConfig] = Field(None, alias='FlowLvlAutoMin')
    FlowLvlAutoMax: Optional[ParameterConfig] = Field(None, alias='FlowLvlAutoMax')
    FlowLvlMan1: Optional[ParameterConfig] = Field(None, alias='FlowLvlMan1')
    FlowLvlMan2: Optional[ParameterConfig] = Field(None, alias='FlowLvlMan2')
    FlowLvlMan3: Optional[ParameterConfig] = Field(None, alias='FlowLvlMan3')
    RhDetMode: Optional[ParameterConfig] = Field(None, alias='RhDetMode')
    RhSetPoint: Optional[ParameterConfig] = Field(None, alias='RhSetPoint')
    Co2SetPoint: Optional[ParameterConfig] = Field(None, alias='Co2SetPoint')
    TempDepEnable: Optional[ParameterConfig] = Field(None, alias='TempDepEnable')
    SwitchMode: Optional[ParameterConfig] = Field(None, alias='SwitchMode')
    ShowSensorLvl: Optional[ParameterConfig] = Field(None, alias='ShowSensorLvl')
    TimeMan: Optional[ParameterConfig] = Field(None, alias='TimeMan')


class ConfigNodeRequest(BaseModel):
    """Represents a configuration request for a node with various flow, CO2, RH, and operational settings."""
    Name: Optional[str] = Field(None, alias='Name')
    FlowMax: Optional[int] = Field(None, alias='FlowMax')
    FlowLvlSwitch: Optional[int] = Field(None, alias='FlowLvlSwitch')
    FlowLvlAutoMin: Optional[int] = Field(None, alias='FlowLvlAutoMin')
    FlowLvlAutoMax: Optional[int] = Field(None, alias='FlowLvlAutoMax')
    FlowLvlMan1: Optional[int] = Field(None, alias='FlowLvlMan1')
    FlowLvlMan2: Optional[int] = Field(None, alias='FlowLvlMan2')
    FlowLvlMan3: Optional[int] = Field(None, alias='FlowLvlMan3')
    RhDetMode: Optional[int] = Field(None, alias='RhDetMode')
    RhSetPoint: Optional[int] = Field(None, alias='RhSetPoint')
    Co2SetPoint: Optional[int] = Field(None, alias='Co2SetPoint')
    TempDepEnable: Optional[int] = Field(None, alias='TempDepEnable')
    SwitchMode: Optional[int] = Field(None, alias='SwitchMode')
    ShowSensorLvl: Optional[int] = Field(None, alias='ShowSensorLvl')
    TimeMan: Optional[int] = Field(None, alias='TimeMan')


class ConfigNodeResponse(BaseModel):
    """ConfigNodeResponse for specific node configurationRepresent configuration parameters and metadata for a node in a ventilation or environmental control system, including serial numbers and various operational settings."""
    SerialBoard: str = Field(..., alias='SerialBoard')
    SerialDuco: str = Field(..., alias='SerialDuco')
    Name: Optional[ParameterConfig] = Field(None, alias='Name')
    FlowMax: Optional[ParameterConfig] = Field(None, alias='FlowMax')
    FlowLvlSwitch: Optional[ParameterConfig] = Field(None, alias='FlowLvlSwitch')
    FlowLvlAutoMin: Optional[ParameterConfig] = Field(None, alias='FlowLvlAutoMin')
    FlowLvlAutoMax: Optional[ParameterConfig] = Field(None, alias='FlowLvlAutoMax')
    FlowLvlMan1: Optional[ParameterConfig] = Field(None, alias='FlowLvlMan1')
    FlowLvlMan2: Optional[ParameterConfig] = Field(None, alias='FlowLvlMan2')
    FlowLvlMan3: Optional[ParameterConfig] = Field(None, alias='FlowLvlMan3')
    RhDetMode: Optional[ParameterConfig] = Field(None, alias='RhDetMode')
    RhSetPoint: Optional[ParameterConfig] = Field(None, alias='RhSetPoint')
    Co2SetPoint: Optional[ParameterConfig] = Field(None, alias='Co2SetPoint')
    TempDepEnable: Optional[ParameterConfig] = Field(None, alias='TempDepEnable')
    SwitchMode: Optional[ParameterConfig] = Field(None, alias='SwitchMode')
    ShowSensorLvl: Optional[ParameterConfig] = Field(None, alias='ShowSensorLvl')
    TimeMan: Optional[ParameterConfig] = Field(None, alias='TimeMan')


class NodesResponse(BaseModel):
    """To represent a collection of node configurations in a structured format using a list of NodeConfig objects."""
    Nodes: List[NodeConfig]


class NodesInfoResponse(BaseModel):
    """Represent a response containing a list of node information, where each node's details are defined by the NodeInfo model, with an optional default of None if no nodes are provided."""
    Nodes: Optional[List['NodeInfo']] = None

class ActionsResponse(BaseModel):
    """Represent a response containing a node identifier and a list of associated actions with their details."""
    NodeId: int
    Actions: List['ActionInfo']

class ActionInfo(BaseModel):
    """Define a structured model for action information, including action type, value type, and optional enumeration values, with validation to ensure Enum is only set when ValType is "Enum"."""
    Type: str = Field(..., alias='Type')
    ValType: str = Field(..., alias='ValType')
    Val: Union[str, int] = Field(..., alias='Val')
    Enum: Optional[List[str]] = Field(None, alias='Enum')

    @classmethod
    def set_optional_enum(cls, values):
        """Set Enum only if ValType is Enum; ignore otherwise."""
        if values.get('ValType') == 'Enum':
            return {'Enum': values.get('Enum', [])}
        return {'Enum': []}

    @unified_validator('Enum')
    def check_enum(cls, v):
        if v is not None and len(v) == 0:
            return []
        return v

class FirmwareResponse(BaseModel):
    """The FirmwareResponse class is a data model designed to structure and validate responses related to firmware operations, including upload metadata and a list of associated files with their attributes."""
    FirmwareVersion: str
    Files: List[Dict[str, Union[str, int]]]


class GeneralInfo(BaseModel):
    """Store basic information with an optional identifier and a required value."""
    Id: Optional[int] = Field(None, alias='Id')
    Val: str


class NetworkDucoInfo(BaseModel):
    """The `NetworkDucoInfo` class is a Pydantic BaseModel designed to represent and validate network communication error counter data, ensuring the `CommErrorCtr` field is properly extracted and validated."""
    CommErrorCtr: int

    @classmethod
    def validate_comm_error_ctr(cls, values):
        """Validate and extract the value of the "CommErrorCtr" field from the input dictionary, ensuring it is properly formatted and returned in the output dictionary."""
        return {'CommErrorCtr': extract_val(values.get('CommErrorCtr'))}


    @unified_validator('CommErrorCtr')
    def check_comm_error(cls,v):
        if v is None:
            return 0
        return v


class NodeInfo(BaseModel):
    """Store and manage information about a node, including general details, network data, ventilation settings, and sensor readings."""
    General: 'NodeGeneralInfo'
    Network: 'NetworkDucoInfo'
    Ventilation: 'VentilationInfo'
    Sensor: Optional['SensorData'] = None

class NodeGeneralInfo(BaseModel):
    """The NodeGeneralInfo class is designed to represent and validate general information about a node, including its type and address, ensuring the address is properly extracted and formatted."""
    Type: str = Field(..., alias='Type')
    Addr: int

    @classmethod
    def validate_addr(cls, values):
        """Validate and extract the address value from the input dictionary by processing the "Addr" key using the `extract_val` function."""
        return {'Addr': extract_val(values.get('Addr'))}

    @unified_validator('Addr')
    def check_addr(cls, v):
        if v is None:
            return 0
        return v


class SensorData(BaseModel):
    """Dynamically captures sensor data, including environmental sensors."""
    data: Optional[Dict[str, Union[int, float, str]]] = None

    @classmethod
    def extract_sensor_values(cls, values):
        """Extract and transform sensor values from a dictionary by replacing each value with its corresponding 'Val' attribute if present, and store the results in a 'data' key within the original dictionary.
        Iterate over all fields and extract their `Val` if they have it
        """
        data = {}
        for key, value in values.items():
            data[key] = extract_val(value)
        return {'data': data}

    @unified_validator('data')
    def check_data(cls, v):
        if v is None:
            return {}
        return v



class VentilationInfo(BaseModel):
    """The VentilationInfo class models ventilation system data, including state, flow levels, timing, and mode, with validation to handle field transformations and optional values."""
    State: Optional[str] = Field(None, alias='State')
    Mode: Optional[str] = Field(None, alias='Mode')
    FlowLvlOvrl: int = Field(..., alias='FlowLvlOvrl')
    FlowLvlTgt: Optional[int] = Field(None, alias='FlowLvlTgt')
    TimeStateRemain: Optional[int] = Field(None, alias='TimeStateRemain')
    TimeStateEnd: Optional[int] = Field(None, alias='TimeStateEnd')

    @classmethod
    def validate_ventilation_fields(cls, values):
        """Validate and transform ventilation-related fields by extracting values, handling special cases for time fields and dash-separated fields, and returning the processed dictionary."""
        return {
            'State': extract_val(values.get('State')),
            'Mode': extract_val(values.get('Mode')),
            'FlowLvlOvrl': extract_val(values.get('FlowLvlOvrl')),
            'FlowLvlTgt': extract_val(values.get('FlowLvlTgt')),
            'TimeStateRemain': extract_val(values.get('TimeStateRemain')),
            'TimeStateEnd': extract_val(values.get('TimeStateEnd')),
        }

    @unified_validator('State', 'Mode', 'FlowLvlOvrl', 'FlowLvlTgt', 'TimeStateRemain', 'TimeStateEnd')
    def check_ventilation_fields(cls, value):
        if value is None:
            return 0
        return value

class ActionsChangeResponse(BaseModel):
    """Represents a standardized response structure for action change operations, including a status code and a result message."""
    status: int
    message: str


def extract_val(data):
    """Helper function to extract `Val` from nested dictionariesExtract the value associated with the key "Val" from a dictionary if it exists; otherwise, return the input data unchanged."""
    if isinstance(data, dict) and 'Val' in data:
        return data['Val']
    return data