import typer
from loguru import logger
import json
from .ducopy import DucoPy
from .models import URLModel
from typing import Optional

app = typer.Typer(help="DucoPy CLI")

@app.command()
def configure(logging_level: Optional[str] = typer.Option(None, "--log-level", help="Logging level")):
    """CLI client for interacting with DucoPy."""
    setup_logging(logging_level)
    
def setup_logging(level):
    if level:
        logger.remove()
        logger.add(lambda msg: print(msg), level=level)

def validate_url(url):
    """Validate the provided URL as an HttpUrl and remove trailing slashes."""
    url_model = URLModel(url=url)
    return str(url_model.url)

@app.command()
def raw_get(url: str, params: Optional[str] = None, format: str = "pretty"):
    """Perform a raw GET request to a specified URL."""
    url = validate_url(url)
    with DucoPy(url) as client:
        try:
            data = client.raw_get(url, params=json.loads(params) if params else None)
            print_output(data, format)
        except Exception as e:
            logger.error(f"Error: {e}")


@app.command()
def get_nodes(base_url: str, format: str = "pretty"):
    """Retrieve list of all nodes."""
    base_url = validate_url(base_url)
    with DucoPy(base_url) as client:
        try:
            data = client.get_nodes()
            print_output(data, format)
        except Exception as e:
            logger.error(f"Error: {e}")


@app.command()
def get_node_info(base_url: str, node_id: int, format: str = "pretty"):
    """Retrieve information for a specific node by ID."""
    base_url = validate_url(base_url)
    with DucoPy(base_url) as client:
        try:
            data = client.get_node_info(node_id)
            print_output(data, format)
        except Exception as e:
            logger.error(f"Error: {e}")


@app.command()
def get_config_nodes(base_url: str, format: str = "pretty"):
    """Retrieve configuration settings for all nodes."""
    base_url = validate_url(base_url)
    with DucoPy(base_url) as client:
        try:
            data = client.get_config_nodes()
            print_output(data, format)
        except Exception as e:
            logger.error(f"Error: {e}")


@app.command()
def get_config_node(base_url: str, node_id: int, format: str = "pretty"):
    """Retrieve configuration settings for a specific node."""
    base_url = validate_url(base_url)
    with DucoPy(base_url) as client:
        try:
            data = client.get_config_node(node_id)
            print_output(data, format)
        except Exception as e:
            logger.error(f"Error: {e}")


@app.command()
def update_config_node(base_url: str, node_id: int, config_json: str, format: str = "pretty"):
    """Update configuration settings for a specific node."""
    base_url = validate_url(base_url)
    with DucoPy(base_url) as client:
        try:
            config = json.loads(config_json)
            data = client.update_config_node(node_id, config)
            print_output(data, format)
        except Exception as e:
            logger.error(f"Error: {e}")



@app.command()
def get_actions_node(base_url: str, node_id: int, action: Optional[str] = None, format: str = "pretty"):
    """Retrieve actions available for a specific node."""
    base_url = validate_url(base_url)
    with DucoPy(base_url) as client:
        try:
            data = client.get_actions_node(node_id, action)
            print_output(data, format)
        except Exception as e:
            logger.error(f"Error: {e}")


@app.command()
def get_action(base_url: str, action: Optional[str] = None, format: str = "pretty"):
    """Retrieve action data with an optional filter."""
    base_url = validate_url(base_url)
    with DucoPy(base_url) as client:
        try:
            data = client.get_action(action)
            print_output(data, format)
        except Exception as e:
            logger.error(f"Error: {e}")


@app.command()
def change_action_node(base_url: str, node_id: int, action: str, value: str, format: str = "pretty"):
    """Perform a POST action by sending a JSON body to the endpoint."""
    base_url = validate_url(base_url)
    with DucoPy(base_url) as client:
        try:
            data = client.change_action_node(action, value, node_id)
            print_output(data, format)
        except Exception as e:
            logger.error(f"Error: {e}")



@app.command()
def get_api_info(base_url: str, format: str = "pretty"):
    """Retrieve API information."""
    base_url = validate_url(base_url)
    with DucoPy(base_url) as client:
        try:
            data = client.get_api_info()
            print_output(data, format)
        except Exception as e:
            logger.error(f"Error: {e}")


@app.command()
def get_info(base_url: str, module: str, submodule: Optional[str] = None, parameter: Optional[str] = None, format: str = "pretty"):
    """Retrieve general API information with optional filters."""
    base_url = validate_url(base_url)
    with DucoPy(base_url) as client:
        try:
            data = client.get_info(module, submodule, parameter)
            print_output(data, format)
        except Exception as e:
            logger.error(f"Error: {e}")


@app.command()
def get_logs(base_url: str, format: str = "pretty"):
    """Retrieve API logs."""
    base_url = validate_url(base_url)
    with DucoPy(base_url) as client:
        try:
            data = client.get_logs()
            print_output(data, format)
        except Exception as e:
            logger.error(f"Error: {e}")


def print_output(data, format):
    """Print output in the specified format."""
    if format == "json":
        print(json.dumps(data, indent=4))
    else:
        print(json.dumps(data, indent=4))

@app.command()
def entry_point():
    """Entry point for the CLI."""
    pass


class URLModel(typer.Model):
    url: str