import time

class ApiKeyGenerator:
    """Generates an API key based on board serial, MAC address, and time."""

    def generate_api_key(self, board_serial, mac_address, time):
        """Generates a unique API key based on the MAC address, board serial, and time.

        Args:
            board_serial: The serial number of the board.
            mac_address: The MAC address of the device.
            time: The Unix timestamp for the generation process.

        Returns:
            The generated API key as a 64-character string.
        """
        combined = board_serial + mac_address + str(time)
        key = ""
        for i in range(0, len(combined), 2):
            c1 = combined[i]
            c2 = combined[i+1] if i + 1 < len(combined) else ' '
            key += self.transform_char(c1, c2)
        return key.ljust(64, ' ')


    def transform_char(self, c1, c2):
        """Transforms two characters into a single character using XOR and ASCII adjustments.

        Args:
            c1: First character for transformation.
            c2: Second character for transformation.

        Returns:
            A single character result of the transformation.
        """
        return chr((ord(c1) ^ ord(c2)) % 128)