import requests
from requests.adapters import HTTPAdapter
from requests.utils import default_headers
from requests.exceptions import RequestException
from urllib3.util.retry import Retry
from loguru import logger
import ssl
from .utils import DucoUrlSession, custom_host_mapping
import pkg_resources
from .models import ConfigNodeRequest, ConfigNodeResponse, NodesInfoResponse, ActionsResponse

class APIClient:
    """A Python class for interacting with a RESTful API, handling HTTP requests, certificate pinning, and providing methods for various API operations including GET, POST, and PATCH requests, with built-in validation and logging."""

    def __init__(self, base_url, verify=True):
        """Initialize an APIClient instance with a base URL and SSL verification settings, setting up a session for HTTP requests."""
        self.base_url = base_url
        self.session = DucoUrlSession(base_url, verify)

    def close(self):
        """Close the HTTP session."""
        self.session.close()

    def _duco_pem(self):
        """Enable certificate pinning."""
        try:
            return pkg_resources.resource_string(__name__, 'duco.pem').decode('utf-8')
        except FileNotFoundError:
            logger.warning('duco.pem not found. Certificate pinning disabled.')
            return None

    def raw_get(self, endpoint, params=None):
        """Perform a raw GET request to the specified endpoint with optional parameters and return the response as a dictionary."""
        response = self.session.request('GET', endpoint, params=params)
        response.raise_for_status()
        return response.json()

    def get_nodes(self):
        """Retrieve list of all nodes."""
        response = self.session.request('GET', '/nodes')
        response.raise_for_status()
        return NodesInfoResponse(**response.json())

    def get_node_info(self, node_id):
        """Retrieve detailed information for a specific node."""
        response = self.session.request('GET', f'/nodes/{node_id}')
        response.raise_for_status()
        return response.json()

    def get_config_nodes(self):
        """Retrieve the configuration settings for all nodes."""
        response = self.session.request('GET', '/nodes/config')
        response.raise_for_status()
        return NodesResponse(**response.json())

    def get_config_node(self, node_id):
        """Retrieve configuration settings for a specific node."""
        response = self.session.request('GET', f'/nodes/{node_id}/config')
        response.raise_for_status()
        return ConfigNodeResponse(**response.json())

    def patch_config_node(self, node_id, config):
        """Update configuration settings for a specific node after validating the new values."""
        response = self.session.request('PATCH', f'/nodes/{node_id}/config', json=config.model_dump())
        response.raise_for_status()
        return ConfigNodeResponse(**response.json())


    def get_actions_node(self, node_id, action=None):
        """Retrieve available actions for a specific node."""
        endpoint = f'/nodes/{node_id}/actions'
        params = {'action': action} if action else None
        response = self.session.request('GET', endpoint, params=params)
        response.raise_for_status()
        return ActionsResponse(**response.json())

    def get_action(self, action=None):
        """Retrieve action data."""
        endpoint = '/actions'
        params = {'action': action} if action else None
        response = self.session.request('GET', endpoint, params=params)
        response.raise_for_status()
        return response.json()

    def post_action_node(self, action, value, node_id):
        """Perform a POST action by sending a JSON body to the endpoint."""
        response = self.session.request('POST', f'/nodes/{node_id}/actions', json={'action': action, 'value': value})
        response.raise_for_status()
        return response.json()

    def get_api_info(self):
        """Fetch API version and available endpoints."""
        response = self.session.request('GET', '/api')
        response.raise_for_status()
        return response.json()

    def get_info(self, module, submodule=None, parameter=None):
        """Fetch general API information."""
        endpoint = f'/info/{module}'
        if submodule:
            endpoint += f'/{submodule}'
        if parameter:
            endpoint += f'/{parameter}'
        response = self.session.request('GET', endpoint)
        response.raise_for_status()
        return response.json()

    def get_logs(self):
        """Retrieve API logs."""
        response = self.session.request('GET', '/logs')
        response.raise_for_status()
        return response.json()