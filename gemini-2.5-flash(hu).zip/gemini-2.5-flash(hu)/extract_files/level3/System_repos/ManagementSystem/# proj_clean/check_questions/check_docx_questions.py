import docx
import json

client = None


class DocxQuestionImporter:
    def __init__(self):
        pass

    def _read_from_word(self, file_path):
        pass

    def clean_non_standard_json(self, content):
        pass

    def import_question_bank(self, file_path):
        pass