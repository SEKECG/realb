import openpyxl
import csv
import json

client = None


class ExcelQuestionImporter:
    def __init__(self):
        pass

    def clean_non_standard_json(self, content):
        pass

    def recognize_tabular_questions(self, file_path):
        pass