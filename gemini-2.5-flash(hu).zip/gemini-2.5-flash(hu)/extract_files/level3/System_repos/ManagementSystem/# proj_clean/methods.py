import logging
from models import *
from datetime import datetime

local_date = datetime.now()
logger = logging.getLogger(__name__)


class StudentModule:
    def register(self, student_id, name, student_class, gender, phone_number, password, confirm_password):
        pass

    def login(self, student_id, password):
        pass

    def logout(self):
        pass

    def list_exams(self):
        pass

    def submit_exam_answers(self, student_id, exam_id, answers):
        pass


class TeacherModule:
    def register(self, teacher_id, name, gender, phone_number, password, confirm_password):
        pass

    def login(self, teacher_id, password):
        pass

    def logout(self):
        pass

    def create_exam(self, name, start_time, end_time, question_bank_id):
        pass

    def edit_exam(self, exam_id, name, start_time, end_time):
        pass

    def delete_exam(self, exam_id):
        pass

    def assign_questions_to_exam(self, exam_id, question_ids_with_scores):
        pass

    def manage_question_bank(self, action, question_bank_id, question_bank_name):
        pass

    def import_question_bank(self, file_path, question_bank_id):
        pass

    def map_question_type(self, raw_type):
        pass

    def update_question(self, question_id, question_type, content, answer):
        pass

    def update_options(self, question_id, options_data):
        pass

    def get_question_by_id(self, question_id):
        pass

    def auto_grade_exam(self, exam_id):
        pass

    def calculate_and_save_total_grades(self, exam_id):
        pass

    def generate_exam_report(self, exam_id):
        pass

    def view_exam_grades(self, exam_id, student_id, student_name):
        pass


class AdminModule:
    def login(self, username, password):
        pass

    def logout(self):
        pass

    def modify_student_account(self, action, student_id, student_info):
        pass

    def modify_teacher_account(self, action, teacher_id, teacher_info):
        pass

    def log_system_activity(self, operation):
        pass