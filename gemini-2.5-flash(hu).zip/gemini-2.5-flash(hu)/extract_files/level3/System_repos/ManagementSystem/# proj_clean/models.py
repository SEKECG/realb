import sqlite3
from datetime import datetime

db = sqlite3.connect('online_exam.db')
cursor = db.cursor()


class BaseModel:
    reserved1 = None
    reserved2 = None


class Admins(BaseModel):
    def __init__(self, admin_id, name, phone_number, password):
        self.admin_id = admin_id
        self.name = name
        self.phone_number = phone_number
        self.password = password


class Teachers(BaseModel):
    def __init__(self, teacher_id, name, gender, phone_number, password):
        self.teacher_id = teacher_id
        self.name = name
        self.gender = gender
        self.phone_number = phone_number
        self.password = password


class Students(BaseModel):
    def __init__(self, student_id, name, student_class, gender, phone_number, password):
        self.student_id = student_id
        self.name = name
        self.student_class = student_class
        self.gender = gender
        self.phone_number = phone_number
        self.password = password


class QuestionBanks(BaseModel):
    def __init__(self, name):
        self.name = name
        self.created_at = datetime.now()


class Questions(BaseModel):
    def __init__(self, question_bank, question_type, content, answer):
        self.question_bank = question_bank
        self.question_type = question_type
        self.content = content
        self.answer = answer


class QuestionOptions(BaseModel):
    def __init__(self, question, option_text, is_correct):
        self.question = question
        self.option_text = option_text
        self.is_correct = is_correct


class Exams(BaseModel):
    def __init__(self, name, question_bank, start_time, end_time):
        self.name = name
        self.question_bank = question_bank
        self.start_time = start_time
        self.end_time = end_time
        self.created_at = datetime.now()


class ExamQuestions(BaseModel):
    def __init__(self, exam, question, score):
        self.exam = exam
        self.question = question
        self.score = score


class StudentAnswers(BaseModel):
    def __init__(self, student, exam, question, selected_option, answer_text):
        self.student = student
        self.exam = exam
        self.question = question
        self.selected_option = selected_option
        self.answer_text = answer_text


class StudentGrades(BaseModel):
    def __init__(self, student, exam, grade):
        self.student = student
        self.exam = exam
        self.grade = grade