import argparse
import logging
from agents.NaiveAgent import NaiveAgent
from src.Game import Game
from src.Player import Player
from src.Colour import Colour

args = None
g = None
p1 = None
p1_class = None
p1_path = None
p2 = None
p2_class = None
p2_path = None
parser = None

def main():
    global args, g, p1, p1_class, p1_path, p2, p2_class, p2_path, parser

    parser = argparse.ArgumentParser(description='Play a game of Hex.')
    parser.add_argument('--p1_agent', type=str, default='NaiveAgent', help='Path to player 1 agent.')
    parser.add_argument('--p2_agent', type=str, default='NaiveAgent', help='Path to player 2 agent.')
    parser.add_argument('--board_size', type=int, default=11, help='Size of the board.')
    parser.add_argument('--log', type=str, default=None, help='Log file path.')
    parser.add_argument('--verbose', action='store_true', help='Enable verbose logging.')
    parser.add_argument('--silent', action='store_true', help='Disable console output.')
    args = parser.parse_args()

    logging.basicConfig(filename=args.log, level=logging.DEBUG if args.verbose else logging.INFO,
                        format='%(asctime)s - %(levelname)s - %(message)s')


    p1_class = args.p1_agent
    p2_class = args.p2_agent
    p1_path = f"agents.{p1_class}"
    p2_path = f"agents.{p2_class}"

    p1 = Player(eval(p1_path)(Colour.RED), "Player 1", Colour.RED)
    p2 = Player(eval(p2_path)(Colour.BLUE), "Player 2", Colour.BLUE)

    g = Game(p1, p2, args.board_size, args.log, args.verbose, args.silent)
    result = g.run()
    print(result)
    logging.info(result)


if __name__ == "__main__":
    main()