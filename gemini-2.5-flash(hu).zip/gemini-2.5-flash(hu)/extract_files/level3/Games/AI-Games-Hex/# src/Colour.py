class Colour:
    RED = 1
    BLUE = 2
    NONE = 0

    @staticmethod
    def from_char(c):
        if c == 'R':
            return Colour.RED
        elif c == 'B':
            return Colour.BLUE
        else:
            return Colour.NONE

    @staticmethod
    def get_char(colour):
        if colour == Colour.RED:
            return 'R'
        elif colour == Colour.BLUE:
            return 'B'
        else:
            return '.'

    @staticmethod
    def opposite(colour):
        if colour == Colour.RED:
            return Colour.BLUE
        elif colour == Colour.BLUE:
            return Colour.RED
        else:
            return Colour.NONE