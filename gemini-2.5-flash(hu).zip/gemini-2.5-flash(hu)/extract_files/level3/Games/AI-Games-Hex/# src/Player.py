class Player:
    def __init__(self, agent, name, colour):
        self.agent = agent
        self.name = name
        self.colour = colour
        self.move_time = 0
        self.turn = 0

    def __eq__(self, value):
        if not isinstance(value,Player):
            return False
        return hash(self.agent) == hash(value.agent) and self.name == value.name and self.move_time == value.move_time