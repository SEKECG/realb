import time
import logging
from src.Board import Board
from src.Colour import Colour
from src.EndState import EndState

logger = logging.getLogger(__name__)

def format_result(player1_name, player2_name, winner, win_method, player_1_move_time, player_2_move_time, player_1_turn, player_2_turn, total_turns, total_time):
    return {
        'player1_name': player1_name,
        'player2_name': player2_name,
        'winner': winner.name if winner else "None",
        'win_method': win_method.name if win_method else "None",
        'player_1_move_time': player_1_move_time,
        'player_2_move_time': player_2_move_time,
        'player_1_turn': player_1_turn,
        'player_2_turn': player_2_turn,
        'total_turns': total_turns,
        'total_time': total_time,
    }

class Game:
    MAXIMUM_TIME = 10

    def __init__(self, player1, player2, board_size=11, logDest=None, verbose=False, silent=False):
        self._board = Board(board_size)
        self._start_time = time.perf_counter_ns()
        self.player1 = player1
        self.player2 = player2
        self.current_player = player1
        self.turn = 1
        self.logDest = logDest
        self.verbose = verbose
        self.silent = silent


    def _end_game(self, status):
        end_time = time.perf_counter_ns()
        total_time = self.ns_to_s(end_time - self._start_time)
        player_1_move_time = self.ns_to_s(self.player1.move_time)
        player_2_move_time = self.ns_to_s(self.player2.move_time)
        player_1_turn = self.player1.turn
        player_2_turn = self.player2.turn
        total_turns = self.turn -1
        result = format_result(self.player1.name, self.player2.name, self._board.get_winner(), status, player_1_move_time, player_2_move_time, player_1_turn, player_2_turn, total_turns, total_time)
        return result

    def _make_move(self, m):
        if not self.is_valid_move(m, self.turn, self._board):
            return EndState.BAD_MOVE
        self.current_player.move_time += time.perf_counter_ns() - start_time
        self.current_player.turn +=1
        self._board.set_tile_colour(m.x, m.y, self.current_player.colour.colour)

        if self._board.has_ended(self.current_player.colour.colour):
            return EndState.WIN

        self.current_player = self.player2 if self.current_player == self.player1 else self.player1
        self.turn += 1
        return None

    def _play(self):
        while True:
            start_time = time.perf_counter_ns()
            try:
                move = self.current_player.agent.make_move(self.turn, self._board, None)
            except Exception as e:
                logger.error(f"Player {self.current_player.name} agent crashed: {e}")
                return self._end_game(EndState.BAD_MOVE)

            status = self._make_move(move)
            if status:
                return self._end_game(status)


    @property
    def board(self):
        return self._board

    def is_valid_move(self, move, turn, board):
        if move.x == -1 and move.y == -1:
            return turn == 2
        if move.x < 0 or move.x >= board.size or move.y < 0 or move.y >= board.size:
            return False
        return board.tiles[move.x][move.y].colour == Colour.NONE

    @staticmethod
    def ns_to_s(t):
        return t/1e9

    def run(self):
        return self._play()

    @property
    def turn(self):
        return self._turn
    
    @turn.setter
    def turn(self,turn):
        self._turn = turn