class EndState:
    WIN = 1
    TIMEOUT = 2
    BAD_MOVE = 3
    FAILED_LOAD = 4