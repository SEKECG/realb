from src.Colour import Colour
from src.Tile import Tile

class Board:
    def __init__(self, board_size):
        self.size = board_size
        self.tiles = [[Tile(x, y) for y in range(board_size)] for x in range(board_size)]

    def __eq__(self, value):
        if not isinstance(value,Board):
            return False
        if self.size != value.size:
            return False
        for x in range(self.size):
            for y in range(self.size):
                if self.tiles[x][y].colour != value.tiles[x][y].colour:
                    return False
        return True

    def __str__(self):
        return self.print_board()

    def DFS_colour(self, x, y, colour):
        if x < 0 or x >= self.size or y < 0 or y >= self.size or self.tiles[x][y].colour != colour or self.tiles[x][y].is_visited():
            return False
        self.tiles[x][y].visit()
        if colour == Colour.RED and x == self.size -1:
            return True
        if colour == Colour.BLUE and y == self.size -1:
            return True
        for dx, dy in zip(Tile.I_DISPLACEMENTS,Tile.J_DISPLACEMENTS):
            if self.DFS_colour(x + dx, y + dy, colour):
                return True
        return False

    def clear_tiles(self):
        for x in range(self.size):
            for y in range(self.size):
                self.tiles[x][y].clear_visit()

    def from_string(self, string_input, board_size):
        self.size = board_size
        self.tiles = [[Tile(x, y) for y in range(board_size)] for x in range(board_size)]
        if string_input == '':
            return
        rows = string_input.split('\n')
        for i, row in enumerate(rows):
            for j, char in enumerate(row):
                if char != '.':
                    self.tiles[i][j].colour = Colour.from_char(char)


    def get_winner(self):
        self.clear_tiles()
        for i in range(self.size):
            if self.DFS_colour(i,0,Colour.RED):
                return Colour.RED
            if self.DFS_colour(0,i,Colour.BLUE):
                return Colour.BLUE
        return Colour.NONE

    def has_ended(self,colour):
        self.clear_tiles()
        if colour == Colour.RED:
            for i in range(self.size):
                if self.DFS_colour(i, 0, colour):
                    return True
        else:
            for i in range(self.size):
                if self.DFS_colour(0, i, colour):
                    return True
        return False


    def print_board(self):
        result = ""
        for row in self.tiles:
            for tile in row:
                result += tile.colour.get_char()
            result += '\n'
        return result

    def set_tile_colour(self, x, y, colour):
        self.tiles[x][y].colour = colour

    @property
    def size(self):
        return self._size
    
    @size.setter
    def size(self,size):
        self._size = size

    @property
    def tiles(self):
        return self._tiles
    
    @tiles.setter
    def tiles(self,tiles):
        self._tiles = tiles