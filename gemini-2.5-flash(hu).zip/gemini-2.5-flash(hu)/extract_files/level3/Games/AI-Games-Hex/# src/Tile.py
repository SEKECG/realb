from src.Colour import Colour

class Tile:
    NEIGHBOUR_COUNT = 6
    I_DISPLACEMENTS = [1, 1, 0, -1, -1, 0]
    J_DISPLACEMENTS = [0, 1, 1, 0, -1, -1]

    def __init__(self, x, y):
        self._colour = Colour.NONE
        self._visited = False
        self._x = x
        self._y = y

    def clear_visit(self):
        self._visited = False

    @property
    def colour(self):
        return self._colour
    
    @colour.setter
    def colour(self,colour):
        self._colour = colour

    def is_visited(self):
        return self._visited

    def visit(self):
        self._visited = True

    @property
    def x(self):
        return self._x

    @property
    def y(self):
        return self._y