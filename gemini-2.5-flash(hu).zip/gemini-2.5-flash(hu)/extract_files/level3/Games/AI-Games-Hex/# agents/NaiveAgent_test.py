import pytest
from agents.NaiveAgent import NaiveAgent
from src.Board import Board
from src.Colour import Colour
from src.Move import Move

@pytest.fixture
def mock_board():
    return Board(3)

@pytest.fixture
def naive_agent():
    return NaiveAgent(Colour.RED)

def test_naive_agent_initialization(naive_agent):
    assert naive_agent.colour == Colour.RED

def test_naive_agent_make_move_first_turn(naive_agent, mock_board):
    move = naive_agent.make_move(1, mock_board, None)
    assert isinstance(move, Move)
    assert 0 <= move.x < mock_board.size and 0 <= move.y < mock_board.size
    assert mock_board.tiles[move.x][move.y].colour == Colour.RED

def test_naive_agent_make_move_swap_turn(naive_agent, mock_board):
    mock_board.set_tile_colour(1,1,Colour.RED)
    move = naive_agent.make_move(2, mock_board, Move(1,1))
    assert isinstance(move, Move)
    assert move.x == -1 and move.y == -1

def test_naive_agent_make_move_with_opponent_move(naive_agent, mock_board):
    mock_board.set_tile_colour(1,1,Colour.BLUE)
    move = naive_agent.make_move(2, mock_board, Move(1,1))
    assert isinstance(move, Move)
    assert 0 <= move.x < mock_board.size and 0 <= move.y < mock_board.size
    assert mock_board.tiles[move.x][move.y].colour == Colour.RED