import random
from src.AgentBase import AgentBase
from src.Move import Move

class NaiveAgent(AgentBase):
    def __init__(self, colour):
        super().__init__(colour)
        self._board_size = 0
        self.choices = []

    def make_move(self, turn, board, opp_move):
        self._board_size = board.size
        if self._board_size == 0:
            return Move(-1,-1)
        if len(self.choices) == 0:
            self.choices = [(x,y) for x in range(self._board_size) for y in range(self._board_size)]
        
        if random.random() < 0.5 and turn > 1:
            return Move(-1,-1)
        
        while True:
            choice = random.choice(self.choices)
            if board.tiles[choice[0]][choice[1]].colour == 0:
                self.choices.remove(choice)
                return Move(choice[0],choice[1])