from typing import List, Optional
from token_encoder.encode import get_token_length

class TreeElement:
    def __init__(self, header: Optional[str], content: str, token_length: int, children: List["TreeElement"]):
        self.header = header
        self.content = content
        self.token_length = token_length
        self.children = children

class SemanticChunk:
    def __init__(self, content: str, token_length: int, headers: List[str]):
        self.content = content
        self.token_length = token_length
        self.headers = headers

class SemanticMarkdownParser:
    def combine_chunks(self, chunk1: SemanticChunk, chunk2: SemanticChunk) -> SemanticChunk:
        combined_content = chunk1.content + "\n" + chunk2.content
        combined_token_length = chunk1.token_length + chunk2.token_length
        combined_headers = chunk1.headers + chunk2.headers
        return SemanticChunk(combined_content, combined_token_length, combined_headers)

    def format_chunk_with_headers(self, headers: List[str], content: str, include_hashes: bool = False) -> str:
        formatted_headers = "\n".join([f"#{header}" if include_hashes else header for header in headers])
        return f"{formatted_headers}\n{content}"

    def get_full_header_path(self, headers: List[str]) -> str:
        return " > ".join(headers)

    def get_semantic_chunks(self, root: TreeElement, max_tokens: int = 500) -> List[str]:
        chunks = self.process_tree_to_chunks(root, max_tokens)
        return [self.format_chunk_with_headers(chunk.headers, chunk.content) for chunk in chunks]

    def parse_markdown_to_tree(self, markdown_text: str) -> TreeElement:
        if not markdown_text:
            raise ValueError("Markdown text is empty or contains no content.")
        # Assuming MarkdownNodeParser is available from llama_index.core.node_parser
        from llama_index.core.node_parser import MarkdownNodeParser
        parser = MarkdownNodeParser()
        return parser.parse(markdown_text)

    def process_tree_to_chunks(self, root: TreeElement, max_tokens: int = 500, current_headers: Optional[List[str]] = None) -> List[SemanticChunk]:
        if current_headers is None:
            current_headers = []
        chunks = []
        for child in root.children:
            chunks.extend(self.process_tree_to_chunks(child, max_tokens, current_headers + [child.header]))
        if root.token_length <= max_tokens:
            chunks.append(SemanticChunk(root.content, root.token_length, current_headers))
        else:
            # Split content into smaller chunks
            from text_splitter import split_text_into_sentences
            sentences = split_text_into_sentences(root.content, chunk_size=max_tokens)
            for sentence in sentences:
                token_length = get_token_length(sentence)
                chunks.append(SemanticChunk(sentence, token_length, current_headers))
        return chunks