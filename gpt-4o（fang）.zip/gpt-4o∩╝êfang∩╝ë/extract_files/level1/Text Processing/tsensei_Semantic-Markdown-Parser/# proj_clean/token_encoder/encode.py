import os
from transformers import AutoTokenizer

current_dir = os.path.dirname(__file__)
tokenizer_path = os.path.join(current_dir, "tokenizer")
tokenizer = AutoTokenizer.from_pretrained(tokenizer_path)

def get_token_length(content):
    tokens = tokenizer.tokenize(content)
    return len(tokens)

def get_tokens(content):
    return tokenizer.tokenize(content)