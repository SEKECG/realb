import json
import os
import re
import pyperclip
import customtkinter as ctk
from cryptography.fernet import Fernet
from datetime import datetime

KEY_FILE = "key.key"
PACKAGE_FOLDER = "src"
SAVE_FILE = "clips.json"
SETTINGS_FILE = "settings.json"

autosave = False
clipsObj = []
cryptKey = None
darkmode = False
lastClip = None
selected_color = "blue"
selected_type_filter = "All"

def UI():
    global root, frame, search_entry, autosave_var, darkmode_var, color_var, type_filter_var
    root = ctk.CTk()
    root.title("Clipboardy")
    root.geometry("800x600")

    frame = ctk.CTkFrame(root)
    frame.pack(fill="both", expand=True)

    search_entry = ctk.CTkEntry(frame, placeholder_text="Search...")
    search_entry.pack(pady=10)
    search_entry.bind("<KeyRelease>", search_clips)

    autosave_var = ctk.CTkSwitch(frame, text="Auto-Save", command=toggle_autosave)
    autosave_var.pack(pady=10)

    darkmode_var = ctk.CTkSwitch(frame, text="Dark Mode", command=toggle_darkmode)
    darkmode_var.pack(pady=10)

    color_var = ctk.CTkOptionMenu(frame, values=["blue", "green", "red"], command=apply_color)
    color_var.pack(pady=10)

    type_filter_var = ctk.CTkOptionMenu(frame, values=["All", "URL", "Email", "IPv4", "IPv6", "Credit Card"], command=apply_filter)
    type_filter_var.pack(pady=10)

    populate_clips_table(frame, clipsObj)

    root.mainloop()

def apply_color(choice):
    global selected_color
    selected_color = choice
    refresh_ui(frame)

def apply_filter(choice):
    global selected_type_filter
    selected_type_filter = choice
    refresh_ui(frame)

def decrypt_clip(encrypted_clip):
    fernet = Fernet(cryptKey)
    return fernet.decrypt(encrypted_clip).decode()

def delete_all_clips():
    global clipsObj
    clipsObj = []
    save_clips()
    refresh_ui(frame)

def delete_clip_from_ui(index):
    global clipsObj
    del clipsObj[index]
    save_clips()
    refresh_ui(frame)

def delete_key():
    if os.path.exists(KEY_FILE):
        os.remove(KEY_FILE)
    delete_all_clips()
    generate_key()

def determine_content_type(current_clip):
    if re.match(r'^https?://', current_clip):
        return "URL"
    elif re.match(r'^[\w\.-]+@[\w\.-]+\.\w+$', current_clip):
        return "Email"
    elif re.match(r'^\d{4}-\d{4}-\d{4}-\d{4}$', current_clip):
        return "Credit Card"
    elif re.match(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$', current_clip):
        return "IPv4"
    elif re.match(r'^[\da-fA-F]{1,4}(:[\da-fA-F]{1,4}){7}$', current_clip):
        return "IPv6"
    else:
        return "Text"

def encrypt_clip(clip):
    fernet = Fernet(cryptKey)
    return fernet.encrypt(clip.encode())

def generate_key():
    global cryptKey
    cryptKey = Fernet.generate_key()
    with open(KEY_FILE, 'wb') as key_file:
        key_file.write(cryptKey)

def load_clips():
    global clipsObj
    if os.path.exists(SAVE_FILE):
        with open(SAVE_FILE, 'r') as file:
            clipsObj = json.load(file)

def load_key():
    global cryptKey
    if os.path.exists(KEY_FILE):
        with open(KEY_FILE, 'rb') as key_file:
            cryptKey = key_file.read()
    else:
        generate_key()

def load_settings():
    global autosave, darkmode, selected_color
    if os.path.exists(SETTINGS_FILE):
        with open(SETTINGS_FILE, 'r') as file:
            settings = json.load(file)
            autosave = settings.get("autosave", False)
            darkmode = settings.get("darkmode", False)
            selected_color = settings.get("selected_color", "blue")

def main():
    load_key()
    load_clips()
    load_settings()
    UI()

def monitor_clipboard():
    global lastClip
    while True:
        current_clip = pyperclip.paste()
        if current_clip != lastClip:
            lastClip = current_clip
            if autosave:
                save_clip()

def populate_clips_table(frame, clips_to_display):
    for widget in frame.winfo_children():
        widget.destroy()
    for index, clip in enumerate(clips_to_display):
        decrypted_clip = decrypt_clip(clip["content"])
        clip_type = clip["type"]
        clip_date = clip["date"]
        ctk.CTkLabel(frame, text=f"{clip_date} - {clip_type} - {decrypted_clip[:20]}...").pack()
        ctk.CTkButton(frame, text="Copy", command=lambda c=decrypted_clip: pyperclip.copy(c)).pack()
        ctk.CTkButton(frame, text="Delete", command=lambda i=index: delete_clip_from_ui(i)).pack()

def refresh_ui(component):
    component.update()

def save_clip():
    current_clip = pyperclip.paste()
    clip_type = determine_content_type(current_clip)
    encrypted_clip = encrypt_clip(current_clip)
    clip_entry = {
        "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "type": clip_type,
        "content": encrypted_clip
    }
    clipsObj.append(clip_entry)
    save_clips()
    refresh_ui(frame)

def save_clips():
    with open(SAVE_FILE, 'w') as file:
        json.dump(clipsObj, file)

def save_settings():
    settings = {
        "autosave": autosave,
        "darkmode": darkmode,
        "selected_color": selected_color
    }
    with open(SETTINGS_FILE, 'w') as file:
        json.dump(settings, file)

def search_clips(event):
    search_text = search_entry.get().lower()
    filtered_clips = [clip for clip in clipsObj if search_text in decrypt_clip(clip["content"]).lower()]
    populate_clips_table(frame, filtered_clips)

def settings_UI():
    settings_window = ctk.CTkToplevel(root)
    settings_window.title("Settings")
    settings_window.geometry("400x300")

    ctk.CTkLabel(settings_window, text="Appearance").pack(pady=10)
    ctk.CTkSwitch(settings_window, text="Dark Mode", command=toggle_darkmode).pack(pady=10)
    ctk.CTkOptionMenu(settings_window, values=["blue", "green", "red"], command=apply_color).pack(pady=10)

    ctk.CTkLabel(settings_window, text="Danger Zone").pack(pady=10)
    ctk.CTkButton(settings_window, text="Reset Encryption Key", command=delete_key).pack(pady=10)

def toggle_autosave():
    global autosave
    autosave = not autosave
    save_settings()

def toggle_darkmode():
    global darkmode
    darkmode = not darkmode
    ctk.set_appearance_mode("dark" if darkmode else "light")
    save_settings()

if __name__ == "__main__":
    main()