import os
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

class CursorDirectoryManager:
    def __init__(self, config):
        self.config = config
        self.cursor_dir = Path(".cursor")
        self.rules_dir = self.cursor_dir / "rules"

    def create_rule_file(self, name, content, metadata=None):
        try:
            rule_file = self.rules_dir / f"{name}.mdc"
            with open(rule_file, "w") as file:
                file.write(content)
                if metadata:
                    file.write("\n")
                    file.write(yaml.dump(metadata))
            return True
        except Exception as e:
            logger.error(f"Failed to create rule file {name}: {e}")
            return False

    def ensure_cursor_structure(self):
        self.cursor_dir.mkdir(exist_ok=True)
        self.rules_dir.mkdir(exist_ok=True)

    def list_rule_files(self):
        return list(self.rules_dir.glob("*.mdc"))

    def update_gitignore(self):
        gitignore_path = Path(".gitignore")
        if gitignore_path.exists():
            with open(gitignore_path, "a") as file:
                file.write("\n.cursor/rules/*.mdc\n")