import yaml
import logging

DEFAULT_CONFIG = {
    "global_rules": "global_rules.yaml",
    "lang_rules_dir": ".cursor/rules",
    "delimiter": "\n",
}

logger = logging.getLogger(__name__)

def load_config():
    try:
        with open("config.yaml", "r") as file:
            config = yaml.safe_load(file)
            return config
    except FileNotFoundError:
        logger.warning("Config file not found, using default settings.")
        return DEFAULT_CONFIG