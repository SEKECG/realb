import argparse
import logging
from config import load_config
from cursor_ops import CursorDirectoryManager
from file_ops import (
    setup_directory_structure,
    list_available_languages,
    check_files_exist,
    backup_existing_rules,
    combine_rules,
    write_rules_to_cursor_dir,
    copy_predefined_rules,
    get_available_languages,
    update_gitignore
)

logger = logging.getLogger(__name__)

def main(languages=None, force=False, verbose=False, show_list=False, setup_dirs=False, legacy=False):
    config = load_config()
    cursor_manager = CursorDirectoryManager(config)

    if setup_dirs:
        setup_directory_structure(verbose, force)
        copy_predefined_rules(config['lang_rules_dir'], verbose, force)
        update_gitignore()
        return

    if show_list:
        list_available_languages(config['lang_rules_dir'])
        return

    if legacy:
        if not check_files_exist(config['global_rules'], config['lang_rules_dir'], languages):
            logger.error("Required rule files are missing.")
            return
        backup_existing_rules(force)
        combined_rules = combine_rules(config['global_rules'], config['lang_rules_dir'], languages, config['delimiter'])
        cursor_manager.create_rule_file(".cursorrules", combined_rules)
    else:
        write_rules_to_cursor_dir(cursor_manager, config['global_rules'], config['lang_rules_dir'], languages, force)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate cursor rules files.")
    parser.add_argument("--languages", nargs="*", help="List of languages to include in the rules")
    parser.add_argument("--force", action="store_true", help="Force overwrite existing files")
    parser.add_argument("--verbose", action="store_true", help="Enable verbose output")
    parser.add_argument("--list", action="store_true", help="List available language rules")
    parser.add_argument("--setup", action="store_true", help="Setup or update the rules directory structure")
    parser.add_argument("--legacy", action="store_true", help="Generate a single .cursorrules file instead of multiple files")
    args = parser.parse_args()

    main(args.languages, args.force, args.verbose, args.list, args.setup, args.legacy)