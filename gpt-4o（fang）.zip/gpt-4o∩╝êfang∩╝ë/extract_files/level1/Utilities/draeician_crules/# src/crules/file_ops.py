import os
import shutil
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

def setup_directory_structure(verbose, force):
    cursor_dir = Path(".cursor")
    rules_dir = cursor_dir / "rules"
    cursor_dir.mkdir(exist_ok=True)
    rules_dir.mkdir(exist_ok=True)
    if verbose:
        logger.info("Directory structure created.")
    return True

def list_available_languages(language_rules_dir):
    lang_dir = Path(language_rules_dir)
    languages = [f.stem for f in lang_dir.glob("*.yaml")]
    for lang in languages:
        print(lang)

def check_files_exist(global_rules, language_rules_dir, languages):
    global_rules_path = Path(global_rules)
    if not global_rules_path.exists():
        return False
    lang_dir = Path(language_rules_dir)
    for lang in languages:
        if not (lang_dir / f"{lang}.yaml").exists():
            return False
    return True

def backup_existing_rules(force):
    cursor_rules_path = Path(".cursorrules")
    if cursor_rules_path.exists():
        if force:
            backup_path = cursor_rules_path.with_suffix(".bak")
            shutil.copy(cursor_rules_path, backup_path)
            return True
        else:
            return False
    return True

def combine_rules(global_rules, language_rules_dir, languages, delimiter):
    combined_rules = []
    with open(global_rules, "r") as file:
        combined_rules.append(file.read())
    lang_dir = Path(language_rules_dir)
    for lang in languages:
        with open(lang_dir / f"{lang}.yaml", "r") as file:
            combined_rules.append(file.read())
    return delimiter.join(combined_rules)

def write_rules_to_cursor_dir(cursor_manager, global_rules, lang_rules_dir, languages, force):
    cursor_manager.ensure_cursor_structure()
    combined_rules = combine_rules(global_rules, lang_rules_dir, languages, "\n")
    cursor_manager.create_rule_file("combined_rules", combined_rules)
    return True

def copy_predefined_rules(lang_rules_dir, verbose, force):
    predefined_dir = Path("predefined_rules")
    lang_dir = Path(lang_rules_dir)
    for rule_file in predefined_dir.glob("*.yaml"):
        dest_file = lang_dir / rule_file.name
        if not dest_file.exists() or force:
            shutil.copy(rule_file, dest_file)
            if verbose:
                logger.info(f"Copied {rule_file.name} to {lang_rules_dir}")

def get_available_languages(language_rules_dir):
    lang_dir = Path(language_rules_dir)
    return {f.stem: f for f in lang_dir.glob("*.yaml")}

def update_gitignore():
    gitignore_path = Path(".gitignore")
    if gitignore_path.exists():
        with open(gitignore_path, "a") as file:
            file.write("\n.cursorrules\n.cursorrules.bak\n")