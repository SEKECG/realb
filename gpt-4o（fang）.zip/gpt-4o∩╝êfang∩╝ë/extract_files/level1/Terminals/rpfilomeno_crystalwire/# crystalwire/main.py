import threading
import time
import psutil
import pandas as pd
import plotille
from scapy.all import sniff

# Global variables
all_macs = {}
connection2pid = {}
connections_thread = None
global_df = pd.DataFrame()
global_graph_data = {}
is_program_running = True
pid2traffic = pd.DataFrame(columns=['PID', 'Process', 'Upload', 'Download', 'Upload Speed', 'Download Speed'])
printing_thread = None

def get_connections():
    while is_program_running:
        for conn in psutil.net_connections(kind='inet'):
            if conn.raddr:
                connection2pid[(conn.laddr.ip, conn.laddr.port, conn.raddr.ip, conn.raddr.port)] = conn.pid
        time.sleep(1)

def get_size(bytes):
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if bytes < 1024:
            return f"{bytes:.2f} {unit}"
        bytes /= 1024

def plot(df):
    fig = plotille.Figure()
    fig.width = 60
    fig.height = 20
    fig.color_mode = 'byte'
    for pid in df.columns:
        fig.plot(df.index, df[pid], label=pid)
    print(fig.show())

def print_pid2traffic():
    while is_program_running:
        print(pid2traffic)
        time.sleep(1)

def print_stats():
    while is_program_running:
        print(global_df.head())
        time.sleep(1)

def process_packet(packet):
    if packet.haslayer('IP'):
        src_ip = packet['IP'].src
        dst_ip = packet['IP'].dst
        src_port = packet['IP'].sport
        dst_port = packet['IP'].dport
        if (src_ip, src_port, dst_ip, dst_port) in connection2pid:
            pid = connection2pid[(src_ip, src_port, dst_ip, dst_port)]
            if pid not in pid2traffic.index:
                try:
                    process = psutil.Process(pid)
                    pid2traffic.loc[pid] = [pid, process.name(), 0, 0, 0, 0]
                except psutil.NoSuchProcess:
                    return
            if packet['IP'].src == src_ip:
                pid2traffic.at[pid, 'Upload'] += len(packet)
            else:
                pid2traffic.at[pid, 'Download'] += len(packet)

def stat(df):
    print(df.head())

def main():
    global connections_thread, printing_thread
    connections_thread = threading.Thread(target=get_connections)
    connections_thread.start()
    printing_thread = threading.Thread(target=print_pid2traffic)
    printing_thread.start()
    sniff(prn=process_packet, store=False)

if __name__ == "__main__":
    main()