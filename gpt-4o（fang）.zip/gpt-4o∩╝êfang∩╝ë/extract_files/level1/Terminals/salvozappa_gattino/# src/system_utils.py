import subprocess
from src.ui import show_spinner

def run_command(command, input=None):
    process = subprocess.Popen(command, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    show_spinner(process)
    stdout, stderr = process.communicate(input=input)
    if process.returncode != 0:
        print(f"Error: {stderr.decode()}")
    return stdout.decode()

def write_file(path, content):
    with open(path, 'w') as file:
        file.write(content)