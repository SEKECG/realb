import itertools
import sys
import time

def show_spinner(process):
    spinner = Spinner()
    while process.poll() is None:
        sys.stdout.write(spinner.next_frame())
        sys.stdout.flush()
        time.sleep(0.1)
        sys.stdout.write('\b')

def print_input_line():
    return input("Please enter your command: ")

def print_intro():
    print("""
    Welcome to Gattino!
    """)

class Spinner:
    def __init__(self):
        self.frames = ['-', '\\', '|', '/']
        self.index = 0

    def next_frame(self):
        frame = self.frames[self.index]
        self.index = (self.index + 1) % len(self.frames)
        return frame

    def show(self, process):
        while process.poll() is None:
            sys.stdout.write(self.next_frame())
            sys.stdout.flush()
            time.sleep(0.1)
            sys.stdout.write('\b')