def extract_first_code_block(text):
    import re
    match = re.search(r'```(?:bash)?\s*(.*?)\s*```', text, re.DOTALL)
    if match:
        return match.group(1).strip()
    return ''