import json
import os

def load_config():
    config_path = os.path.expanduser('~/.config/kitty/gattino/gattino.config.json')
    try:
        with open(config_path, 'r') as file:
            return json.load(file)
    except FileNotFoundError:
        print(f"Configuration file not found at {config_path}")
    except json.JSONDecodeError:
        print(f"Invalid JSON in configuration file at {config_path}")
    return {}