import hashlib
import logging
import threading
import time
from PyQt5.QtWidgets import QApplication, QMainWindow, QPushButton, QTableWidget, QVBoxLayout, QWidget

SECRET_KEY = b'secret_key'
app = QApplication([])
can_bus = []
freshness_manager = {}
stop_event = threading.Event()
window = None

def generate_mac(message, freshness, key):
    mac = hashlib.sha256()
    mac.update(message.encode('utf-8'))
    mac.update(freshness.encode('utf-8'))
    mac.update(key)
    return mac.hexdigest()

def setup_logging():
    logging.basicConfig(level=logging.DEBUG)

def verify_mac(message, freshness, received_mac, key):
    expected_mac = generate_mac(message, freshness, key)
    return expected_mac == received_mac

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("CAN Message Simulation")
        self.tableWidget = QTableWidget()
        self.start_stop_button = QPushButton("Start/Stop Simulation")
        self.replay_button = QPushButton("Trigger Replay Attack")
        self.clear_button = QPushButton("Clear Simulation")
        self.sender_thread = None
        self.receiver_thread = None
        self.replay_attack_triggered = False

        layout = QVBoxLayout()
        layout.addWidget(self.tableWidget)
        layout.addWidget(self.start_stop_button)
        layout.addWidget(self.replay_button)
        layout.addWidget(self.clear_button)

        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

        self.start_stop_button.clicked.connect(self.toggle_simulation)
        self.replay_button.clicked.connect(self.trigger_replay_attack)
        self.clear_button.clicked.connect(self.clear_simulation)

    def clear_simulation(self):
        self.tableWidget.clearContents()

    def closeEvent(self, event):
        stop_event.set()
        if self.sender_thread:
            self.sender_thread.join()
        if self.receiver_thread:
            self.receiver_thread.join()
        event.accept()

    def toggle_simulation(self):
        if stop_event.is_set():
            stop_event.clear()
            self.sender_thread = SenderThread()
            self.receiver_thread = ReceiverThread()
            self.sender_thread.start()
            self.receiver_thread.start()
        else:
            stop_event.set()
            if self.sender_thread:
                self.sender_thread.join()
            if self.receiver_thread:
                self.receiver_thread.join()

    def trigger_replay_attack(self):
        self.replay_attack_triggered = True

    def update_table(self, message_parts, is_replay_attack, message_type):
        row_position = self.tableWidget.rowCount()
        self.tableWidget.insertRow(row_position)
        for i, part in enumerate(message_parts):
            self.tableWidget.setItem(row_position, i, QTableWidgetItem(part))
        if is_replay_attack:
            for i in range(self.tableWidget.columnCount()):
                self.tableWidget.item(row_position, i).setBackground(Qt.red)

class ReceiverThread(threading.Thread):
    def __init__(self):
        super().__init__()
        self.replay_attack_triggered = False

    def run(self):
        while not stop_event.is_set():
            if can_bus:
                message = can_bus.pop(0)
                message_parts = message.split(',')
                message_content = message_parts[0]
                freshness = message_parts[1]
                received_mac = message_parts[2]
                if freshness in freshness_manager:
                    is_replay_attack = True
                else:
                    is_replay_attack = False
                    freshness_manager[freshness] = True
                if verify_mac(message_content, freshness, received_mac, SECRET_KEY):
                    window.update_table(message_parts, is_replay_attack, "Received")
                time.sleep(1)

class SenderThread(threading.Thread):
    def __init__(self):
        super().__init__()
        self.last_sent_freshness = None

    def run(self):
        while not stop_event.is_set():
            message_content = "Hello"
            freshness = str(time.time())
            mac = generate_mac(message_content, freshness, SECRET_KEY)
            message = f"{message_content},{freshness},{mac}"
            can_bus.append(message)
            window.update_table(message.split(','), False, "Sent")
            time.sleep(1)

if __name__ == "__main__":
    setup_logging()
    window = MainWindow()
    window.show()
    app.exec_()