class Metrics:
    def __init__(self, signal_strength, bitrate, is_power_save_enabled):
        self.signal_strength = signal_strength
        self.bitrate = bitrate
        self.is_power_save_enabled = is_power_save_enabled

    def __str__(self):
        return f"Signal Strength: {self.signal_strength} dBm, Bitrate: {self.bitrate} Mbps, Power Save Enabled: {self.is_power_save_enabled}"