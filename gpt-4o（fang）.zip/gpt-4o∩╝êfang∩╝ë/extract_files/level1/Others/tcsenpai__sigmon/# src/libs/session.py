from datetime import datetime

class SessionMetrics:
    def __init__(self):
        self.bitrate_readings = []
        self.signal_readings = []
        self.start_time = datetime.now()

    def add_metrics(self, metrics):
        try:
            signal_strength = float(metrics.signal_strength)
            bitrate = float(metrics.bitrate)
            if signal_strength > 0:
                signal_strength = -signal_strength
            self.signal_readings.append(signal_strength)
            self.bitrate_readings.append(bitrate)
        except ValueError:
            print("Invalid metrics values")

    def get_session_summary(self):
        avg_signal = sum(self.signal_readings) / len(self.signal_readings) if self.signal_readings else 0
        avg_bitrate = sum(self.bitrate_readings) / len(self.bitrate_readings) if self.bitrate_readings else 0
        duration = datetime.now() - self.start_time
        return f"Session Summary:\nAverage Signal Strength: {avg_signal} dBm\nAverage Bitrate: {avg_bitrate} Mbps\nDuration: {duration}\nSamples Collected: {len(self.signal_readings)}"