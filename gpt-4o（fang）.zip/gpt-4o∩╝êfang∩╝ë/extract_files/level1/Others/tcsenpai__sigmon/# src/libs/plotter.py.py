import subprocess
from typing import Optional

def get_active_interface() -> Optional[str]:
    try:
        result = subprocess.run(['iwconfig'], capture_output=True, text=True)
        for line in result.stdout.split('\n'):
            if 'IEEE 802.11' in line:
                return line.split()[0]
    except Exception as e:
        print(f"Error getting active interface: {e}")
    return None

def get_metrics(adapter_name):
    try:
        result = subprocess.run(['iwconfig', adapter_name], capture_output=True, text=True)
        for line in result.stdout.split('\n'):
            if 'Link Quality' in line:
                signal_strength = line.split('Signal level=')[1].split(' ')[0]
                bitrate = line.split('Bit Rate=')[1].split(' ')[0]
                is_power_save_enabled = 'Power Management:on' in line
                return Metrics(signal_strength, bitrate, is_power_save_enabled)
    except Exception as e:
        print(f"Error getting metrics: {e}")
    return None