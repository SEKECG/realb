import argparse
from libs.plotter import plot_metrics_live
from libs.plotter.py import get_active_interface, get_metrics

def main():
    parser = argparse.ArgumentParser(description="WiFi Signal Monitor")
    parser.add_argument('-i', '--interface', type=str, help="Network interface name")
    parser.add_argument('-t', '--interval', type=int, default=5, help="Update interval in seconds")
    args = parser.parse_args()

    active_interface = args.interface or get_active_interface()
    if not active_interface:
        print("No active interface found")
        return

    try:
        plot_metrics_live(get_metrics, active_interface, args.interval)
    except KeyboardInterrupt:
        print("Monitoring stopped")

if __name__ == "__main__":
    main()