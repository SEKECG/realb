class QuantumComm:
    def __init__(self):
        self.entangled_pairs = []
        self.max_pairs = 10

    def create_entangled_pair(self):
        if len(self.entangled_pairs) < self.max_pairs:
            pair = {"id": len(self.entangled_pairs), "state": None}
            self.entangled_pairs.append(pair)
            return pair
        else:
            raise Exception("Maximum entangled pairs reached")

    def measure_state(self, pair_index):
        if pair_index < len(self.entangled_pairs):
            return self.entangled_pairs[pair_index]["state"]
        else:
            raise IndexError("Pair index out of range")

    def transmit_message(self, message, pair_index):
        if pair_index < len(self.entangled_pairs):
            self.entangled_pairs[pair_index]["state"] = message

    def receive_message(self, pair_index):
        return self.measure_state(pair_index)

    def format_message(self, recipient, message):
        return f"To: {recipient}, Message: {message}"

    def parse_message(self, raw_message):
        parts = raw_message.split(", ")
        return {"recipient": parts[0].split(": ")[1], "message": parts[1].split(": ")[1]}

    def validate_message(self, message_dict):
        return "recipient" in message_dict and "message" in message_dict