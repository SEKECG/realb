class MessageProtocol:
    @staticmethod
    def add_metadata(message_dict, key, value):
        message_dict[key] = value

    @staticmethod
    def format_message(recipient, message, metadata=None):
        formatted_message = f"To: {recipient}, Message: {message}"
        if metadata:
            for key, value in metadata.items():
                formatted_message += f", {key}: {value}"
        return formatted_message

    @staticmethod
    def get_metadata(message_dict, key):
        return message_dict.get(key)

    @staticmethod
    def parse_message(raw_message):
        parts = raw_message.split(", ")
        message_dict = {"recipient": parts[0].split(": ")[1], "message": parts[1].split(": ")[1]}
        for part in parts[2:]:
            key, value = part.split(": ")
            message_dict[key] = value
        return message_dict

    @staticmethod
    def remove_metadata(message_dict, key):
        if key in message_dict:
            del message_dict[key]

    @staticmethod
    def validate_message(message_dict):
        return "recipient" in message_dict and "message" in message_dict