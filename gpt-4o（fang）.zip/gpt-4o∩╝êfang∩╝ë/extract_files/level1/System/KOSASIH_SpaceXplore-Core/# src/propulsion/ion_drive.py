import logging

class IonDrive:
    def __init__(self, thrust, fuel_mass, specific_impulse):
        self.thrust = thrust
        self.fuel_mass = fuel_mass
        self.specific_impulse = specific_impulse
        self.is_active = False
        logging.basicConfig(level=logging.INFO)

    def activate(self):
        # Activation logic
        pass

    def calculate_acceleration(self):
        # Acceleration calculation logic
        pass

    def consume_fuel(self, time):
        # Fuel consumption logic
        pass

    def deactivate(self):
        # Deactivation logic
        pass

    def simulate(self, duration):
        # Simulation logic
        pass

    def status(self):
        # Status retrieval logic
        pass