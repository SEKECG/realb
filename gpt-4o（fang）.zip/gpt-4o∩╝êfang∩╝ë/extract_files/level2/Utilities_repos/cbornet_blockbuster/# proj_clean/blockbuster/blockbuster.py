import time
import os
import io
import socket
import ssl
import sqlite3
import threading
from contextvars import ContextVar
from typing import Callable, Iterable, Iterator, Any

HAS_FORBIDDENFRUIT = False

class BlockingError(Exception):
    def __init__(self, func):
        super().__init__(f"Blocking call detected: {func}")

class BlockBusterFunction:
    def __init__(self, module, func_name, scanned_modules=None, excluded_modules=None, can_block_functions=None, can_block_predicate=None):
        self.module = module
        self.func_name = func_name
        self.scanned_modules = scanned_modules
        self.excluded_modules = excluded_modules
        self.can_block_functions = can_block_functions or []
        self.can_block_predicate = can_block_predicate
        self.full_name = f"{module.__name__}.{func_name}"
        self.original_func = getattr(module, func_name)
        self.activated = False

    def activate(self):
        if not self.activated:
            setattr(self.module, self.func_name, self._wrap_blocking(self.original_func))
            self.activated = True
        return self

    def deactivate(self):
        if self.activated:
            setattr(self.module, self.func_name, self.original_func)
            self.activated = False
        return self

    def can_block_in(self, filename, functions):
        self.can_block_functions.append((filename, functions))
        return self

    def _wrap_blocking(self, func):
        def wrapper(*args, **kwargs):
            if blockbuster_skip.get():
                return func(*args, **kwargs)
            raise BlockingError(func)
        return wrapper

class BlockBuster:
    def __init__(self, scanned_modules=None, excluded_modules=None):
        self.scanned_modules = scanned_modules
        self.excluded_modules = excluded_modules
        self.functions = []

    def activate(self):
        for func in self.functions:
            func.activate()

    def deactivate(self):
        for func in self.functions:
            func.deactivate()

blockbuster_skip = ContextVar("blockbuster_skip", default=False)

def blockbuster_ctx(scanned_modules=None, excluded_modules=None):
    bb = BlockBuster(scanned_modules, excluded_modules)
    bb.activate()
    try:
        yield bb
    finally:
        bb.deactivate()

def _blocking_error(func):
    return BlockingError(func)

def _get_builtins_wrapped_functions(modules, excluded_modules):
    return {}

def _get_io_wrapped_functions(modules, excluded_modules):
    return {}

def _get_lock_wrapped_functions(modules, excluded_modules):
    return {}

def _get_os_wrapped_functions(modules, excluded_modules):
    return {}

def _get_socket_wrapped_functions(modules, excluded_modules):
    return {}

def _get_sqlite_wrapped_functions(modules, excluded_modules):
    return {}

def _get_ssl_wrapped_functions(modules, excluded_modules):
    return {}

def _get_time_wrapped_functions(modules, excluded_modules):
    return {}

def _resolve_module_paths(modules):
    return []

def _socket_exclude(sock, _, __):
    return not sock.getblocking()

def _wrap_blocking(modules, excluded_modules, func, func_name, can_block_functions, can_block_predicate):
    def wrapper(*args, **kwargs):
        if blockbuster_skip.get():
            return func(*args, **kwargs)
        raise BlockingError(func)
    return wrapper