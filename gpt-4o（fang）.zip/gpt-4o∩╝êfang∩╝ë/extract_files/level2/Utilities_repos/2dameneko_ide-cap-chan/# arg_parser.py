import argparse

def check_mutually_exclusive(args, arg_names):
    count = sum([1 for arg in arg_names if getattr(args, arg)])
    if count > 1:
        raise argparse.ArgumentError(None, f"Arguments {arg_names} are mutually exclusive.")

def parse_arguments():
    parser = argparse.ArgumentParser(description="Image Captioning System")
    parser.add_argument('--model', type=str, required=True, help='Model name or path')
    parser.add_argument('--input_dir', type=str, required=True, help='Input directory for images')
    parser.add_argument('--gpu', type=int, nargs='+', default=[0], help='GPU device selection')
    parser.add_argument('--output_ext', type=str, default='json', choices=['json', 'md', 'short', 'long', 'bbox'], help='Output file extension for captions')
    parser.add_argument('--caption_format', type=str, default='json', choices=['json', 'markdown', 'short', 'long', 'bounding_box'], help='Caption format')
    parser.add_argument('--tags', type=str, help='File with existing tags to improve caption quality')
    parser.add_argument('--character_info', type=str, help='File with character information')
    parser.add_argument('--character_traits', type=str, help='File with character traits')
    parser.add_argument('--additional_info', type=str, help='File with additional image information')
    parser.add_argument('--multi_gpu', action='store_true', help='Enable multi-GPU processing')
    parser.add_argument('--quantization', action='store_true', help='Enable 4-bit NF4 quantization')

    args = parser.parse_args()
    check_mutually_exclusive(args, ['tags', 'character_info', 'character_traits', 'additional_info'])
    return args