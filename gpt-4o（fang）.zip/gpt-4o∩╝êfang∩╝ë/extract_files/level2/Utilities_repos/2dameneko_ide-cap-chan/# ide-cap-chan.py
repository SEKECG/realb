import os
import multiprocessing
from arg_parser import parse_arguments
from image_processor import process_image_worker
from utils import measure_gpu_speed

def main():
    args = parse_arguments()
    input_files = [os.path.join(args.input_dir, f) for f in os.listdir(args.input_dir) if f.lower().endswith(('jpg', 'png', 'webp', 'jpeg'))]
    job_queue = multiprocessing.Queue()
    result_queue = multiprocessing.Queue()

    for file in input_files:
        job_queue.put(file)

    workers = []
    for i, gpu_id in enumerate(args.gpu):
        worker = multiprocessing.Process(target=process_image_worker, args=(i, gpu_id, job_queue, result_queue, args.model, args.caption_format, vars(args), len(input_files)))
        workers.append(worker)
        worker.start()

    for worker in workers:
        worker.join()

    while not result_queue.empty():
        result = result_queue.get()
        print(result)

if __name__ == "__main__":
    main()