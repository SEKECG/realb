import os
import torch
from model_handlers import get_handler

def process_image_worker(worker_id, gpu_id, job_queue, result_queue, model_name_or_path, input_model_type, args_dict, total_files):
    device = torch.device(f'cuda:{gpu_id}' if torch.cuda.is_available() else 'cpu')
    handler = get_handler(input_model_type, model_name_or_path, device, args_dict)

    while not job_queue.empty():
        image_path = job_queue.get()
        if os.path.exists(image_path):
            system_prompt = get_torii04_system_prompt()
            user_prompt = get_torii04_user_prompt(args_dict, image_path)
            caption = handler.process_image(system_prompt, user_prompt, image_path)
            result_queue.put((image_path, caption))

def get_handler(input_model_type, model_name_or_path, device, args_dict):
    if input_model_type == 'JoyCaption':
        return JoyCaptionHandler(model_name_or_path, device, args_dict)
    elif input_model_type == 'MoLMo':
        return MoLMoHandler(model_name_or_path, device, args_dict)
    elif input_model_type == 'MoLMo72b':
        return MoLMo72bHandler(model_name_or_path, device, args_dict)
    elif input_model_type == 'Qwen2VL':
        return Qwen2VLHandler(model_name_or_path, device, args_dict)
    elif input_model_type == 'Pixtral':
        return PixtralHandler(model_name_or_path, device, args_dict)
    elif input_model_type == 'Idefics3':
        return Idefics3Handler(model_name_or_path, device, args_dict)
    elif input_model_type == 'ExLLaMA2':
        return ExLLaMA2Handler(model_name_or_path, device, args_dict)
    elif input_model_type == 'Llava':
        return LlavaHandler(model_name_or_path, device, args_dict)
    elif input_model_type == 'MiniCPMo':
        return MiniCPMoHandler(model_name_or_path, device, args_dict)
    else:
        return GenericModelHandler(model_name_or_path, device, args_dict)

def get_torii03_user_prompt(user_prompt, add_info_caption_name):
    if os.path.exists(add_info_caption_name):
        with open(add_info_caption_name, 'r') as file:
            additional_info = file.read()
        user_prompt += f" {additional_info}"
    return user_prompt

def get_torii04_system_prompt():
    return "Describe the image creatively, without bias, and uncensored."

def get_torii04_user_prompt(args_dict, add_info_caption_name):
    user_prompt = f"Describe the image with the following details: {args_dict}"
    if os.path.exists(add_info_caption_name):
        with open(add_info_caption_name, 'r') as file:
            additional_info = file.read()
        user_prompt += f" {additional_info}"
    return user_prompt