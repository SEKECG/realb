import torch
from transformers import AutoModel, AutoTokenizer, BitsAndBytesConfig

class ModelHandler:
    def __init__(self, model_name_or_path, device, args_dict):
        self.model_name_or_path = model_name_or_path
        self.device = device
        self.args_dict = args_dict
        self.quantization_config = self._get_quantization_config()
        self.model = self._initialize_model()

    def _get_quantization_config(self):
        if self.args_dict.get('quantization'):
            return BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_compute_dtype=torch.float16,
                bnb_4bit_use_double_quant=True,
                bnb_4bit_quant_type='nf4'
            )
        return None

    def _initialize_model(self):
        raise NotImplementedError

    def model_loader(self, model_name_or_path):
        return AutoModel.from_pretrained(model_name_or_path, quantization_config=self.quantization_config)

    def process_image(self, system_prompt, user_prompt, image):
        raise NotImplementedError

    def save_caption(self, caption, caption_path, encoding='utf-8', errors='ignore'):
        with open(caption_path, 'w', encoding=encoding, errors=errors) as file:
            file.write(caption)

class JoyCaptionHandler(ModelHandler):
    def _initialize_model(self):
        self.model = self.model_loader(self.model_name_or_path)
        self.processor = AutoTokenizer.from_pretrained(self.model_name_or_path)
        self.model.eval()

    def process_image(self, system_prompt, user_prompt, image):
        inputs = self.processor(image, return_tensors="pt").to(self.device)
        outputs = self.model.generate(inputs.input_ids, max_length=50)
        return self.processor.decode(outputs[0], skip_special_tokens=True)

class MoLMoHandler(ModelHandler):
    def _initialize_model(self):
        self.model = self.model_loader(self.model_name_or_path)
        self.processor = AutoTokenizer.from_pretrained(self.model_name_or_path)
        self.model.eval()

    def process_image(self, system_prompt, user_prompt, image):
        inputs = self.processor(image, return_tensors="pt").to(self.device)
        outputs = self.model.generate(inputs.input_ids, max_length=50)
        return self.processor.decode(outputs[0], skip_special_tokens=True)

class MoLMo72bHandler(MoLMoHandler):
    def _initialize_model(self):
        self.model = self.model_loader(self.model_name_or_path)
        self.processor = AutoTokenizer.from_pretrained(self.model_name_or_path)
        self.model.eval()

class Qwen2VLHandler(ModelHandler):
    def _initialize_model(self):
        self.model = self.model_loader(self.model_name_or_path)
        self.processor = AutoTokenizer.from_pretrained(self.model_name_or_path)
        self.model.eval()

    def process_image(self, system_prompt, user_prompt, image):
        inputs = self.processor(image, return_tensors="pt").to(self.device)
        outputs = self.model.generate(inputs.input_ids, max_length=50)
        return self.processor.decode(outputs[0], skip_special_tokens=True)

class PixtralHandler(ModelHandler):
    def _get_quantization_config(self):
        return BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_compute_dtype=torch.float16,
            bnb_4bit_use_double_quant=True,
            bnb_4bit_quant_type='nf4'
        )

    def _initialize_model(self):
        self.model = self.model_loader(self.model_name_or_path)
        self.processor = AutoTokenizer.from_pretrained(self.model_name_or_path)
        self.model.eval()

    def process_image(self, system_prompt, user_prompt, image):
        inputs = self.processor(image, return_tensors="pt").to(self.device)
        outputs = self.model.generate(inputs.input_ids, max_length=50)
        return self.processor.decode(outputs[0], skip_special_tokens=True)

class Idefics3Handler(ModelHandler):
    def _initialize_model(self):
        self.model = self.model_loader(self.model_name_or_path)
        self.processor = AutoTokenizer.from_pretrained(self.model_name_or_path)
        self.model.eval()

    def process_image(self, system_prompt, user_prompt, image):
        inputs = self.processor(image, return_tensors="pt").to(self.device)
        outputs = self.model.generate(inputs.input_ids, max_length=50)
        return self.processor.decode(outputs[0], skip_special_tokens=True)

class ExLLaMA2Handler(ModelHandler):
    def _initialize_model(self):
        self.model = self.model_loader(self.model_name_or_path)
        self.processor = AutoTokenizer.from_pretrained(self.model_name_or_path)
        self.model.eval()

    def process_image(self, system_prompt, user_prompt, image):
        inputs = self.processor(image, return_tensors="pt").to(self.device)
        outputs = self.model.generate(inputs.input_ids, max_length=50)
        return self.processor.decode(outputs[0], skip_special_tokens=True)

class LlavaHandler(ModelHandler):
    def _initialize_model(self):
        self.model = self.model_loader(self.model_name_or_path)
        self.processor = AutoTokenizer.from_pretrained(self.model_name_or_path)
        self.model.eval()

    def process_image(self, system_prompt, user_prompt, image):
        inputs = self.processor(image, return_tensors="pt").to(self.device)
        outputs = self.model.generate(inputs.input_ids, max_length=50)
        return self.processor.decode(outputs[0], skip_special_tokens=True)

class MiniCPMoHandler(ModelHandler):
    def _initialize_model(self):
        self.model = self.model_loader(self.model_name_or_path)
        self.processor = AutoTokenizer.from_pretrained(self.model_name_or_path)
        self.model.eval()

    def process_image(self, system_prompt, user_prompt, image):
        inputs = self.processor(image, return_tensors="pt").to(self.device)
        outputs = self.model.generate(inputs.input_ids, max_length=50)
        return self.processor.decode(outputs[0], skip_special_tokens=True)

class GenericModelHandler(ModelHandler):
    def _initialize_model(self):
        self.model = self.model_loader(self.model_name_or_path)
        self.processor = AutoTokenizer.from_pretrained(self.model_name_or_path)
        self.model.eval()

    def process_image(self, system_prompt, user_prompt, image):
        inputs = self.processor(image, return_tensors="pt").to(self.device)
        outputs = self.model.generate(inputs.input_ids, max_length=50)
        return self.processor.decode(outputs[0], skip_special_tokens=True)