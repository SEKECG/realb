import torch
from PIL import Image

GPU_TEST_ITERATIONS = 1000
GPU_TEST_SIZE = 1024

def measure_gpu_speed(device):
    torch.cuda.set_device(device)
    a = torch.randn(GPU_TEST_SIZE, GPU_TEST_SIZE, device=device)
    b = torch.randn(GPU_TEST_SIZE, GPU_TEST_SIZE, device=device)
    start = torch.cuda.Event(enable_timing=True)
    end = torch.cuda.Event(enable_timing=True)
    start.record()
    for _ in range(GPU_TEST_ITERATIONS):
        c = torch.matmul(a, b)
    end.record()
    torch.cuda.synchronize()
    return start.elapsed_time(end) / GPU_TEST_ITERATIONS

def resize_image_proportionally(image, max_width, max_height):
    width, height = image.size
    aspect_ratio = width / height
    if width > max_width:
        width = max_width
        height = int(width / aspect_ratio)
    if height > max_height:
        height = max_height
        width = int(height * aspect_ratio)
    return image.resize((width, height), Image.ANTIALIAS)