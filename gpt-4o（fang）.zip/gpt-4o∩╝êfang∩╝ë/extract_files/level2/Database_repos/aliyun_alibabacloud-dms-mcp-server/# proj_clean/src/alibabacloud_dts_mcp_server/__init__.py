def main():
    print("Alibaba Cloud DTS MCP Server is running.")

if __name__ == "__main__":
    main()