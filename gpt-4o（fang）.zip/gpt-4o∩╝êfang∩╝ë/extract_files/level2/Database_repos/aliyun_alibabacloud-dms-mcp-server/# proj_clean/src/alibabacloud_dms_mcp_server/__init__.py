def main():
    print("Alibaba Cloud DMS MCP Server is running.")

if __name__ == "__main__":
    main()