import os
from azure.kusto.data import KustoClient, KustoConnectionStringBuilder
from azure.identity import DefaultAzureCredential, WorkloadIdentityCredential

class ADXConfig:
    def __init__(self, cluster_url, database_name, tenant_id=None, client_id=None, token_file_path=None):
        self.cluster_url = cluster_url
        self.database_name = database_name
        self.tenant_id = tenant_id
        self.client_id = client_id
        self.token_file_path = token_file_path

def get_kusto_client(config):
    if config.tenant_id and config.client_id and config.token_file_path:
        credential = WorkloadIdentityCredential(
            tenant_id=config.tenant_id,
            client_id=config.client_id,
            token_file_path=config.token_file_path
        )
    else:
        credential = DefaultAzureCredential()

    kcsb = KustoConnectionStringBuilder.with_azure_token_credential(config.cluster_url, credential)
    return KustoClient(kcsb)

def execute_query(kusto_client, query):
    response = kusto_client.execute(config.database_name, query)
    return format_query_results(response.primary_results[0])

def format_query_results(result_set):
    results = []
    for row in result_set.rows:
        results.append({col: row[col] for col in result_set.columns})
    return results

def list_tables(kusto_client):
    query = ".show tables"
    return execute_query(kusto_client, query)

def get_table_schema(kusto_client, table_name):
    query = f".show table {table_name} schema"
    return execute_query(kusto_client, query)

def sample_table_data(kusto_client, table_name, sample_size):
    query = f"{table_name} | take {sample_size}"
    return execute_query(kusto_client, query)

def get_table_details(kusto_client, table_name):
    query = f".show table {table_name} details"
    return execute_query(kusto_client, query)