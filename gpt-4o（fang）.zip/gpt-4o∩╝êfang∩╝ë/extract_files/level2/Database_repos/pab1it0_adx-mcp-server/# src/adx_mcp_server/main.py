import os
from dotenv import load_dotenv
from adx_mcp_server.server import get_kusto_client, ADXConfig

def setup_environment():
    load_dotenv()
    cluster_url = os.getenv("ADX_CLUSTER_URL")
    database_name = os.getenv("ADX_DATABASE_NAME")
    tenant_id = os.getenv("TENANT_ID")
    client_id = os.getenv("CLIENT_ID")
    token_file_path = os.getenv("TOKEN_FILE_PATH")

    if not cluster_url or not database_name:
        raise ValueError("ADX_CLUSTER_URL and ADX_DATABASE_NAME must be set")

    config = ADXConfig(cluster_url, database_name, tenant_id, client_id, token_file_path)
    return config

def run_server():
    config = setup_environment()
    kusto_client = get_kusto_client(config)
    print(f"Server running with version {__version__}")
    # Additional server setup and operations can be added here

if __name__ == "__main__":
    run_server()