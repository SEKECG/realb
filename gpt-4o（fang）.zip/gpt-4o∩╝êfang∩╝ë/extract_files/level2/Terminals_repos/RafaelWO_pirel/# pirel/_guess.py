import random
import csv
import logging
from pathlib import Path

STATS_DIR = Path.home() / ".pirel_stats"
STATS_FIELDNAMES = ["question", "score"]
STATS_FILENAME = STATS_DIR / "stats.csv"
logger = logging.getLogger(__name__)

class Question:
    def __init__(self, releases):
        self.releases = releases
        self.target_release = random.choice(releases)
        self.choices = self.build_choices()

    def __repr__(self):
        return f"Question(target_release={self.target_release.version})"

    def ask(self):
        prompt = PirelPrompt(self.format_question(), choices=self.choices)
        answer = prompt()
        return answer == self.correct_answer

    def build_choices(self):
        return [self.correct_answer] + [release.version for release in self.generate_incorrect_choices()]

    @property
    def correct_answer(self):
        return self.get_target_field(self.target_release)

    def format_question(self):
        return f"What is the version of Python released on {self.target_release.released}?"

    def generate_incorrect_choices(self, k=3):
        return random.sample([release for release in self.releases if release != self.target_release], k)

class DateVersionQuestion(Question):
    def format_question(self):
        return f"When was Python {self.target_release.version} released?"

class LatestVersionQuestion(Question):
    def format_question(self):
        return "What is the latest stable version of Python?"

class ReleaseManagerVersionQuestion(Question):
    def format_question(self):
        return f"Who was the release manager for Python {self.target_release.version}?"

class VersionDateQuestion(Question):
    def format_question(self):
        return f"When was Python {self.target_release.version} released?"

class PirelPrompt:
    def __init__(self, prompt, choices, console=None, password=False, case_sensitive=False, show_default=True):
        self.prompt = prompt
        self.choices = choices
        self.console = console
        self.password = password
        self.case_sensitive = case_sensitive
        self.show_default = show_default

    def __call__(self):
        return self.prompt

def get_random_question():
    return random.choice([DateVersionQuestion, LatestVersionQuestion, ReleaseManagerVersionQuestion, VersionDateQuestion])

def store_question_score(question, score):
    STATS_DIR.mkdir(parents=True, exist_ok=True)
    with open(STATS_FILENAME, "a", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=STATS_FIELDNAMES)
        writer.writerow({"question": repr(question), "score": score})