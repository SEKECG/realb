import pathlib
import json
import datetime

CACHE_DIR = pathlib.Path.home() / ".pirel_cache"
CACHE_FILE_GLOB = "*.json"

def calc_cache_age_days(cache_file):
    cache_date = datetime.datetime.fromtimestamp(cache_file.stat().st_mtime)
    return (datetime.datetime.now() - cache_date).days

def clear(clear_all=False):
    for cache_file in CACHE_DIR.glob(CACHE_FILE_GLOB):
        if clear_all or calc_cache_age_days(cache_file) > 7:
            cache_file.unlink()

def filename():
    return CACHE_DIR / f"{datetime.date.today()}.json"

def get_latest_cache_file():
    cache_files = list(CACHE_DIR.glob(CACHE_FILE_GLOB))
    if not cache_files:
        return None
    return max(cache_files, key=lambda f: f.stat().st_mtime)

def load(cache_file):
    with open(cache_file, "r") as f:
        return json.load(f)

def save(data):
    with open(filename(), "w") as f:
        json.dump(data, f)