import re
import subprocess
import logging

PYTHON_VERSION_RE = re.compile(r"Python (\d+\.\d+\.\d+)")
logger = logging.getLogger(__name__)

class ActivePythonInfo:
    def __init__(self, command, path, version):
        self.command = command
        self.path = path
        self.version = version

    def __repr__(self):
        return f"ActivePythonInfo(command={self.command}, path={self.path}, version={self.version})"

def get_active_python_info():
    for command in ["python", "python3", "python2"]:
        try:
            result = subprocess.run([command, "--version"], capture_output=True, text=True)
            match = PYTHON_VERSION_RE.search(result.stdout)
            if match:
                version = match.group(1)
                path = subprocess.run([command, "-c", "import sys; print(sys.executable)"], capture_output=True, text=True).stdout.strip()
                return ActivePythonInfo(command, path, version)
        except FileNotFoundError:
            continue
    return None