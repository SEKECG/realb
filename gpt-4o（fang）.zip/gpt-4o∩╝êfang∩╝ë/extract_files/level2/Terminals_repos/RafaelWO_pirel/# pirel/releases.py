import datetime
import requests
from rich.table import Table
from rich.console import Console
import logging

DATE_NOW = datetime.date.today()
RELEASE_CYCLE_URL = "https://raw.githubusercontent.com/python/devguide/master/releases.json"
STATUS_TO_EMOJI = {
    "feature": "✨",
    "prerelease": "🔧",
    "bugfix": "🐛",
    "security": "🔒",
    "end-of-life": "💀"
}
STATUS_TO_TEXT = {
    "feature": "Feature",
    "prerelease": "Pre-release",
    "bugfix": "Bugfix",
    "security": "Security",
    "end-of-life": "End-of-life"
}
logger = logging.getLogger(__name__)

def load_releases():
    response = requests.get(RELEASE_CYCLE_URL)
    response.raise_for_status()
    return PythonReleases(response.json())

def date_style(date):
    return "bold"

def eol_color(eol):
    if eol < DATE_NOW:
        return "red"
    elif (eol - DATE_NOW).days < 180:
        return "dark_orange"
    elif (eol - DATE_NOW).days < 365:
        return "yellow"
    else:
        return "green"

def parse_date(date_str):
    return datetime.datetime.strptime(date_str, "%Y-%m-%d").date()

def status_style(status):
    return STATUS_TO_EMOJI.get(status, "")

def wrap_style(text, style):
    return f"[{style}]{text}[/{style}]"

class PythonReleases:
    def __init__(self, releases_data):
        self.releases = {version: PythonRelease(version, data) for version, data in releases_data.items()}

    def __getitem__(self, version):
        return self.releases[version]

    def to_list(self):
        return list(self.releases.values())

    def to_table(self, active_python_version=None):
        table = Table(title="Python Releases")
        table.add_column("Version")
        table.add_column("Status")
        table.add_column("Release Date")
        table.add_column("End-of-life Date")
        for release in self.to_list():
            table.add_row(
                release.version,
                release.status,
                release.released,
                release.end_of_life
            )
        return table

class PythonRelease:
    def __init__(self, version, data):
        self._version = version
        self._status = data["status"]
        self._released = parse_date(data["released"])
        self._end_of_life = parse_date(data["end_of_life"])
        self._release_manager = data["release_manager"]

    def __repr__(self):
        return f"PythonRelease(version={self._version})"

    def __str__(self):
        return f"{self._version} {STATUS_TO_TEXT[self._status]} {self._end_of_life}"

    @property
    def end_of_life(self):
        return wrap_style(str(self._end_of_life), eol_color(self._end_of_life))

    @property
    def is_eol(self):
        return self._status == "end-of-life"

    @property
    def released(self):
        return wrap_style(str(self._released), date_style(self._released))

    @property
    def status(self):
        return wrap_style(STATUS_TO_TEXT[self._status], status_style(self._status))

    @property
    def version(self):
        return self._version

    @property
    def version_tuple(self):
        return tuple(map(int, self._version.split(".")))