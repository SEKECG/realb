class VersionLike:
    def __eq__(self, other):
        return self.version_tuple == other.version_tuple

    def __ge__(self, other):
        return self.version_tuple >= other.version_tuple

    def __gt__(self, other):
        return self.version_tuple > other.version_tuple

    def __le__(self, other):
        return self.version_tuple <= other.version_tuple

    def __lt__(self, other):
        return self.version_tuple < other.version_tuple

    @property
    def version_tuple(self):
        return self._version_tuple