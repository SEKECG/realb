import click
from pirel import CONTEXT, __version__
from pirel.releases import PythonReleases
from pirel.python_cli import get_active_python_info
import logging

logger = logging.getLogger(__name__)

@click.group()
@click.option("--verbose", is_flag=True, help="Enable verbose output")
@click.option("--version", is_flag=True, help="Show the version and exit")
def main(verbose, version):
    if version:
        click.echo(f"pirel version {__version__}")
        return
    if verbose:
        logging.basicConfig(level=logging.DEBUG)
    else:
        logging.basicConfig(level=logging.INFO)

@main.command()
def list():
    releases = CONTEXT.releases
    table = releases.to_table()
    CONTEXT.rich_console.print(table)

@main.command()
def check():
    active_python_info = get_active_python_info()
    if active_python_info:
        click.echo(f"Active Python: {active_python_info}")
    else:
        click.echo("No active Python interpreter found.")
        exit(2)

@main.command()
def guess():
    ask_random_question()

def ask_random_question():
    # Implementation for asking random question
    pass