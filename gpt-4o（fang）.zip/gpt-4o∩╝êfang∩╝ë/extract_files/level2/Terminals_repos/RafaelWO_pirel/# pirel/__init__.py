from rich.console import Console
from pirel.releases import load_releases

CONTEXT = None
__version__ = "0.1.0"

class PirelContext:
    def __init__(self):
        self.rich_console = Console(highlight=False)

    @property
    def releases(self):
        return load_releases()