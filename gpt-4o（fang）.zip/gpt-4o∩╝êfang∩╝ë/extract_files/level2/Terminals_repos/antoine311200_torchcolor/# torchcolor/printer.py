def _addindent(s_, numSpaces):
    pass

def summarize_repeated_modules(lines):
    pass

class ModuleParam:
    pass

class Printer:
    def __init__(self, strategy):
        self.strategy = strategy

    def print(self, module, display_depth=None, display_legend=None):
        pass

    def repr_module(self, parent_module, display_depth=None, indent=None):
        pass

    def set_strategy(self, strategy, *args, **kwargs):
        pass