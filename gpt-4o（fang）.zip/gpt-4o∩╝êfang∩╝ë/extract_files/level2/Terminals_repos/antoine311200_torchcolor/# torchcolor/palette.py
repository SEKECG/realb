from dataclasses import dataclass, field
from typing import ClassVar, Dict, List

palette_autumn_foliage = []
palette_forest_greens = []
palette_lavender_dreams = []
palette_monochrome = []
palette_ocean_breeze = []
palette_pastel = []
palette_rainbow = []
palette_retro_neon = []
palette_warm_sunset = []

@dataclass
class Palette:
    name: str
    colors: List[str]
    _registry: ClassVar[Dict[str, "Palette"]] = {}
    disable_registry: bool = False

    def __post_init__(self):
        if not self.disable_registry:
            self._registry[self.name] = self

    @classmethod
    def get_palette(cls, name):
        return cls._registry.get(name)

    def __getitem__(self, index):
        return self.colors[index % len(self.colors)]

    def generate_gradient(self, n):
        return []

    @classmethod
    def get(cls, name):
        return cls._registry.get(name)