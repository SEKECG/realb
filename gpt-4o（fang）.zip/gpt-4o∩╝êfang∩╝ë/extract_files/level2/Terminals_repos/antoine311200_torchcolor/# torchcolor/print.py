from torchcolor.color import Color, reset_color

def print_color(text, text_color, bg_color=None):
    text_color_ansi = Color(text_color).to_ansi()
    bg_color_ansi = Color(bg_color).to_ansi(True) if bg_color else ""
    print(f"{bg_color_ansi}{text_color_ansi}{text}{reset_color}")

def print_more(*args, **kwargs):
    separator = kwargs.get('separator', ' ')
    styled_text = separator.join(str(arg) for arg in args)
    print(styled_text)