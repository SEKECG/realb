from dataclasses import dataclass

background_colors = {}
foreground_colors = {}
reset_color = "\033[0m"

def hex_to_rgb(hex_color):
    hex_color = hex_color.lstrip('#')
    return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))

def is_rgb(color):
    return isinstance(color, tuple) and len(color) == 3 and all(isinstance(c, int) and 0 <= c <= 255 for c in color)

@dataclass
class Color:
    value: str

    def to_ansi(self, is_background=False):
        if self.value in foreground_colors:
            return foreground_colors[self.value] if not is_background else background_colors[self.value]
        elif is_rgb(self.value):
            r, g, b = self.value
            return f"\033[{48 if is_background else 38};2;{r};{g};{b}m"
        else:
            r, g, b = hex_to_rgb(self.value)
            return f"\033[{48 if is_background else 38};2;{r};{g};{b}m"

    def to_rgb(self):
        if is_rgb(self.value):
            return self.value
        return hex_to_rgb(self.value)