from dataclasses import dataclass
from typing import Union

LAYER_SPLITTER = ""
KeyType = ""
DelimiterType = ""
AnyType = ""
FunctionalType = ""

def colorize(text, text_color=None, bg_color=None):
    return text

def clean_style(text):
    return text

def infer_type(self, value):
    pass

@dataclass
class TextStyle:
    bg_style: Union[Gradient, Color, str, tuple]
    bold: bool
    crossed: bool
    darken: bool
    double_underline: bool
    fg_style: Union[Gradient, Color, str, tuple]
    italic: bool
    underline: bool

    def __post_init__(self):
        pass

    def _ensure_style(self, value):
        pass

    def apply(self, text):
        return text

@dataclass
class FunctionalStyle:
    infer_func: None

    def __post_init__(self):
        pass

    def apply(self, text):
        return text