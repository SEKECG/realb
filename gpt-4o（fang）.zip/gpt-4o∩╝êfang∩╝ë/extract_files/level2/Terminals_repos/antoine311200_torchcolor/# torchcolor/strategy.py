from dataclasses import dataclass
from typing import Union

@dataclass
class ColorStrategy:
    _registry: dict = {}

    @classmethod
    def get_strategy(cls, key, *args, **kwargs):
        pass

    @classmethod
    def available_strategies(cls):
        pass

    @classmethod
    def create(cls, key, *args, **kwargs):
        pass

    def get_style(self, module, params):
        pass

    @classmethod
    def register(cls, key):
        pass

@dataclass
class ModuleStyle:
    extra_style: Union[TextStyle, FunctionalStyle]
    layer_style: Union[TextStyle, FunctionalStyle]
    name_style: Union[TextStyle, FunctionalStyle]

@dataclass
class ConstantColorStrategy(ColorStrategy):
    color: str

    def __init__(self, color):
        self.color = color

    def get_style(self, module, config):
        pass

@dataclass
class LayerColorStrategy(ColorStrategy):
    def get_style(self, module):
        pass

@dataclass
class TrainableStrategy(ColorStrategy):
    def get_style(self, module, config):
        pass