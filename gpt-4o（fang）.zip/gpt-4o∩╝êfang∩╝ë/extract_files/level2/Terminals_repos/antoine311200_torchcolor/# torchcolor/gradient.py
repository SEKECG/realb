from dataclasses import dataclass
from typing import List

GradientChunk = {}

@dataclass
class Gradient:
    interpolate: bool
    repeat: bool
    reverse: bool
    window_size: int

    def __post_init__(self):
        pass

    def _ensure_palette(self, palette):
        pass

    def apply(self, text):
        return []