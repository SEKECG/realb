__all__ = ['Function']

from collections import OrderedDict
from typing import Type
from nodeflow.node.variable import Variable

class Function:
    def compute(self, *args, **kwargs):
        raise NotImplementedError

    def get_parameters(self):
        return OrderedDict()

    def get_return_type(self):
        return Variable