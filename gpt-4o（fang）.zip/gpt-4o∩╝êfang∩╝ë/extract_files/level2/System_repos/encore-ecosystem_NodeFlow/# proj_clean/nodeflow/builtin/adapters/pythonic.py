__all__ = []

from nodeflow.adapter.abstract import Adapter
from nodeflow.node.variable import Variable

class Boolean2bool(Adapter):
    def compute(self, variable):
        return bool(variable.value)

class Float2float(Adapter):
    def compute(self, variable):
        return float(variable.value)

class Integer2int(Adapter):
    def compute(self, variable):
        return int(variable.value)

class PythonicAdapter(Adapter):
    def is_loses_information(self):
        return False

class bool2Boolean(Adapter):
    def compute(self, variable):
        return Boolean(variable)

class float2Float(Adapter):
    def compute(self, variable):
        return Float(variable)

class int2Integer(Adapter):
    def compute(self, variable):
        return Integer(variable)