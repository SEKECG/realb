__all__ = ['PathVariable']

from nodeflow.node.variable import Variable
import pathlib

class PathVariable(Variable):
    def __init__(self, value):
        if not isinstance(value, pathlib.Path):
            raise ValueError("value must be a pathlib.Path instance")
        super().__init__(value.resolve())

    def __truediv__(self, other):
        return self.value / other