__all__ = ['Integer', 'Float', 'Boolean']

from nodeflow.node.variable import Variable

class Integer(Variable):
    def __init__(self, value):
        super().__init__(value)

    def __add__(self, other):
        return Integer(self.value + other.value)

    def __mul__(self, other):
        return Integer(self.value * other.value)

class Float(Variable):
    def __init__(self, value):
        super().__init__(value)

    def __add__(self, other):
        return Float(self.value + other.value)

    def __mul__(self, other):
        return Float(self.value * other.value)

class Boolean(Variable):
    def __init__(self, value):
        super().__init__(value)

    def __add__(self, other):
        return Boolean(self.value or other.value)

    def __mul__(self, other):
        return Boolean(self.value and other.value)