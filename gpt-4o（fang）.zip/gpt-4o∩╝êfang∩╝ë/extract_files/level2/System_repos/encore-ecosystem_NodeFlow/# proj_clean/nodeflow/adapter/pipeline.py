__all__ = ['Pipeline']

from .abstract import Adapter

class Pipeline:
    def __init__(self):
        self._loose_information = False
        self._pipeline = []

    def add_adapter(self, adapter):
        self._pipeline.append(adapter)
        if adapter.is_loses_information():
            self._loose_information = True

    def compute(self, variable):
        for adapter in self._pipeline:
            variable = adapter.compute(variable)
        return variable

    def get_type_of_source_variable(self):
        if self._pipeline:
            return self._pipeline[0].get_type_of_source_variable()
        return None

    def get_type_of_target_variable(self):
        if self._pipeline:
            return self._pipeline[-1].get_type_of_target_variable()
        return None

    def is_loses_information(self):
        return self._loose_information