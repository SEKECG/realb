__all__ = ['Adapter']

class Adapter:
    def compute(self, variable):
        raise NotImplementedError

    def get_type_of_source_variable(self):
        return Variable

    def get_type_of_target_variable(self):
        return Variable

    def is_loses_information(self):
        return False