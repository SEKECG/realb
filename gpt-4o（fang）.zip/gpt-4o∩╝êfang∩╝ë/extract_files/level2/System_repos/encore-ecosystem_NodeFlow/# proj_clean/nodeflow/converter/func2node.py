__all__ = ['func2node']

from nodeflow.node.function import Function

def func2node(func):
    class ConvertedFunction(Function):
        def compute(self, *args, **kwargs):
            return func(*args, **kwargs)
    return ConvertedFunction()