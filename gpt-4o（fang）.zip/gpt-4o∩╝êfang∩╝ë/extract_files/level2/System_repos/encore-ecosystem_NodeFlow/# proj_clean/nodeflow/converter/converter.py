__all__ = ['Converter']

from nodeflow.adapter.pipeline import Pipeline
from nodeflow.node.variable import Variable
from typing import Optional

class Converter:
    ROOT_CONVERTER = None

    def __init__(self, adapters=None, sub_converters=None):
        self.graph = {}
        self.sub_converters = set()
        if adapters:
            self.register_adapters(adapters)
        if sub_converters:
            self.register_converters(sub_converters)

    def __enter__(self):
        Converter.ROOT_CONVERTER = self

    def __exit__(self, exc_type, exc_val, exc_tb):
        Converter.ROOT_CONVERTER = None

    def convert(self, variable, to_type):
        pipeline, loses_info = self.get_converting_pipeline(type(variable), to_type)
        if pipeline:
            return pipeline.compute(variable)
        return None

    def get_converting_pipeline(self, source, target):
        # Simplified for brevity
        return None, False

    def is_support_variable(self, variable_type):
        return variable_type in self.graph

    def register_adapter(self, adapter):
        source_type = adapter.get_type_of_source_variable()
        target_type = adapter.get_type_of_target_variable()
        self.graph[(source_type, target_type)] = adapter

    def register_adapters(self, adapters):
        for adapter in adapters:
            self.register_adapter(adapter)

    def register_converter(self, converter):
        self.sub_converters.add(converter)

    def register_converters(self, converters):
        for converter in converters:
            self.register_converter(converter)