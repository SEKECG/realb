__all__ = ['Node']

class Node:
    pass