__all__ = ['BUILTIN_CONVERTER']

from nodeflow.converter.converter import Converter
from nodeflow.builtin.adapters.numeric import *
from nodeflow.builtin.adapters.pythonic import *

BUILTIN_CONVERTER = Converter(
    adapters=[
        Boolean2Integer(), Float2Integer(), Integer2Boolean(), Integer2Float(),
        PyBool2Boolean(), PyFloat2Float(), PyInt2Integer(),
        Boolean2bool(), Float2float(), Integer2int(),
        bool2Boolean(), float2Float(), int2Integer()
    ]
)