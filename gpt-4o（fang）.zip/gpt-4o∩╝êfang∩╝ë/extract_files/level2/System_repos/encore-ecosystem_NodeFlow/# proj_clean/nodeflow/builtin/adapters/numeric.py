__all__ = []

from nodeflow.adapter.abstract import Adapter
from nodeflow.node.variable import Variable

class Boolean2Integer(Adapter):
    def compute(self, variable):
        return Integer(1 if variable.value else 0)

    def is_loses_information(self):
        return False

class Float2Integer(Adapter):
    def compute(self, variable):
        return Integer(int(variable.value))

    def is_loses_information(self):
        return True

class Integer2Boolean(Adapter):
    def compute(self, variable):
        return Boolean(variable.value != 0)

    def is_loses_information(self):
        return True

class Integer2Float(Adapter):
    def compute(self, variable):
        return Float(float(variable.value))

    def is_loses_information(self):
        return False

class PyBool2Boolean(Adapter):
    def compute(self, variable):
        return Boolean(variable)

    def is_loses_information(self):
        return False

class PyFloat2Float(Adapter):
    def compute(self, variable):
        return Float(variable)

    def is_loses_information(self):
        return False

class PyInt2Integer(Adapter):
    def compute(self, variable):
        return Integer(variable)

    def is_loses_information(self):
        return False