__all__ = ['Dispenser']

from nodeflow.node.variable import Variable

class Dispenser:
    def __init__(self, **kwargs):
        self.variables_table = kwargs

    def __rshift__(self, other):
        params = other.get_parameters()
        converted_params = {}
        for name, param_type in params.items():
            if name in self.variables_table:
                variable = self.variables_table[name]
                if isinstance(variable, param_type):
                    converted_params[name] = variable
                else:
                    converted_params[name] = Converter.ROOT_CONVERTER.convert(variable, param_type)
        return other.compute(**converted_params)