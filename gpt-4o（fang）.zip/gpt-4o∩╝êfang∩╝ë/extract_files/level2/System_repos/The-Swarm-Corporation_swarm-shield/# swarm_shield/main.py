import os
import json
import threading
import hashlib
import hmac
import time
from datetime import datetime
from typing import Dict, List, Tuple, Union
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization

class EncryptionStrength:
    STANDARD = "standard"
    ENHANCED = "enhanced"
    MAXIMUM = "maximum"

class SwarmShield:
    def __init__(self, encryption_strength, key_rotation_interval, storage_path):
        self.encryption_strength = encryption_strength
        self.key_rotation_interval = key_rotation_interval
        self.storage_path = storage_path
        self._conv_lock = threading.Lock()
        self._conversations = {}
        self._initialize_security()
        self._load_conversations()

    def _check_rotation(self):
        if time.time() - self.last_rotation > self.key_rotation_interval:
            self._rotate_keys()

    def _initialize_security(self):
        self.key_file = os.path.join(self.storage_path, "keys.json")
        if os.path.exists(self.key_file):
            with open(self.key_file, "r") as f:
                keys = json.load(f)
                self.master_key = keys["master_key"]
                self.salt = keys["salt"]
                self.hmac_key = keys["hmac_key"]
                self.last_rotation = keys["last_rotation"]
        else:
            self.master_key = os.urandom(32)
            self.salt = os.urandom(16)
            self.hmac_key = os.urandom(32)
            self.last_rotation = time.time()
            self._save_keys()

        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA512(),
            length=32,
            salt=self.salt,
            iterations=100000,
            backend=default_backend()
        )
        self.encryption_key = kdf.derive(self.master_key)
        self.iv = os.urandom(12)

    def _load_conversations(self):
        conv_file = os.path.join(self.storage_path, "conversations.json")
        if os.path.exists(conv_file):
            with open(conv_file, "r") as f:
                self._conversations = json.load(f)

    def _rotate_keys(self, initial=False):
        self.master_key = os.urandom(32)
        self.salt = os.urandom(16)
        self.hmac_key = os.urandom(32)
        self.last_rotation = time.time()
        self._save_keys()
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA512(),
            length=32,
            salt=self.salt,
            iterations=100000,
            backend=default_backend()
        )
        self.encryption_key = kdf.derive(self.master_key)
        self.iv = os.urandom(12)

    def _save_conversation(self, conversation_id):
        conv_file = os.path.join(self.storage_path, "conversations.json")
        with open(conv_file, "w") as f:
            json.dump(self._conversations, f)

    def _save_keys(self):
        keys = {
            "master_key": self.master_key,
            "salt": self.salt,
            "hmac_key": self.hmac_key,
            "last_rotation": self.last_rotation
        }
        with open(self.key_file, "w") as f:
            json.dump(keys, f)

    def add_message(self, conversation_id, agent_name, message):
        self._check_rotation()
        encrypted_message = self.protect_message(agent_name, message)
        timestamp = datetime.now().isoformat()
        with self._conv_lock:
            if conversation_id not in self._conversations:
                self._conversations[conversation_id] = []
            self._conversations[conversation_id].append({
                "agent_name": agent_name,
                "message": encrypted_message,
                "timestamp": timestamp
            })
            self._save_conversation(conversation_id)

    def backup_conversations(self, backup_dir=None):
        if backup_dir is None:
            backup_dir = os.path.join(self.storage_path, "backup")
        if not os.path.exists(backup_dir):
            os.makedirs(backup_dir)
        backup_file = os.path.join(backup_dir, f"backup_{int(time.time())}.json")
        with open(backup_file, "w") as f:
            json.dump(self._conversations, f)
        return backup_dir

    def create_conversation(self, name):
        conversation_id = hashlib.sha256(name.encode()).hexdigest()
        with self._conv_lock:
            if conversation_id not in self._conversations:
                self._conversations[conversation_id] = []
            self._save_conversation(conversation_id)
        return conversation_id

    def delete_conversation(self, conversation_id):
        with self._conv_lock:
            if conversation_id in self._conversations:
                del self._conversations[conversation_id]
                self._save_conversation(conversation_id)

    def export_conversation(self, conversation_id, format, path=None):
        if conversation_id not in self._conversations:
            return None
        conversation_data = self._conversations[conversation_id]
        if format == "json":
            export_data = json.dumps(conversation_data)
        elif format == "text":
            export_data = "\n".join([f"{msg['timestamp']} - {msg['agent_name']}: {msg['message']}" for msg in conversation_data])
        else:
            return None
        if path:
            with open(path, "w") as f:
                f.write(export_data)
        return export_data

    def get_agent_stats(self, agent_name):
        stats = {"message_count": 0, "activity_timeline": []}
        for conv in self._conversations.values():
            for msg in conv:
                if msg["agent_name"] == agent_name:
                    stats["message_count"] += 1
                    stats["activity_timeline"].append(msg["timestamp"])
        return stats

    def get_conversation_summary(self, conversation_id):
        if conversation_id not in self._conversations:
            return None
        conv = self._conversations[conversation_id]
        summary = {
            "participants": list(set([msg["agent_name"] for msg in conv])),
            "message_count": len(conv)
        }
        return summary

    def get_messages(self, conversation_id):
        if conversation_id not in self._conversations:
            return None
        conv = self._conversations[conversation_id]
        messages = [(msg["agent_name"], self.retrieve_message(msg["message"]), msg["timestamp"]) for msg in conv]
        return messages

    def protect_message(self, agent_name, message):
        if self.encryption_strength == EncryptionStrength.STANDARD:
            aesgcm = AESGCM(self.encryption_key)
            encrypted_message = aesgcm.encrypt(self.iv, message.encode(), None)
        elif self.encryption_strength == EncryptionStrength.ENHANCED:
            aesgcm = AESGCM(self.encryption_key)
            encrypted_message = aesgcm.encrypt(self.iv, message.encode(), None)
            message_hash = hashlib.sha512(encrypted_message).hexdigest()
            encrypted_message = f"{encrypted_message.hex()}:{message_hash}"
        elif self.encryption_strength == EncryptionStrength.MAXIMUM:
            aesgcm = AESGCM(self.encryption_key)
            encrypted_message = aesgcm.encrypt(self.iv, message.encode(), None)
            message_hash = hashlib.sha512(encrypted_message).hexdigest()
            hmac_signature = hmac.new(self.hmac_key, encrypted_message, hashlib.sha512).hexdigest()
            encrypted_message = f"{encrypted_message.hex()}:{message_hash}:{hmac_signature}"
        return encrypted_message

    def query_conversations(self, agent_name=None, text=None, start_date=None, end_date=None, limit=None):
        results = []
        for conv_id, conv in self._conversations.items():
            for msg in conv:
                if agent_name and msg["agent_name"] != agent_name:
                    continue
                if text and text not in msg["message"]:
                    continue
                if start_date and datetime.fromisoformat(msg["timestamp"]) < start_date:
                    continue
                if end_date and datetime.fromisoformat(msg["timestamp"]) > end_date:
                    continue
                results.append({
                    "conversation_id": conv_id,
                    "agent_name": msg["agent_name"],
                    "message": msg["message"],
                    "timestamp": msg["timestamp"]
                })
                if limit and len(results) >= limit:
                    return results
        return results

    def retrieve_message(self, encrypted_str):
        if self.encryption_strength == EncryptionStrength.STANDARD:
            aesgcm = AESGCM(self.encryption_key)
            decrypted_message = aesgcm.decrypt(self.iv, bytes.fromhex(encrypted_str), None).decode()
        elif self.encryption_strength == EncryptionStrength.ENHANCED:
            encrypted_message, message_hash = encrypted_str.split(":")
            aesgcm = AESGCM(self.encryption_key)
            decrypted_message = aesgcm.decrypt(self.iv, bytes.fromhex(encrypted_message), None).decode()
            if hashlib.sha512(bytes.fromhex(encrypted_message)).hexdigest() != message_hash:
                raise ValueError("Message integrity check failed")
        elif self.encryption_strength == EncryptionStrength.MAXIMUM:
            encrypted_message, message_hash, hmac_signature = encrypted_str.split(":")
            aesgcm = AESGCM(self.encryption_key)
            decrypted_message = aesgcm.decrypt(self.iv, bytes.fromhex(encrypted_message), None).decode()
            if hashlib.sha512(bytes.fromhex(encrypted_message)).hexdigest() != message_hash:
                raise ValueError("Message integrity check failed")
            if hmac.new(self.hmac_key, bytes.fromhex(encrypted_message), hashlib.sha512).hexdigest() != hmac_signature:
                raise ValueError("Message authenticity check failed")
        return decrypted_message