import numpy as np
import qutip as qt
from .displaced_state import DisplacedState

class FloquetAnalysis:
    def __init__(self, model, state_indices, options, init_data_to_save=None):
        self.model = model
        self.state_indices = state_indices
        self.options = options
        self.init_data_to_save = init_data_to_save

    def __str__(self):
        return f"FloquetAnalysis with model: {self.model}, state_indices: {self.state_indices}, options: {self.options}"

    def _calculate_mean_excitation(self, f_modes_ordered):
        return np.mean(f_modes_ordered)

    def _floquet_main_for_amp_range(self, amp_idxs, displaced_state, previous_coefficients, prev_f_modes_arr):
        return (amp_idxs, displaced_state, previous_coefficients, prev_f_modes_arr)

    def _place_into(self, amp_idxs, array_for_range, overall_array):
        overall_array[amp_idxs] = array_for_range
        return overall_array

    def _step_in_amp(self, f_modes_energies, prev_f_modes):
        return (f_modes_energies, prev_f_modes, np.mean(f_modes_energies))

    def bare_state_array(self):
        return np.eye(self.model.hilbert_dim)

    def identify_floquet_modes(self, f_modes_energies, params_0, displaced_state, previous_coefficients):
        return np.array([np.dot(f_modes_energies, previous_coefficients)])

    def run(self, filepath):
        return {"filepath": filepath}

    def run_one_floquet(self, omega_d_amp):
        return (np.array([omega_d_amp]), qt.Qobj(np.eye(self.model.hilbert_dim)))