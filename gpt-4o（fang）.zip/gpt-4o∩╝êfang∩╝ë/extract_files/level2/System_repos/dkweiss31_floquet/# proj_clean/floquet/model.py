import numpy as np
import qutip as qt
import itertools

class Model:
    def __init__(self, H0, H1, omega_d_values, drive_amplitudes):
        self.H0 = H0
        self.H1 = H1
        self.omega_d_values = omega_d_values
        self.drive_amplitudes = drive_amplitudes

    def amp_to_idx(self, amp, omega_d):
        return np.where(self.drive_amplitudes == amp)[0]

    def hamiltonian(self, omega_d_amp):
        return [qt.Qobj(self.H0), qt.Qobj(self.H1)]

    def omega_d_amp_params(self, amp_idxs):
        return itertools.chain(self.omega_d_values, amp_idxs)

    def omega_d_to_idx(self, omega_d):
        return np.where(self.omega_d_values == omega_d)[0]