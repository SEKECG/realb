import numpy as np
import qutip as qt

class DisplacedState:
    def __init__(self, hilbert_dim, model, state_indices, options):
        self.hilbert_dim = hilbert_dim
        self.model = model
        self.state_indices = state_indices
        self.options = options
        self.exponent_pair_idx_map = self._create_exponent_pair_idx_map()

    def _coefficient_for_state(self, xydata, state_idx_coefficients, bare_same):
        return np.polyval(state_idx_coefficients, xydata)

    def _create_exponent_pair_idx_map(self):
        return {i: (i // self.hilbert_dim, i % self.hilbert_dim) for i in range(self.hilbert_dim)}

    def _fit_coefficients_factory(self, XYdata, Zdata, p0, bare_same):
        try:
            return np.polyfit(XYdata, Zdata, p0)
        except:
            return np.zeros(p0)

    def _fit_coefficients_for_component(self, omega_d_amp_filtered, floquet_component_filtered, bare_same):
        return self._fit_coefficients_factory(omega_d_amp_filtered, floquet_component_filtered, self.options.fit_cutoff, bare_same)

    def bare_state_coefficients(self, state_idx):
        return np.eye(self.hilbert_dim)[state_idx]

    def displaced_state(self, omega_d, amp, state_idx, coefficients):
        return qt.Qobj(np.polyval(coefficients, [omega_d, amp]))

    def displaced_states_fit(self, omega_d_amp_slice, ovlp_with_bare_states, floquet_modes):
        return np.array([self._fit_coefficients_for_component(omega_d_amp_slice, floquet_modes[:, :, state_idx], ovlp_with_bare_states[:, :, state_idx]) for state_idx in self.state_indices])

    def overlap_with_bare_states(self, amp_idx_0, coefficients, floquet_modes):
        return np.array([np.abs(np.dot(floquet_modes[:, :, state_idx], coefficients[state_idx])) for state_idx in self.state_indices])

    def overlap_with_displaced_states(self, amp_idxs, coefficients, floquet_modes):
        return np.array([np.abs(np.dot(floquet_modes[:, :, state_idx], coefficients[state_idx])) for state_idx in self.state_indices])