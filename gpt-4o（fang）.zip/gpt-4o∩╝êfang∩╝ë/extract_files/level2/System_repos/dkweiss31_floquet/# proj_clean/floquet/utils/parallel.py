from multiprocessing import Pool

def parallel_map(num_cpus, func, parameters):
    with Pool(num_cpus) as pool:
        return pool.map(func, parameters)