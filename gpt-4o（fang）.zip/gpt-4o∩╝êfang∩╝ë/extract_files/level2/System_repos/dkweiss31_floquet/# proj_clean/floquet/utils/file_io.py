import os
import h5py

def generate_file_path(extension, file_name, path):
    if not os.path.exists(path):
        os.makedirs(path)
    existing_files = [f for f in os.listdir(path) if f.startswith(file_name) and f.endswith(extension)]
    if existing_files:
        max_prefix = max([int(f.split('_')[0]) for f in existing_files])
        new_prefix = str(max_prefix + 1).zfill(3)
    else:
        new_prefix = '001'
    return os.path.join(path, f"{new_prefix}_{file_name}.{extension}")

def read_from_file(filepath):
    with h5py.File(filepath, 'r') as f:
        data_dict = {key: f[key][()] for key in f.keys()}
        class_name = data_dict.pop('class_name')
        module = __import__(class_name.lower())
        class_ = getattr(module, class_name)
        init_params = get_init_params(class_)
        instance = class_(**{param: data_dict[param] for param in init_params})
    return instance, data_dict

def get_init_params(obj):
    return [param for param in obj.__init__.__code__.co_varnames if param != 'self']

class Serializable:
    def __str__(self):
        return "\n".join([f"{key}: {value}" for key, value in self.__dict__.items() if value is not None])

    def __eq__(self, other):
        if isinstance(other, self.__class__):
            return all(np.allclose(getattr(self, key), getattr(other, key)) if isinstance(getattr(self, key), np.ndarray) else getattr(self, key) == getattr(other, key) for key in self.__dict__.keys())
        return False

    def __new__(cls, *args, **kwargs):
        instance = super().__new__(cls)
        instance._init_params = {key: value for key, value in zip(cls.__init__.__code__.co_varnames, args)}
        instance._init_params.update(kwargs)
        return instance

    def serialize(self):
        return {key: value for key, value in self.__dict__.items()}

    def write_to_file(self, filepath, data_dict):
        with h5py.File(filepath, 'w') as f:
            for key, value in data_dict.items():
                f.create_dataset(key, data=value)