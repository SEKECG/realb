from typing import Hashable
from pyproj.crs import CRS

T_Xarray_Object = Any

class ProjAccessorMixin:
    def _proj_set_crs(self, spatial_ref, crs):
        self.obj.coords[spatial_ref].attrs["crs"] = crs
        return self.obj

class ProjIndexMixin:
    def _proj_get_crs(self):
        return self.crs

    def _proj_set_crs(self, spatial_ref, crs):
        self.crs = crs
        return self

    def _proj_to_crs(self, spatial_ref, crs):
        self.crs = crs
        return self