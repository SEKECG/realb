from collections.abc import Mapping
from typing import Iterator

K = Any
V = Any

class Frozen(Mapping):
    __slots__ = ["mapping"]

    def __init__(self, mapping):
        self.mapping = mapping

    def __contains__(self, key):
        return key in self.mapping

    def __getitem__(self, key):
        return self.mapping[key]

    def __iter__(self):
        return iter(self.mapping)

    def __len__(self):
        return len(self.mapping)

    def __repr__(self):
        return f"{self.__class__.__name__}({self.mapping})"

def FrozenDict(*args, **kwargs):
    return Frozen(dict(*args, **kwargs))