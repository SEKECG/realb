from pyproj.crs import CRS
from xarray import Index

class CRSIndex(Index):
    def __init__(self, crs):
        self.crs = CRS.from_user_input(crs)

    def __repr__(self):
        return f"{self.__class__.__name__}\n{self.crs}"

    def _repr_inline_(self, max_width):
        crs_str = str(self.crs)
        if len(crs_str) > max_width:
            crs_str = crs_str[:max_width - 3] + "..."
        return crs_str

    @property
    def crs(self):
        return self.crs

    def equals(self, other):
        return self.crs == other.crs

    @classmethod
    def from_variables(cls, variables, options):
        if len(variables) != 1:
            raise ValueError("CRSIndex can only be created from a single scalar variable.")
        crs = options.get("crs")
        if crs is None:
            raise ValueError("CRS must be provided.")
        return cls(crs)