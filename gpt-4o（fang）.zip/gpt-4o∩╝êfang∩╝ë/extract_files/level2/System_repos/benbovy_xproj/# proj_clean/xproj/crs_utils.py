from pyproj.crs import CRS

def format_compact_cf(crs):
    return {"crs_wkt": crs.to_wkt()}

def format_full_cf_gdal(crs):
    return {
        "crs_wkt": crs.to_wkt(),
        "spatial_ref": crs.to_wkt(),
        **crs.to_cf()
    }