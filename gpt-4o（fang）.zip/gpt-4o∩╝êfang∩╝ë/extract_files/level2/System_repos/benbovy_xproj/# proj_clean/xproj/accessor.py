import xarray as xr
from .index import CRSIndex
from .utils import Frozen
from typing import Any, Mapping, Hashable

T_AccessorClass = Any

def register_accessor(accessor_cls):
    # Decorator for registering a geospatial, CRS-dependent Xarray accessor.
    return accessor_cls

def either_dict_or_kwargs(positional, keyword, func_name):
    # Resolve combination of positional and keyword arguments.
    return keyword if positional is None else positional

def is_crs_aware(index):
    # Determine whether a given xarray Index is CRS-aware.
    return isinstance(index, ProjIndexMixin) or hasattr(index, "_proj_get_crs")

class ProjAccessor:
    def __init__(self, obj):
        self.obj = obj
        self._cache_all_crs_indexes()

    def __call__(self, coord_name):
        return CRSProxy(self.obj, coord_name, self._get_crs_index(coord_name).crs)

    def _cache_all_crs_indexes(self):
        self.crs_indexes = {name: index for name, index in self.obj.xindexes.items() if isinstance(index, CRSIndex)}
        self.crs_aware_indexes = {name: index for name, index in self.obj.xindexes.items() if is_crs_aware(index)}

    def _get_crs_index(self, coord_name):
        if coord_name not in self.obj.coords:
            raise KeyError(f"Coordinate {coord_name} not found.")
        index = self.obj.xindexes.get(coord_name)
        if not isinstance(index, CRSIndex):
            raise TypeError(f"Coordinate {coord_name} does not have a CRSIndex.")
        return index

    def _update_crs_info(self, spatial_ref, func):
        if spatial_ref:
            crs_index = self._get_crs_index(spatial_ref)
            crs_index.crs = func(crs_index.crs)
        else:
            for crs_index in self.crs_indexes.values():
                crs_index.crs = func(crs_index.crs)
        return self.obj

    def assert_one_crs_index(self):
        if len(self.crs_indexes) != 1:
            raise AssertionError("Expected exactly one CRS-indexed coordinate.")

    def assign_crs(self, spatial_ref_crs=None, allow_override=False, **spatial_ref_crs_kwargs):
        spatial_ref_crs = either_dict_or_kwargs(spatial_ref_crs, spatial_ref_crs_kwargs, "assign_crs")
        for coord_name, crs in spatial_ref_crs.items():
            if coord_name in self.obj.coords and not allow_override:
                raise ValueError(f"Coordinate {coord_name} already has an index.")
            self.obj.coords[coord_name].attrs["crs"] = crs
            self.obj.set_xindex(coord_name, CRSIndex(crs))
        return self.obj

    def clear_crs_info(self, spatial_ref=None):
        return self._update_crs_info(spatial_ref, lambda crs: None)

    @property
    def crs(self):
        self.assert_one_crs_index()
        return next(iter(self.crs_indexes.values())).crs

    @property
    def crs_aware_indexes(self):
        return Frozen(self.crs_aware_indexes)

    @property
    def crs_indexes(self):
        return Frozen(self.crs_indexes)

    def map_crs(self, spatial_ref_coords=None, allow_override=False, transform=False, **spatial_ref_coords_kwargs):
        spatial_ref_coords = either_dict_or_kwargs(spatial_ref_coords, spatial_ref_coords_kwargs, "map_crs")
        for spatial_ref, target_coord in spatial_ref_coords.items():
            crs_index = self._get_crs_index(spatial_ref)
            target_index = self.obj.xindexes.get(target_coord)
            if not is_crs_aware(target_index):
                raise TypeError(f"Coordinate {target_coord} does not have a CRS-aware index.")
            if not allow_override and target_index._proj_get_crs() is not None:
                raise ValueError(f"Coordinate {target_coord} already has a CRS.")
            target_index._proj_set_crs(spatial_ref, crs_index.crs)
            if transform:
                target_index._proj_to_crs(spatial_ref, crs_index.crs)
        return self.obj

    def write_crs_info(self, spatial_ref=None, func=None):
        func = func or format_compact_cf
        return self._update_crs_info(spatial_ref, func)

class CRSProxy:
    def __init__(self, obj, coord_name, crs):
        self.obj = obj
        self.coord_name = coord_name
        self.crs = crs

    @property
    def crs(self):
        return self.crs