__all__ = ["main"]

def main():
    print("Semgrep MCP package initialized.")