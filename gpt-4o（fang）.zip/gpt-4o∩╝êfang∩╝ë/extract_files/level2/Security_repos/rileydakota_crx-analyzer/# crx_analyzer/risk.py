from .models import RiskLevel, ChromePermission, RiskReport

permissions_risk_map = {
    ChromePermission.ALARMS: RiskLevel.NONE,
    ChromePermission.ACTIVE_TAB: RiskLevel.LOW,
    ChromePermission.BOOKMARKS: RiskLevel.MEDIUM,
    ChromePermission.CLIPBOARD_READ: RiskLevel.HIGH,
    ChromePermission.COOKIES: RiskLevel.CRITICAL,
    # Add other permissions here
}

risk_score_map = {
    RiskLevel.NONE: 0,
    RiskLevel.LOW: 20,
    RiskLevel.MEDIUM: 50,
    RiskLevel.HIGH: 80,
    RiskLevel.CRITICAL: 100,
}

def get_risk_report(extension):
    risk_levels = [get_risk_level(permission) for permission in extension.permissions]
    risk_score = sum(get_risk_score(level) for level in risk_levels) / len(risk_levels)
    return RiskReport(
        name=extension.name,
        version=extension.version,
        author=extension.author,
        permissions=extension.permissions,
        risk_levels=risk_levels,
        risk_score=risk_score,
        javascript_files=extension.javascript_files,
        urls=extension.urls,
        sha256=extension.sha256,
    )

def get_risk_level(permission):
    return permissions_risk_map.get(permission, RiskLevel.NONE)

def get_risk_score(risk_level):
    return risk_score_map[risk_level]