from typing import Optional, Dict, Any, List, Union
from pydantic import BaseModel, HttpUrl

class RiskLevel:
    NONE = "None"
    LOW = "Low"
    MEDIUM = "Medium"
    HIGH = "High"
    CRITICAL = "Critical"

class ChromeManifest(BaseModel):
    manifest_version: int
    name: Optional[str]
    version: Optional[str]
    author: Optional[str]
    homepage_url: Optional[str]
    permissions: Optional[List[Union[str, Any]]]
    background: Optional[Dict[str, Any]]
    content_scripts: Optional[List[Dict[str, Any]]]
    icons: Optional[Dict[str, str]]
    options_ui: Optional[Dict[str, Any]]
    web_accessible_resources: Optional[List[Union[Dict[str, Any], str]]]

class BackgroundConfig(BaseModel):
    persistent: bool
    scripts: Optional[List[str]]
    service_worker: Optional[str]

class ChromePermission:
    ACCESSIBILITY_FEATURES_MODIFY = "accessibilityFeatures.modify"
    ACCESSIBILITY_FEATURES_READ = "accessibilityFeatures.read"
    ACTIVE_TAB = "activeTab"
    ALARMS = "alarms"
    AUDIO = "audio"
    BACKGROUND = "background"
    BOOKMARKS = "bookmarks"
    BROWSING_DATA = "browsingData"
    CERTIFICATE_PROVIDER = "certificateProvider"
    CLIPBOARD_READ = "clipboardRead"
    CLIPBOARD_WRITE = "clipboardWrite"
    CONTENT_SETTINGS = "contentSettings"
    CONTEXT_MENUS = "contextMenus"
    COOKIES = "cookies"
    DEBUGGER = "debugger"
    DECLARATIVE_CONTENT = "declarativeContent"
    DECLARATIVE_NET_REQUEST = "declarativeNetRequest"
    DECLARATIVE_NET_REQUEST_FEEDBACK = "declarativeNetRequestFeedback"
    DECLARATIVE_NET_REQUEST_WITH_HOST_ACCESS = "declarativeNetRequestWithHostAccess"
    DECLARATIVE_WEB_REQUEST = "declarativeWebRequest"
    DESKTOP_CAPTURE = "desktopCapture"
    DISPLAY_SOURCE = "displaySource"
    DNS = "dns"
    DOCUMENT_SCAN = "documentScan"
    DOWNLOADS = "downloads"
    DOWNLOADS_OPEN = "downloads.open"
    DOWNLOADS_UI = "downloads.ui"
    ENTERPRISE_DEVICE_ATTRIBUTES = "enterprise.deviceAttributes"
    ENTERPRISE_HARDWARE_PLATFORM = "enterprise.hardwarePlatform"
    ENTERPRISE_NETWORKING_ATTRIBUTES = "enterprise.networkingAttributes"
    ENTERPRISE_PLATFORM_KEYS = "enterprise.platformKeys"
    EXPERIMENTAL = "experimental"
    FAVICON = "favicon"
    FILE_BROWSER_HANDLER = "fileBrowserHandler"
    FILE_SYSTEM_PROVIDER = "fileSystemProvider"
    FONT_SETTINGS = "fontSettings"
    GCM = "gcm"
    GEOLOCATION = "geolocation"
    HISTORY = "history"
    IDENTITY = "identity"
    IDENTITY_EMAIL = "identity.email"
    IDLE = "idle"
    LOGIN_STATE = "loginState"
    MANAGEMENT = "management"
    NATIVE_MESSAGING = "nativeMessaging"
    NOTIFICATIONS = "notifications"
    OFFSCREEN = "offscreen"
    PAGE_CAPTURE = "pageCapture"
    PLATFORM_KEYS = "platformKeys"
    POWER = "power"
    PRINTER_PROVIDER = "printerProvider"
    PRINTING = "printing"
    PRINTING_METRICS = "printingMetrics"
    PRIVACY = "privacy"
    PROCESSES = "processes"
    PROXY = "proxy"
    READING_LIST = "readingList"
    RUNTIME = "runtime"
    SCRIPTING = "scripting"
    SEARCH = "search"
    SESSIONS = "sessions"
    SIDE_PANEL = "sidePanel"
    STORAGE = "storage"
    SYSTEM_CPU = "system.cpu"
    SYSTEM_DISPLAY = "system.display"
    SYSTEM_MEMORY = "system.memory"
    SYSTEM_STORAGE = "system.storage"
    TABS = "tabs"
    TAB_CAPTURE = "tabCapture"
    TAB_GROUPS = "tabGroups"
    TOP_SITES = "topSites"
    TTS = "tts"
    TTS_ENGINE = "ttsEngine"
    UNLIMITED_STORAGE = "unlimitedStorage"
    VPN_PROVIDER = "vpnProvider"
    WALLPAPER = "wallpaper"
    WEB_AUTHENTICATION_PROXY = "webAuthenticationProxy"
    WEB_NAVIGATION = "webNavigation"
    WEB_REQUEST = "webRequest"
    WEB_REQUEST_BLOCKING = "webRequestBlocking"

class CrossOriginPolicy(BaseModel):
    pass

class ExternallyConnectable(BaseModel):
    accepts_tls_channel_id: Optional[bool]
    ids: Optional[List[str]]
    matches: Optional[List[str]]

class FileSystemProviderCapabilities(BaseModel):
    configurable: bool
    multiple_mounts: bool
    source: str

class ImportConfig(BaseModel):
    pass

class IncognitoMode:
    NOT_ALLOWED = "not_allowed"
    SPANNING = "spanning"
    SPLIT = "split"

class OmniboxConfig(BaseModel):
    pass

class OptionsUI(BaseModel):
    chrome_style: bool

class PermissionRiskMapping(BaseModel):
    pass

class RiskReport(BaseModel):
    pass

class SidePanel(BaseModel):
    default_path: Optional[str]

class Storage(BaseModel):
    pass