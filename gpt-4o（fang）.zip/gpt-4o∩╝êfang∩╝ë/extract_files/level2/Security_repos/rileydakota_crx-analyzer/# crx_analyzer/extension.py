import os
import zipfile
import hashlib
from .models import ChromeManifest

class Browser:
    CHROME = "chrome"
    EDGE = "edge"

class InvalidExtensionIDError(Exception):
    pass

class Extension:
    def __init__(self, extension_id, browser, working_dir):
        self.extension_id = extension_id
        self.browser = browser
        self.working_dir = working_dir
        self.extension_zip_path = os.path.join(working_dir, f"{extension_id}.zip")
        self.extension_dir_path = os.path.join(working_dir, extension_id)
        self.download_url = self.__get_download_url()
        self.manifest = None
        self.permissions = []
        self.javascript_files = []
        self.urls = []
        self.sha256 = None

    def __enter__(self):
        self.__download_extension()
        self.__unzip_extension()
        self.manifest = self.__get_manifest()
        self.permissions = self.manifest.permissions or []
        self.javascript_files = self.__get_javascript_files()
        self.urls = self.__get_urls()
        self.sha256 = self.__calculate_sha256()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        pass

    def __get_download_url(self):
        if self.browser == Browser.CHROME:
            return get_chrome_extension_url(self.extension_id)
        elif self.browser == Browser.EDGE:
            return get_edge_extension_url(self.extension_id)
        else:
            raise InvalidExtensionIDError(f"Invalid browser: {self.browser}")

    def __download_extension(self):
        download_extension(self.download_url, self.extension_zip_path)

    def __unzip_extension(self):
        with zipfile.ZipFile(self.extension_zip_path, 'r') as zip_ref:
            zip_ref.extractall(self.extension_dir_path)

    def __get_manifest(self):
        manifest_path = os.path.join(self.extension_dir_path, "manifest.json")
        with open(manifest_path, 'r') as file:
            return ChromeManifest.parse_raw(file.read())

    def __get_javascript_files(self):
        js_files = []
        for root, _, files in os.walk(self.extension_dir_path):
            for file in files:
                if file.endswith(".js"):
                    js_files.append(os.path.join(root, file))
        return js_files

    def __get_urls(self):
        urls = []
        for js_file in self.javascript_files:
            with open(js_file, 'r') as file:
                content = file.read()
                urls.extend(self.__extract_urls(content))
        return urls

    def __extract_urls(self, content):
        # Dummy implementation for URL extraction
        return []

    def __calculate_sha256(self):
        sha256_hash = hashlib.sha256()
        with open(self.extension_zip_path, "rb") as file:
            for byte_block in iter(lambda: file.read(4096), b""):
                sha256_hash.update(byte_block)
        return sha256_hash.hexdigest()

    @property
    def author(self):
        return self.manifest.author

    @property
    def homepage_url(self):
        return self.manifest.homepage_url

    @property
    def javascript_files(self):
        return self.javascript_files

    @property
    def manifest_version(self):
        return self.manifest.manifest_version

    @property
    def name(self):
        return self.manifest.name

    @property
    def permissions(self):
        return self.permissions

    @property
    def urls(self):
        return self.urls

    @property
    def version(self):
        return self.manifest.version