from textual.widget import Widget

class CustomRichLog(Widget):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.border_title = "Log"
        self.border_subtitle = "v1.0"
        self.display = False