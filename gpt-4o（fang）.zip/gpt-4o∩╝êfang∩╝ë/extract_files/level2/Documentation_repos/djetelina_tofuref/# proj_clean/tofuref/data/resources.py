class Resource:
    def __init__(self, raw_json=None):
        self.raw_json = raw_json
        self._content = None

    def __gt__(self, other):
        return self.raw_json["name"] > other.raw_json["name"]

    def __hash__(self):
        return hash((self.raw_json["provider"], self.raw_json["type"], self.raw_json["name"]))

    def __lt__(self, other):
        return self.raw_json["name"] < other.raw_json["name"]

    def __rich__(self):
        return f"{self.raw_json['type']} {self.raw_json['name']}"

    def __str__(self):
        return f"[cyan]{self.raw_json['type']}[/cyan] {self.raw_json['name']}"

    @property
    def content(self):
        return self._content or self.raw_json.get("content", "")

class ResourceType:
    GUIDE = "guide"
    RESOURCE = "resource"
    DATASOURCE = "datasource"
    FUNCTION = "function"