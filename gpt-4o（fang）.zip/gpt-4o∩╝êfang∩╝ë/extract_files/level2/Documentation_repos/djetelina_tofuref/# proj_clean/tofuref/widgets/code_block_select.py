from textual.widget import Widget

class CodeBlockSelect(Widget):
    BINDINGS = []

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.border_title = "Code Blocks"
        self.highlighted = None

    def action_close(self):
        self.parent.remove(self)

    def on_option_selected(self, option):
        pass

    def set_new_options(self, code_blocks):
        self.highlighted = code_blocks[0] if code_blocks else None