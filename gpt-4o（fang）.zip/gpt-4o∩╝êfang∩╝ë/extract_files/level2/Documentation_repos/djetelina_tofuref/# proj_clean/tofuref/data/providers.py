from .resources import Resource

class Provider:
    def __init__(self, raw_json=None, log_widget=None):
        self.raw_json = raw_json
        self.log_widget = log_widget
        self._active_version = None
        self._endpoint = None
        self._overview = None
        self.datasources = []
        self.functions = []
        self.guides = []
        self.resources = []
        self.versions = []

    @property
    def active_version(self):
        if not self._active_version:
            self._active_version = self.versions[0]["id"]
        return self._active_version

    @active_version.setter
    def active_version(self, value):
        self._active_version = value

    @property
    def display_name(self):
        return f"{self.raw_json['organization']}/{self.raw_json['name']}"

    @classmethod
    def from_json(cls, data):
        provider = cls(raw_json=data)
        provider.versions = data.get("versions", [])
        provider.load_resources()
        return provider

    def load_resources(self):
        self.resources = [Resource(r) for r in self.raw_json.get("resources", [])]
        self.datasources = [Resource(r) for r in self.raw_json.get("datasources", [])]
        self.functions = [Resource(r) for r in self.raw_json.get("functions", [])]
        self.guides = [Resource(r) for r in self.raw_json.get("guides", [])]

    def overview(self):
        return self._overview or self.raw_json.get("overview", "")

    @property
    def use_configuration(self):
        return self.raw_json.get("use_configuration", "")