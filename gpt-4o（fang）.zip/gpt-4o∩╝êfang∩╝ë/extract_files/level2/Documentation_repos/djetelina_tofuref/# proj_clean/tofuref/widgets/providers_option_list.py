from textual.widget import Widget
from ..data.providers import Provider

LOGGER = logging.getLogger(__name__)

class ProvidersOptionList(Widget):
    BINDINGS = []

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.border_title = "Providers"
        self.border_subtitle = None

    def load_index(self):
        return {}

    def on_option_selected(self, option):
        pass

    def populate(self, providers=None):
        self.border_subtitle = f"{len(providers)} providers" if providers else "All providers"