from textual.widget import Widget

class ContentWindow(Widget):
    ALLOW_MAXIMIZE = True
    BINDINGS = []

    def __init__(self, content, **kwargs):
        super().__init__(**kwargs)
        self.content = content
        self.show_table_of_contents = False

    def action_down(self):
        pass

    def action_page_down(self):
        pass

    def action_page_up(self):
        pass

    def action_scroll_end(self):
        pass

    def action_scroll_home(self):
        pass

    def action_toggle_toc(self):
        pass

    def action_up(self):
        pass

    def action_yank(self):
        pass

    def go(self, location):
        pass

    def update(self, markdown):
        self.content = markdown