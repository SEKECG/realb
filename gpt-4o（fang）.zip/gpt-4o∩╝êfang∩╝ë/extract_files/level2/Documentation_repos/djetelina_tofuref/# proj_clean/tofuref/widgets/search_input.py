from textual.widget import Widget

class SearchInput(Widget):
    BINDINGS = []

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.border_title = "Search"

    def action_close(self):
        pass