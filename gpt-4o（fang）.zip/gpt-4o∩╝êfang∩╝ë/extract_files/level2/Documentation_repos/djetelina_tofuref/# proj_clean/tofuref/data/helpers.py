import json
import logging
import re
from pathlib import Path

CODEBLOCK_REGEX = re.compile(r"```(.*?)```", re.DOTALL)
LOGGER = logging.getLogger(__name__)

def cached_file_path(endpoint):
    return Path(f"cache/{endpoint.replace('/', '_')}")

def get_from_cache(endpoint):
    path = cached_file_path(endpoint)
    if path.exists() and not is_provider_index_expired(path):
        with path.open() as f:
            return f.read()
    return None

def get_registry_api(endpoint, json=True, log_widget=None, timeout=10):
    cached_content = get_from_cache(endpoint)
    if cached_content:
        return jsonlib.loads(cached_content) if json else cached_content

    response = requests.get(f"https://registry.opentofu.com/{endpoint}", timeout=timeout)
    if log_widget:
        log_widget.log(f"GET {endpoint} - {response.status_code}")
    content = response.json() if json else response.text
    save_to_cache(endpoint, content)
    return content

def header_markdown_split(contents):
    if contents.startswith("---"):
        header, _, body = contents.partition("---\n")
        return yaml.safe_load(header), body
    return {}, contents

def is_provider_index_expired(file, timeout=31*24*60*60):
    return (time.time() - file.stat().st_mtime) > timeout

def save_to_cache(endpoint, contents):
    path = cached_file_path(endpoint)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w") as f:
        f.write(contents)