from textual.widget import Widget

class ResourcesOptionList(Widget):
    BINDINGS = []

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.border_title = "Resources"
        self.border_subtitle = None
        self.highlighted = None
        self.loading = False

    def load_provider_resources(self, provider):
        pass

    def on_option_selected(self, option):
        pass

    def populate(self, provider, resources=None):
        self.border_subtitle = f"{len(resources)} resources" if resources else "All resources"