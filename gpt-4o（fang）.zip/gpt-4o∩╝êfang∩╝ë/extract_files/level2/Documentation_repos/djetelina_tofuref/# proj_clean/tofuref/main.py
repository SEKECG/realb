import logging
from textual.app import App
from textual.widgets import Header, Footer
from .widgets import (
    CodeBlockSelect,
    ContentWindow,
    CustomRichLog,
    ProvidersOptionList,
    ResourcesOptionList,
    SearchInput,
)
from .data.providers import Provider

LOGGER = logging.getLogger(__name__)

class TofuRefApp(App):
    BINDINGS = []
    CSS_PATH = "styles.css"
    ESCAPE_TO_MINIMIZE = True
    TITLE = "TofuRef"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.active_provider = None
        self.active_resource = None
        self.code_block_selector = CodeBlockSelect()
        self.content_markdown = ContentWindow("")
        self.fullscreen_mode = False
        self.log_widget = CustomRichLog()
        self.navigation_providers = ProvidersOptionList()
        self.navigation_resources = ResourcesOptionList()
        self.providers = []
        self.search = SearchInput()

    def action_content(self):
        pass

    def action_fullscreen(self):
        pass

    def action_log(self):
        pass

    def action_providers(self):
        pass

    def action_resources(self):
        pass

    def action_search(self):
        pass

    def action_use(self):
        pass

    def action_version(self):
        pass

    def change_provider_version(self, event):
        pass

    def compose(self):
        pass

    def get_system_commands(self, screen):
        pass

    def on_ready(self):
        pass

    def option_list_option_selected(self, event):
        pass

    def search_input_changed(self, event):
        pass

    def search_input_submitted(self, event):
        pass

def main():
    LOGGER.info("Starting TofuRef application")
    app = TofuRefApp()
    app.run()

if __name__ == "__main__":
    main()