class TaintDetector:
    def detect_ast_taint(self, file_object, ast_tree, sink_list, vuln_prefix):
        pass