class ASCIIReport:
    def generate(self, results):
        pass