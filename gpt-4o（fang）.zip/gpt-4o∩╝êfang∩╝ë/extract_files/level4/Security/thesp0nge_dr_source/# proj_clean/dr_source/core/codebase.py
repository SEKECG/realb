import os

class FileObject:
    def __init__(self, path, content):
        self.path = path
        self.content = content

class Codebase:
    def __init__(self, root_path):
        self.root_path = root_path
        self.files = []

    def load_files(self):
        pass