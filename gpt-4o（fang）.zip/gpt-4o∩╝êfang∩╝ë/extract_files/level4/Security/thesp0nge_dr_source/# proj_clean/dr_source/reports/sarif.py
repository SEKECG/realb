class SARIFReport:
    def generate(self, results):
        pass