import re
from .base import BaseDetector

class InsecureCookieDetector(BaseDetector):
    REGEX_PATTERNS = []

    def detect(self, file_object):
        pass

    def detect_ast_from_tree(self, file_object, ast_tree):
        pass