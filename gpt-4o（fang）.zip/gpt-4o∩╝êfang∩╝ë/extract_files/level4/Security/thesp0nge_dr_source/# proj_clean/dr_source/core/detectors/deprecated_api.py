import re
from .base import BaseDetector

class DeprecatedAPIDetector(BaseDetector):
    BUILTIN_REGEX_PATTERNS = []

    def __init__(self):
        self.ast_mode = False
        self.regex_patterns = self.BUILTIN_REGEX_PATTERNS

    def detect(self, file_object):
        pass

    def detect_ast_from_tree(self, file_object, ast_tree):
        pass