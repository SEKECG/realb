import yaml

class DetectionRules:
    _instance = None

    def __init__(self):
        self.rules = {}
        self.load_rules()

    def load_rules(self):
        pass

    def get_rules(self, detector_key):
        pass

    @classmethod
    def instance(cls):
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance