def main(target_path, ast, init_db, history, compare, export, where_used, verbose, output, debug, show_trace, show_version):
    pass

get_version = None