from concurrent.futures import ThreadPoolExecutor

class Scanner:
    def __init__(self, codebase, ast_mode=False):
        self.codebase = codebase
        self.ast_mode = ast_mode
        self.detectors = []

    def scan(self):
        pass

    def scan_file(self, file_obj):
        pass