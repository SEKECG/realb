class TaintVisitor:
    def __init__(self):
        self.source_member = 'getParameter'
        self.source_qualifier = 'request'
        self.tainted = {}

    def collect_identifiers(self, expr):
        pass

    def get_vulnerabilities(self, ast_tree, sink_list):
        pass

    def is_tainted(self, expr):
        pass

    def visit(self, node):
        pass