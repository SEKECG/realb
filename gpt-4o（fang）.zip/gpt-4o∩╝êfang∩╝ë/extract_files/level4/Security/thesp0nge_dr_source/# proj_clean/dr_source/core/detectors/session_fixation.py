import re
from .base import BaseDetector

class SessionFixationDetector(BaseDetector):
    REGEX_GETSESSION = []
    REGEX_SAFE = []

    def _collect_identifiers(self, expr):
        pass

    def detect(self, file_object):
        pass

    def detect_ast_from_tree(self, file_object, ast_tree):
        pass