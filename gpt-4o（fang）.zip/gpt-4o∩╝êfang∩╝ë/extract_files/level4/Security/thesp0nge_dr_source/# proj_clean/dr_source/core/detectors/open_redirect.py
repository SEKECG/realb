import re
from .base import BaseDetector

class OpenRedirectDetector(BaseDetector):
    BUILTIN_AST_SINK = []
    BUILTIN_REGEX_PATTERNS = []

    def __init__(self):
        self.ast_mode = False
        self.ast_sink = self.BUILTIN_AST_SINK
        self.regex_patterns = self.BUILTIN_REGEX_PATTERNS

    def detect(self, file_object):
        pass

    def detect_ast_from_tree(self, file_object, ast_tree):
        pass