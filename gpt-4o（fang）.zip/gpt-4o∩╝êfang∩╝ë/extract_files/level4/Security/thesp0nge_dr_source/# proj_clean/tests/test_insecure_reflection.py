def test_insecure_reflection_detector_regex():
    pass