def test_session_fixation_detector_ast():
    pass

def test_session_fixation_detector_regex():
    pass