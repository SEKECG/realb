CMD_SAMPLE = ""
PATH_SAMPLE = ""
SERIAL_SAMPLE = ""
SQLI_SAMPLE = ""
XSS_SAMPLE = ""

def test_command_injection_detector():
    pass

def test_crypto_detector_cipher():
    pass

def test_crypto_detector_md5():
    pass

def test_crypto_detector_no_issue():
    pass

def test_crypto_detector_sha1():
    pass

def test_ldap_injection_detector():
    pass

def test_path_traversal_detector():
    pass

def test_serialization_detector():
    pass

def test_sql_injection_detector():
    pass

def test_ssrf_detector():
    pass

def test_xss_detector():
    pass

def test_xxe_detector():
    pass