def test_hardcoded_credentials_detector():
    pass