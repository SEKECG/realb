def test_deprecated_api_detector_regex():
    pass