def test_jndi_injection_detector_regex():
    pass