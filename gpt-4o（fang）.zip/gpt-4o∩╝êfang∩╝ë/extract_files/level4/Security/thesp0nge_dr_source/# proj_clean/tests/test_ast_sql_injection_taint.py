def test_sql_injection_ast_taint():
    pass