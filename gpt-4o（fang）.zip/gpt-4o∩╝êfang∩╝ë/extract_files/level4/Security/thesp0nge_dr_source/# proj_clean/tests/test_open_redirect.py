def test_open_redirect_detector_regex():
    pass