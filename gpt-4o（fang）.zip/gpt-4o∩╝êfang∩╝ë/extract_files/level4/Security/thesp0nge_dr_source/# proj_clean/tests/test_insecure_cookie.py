def test_insecure_cookie_detector_regex():
    pass