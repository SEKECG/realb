def test_file_inclusion_detector_regex():
    pass