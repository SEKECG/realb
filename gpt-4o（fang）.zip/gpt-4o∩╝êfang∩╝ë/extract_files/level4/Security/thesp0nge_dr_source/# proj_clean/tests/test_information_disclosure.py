def test_information_disclosure_detector_regex():
    pass