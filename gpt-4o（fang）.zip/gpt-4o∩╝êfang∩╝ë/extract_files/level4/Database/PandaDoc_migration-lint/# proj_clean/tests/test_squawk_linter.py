FAKE_STATEMENT = 'FAKE_STATEMENT'

def test_platform(platform, result):
    pass

def test_squawk_command(params, result_flags):
    pass

def test_unsupported_platform():
    pass