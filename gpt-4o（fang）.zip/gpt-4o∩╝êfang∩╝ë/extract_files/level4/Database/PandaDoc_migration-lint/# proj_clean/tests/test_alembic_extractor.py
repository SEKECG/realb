def test_alembic_extractor__error():
    pass

def test_alembic_extractor__ok():
    pass

def test_alembic_extractor_command__ok(command, expected_command):
    pass

def test_alembic_extractor_path__ok():
    pass