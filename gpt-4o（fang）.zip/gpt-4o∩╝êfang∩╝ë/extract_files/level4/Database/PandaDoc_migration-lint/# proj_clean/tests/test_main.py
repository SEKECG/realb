def test_main(squawk_config):
    pass