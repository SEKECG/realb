def test_flyway_extractor__ok():
    pass