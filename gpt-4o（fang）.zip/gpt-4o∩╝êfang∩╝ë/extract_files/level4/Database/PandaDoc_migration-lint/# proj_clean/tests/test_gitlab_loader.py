def test_gitlab_branch_loader():
    pass

def test_gitlab_branch_loader_default_branch():
    pass

def test_gitlab_branch_loader_not_configured():
    pass

def test_gitlab_branch_loader_on_changed_files():
    pass

def test_gitlab_mr_loader():
    pass

def test_gitlab_mr_loader_not_configured():
    pass

def test_gitlab_mr_loader_on_changed_files():
    pass