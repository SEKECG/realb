class StatementType:
    UNSUPPORTED = 'unsupported'
    RESTRICTED = 'restricted'
    BACKWARD_INCOMPATIBLE = 'backward_incompatible'
    DATA_MIGRATION = 'data_migration'
    BACKWARD_COMPATIBLE = 'backward_compatible'
    IGNORED = 'ignored'

    @property
    def colorized(self):
        return self.colorized_getter()

    def colorized_getter(self):
        return self.colorized