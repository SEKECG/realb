class FlywayExtractor:
    NAME = 'flyway'

    def is_allowed_with_backward_incompatible_migration(self, path):
        return True

    def is_migration(self, path):
        return True