class LocalLoader:
    NAME = 'local'

    def get_changed_files(self):
        return []