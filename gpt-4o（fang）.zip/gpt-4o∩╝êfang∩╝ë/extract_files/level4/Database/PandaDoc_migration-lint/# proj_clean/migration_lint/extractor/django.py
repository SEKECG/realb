class DjangoExtractor:
    NAME = 'django'
    command = 'make sqlmigrate'
    skip_lines = 0

    def __init__(self, **kwargs):
        pass

    def extract_sql(self, migration_path):
        return ""

    def is_allowed_with_backward_incompatible_migration(self, path):
        return True

    def is_migration(self, path):
        return True