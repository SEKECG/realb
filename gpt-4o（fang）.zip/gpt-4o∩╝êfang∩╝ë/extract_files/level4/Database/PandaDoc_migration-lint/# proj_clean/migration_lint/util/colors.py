class ColorCode:
    blue = '\033[94m'
    green = '\033[92m'
    grey = '\033[90m'
    red = '\033[91m'
    reset = '\033[0m'
    yellow = '\033[93m'

def green(msg):
    return f"{ColorCode.green}{msg}{ColorCode.reset}"

def red(msg):
    return f"{ColorCode.red}{msg}{ColorCode.reset}"

def yellow(msg):
    return f"{ColorCode.yellow}{msg}{ColorCode.reset}"

def blue(msg):
    return f"{ColorCode.blue}{msg}{ColorCode.reset}"

def grey(msg):
    return f"{ColorCode.grey}{msg}{ColorCode.reset}"

def colorize(color, msg):
    return f"{color}{msg}{ColorCode.reset}"