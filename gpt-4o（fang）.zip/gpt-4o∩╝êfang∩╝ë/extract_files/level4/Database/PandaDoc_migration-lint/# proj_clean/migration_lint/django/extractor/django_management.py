class DjangoManagementExtractor:
    NAME = 'django_management'

    def extract_sql(self, migration_path):
        # Extract raw SQL from the migration file
        return ""