def classify_migration(raw_sql):
    return []

def classify_statement(statement, context):
    return None