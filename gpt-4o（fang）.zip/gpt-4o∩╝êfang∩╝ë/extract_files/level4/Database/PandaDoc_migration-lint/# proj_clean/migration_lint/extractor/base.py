class BaseExtractor:
    def __init__(self, **kwargs):
        pass

    def extract_sql(self, migration_path):
        return ""

    def is_allowed_with_backward_incompatible_migration(self, path):
        return True

    def is_migration(self, path):
        return True

    def create_metadata(self, changed_files):
        return MigrationsMetadata(changed_files, [])

class Extractor:
    extractors = {}

    def get(mcls, name):
        return mcls.extractors.get(name)

    def __new__(mcls, name, bases, classdict):
        cls = super().__new__(mcls, name, bases, classdict)
        if name != 'BaseExtractor':
            mcls.extractors[name] = cls
        return cls

    def names(mcls):
        return list(mcls.extractors.keys())