class ConditionalMatch:
    def __init__(self, locator, match_by):
        self.locator = locator
        self.match_by = match_by

class KeywordLocator:
    def __init__(self, type):
        self.type = type

class SegmentLocator:
    def __init__(self, type, raw=None, children=None, inverted=False, ignore_order=False, only_with=None):
        self.type = type
        self.raw = raw
        self.children = children
        self.inverted = inverted
        self.ignore_order = ignore_order
        self.only_with = only_with