import os

def get_bool_env(var_name, default):
    value = os.getenv(var_name, default)
    return value.lower() in ['true', '1']