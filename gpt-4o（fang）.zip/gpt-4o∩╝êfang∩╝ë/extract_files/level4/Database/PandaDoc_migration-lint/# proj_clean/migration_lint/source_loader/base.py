class BaseSourceLoader:
    def __init__(self, only_new_files, **kwargs):
        self.only_new_files = only_new_files

    def get_changed_files(self):
        return []

class SourceLoader:
    source_loaders = {}

    def names(mcls):
        return list(mcls.source_loaders.keys())

    def get(mcls, name):
        return mcls.source_loaders.get(name)

    def __new__(mcls, name, bases, classdict):
        cls = super().__new__(mcls, name, bases, classdict)
        if name != 'BaseSourceLoader':
            mcls.source_loaders[name] = cls
        return cls