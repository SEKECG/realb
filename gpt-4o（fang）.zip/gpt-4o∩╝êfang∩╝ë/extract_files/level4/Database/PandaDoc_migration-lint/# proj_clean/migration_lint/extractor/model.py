class ExtendedSourceDiff:
    def __init__(self, allowed_with_backward_incompatible):
        self.allowed_with_backward_incompatible = allowed_with_backward_incompatible

    @classmethod
    def of_source_diff(cls, source_diff, allowed_with_backward_incompatible):
        return cls(allowed_with_backward_incompatible)

class Migration:
    def __init__(self, path, raw_sql):
        self.path = path
        self.raw_sql = raw_sql

class MigrationsMetadata:
    def __init__(self, changed_files, migrations):
        self.changed_files = changed_files
        self.migrations = migrations