DOCS_URL = 'https://docs.example.com'

class CompatibilityLinter:
    def lint(self, migration_sql, changed_files, report_restricted):
        # Perform SQL migration linting
        return []