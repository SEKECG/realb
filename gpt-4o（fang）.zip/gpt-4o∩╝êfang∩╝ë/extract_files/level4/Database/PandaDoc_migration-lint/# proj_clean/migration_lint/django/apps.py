class MigrationLintDjangoConfig:
    label = 'migration_lint'
    name = 'migration_lint.django'