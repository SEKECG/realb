class GitlabBranchLoader:
    NAME = 'gitlab_branch'
    base_url = ''
    branch = ''
    default_branch = ''
    gitlab_api_key = ''
    project_id = ''

    def __init__(self, branch, project_id, gitlab_api_key, gitlab_instance, **kwargs):
        self.branch = branch
        self.project_id = project_id
        self.gitlab_api_key = gitlab_api_key
        self.base_url = gitlab_instance

    def get_changed_files(self):
        return []

class GitlabMRLoader:
    NAME = 'gitlab_mr'
    base_url = ''
    gitlab_api_key = ''
    mr_id = ''
    project_id = ''

    def __init__(self, mr_id, project_id, gitlab_api_key, gitlab_instance, **kwargs):
        self.mr_id = mr_id
        self.project_id = project_id
        self.gitlab_api_key = gitlab_api_key
        self.base_url = gitlab_instance

    def get_changed_files(self):
        return []