def main(loader_type, extractor_type, squawk_config_path, squawk_pg_version, **kwargs):
    pass