CLASSIFICATION_LINK = 'classification_link'
IGNORE_LINK = 'ignore_link'
MANUALLY_IGNORE_ANNOTATION = 'migration-lint: ignore'

class Analyzer:
    def __init__(self, loader, extractor, linters):
        self.loader = loader
        self.extractor = extractor
        self.linters = linters

    def analyze(self):
        changed_files = self.loader.get_changed_files()
        for file in changed_files:
            if self.extractor.is_migration(file.path):
                migration_sql = self.extractor.extract_sql(file.path)
                for linter in self.linters:
                    linter.lint(migration_sql, changed_files)