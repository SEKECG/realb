class SquawkLinter:
    def __init__(self, config_path, pg_version):
        self.config_path = config_path
        self.pg_version = pg_version
        self.squawk = 'squawk_binary_path'

    def lint(self, migration_sql, changed_files):
        # Perform SQL migration linting
        return []

    def squawk_command(self, migration_sql):
        return f"{self.squawk} {migration_sql}"