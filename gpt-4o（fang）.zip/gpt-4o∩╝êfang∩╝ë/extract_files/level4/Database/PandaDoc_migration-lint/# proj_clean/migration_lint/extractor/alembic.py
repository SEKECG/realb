class AlembicExtractor:
    NAME = 'alembic'
    command = 'make sqlmigrate'
    migration_path = '/migrations/versions/'

    def __init__(self, **kwargs):
        pass

    def _get_migrations_sql(self):
        pass

    def extract_sql(self, migration_path):
        return ""

    def is_allowed_with_backward_incompatible_migration(self, path):
        return True

    def is_migration(self, path):
        return True