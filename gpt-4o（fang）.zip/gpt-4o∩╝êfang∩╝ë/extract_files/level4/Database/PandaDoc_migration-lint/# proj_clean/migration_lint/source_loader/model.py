class SourceDiff:
    def __init__(self, path, old_path, diff=None):
        self.path = path
        self.old_path = old_path
        self.diff = diff

    def __post_init__(self):
        if not self.old_path:
            self.old_path = self.path