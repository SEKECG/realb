from .cli import play

def play(audio, safe=True, normalize=False):
    play(audio, safe=safe, normalize=normalize)