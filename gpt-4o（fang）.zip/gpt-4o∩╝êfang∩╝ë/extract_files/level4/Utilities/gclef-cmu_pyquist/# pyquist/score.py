from typing import TypeAlias, Tuple, List
from .audio import Audio

Instrument: TypeAlias = str
PlayableScore: TypeAlias = dict
PlayableSoundEvent: TypeAlias = dict
Score: TypeAlias = dict
SoundEvent: TypeAlias = dict
_KwargsDict: TypeAlias = dict

class Metronome:
    def beat_to_time(self, beat):
        raise NotImplementedError

    def time_to_beat(self, time):
        raise NotImplementedError

class BasicMetronome(Metronome):
    def __init__(self, bpm):
        self.bpm = bpm
        self.beat_duration = 60.0 / bpm

    def beat_to_time(self, beat):
        return beat * self.beat_duration

    def time_to_beat(self, time):
        return time / self.beat_duration

def is_playable_score(obj):
    return isinstance(obj, dict) and 'events' in obj

def is_playable_sound_event(obj):
    return isinstance(obj, dict) and 'start' in obj and 'duration' in obj

def is_score(obj):
    return isinstance(obj, dict) and 'tracks' in obj

def is_sound_event(obj):
    return isinstance(obj, dict) and 'start' in obj and 'duration' in obj

def render_score(score, metronome):
    duration = max(event['start'] + event['duration'] for event in score['events'])
    audio = AudioBuffer(int(duration * metronome.beat_to_time(1)), 1)
    for event in score['events']:
        start_sample = int(metronome.beat_to_time(event['start']) * audio.sample_rate)
        end_sample = start_sample + int(metronome.beat_to_time(event['duration']) * audio.sample_rate)
        audio[0, start_sample:end_sample] += event['amplitude']
    return Audio(audio, sample_rate=audio.sample_rate)