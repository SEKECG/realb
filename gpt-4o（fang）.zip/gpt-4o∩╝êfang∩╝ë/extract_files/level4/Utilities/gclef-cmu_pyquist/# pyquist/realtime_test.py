import unittest
from .realtime import AudioProcessor, process, iter_process, Message, BlockMessage
from .audio import AudioBuffer

class MessageAudioProcessor(AudioProcessor):
    def __init__(self):
        super().__init__(1, 1)
        self.current_value = 0.0

    def process_block(self, buffer, messages):
        for message in messages:
            self.current_value = message.data
        buffer.fill(self.current_value)

class SineAudioProcessor(AudioProcessor):
    def __init__(self):
        super().__init__(1, 1)

    def process_block(self, buffer, messages):
        t = np.linspace(0, 1, buffer.shape[1], endpoint=False)
        buffer[0, :] = np.sin(2 * np.pi * 440 * t)

class TestAudioProcessing(unittest.TestCase):
    def test_audio_processor(self):
        processor = AudioProcessor(1, 1)
        self.assertEqual(processor.num_input_channels, 1)
        self.assertEqual(processor.num_output_channels, 1)
        self.assertFalse(processor.ready)
        with self.assertRaises(RuntimeError):
            _ = processor.sample_rate
        with self.assertRaises(RuntimeError):
            _ = processor.block_size

    def test_prepare_to_play(self):
        processor = SineAudioProcessor()
        processor.prepare(44100, 512)
        self.assertTrue(processor.ready)
        self.assertEqual(processor.sample_rate, 44100)
        self.assertEqual(processor.block_size, 512)

    def test_process(self):
        processor = SineAudioProcessor()
        output = process(processor, 1.0, block_size=512, sample_rate=44100)
        self.assertEqual(output.sample_rate, 44100)
        self.assertEqual(output.shape, (1, 44100))

    def test_process_messages(self):
        processor = MessageAudioProcessor()
        messages = [BlockMessage(0, 1.0), BlockMessage(256, 0.5)]
        output = process(processor, 1.0, messages=messages, block_size=512, sample_rate=44100)
        self.assertEqual(output[0, 0], 1.0)
        self.assertEqual(output[0, 256], 0.5)

    def test_release_resources(self):
        processor = SineAudioProcessor()
        processor.prepare(44100, 512)
        processor.release()
        self.assertFalse(processor.ready)
        with self.assertRaises(RuntimeError):
            _ = processor.sample_rate
        with self.assertRaises(RuntimeError):
            _ = processor.block_size

if __name__ == '__main__':
    unittest.main()