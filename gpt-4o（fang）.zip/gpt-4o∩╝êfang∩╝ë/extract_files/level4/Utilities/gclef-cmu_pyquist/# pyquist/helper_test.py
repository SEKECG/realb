import unittest
from .helper import dbfs_to_gain, gain_to_dbfs, frequency_to_pitch, pitch_to_frequency, pitch_name_to_pitch

class TestHelper(unittest.TestCase):
    def test_dbfs_gain_conversion(self):
        self.assertAlmostEqual(dbfs_to_gain(-6), 0.501187, places=5)
        self.assertAlmostEqual(gain_to_dbfs(0.501187), -6, places=1)

    def test_frequency_pitch_conversion(self):
        self.assertAlmostEqual(frequency_to_pitch(440), 69, places=1)
        self.assertAlmostEqual(pitch_to_frequency(69), 440, places=1)

    def test_pitch_name_to_pitch(self):
        self.assertEqual(pitch_name_to_pitch('C4'), 60)
        self.assertEqual(pitch_name_to_pitch('A4'), 69)
        self.assertEqual(pitch_name_to_pitch('C#4'), 61)
        self.assertEqual(pitch_name_to_pitch('Bb3'), 58)

if __name__ == '__main__':
    unittest.main()