import os

LIB_DIR = os.path.dirname(os.path.abspath(__file__))
TEST_DATA_DIR = os.path.join(LIB_DIR, 'test_data')
CACHE_DIR = os.path.join(LIB_DIR, 'cache')