import unittest

__all__ = ['load_tests']

def load_tests(loader, standard_tests, pattern):
    if pattern is None:
        pattern = "*test.py"
    suite = unittest.TestSuite()
    for all_test_suite in loader.discover('.', pattern=pattern):
        for test_suite in all_test_suite:
            suite.addTests(test_suite)
    return suite