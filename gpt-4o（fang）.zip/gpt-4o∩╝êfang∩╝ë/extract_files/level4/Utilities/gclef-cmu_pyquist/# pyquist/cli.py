import sounddevice as sd
import numpy as np
from .audio import Audio

_SD_DEFAULTS = {}
_SD_DEFAULTS_PATH = "sd_defaults.json"

def _restore_sd_defaults():
    import json
    try:
        with open(_SD_DEFAULTS_PATH, 'r') as f:
            _SD_DEFAULTS.update(json.load(f))
    except FileNotFoundError:
        pass

def _set_sd_default(name, value, write=True):
    _SD_DEFAULTS[name] = value
    if write:
        import json
        with open(_SD_DEFAULTS_PATH, 'w') as f:
            json.dump(_SD_DEFAULTS, f)

def play(audio, safe=True, normalize=False):
    if normalize:
        audio = audio.normalize(-1.0)
    sd.play(audio, samplerate=audio.sample_rate)
    sd.wait()

def record(duration, progress_bar=False, **kwargs):
    if progress_bar:
        import tqdm
        with tqdm.tqdm(total=duration) as pbar:
            def callback(indata, frames, time, status):
                pbar.update(frames / indata.shape[0])
            audio = sd.rec(int(duration * _SD_DEFAULTS['samplerate']), channels=_SD_DEFAULTS['channels'], callback=callback, **kwargs)
    else:
        audio = sd.rec(int(duration * _SD_DEFAULTS['samplerate']), channels=_SD_DEFAULTS['channels'], **kwargs)
    sd.wait()
    return Audio(audio, sample_rate=_SD_DEFAULTS['samplerate'])

def set_sd_defaults(**kwargs):
    for name, value in kwargs.items():
        _set_sd_default(name, value)