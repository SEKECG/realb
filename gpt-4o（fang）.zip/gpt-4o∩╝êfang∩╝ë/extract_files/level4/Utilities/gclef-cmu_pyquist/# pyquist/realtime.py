from typing import Iterator, Tuple, List
from .audio import AudioBuffer, Audio

class AudioProcessor:
    def __init__(self, num_input_channels, num_output_channels):
        self._num_input_channels = num_input_channels
        self._num_output_channels = num_output_channels
        self._sample_rate = None
        self._block_size = None
        self._ready = False

    def __call__(self, buffer, messages):
        self.process_block(buffer, messages)

    @property
    def block_size(self):
        if not self._ready:
            raise RuntimeError("Processor not ready")
        return self._block_size

    @property
    def num_input_channels(self):
        return self._num_input_channels

    @property
    def num_output_channels(self):
        return self._num_output_channels

    @property
    def ready(self):
        return self._ready

    @property
    def sample_rate(self):
        if not self._ready:
            raise RuntimeError("Processor not ready")
        return self._sample_rate

    def prepare(self, sample_rate, block_size):
        self._sample_rate = sample_rate
        self._block_size = block_size
        self._ready = True

    def process_block(self, buffer, messages):
        raise NotImplementedError

    def release(self):
        self._ready = False

class AudioProcessorStream:
    def __init__(self, processor, block_size, sample_rate, gain_dbfs=0.0):
        self._processor = processor
        self._block_size = block_size
        self._sample_rate = sample_rate
        self._gain_dbfs = gain_dbfs
        self._message_queue = deque()
        self._blocks_elapsed = 0
        self._seconds_per_block = block_size / sample_rate

    def start(self, *args, **kwargs):
        self._processor.prepare(self._sample_rate, self._block_size)
        self._blocks_elapsed = 0
        self._message_queue.clear()
        super().start(*args, **kwargs)

    def stop(self, *args, **kwargs):
        super().stop(*args, **kwargs)

    def abort(self, *args, **kwargs):
        super().abort(*args, **kwargs)

    def close(self, *args, **kwargs):
        self._processor.release()
        super().close(*args, **kwargs)

    def callback(self, outdata, *args, **kwargs):
        buffer = AudioBuffer(self._block_size, self._processor.num_output_channels)
        messages = []
        while self._message_queue and self._message_queue[0].time <= self._blocks_elapsed * self._seconds_per_block:
            messages.append(self._message_queue.popleft())
        self._processor(buffer, messages)
        outdata[:] = buffer * (10 ** (self._gain_dbfs / 20))
        self._blocks_elapsed += 1

    @property
    def message_queue(self):
        return self._message_queue

    def sleep(self, duration):
        import time
        time.sleep(duration)

class BlockMessage:
    def __init__(self, offset, data):
        self.offset = offset
        self.data = data

class Message:
    def __init__(self, time, data):
        self.time = time
        self.data = data

def iter_process(processor, duration, input_audio=None, messages=None, pad_end=False, block_size=512, sample_rate=44100):
    if messages is None:
        messages = []
    if input_audio is None:
        input_audio = AudioBuffer(int(duration * sample_rate), processor.num_input_channels)
    processor.prepare(sample_rate, block_size)
    blocks = int(np.ceil(duration * sample_rate / block_size))
    for i in range(blocks):
        buffer = input_audio[:, i * block_size:(i + 1) * block_size]
        processor(buffer, messages)
        yield i, buffer, messages
    if pad_end:
        buffer = AudioBuffer(block_size, processor.num_output_channels)
        processor(buffer, messages)
        yield blocks, buffer, messages

def process(processor, duration, input_audio=None, messages=None, block_size=512, sample_rate=44100):
    output_audio = AudioBuffer(int(duration * sample_rate), processor.num_output_channels)
    for i, buffer, _ in iter_process(processor, duration, input_audio, messages, block_size=block_size, sample_rate=sample_rate):
        output_audio[:, i * block_size:(i + 1) * block_size] = buffer
    return Audio(output_audio, sample_rate=sample_rate)