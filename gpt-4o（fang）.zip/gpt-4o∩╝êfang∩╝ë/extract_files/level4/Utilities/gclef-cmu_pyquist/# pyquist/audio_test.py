import unittest
from .audio import Audio, AudioBuffer

class TestAudioBuffer(unittest.TestCase):
    def test_audio(self):
        audio = Audio.from_file('test.wav')
        self.assertEqual(audio.sample_rate, 44100)
        self.assertAlmostEqual(audio.duration, 5.0, places=1)
        normalized_audio = audio.normalize(-1.0)
        self.assertAlmostEqual(normalized_audio.peak_gain, 1.0, places=1)
        clipped_audio = audio.clip(0.5)
        self.assertAlmostEqual(clipped_audio.peak_gain, 0.5, places=1)
        resampled_audio = audio.resample(22050)
        self.assertEqual(resampled_audio.sample_rate, 22050)

    def test_audio_buffer(self):
        buffer = AudioBuffer(44100, 2)
        self.assertEqual(buffer.num_channels, 2)
        self.assertEqual(buffer.num_samples, 44100)
        buffer.clear()
        self.assertTrue(np.all(buffer == 0))

if __name__ == '__main__':
    unittest.main()