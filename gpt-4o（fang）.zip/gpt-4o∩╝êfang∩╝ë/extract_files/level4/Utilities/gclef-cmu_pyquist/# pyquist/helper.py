import numpy as np

ACCIDENTALS = {'#': 1, 'b': -1}
PITCHES = {'C': 0, 'D': 2, 'E': 4, 'F': 5, 'G': 7, 'A': 9, 'B': 11}

def dbfs_to_gain(dbfs):
    return 10 ** (dbfs / 20)

def gain_to_dbfs(gain):
    return 20 * np.log10(gain)

def frequency_to_pitch(frequency):
    return 69 + 12 * np.log2(frequency / 440.0)

def pitch_to_frequency(pitch):
    return 440.0 * 2 ** ((pitch - 69) / 12)

def pitch_name_to_pitch(pitch):
    octave = int(pitch[-1])
    pitch_class = PITCHES[pitch[0].upper()]
    if len(pitch) > 2:
        pitch_class += ACCIDENTALS[pitch[1]]
    return 12 * (octave + 1) + pitch_class

def _scientific_pitch_name_to_pitch(pitch_name):
    return pitch_name_to_pitch(pitch_name)