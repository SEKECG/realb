from typing import Optional, Dict, Any

def decrypt_meta_json(meta_path, user_password):
    # Decrypt metadata JSON
    pass

def encrypt_meta_json(meta_path, meta_plain, user_password):
    # Encrypt metadata JSON
    pass