import tkinter as tk
from tkinter import filedialog

def select_file_for_encryption():
    root = tk.Tk()
    root.withdraw()
    file_path = filedialog.askopenfilename()
    return file_path if file_path else ""

def select_files_for_decryption():
    root = tk.Tk()
    root.withdraw()
    file_paths = filedialog.askopenfilenames()
    return file_paths if file_paths else ()