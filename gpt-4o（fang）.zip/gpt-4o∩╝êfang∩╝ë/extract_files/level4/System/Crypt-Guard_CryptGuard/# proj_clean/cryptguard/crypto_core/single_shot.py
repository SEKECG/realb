def decrypt_data_single(enc_path, password):
    # Decrypt single-shot data
    pass

def encrypt_data_single(data, password, file_type, original_ext, key_file_hash, subchunk_size):
    # Encrypt single-shot data
    pass