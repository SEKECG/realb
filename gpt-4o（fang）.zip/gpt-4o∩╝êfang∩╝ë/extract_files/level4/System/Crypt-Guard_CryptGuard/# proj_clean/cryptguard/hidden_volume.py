def change_real_volume_password():
    # Change real volume password
    pass

def decrypt_data_raw_chacha(enc_dict, password, extra):
    # Decrypt raw data with ChaCha20
    pass

def decrypt_file(encrypted_file, outer_password):
    # Decrypt file
    pass

def encrypt_data_raw_chacha(data, password, argon_params, extra):
    # Encrypt raw data with ChaCha20
    pass

def encrypt_hidden_volume():
    # Encrypt hidden volume
    pass

def read_file_data(file_path):
    with open(file_path, 'rb') as f:
        return f.read()