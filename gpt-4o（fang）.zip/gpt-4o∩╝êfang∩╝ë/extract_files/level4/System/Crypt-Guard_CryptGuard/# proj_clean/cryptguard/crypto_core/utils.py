import os
import random
import string
import time

def generate_unique_filename(prefix, extension):
    timestamp = int(time.time())
    random_hex = ''.join(random.choices(string.hexdigits, k=8))
    return f"{prefix}_{timestamp}_{random_hex}.{extension}"

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def generate_ephemeral_token(n_bits):
    return ''.join(random.choices(string.hexdigits, k=n_bits // 4))

def generate_random_number(n_bits):
    return random.getrandbits(n_bits)