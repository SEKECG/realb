def calculate_optimal_workers(file_size):
    # Calculate optimal workers
    pass

def decrypt_data_streaming(enc_path, password):
    # Decrypt streaming data
    pass

def encrypt_data_streaming(file_path, password, file_type, original_ext, key_file_hash, chunk_size):
    # Encrypt streaming data
    pass