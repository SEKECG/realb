from pathlib import Path
import yaml

class Config:
    DEFAULT_CONFIG = {
        'default_backend': 0,
        'shell': 'bash',
        'backends': []
    }

    def __init__(self, config_path=None):
        self.config = self.DEFAULT_CONFIG.copy()
        self.config_file_found = False
        self.config_file_path = None
        if config_path:
            self.config_file_path = Path(config_path)
            self._load_config_file(self.config_file_path)
        else:
            self.config_file_path = self._find_config_file()
            if self.config_file_path:
                self._load_config_file(self.config_file_path)
        self._apply_env_overrides()

    def _apply_env_overrides(self):
        pass

    def _find_config_file(self, config_path=None):
        if config_path:
            return Path(config_path)
        return None

    def _get_default_config_path(self):
        return Path.home() / '.config' / 'nlsh' / 'config.yaml'

    def _load_config_file(self, config_file):
        with open(config_file, 'r') as file:
            new_config = yaml.safe_load(file)
            self._update_config(self.config, new_config)

    def _update_config(self, base_config, new_config):
        for key, value in new_config.items():
            if isinstance(value, dict) and key in base_config:
                self._update_config(base_config[key], value)
            else:
                base_config[key] = value

    def _validate_config(self, config):
        pass

    def create_default_config(self, config_path=None):
        if not config_path:
            config_path = self._get_default_config_path()
        config_path.parent.mkdir(parents=True, exist_ok=True)
        with open(config_path, 'w') as file:
            yaml.dump(self.DEFAULT_CONFIG, file)
        return config_path

    def get_backend(self, index=None):
        if index is None:
            index = self.config.get('default_backend', 0)
        return self.config['backends'][index]

    def get_nlgc_config(self):
        return self.config.get('nlgc', {})

    def get_shell(self):
        return self.config.get('shell', 'bash')

class ConfigValidationError(Exception):
    pass