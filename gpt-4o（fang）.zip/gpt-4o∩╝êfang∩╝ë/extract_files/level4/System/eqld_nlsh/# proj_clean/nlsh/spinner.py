import sys
import threading
import time

class Spinner:
    def __init__(self, message, stream=sys.stderr):
        self.message = message
        self.stream = stream
        self.spinner_chars = "|/-\\"
        self.running = False
        self.spinner_thread = None

    def spin(self):
        while self.running:
            for char in self.spinner_chars:
                self.stream.write(f"\r{self.message} {char}")
                self.stream.flush()
                time.sleep(0.1)

    def start(self):
        self.running = True
        self.spinner_thread = threading.Thread(target=self.spin)
        self.spinner_thread.start()

    def stop(self):
        self.running = False
        if self.spinner_thread:
            self.spinner_thread.join()
        self.stream.write("\r" + " " * (len(self.message) + 2) + "\r")
        self.stream.flush()