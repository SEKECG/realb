import re

def strip_markdown_code_blocks(text):
    text = re.sub(r'```.*?\n(.*?)\n```', r'\1', text, flags=re.DOTALL)
    text = re.sub(r'`(.*?)`', r'\1', text)
    return text

class BackendManager:
    def __init__(self, config):
        self.backends = []
        self.config = config

    def get_backend(self, index=None):
        if index is None:
            index = self.config.get('default_backend', 0)
        return self.backends[index]

class LLMBackend:
    def __init__(self, config):
        self.api_key = config.get('api_key')
        self.client = None
        self.config = config
        self.is_reasoning_model = config.get('is_reasoning_model', False)
        self.model = config.get('model')
        self.name = config.get('name')
        self.timeout = config.get('timeout', 60)
        self.url = config.get('url')

    def _calculate_temperature(self, regeneration_count):
        return min(0.2 + 0.1 * regeneration_count, 1.0)

    def _generate_non_streaming_response(self, messages, temperature, max_tokens, strip_markdown):
        # Placeholder for actual API call
        response = "Generated response"
        if strip_markdown:
            response = strip_markdown_code_blocks(response)
        return response

    def _generate_streaming_response(self, messages, temperature, max_tokens, strip_markdown):
        # Placeholder for actual API call
        response = "Generated response"
        if strip_markdown:
            response = strip_markdown_code_blocks(response)
        return response

    def generate_response(self, prompt, system_context, verbose, strip_markdown, max_tokens, regeneration_count):
        temperature = self._calculate_temperature(regeneration_count)
        messages = [{"role": "system", "content": system_context}, {"role": "user", "content": prompt}]
        return self._generate_non_streaming_response(messages, temperature, max_tokens, strip_markdown)