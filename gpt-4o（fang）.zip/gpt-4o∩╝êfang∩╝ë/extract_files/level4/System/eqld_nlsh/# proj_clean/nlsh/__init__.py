__version__ = "1.0.0"

def get_tools(config):
    from .tools import AVAILABLE_TOOLS
    return [tool(config) for tool in AVAILABLE_TOOLS]

def get_tool_class(tool_name):
    from .tools import AVAILABLE_TOOLS
    for tool in AVAILABLE_TOOLS:
        if tool.__name__ == tool_name:
            return tool
    return None

AVAILABLE_TOOLS = []