class BaseTool:
    def __init__(self, config):
        self.config = config
        self.name = self.__class__.__name__

    def get_context(self):
        raise NotImplementedError("Subclasses must implement this method")

    @property
    def name(self):
        return self.__class__.__name__