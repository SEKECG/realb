import os
import tempfile
import subprocess

def edit_text_in_editor(initial_text, suffix):
    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp_file:
        tmp_file.write(initial_text.encode('utf-8'))
        tmp_file.flush()
        tmp_file_path = tmp_file.name

    editor = os.getenv('EDITOR', 'vi')
    subprocess.call([editor, tmp_file_path])

    with open(tmp_file_path, 'r') as tmp_file:
        edited_text = tmp_file.read()

    os.remove(tmp_file_path)

    if edited_text.strip():
        return edited_text
    return None