import os
import shlex

class DirLister:
    def _format_file_info(self, entry):
        return {
            "name": entry.name,
            "size": self._format_size(entry.stat().st_size),
            "modified": entry.stat().st_mtime
        }

    def _format_size(self, size_bytes):
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if size_bytes < 1024:
                return f"{size_bytes:.2f} {unit}"
            size_bytes /= 1024

    def _sanitize_path(self, path):
        return shlex.quote(path)

    def get_context(self):
        files = []
        with os.scandir('.') as it:
            for entry in it:
                if not entry.name.startswith('.') and entry.is_file():
                    files.append(self._format_file_info(entry))
        return str(files)