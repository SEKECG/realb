class PromptBuilder:
    BASE_SYSTEM_PROMPT = "Base system prompt"
    EXPLANATION_SYSTEM_PROMPT = "Explanation system prompt"
    FIXING_SYSTEM_PROMPT = "Fixing system prompt"
    GIT_COMMIT_SYSTEM_PROMPT = "Git commit system prompt"

    def __init__(self, config):
        self.config = config
        self.shell = config.get_shell()

    def _gather_tools_context(self, tools):
        context = ""
        for tool in tools:
            try:
                context += tool.get_context() + "\n"
            except Exception as e:
                context += f"Error gathering context from {tool.name}: {e}\n"
        return context

    def build_explanation_system_prompt(self, tools):
        context = self._gather_tools_context(tools)
        return f"{self.EXPLANATION_SYSTEM_PROMPT}\n{context}"

    def build_fixing_system_prompt(self, tools):
        context = self._gather_tools_context(tools)
        return f"{self.FIXING_SYSTEM_PROMPT}\n{context}"

    def build_fixing_user_prompt(self, prompt, failed_command, failed_command_exit_code, failed_command_output):
        return f"Fix the following command:\n{failed_command}\nExit code: {failed_command_exit_code}\nOutput: {failed_command_output}\nOriginal prompt: {prompt}"

    def build_git_commit_system_prompt(self, declined_messages):
        return f"{self.GIT_COMMIT_SYSTEM_PROMPT}\nDeclined messages: {declined_messages}"

    def build_git_commit_user_prompt(self, git_diff, changed_files_content):
        return f"Generate a commit message for the following changes:\n{git_diff}\nChanged files: {changed_files_content}"

    def build_system_prompt(self, tools, declined_commands):
        context = self._gather_tools_context(tools)
        return f"{self.BASE_SYSTEM_PROMPT}\n{context}\nDeclined commands: {declined_commands}"

    def load_prompt_from_file(self, file_path):
        with open(file_path, 'r') as file:
            return file.read()