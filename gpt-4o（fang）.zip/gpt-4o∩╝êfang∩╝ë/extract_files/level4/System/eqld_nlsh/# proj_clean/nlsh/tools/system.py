import platform

class SystemInfo:
    def get_context(self):
        return f"OS: {platform.system()}, Kernel: {platform.release()}, Architecture: {platform.machine()}"