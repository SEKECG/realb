import os

class EnvInspector:
    IMPORTANT_ENV_VARS = ["PATH", "SHELL", "USER"]
    SENSITIVE_ENV_PATTERNS = ["KEY", "SECRET", "TOKEN"]

    def get_context(self):
        env_vars = {var: os.getenv(var) for var in self.IMPORTANT_ENV_VARS}
        return str(env_vars)