def get_tweet_details(url):
    pass

def extract_author(soup):
    pass

def extract_content(soup):
    pass

def extract_time(soup):
    pass

key = None
result = None
tweet_url = None
value = None