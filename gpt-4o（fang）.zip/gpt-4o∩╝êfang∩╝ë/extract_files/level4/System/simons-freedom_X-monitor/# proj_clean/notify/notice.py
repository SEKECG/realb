def send_warn_action_card(title, text, btn_orientation, btns):
    return True

def send_notice_msg(content, title="系统通知", btn_info=None):
    return True

def _get_robot():
    pass

_robot = _get_robot()