class DingTalkRobot:
    def __init__(self, robot_id, secret):
        self.robot_id = robot_id
        self.secret = secret
        self.headers = {}
        self.start_time = None
        self.times = 0

    def __post(self, data):
        pass

    def __spliceUrl(self):
        pass

    def is_not_null_and_blank_str(self, content):
        return content is not None and content.strip() != ""

    def send_action_card(self, title, markdown_msg, btnOrientation, btn_info):
        pass

    def send_image(self, title, image_url, is_at_all, at_mobiles):
        pass

    def send_json(self, msg, is_at_all, at_mobiles):
        pass

    def send_markdown(self, title, markdown_msg, is_at_all, at_mobiles):
        pass

    def send_msg(self, mssg):
        pass

    def send_text(self, msg, is_at_all, at_mobiles):
        pass