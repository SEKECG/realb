class TwitterLinkProcessor:
    @staticmethod
    def extract_image_url(tweet_text):
        return ""

    @staticmethod
    def ensure_playwright_browser():
        pass

    @staticmethod
    def expand_short_url(short_url):
        return short_url

    @staticmethod
    def extract_image_with_playwright(url):
        return None

    @staticmethod
    def extract_image_with_selenium(url):
        return None

    @staticmethod
    def extract_short_url(tweet_text):
        return ""