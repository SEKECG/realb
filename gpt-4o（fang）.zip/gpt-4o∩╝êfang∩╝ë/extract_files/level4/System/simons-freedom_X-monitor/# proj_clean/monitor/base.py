from ..core.analyzer import LlmAnalyzer
from ..core.analyzer import TokenSearcher
from ..core.trader import ChainTrader

class BaseMonitor:
    def __init__(self):
        self.analyzer = LlmAnalyzer(api_key="your_api_key")
        self.token_searcher = TokenSearcher(max_retries=3, retry_delay=5)
        self.trader = ChainTrader()

    def _analyze_message(self, msg):
        pass

    def _format_token_notification(self, token_names, search_results, tweet_author, tweet_content):
        pass

    def _init_trader(self):
        pass

    def _search_tokens(self, token_names):
        return {}

    def _should_trade(self, token):
        return False

    def process_message(self, message):
        pass