from .base import BaseMonitor

class WebhookMonitor(BaseMonitor):
    def __init__(self, host, port):
        super().__init__()
        self.app = None
        self.host = host
        self.port = port

    def _parse_tweet_data(self, raw_data):
        return None

    def _register_routes(self):
        pass

    def start(self):
        pass