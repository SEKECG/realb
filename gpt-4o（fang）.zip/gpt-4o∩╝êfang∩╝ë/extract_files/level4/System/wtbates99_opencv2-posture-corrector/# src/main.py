import os
import sys
import signal
from tray_interface import PostureTrackerTray

def kill_existing_instance(lock_file):
    if os.path.exists(lock_file):
        with open(lock_file, 'r') as f:
            pid = int(f.read().strip())
        try:
            os.kill(pid, signal.SIGTERM)
        except ProcessLookupError:
            pass

def main():
    lock_file = "posture_tracker.lock"
    kill_existing_instance(lock_file)
    with open(lock_file, 'w') as f:
        f.write(str(os.getpid()))
    app = PostureTrackerTray()
    app.run()
    os.remove(lock_file)

if __name__ == "__main__":
    main()