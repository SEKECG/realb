from datetime import datetime, timedelta
from util__send_notification import send_notification

class Notifications:
    def __init__(self, icon_path):
        self.icon_path = icon_path
        self.interval_message = "Time to check your posture!"
        self.last_notification_time = datetime.min
        self.notification_cooldown = timedelta(minutes=30)
        self.poor_posture_threshold = 50
        self.posture_message = "Your posture needs improvement!"

    def check_and_notify(self, posture_score):
        now = datetime.now()
        if posture_score < self.poor_posture_threshold and now - self.last_notification_time > self.notification_cooldown:
            send_notification(self.posture_message, "Posture Alert", self.icon_path)
            self.last_notification_time = now

    def set_interval_message(self, message):
        self.interval_message = message
        send_notification(self.interval_message, "Interval Alert", self.icon_path)