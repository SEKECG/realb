import cv2
import mediapipe as mp
import numpy as np
from util__settings import get_setting

class PoseDetector:
    def __init__(self, min_detection_confidence=None, min_tracking_confidence=None, frame_width=None, frame_height=None):
        self.frame_height = frame_height or get_setting("frame_height")
        self.frame_width = frame_width or get_setting("frame_width")
        self.ideal_neck_vector = np.array([0, -1])
        self.ideal_spine_vector = np.array([0, -1])
        self.mp_draw = mp.solutions.drawing_utils
        self.mp_pose = mp.solutions.pose
        self.pose = self.mp_pose.Pose(min_detection_confidence=min_detection_confidence or get_setting("min_detection_confidence"),
                                      min_tracking_confidence=min_tracking_confidence or get_setting("min_tracking_confidence"))
        self.posture_landmarks = ["nose", "left_eye", "right_eye", "left_ear", "right_ear", "left_shoulder", "right_shoulder", "left_elbow", "right_elbow", "left_wrist", "right_wrist", "left_hip", "right_hip", "left_knee", "right_knee", "left_ankle", "right_ankle"]
        self.score_thresholds = {"good": 80, "average": 50, "poor": 0}
        self.weights = {"neck": 0.5, "spine": 0.5}

    def _calculate_posture_score(self, landmarks):
        neck_vector = np.array([landmarks["left_shoulder"][0] - landmarks["right_shoulder"][0],
                                landmarks["left_shoulder"][1] - landmarks["right_shoulder"][1]])
        spine_vector = np.array([landmarks["left_hip"][0] - landmarks["right_hip"][0],
                                 landmarks["left_hip"][1] - landmarks["right_hip"][1]])
        neck_angle = self.angle_between(neck_vector, self.ideal_neck_vector)
        spine_angle = self.angle_between(spine_vector, self.ideal_spine_vector)
        neck_score = max(0, 100 - neck_angle)
        spine_score = max(0, 100 - spine_angle)
        return (neck_score * self.weights["neck"] + spine_score * self.weights["spine"])

    def _detect_pose(self, frame):
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = self.pose.process(frame_rgb)
        return results

    def _draw_landmarks(self, frame, results):
        self.mp_draw.draw_landmarks(frame, results.pose_landmarks, self.mp_pose.POSE_CONNECTIONS)

    def _draw_posture_feedback(self, frame, score):
        color = (0, 255, 0) if score > self.score_thresholds["good"] else (0, 255, 255) if score > self.score_thresholds["average"] else (0, 0, 255)
        cv2.putText(frame, f"Posture Score: {int(score)}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, color, 2, cv2.LINE_AA)

    def _preprocess_frame(self, frame):
        frame_resized = cv2.resize(frame, (self.frame_width, self.frame_height))
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        frame_gray = cv2.cvtColor(frame_resized, cv2.COLOR_BGR2GRAY)
        frame_clahe = clahe.apply(frame_gray)
        frame_preprocessed = cv2.cvtColor(frame_clahe, cv2.COLOR_GRAY2BGR)
        return frame_preprocessed

    @staticmethod
    def angle_between(v1, v2):
        dot_product = np.dot(v1, v2)
        norms = np.linalg.norm(v1) * np.linalg.norm(v2)
        cos_theta = dot_product / norms
        angle = np.arccos(np.clip(cos_theta, -1.0, 1.0))
        return np.degrees(angle)

    def process_frame(self, frame):
        frame_preprocessed = self._preprocess_frame(frame)
        results = self._detect_pose(frame_preprocessed)
        if results.pose_landmarks:
            landmarks = {lm: (results.pose_landmarks.landmark[idx].x, results.pose_landmarks.landmark[idx].y, results.pose_landmarks.landmark[idx].z) for idx, lm in enumerate(self.posture_landmarks)}
            score = self._calculate_posture_score(landmarks)
            self._draw_landmarks(frame, results)
            self._draw_posture_feedback(frame, score)
            return frame, score, landmarks
        return frame, 0, {}