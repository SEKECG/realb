import sqlite3
from datetime import datetime

class Database:
    def __init__(self, db_path):
        self.conn = sqlite3.connect(db_path)
        self.cursor = self.conn.cursor()
        self.posture_landmarks = ["nose", "left_eye", "right_eye", "left_ear", "right_ear", "left_shoulder", "right_shoulder", "left_elbow", "right_elbow", "left_wrist", "right_wrist", "left_hip", "right_hip", "left_knee", "right_knee", "left_ankle", "right_ankle"]
        self._create_tables()

    def _create_tables(self):
        self.cursor.execute('''CREATE TABLE IF NOT EXISTS posture_scores (
                                id INTEGER PRIMARY KEY,
                                timestamp TEXT,
                                score REAL)''')
        self.cursor.execute('''CREATE TABLE IF NOT EXISTS pose_landmarks (
                                id INTEGER PRIMARY KEY,
                                timestamp TEXT,
                                landmark TEXT,
                                x REAL,
                                y REAL,
                                z REAL)''')
        self.conn.commit()

    def close(self):
        self.conn.close()

    def create_table(self, table_name, columns):
        columns_def = ", ".join([f"{col} {dtype}" for col, dtype in columns.items()])
        self.cursor.execute(f"CREATE TABLE IF NOT EXISTS {table_name} ({columns_def})")
        self.conn.commit()

    def insert(self, table_name, values):
        placeholders = ", ".join(["?" for _ in values[0]])
        self.cursor.executemany(f"INSERT INTO {table_name} VALUES ({placeholders})", values)
        self.conn.commit()

    def save_pose_data(self, landmarks, score):
        timestamp = datetime.now().isoformat()
        self.insert("posture_scores", [(None, timestamp, score)])
        landmark_values = [(None, timestamp, lm, x, y, z) for lm, (x, y, z) in landmarks.items()]
        self.insert("pose_landmarks", landmark_values)