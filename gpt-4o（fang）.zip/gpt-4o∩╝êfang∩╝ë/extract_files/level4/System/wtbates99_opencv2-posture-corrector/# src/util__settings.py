import json

POSTURE_LANDMARKS = ["nose", "left_eye", "right_eye", "left_ear", "right_ear", "left_shoulder", "right_shoulder", "left_elbow", "right_elbow", "left_wrist", "right_wrist", "left_hip", "right_hip", "left_knee", "right_knee", "left_ankle", "right_ankle"]
CUSTOMIZABLE_SETTINGS = {"camera_id": 0, "fps": 30, "frame_width": 640, "frame_height": 480, "model_complexity": 1}
IMMUTABLE_SETTINGS = {"min_detection_confidence": 0.5, "min_tracking_confidence": 0.5}
USER_SETTINGS_FILE = "user_settings.json"

def get_setting(key):
    if key in IMMUTABLE_SETTINGS:
        return IMMUTABLE_SETTINGS[key]
    if key in CUSTOMIZABLE_SETTINGS:
        return CUSTOMIZABLE_SETTINGS[key]
    raise KeyError(f"Setting {key} not found")

def save_user_settings():
    with open(USER_SETTINGS_FILE, 'w') as f:
        json.dump(CUSTOMIZABLE_SETTINGS, f)

def load_user_settings():
    global CUSTOMIZABLE_SETTINGS
    try:
        with open(USER_SETTINGS_FILE, 'r') as f:
            CUSTOMIZABLE_SETTINGS.update(json.load(f))
    except FileNotFoundError:
        save_user_settings()

def update_setting(key, value):
    if key in CUSTOMIZABLE_SETTINGS:
        CUSTOMIZABLE_SETTINGS[key] = value
    else:
        raise KeyError(f"Setting {key} not found")