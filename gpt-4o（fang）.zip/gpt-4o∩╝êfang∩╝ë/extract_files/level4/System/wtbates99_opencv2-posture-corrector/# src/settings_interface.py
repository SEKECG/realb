from PyQt5.QtWidgets import QDialog, QVBoxLayout, QTabWidget, QPushButton, QComboBox, QSpinBox, QLineEdit, QTableWidget, QTableWidgetItem, QHBoxLayout
from util__settings import CUSTOMIZABLE_SETTINGS, save_user_settings, load_user_settings

class SettingsInterface(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Settings")
        self.setLayout(QVBoxLayout())
        self.tabs = QTabWidget()
        self.layout().addWidget(self.tabs)
        self.button_box = QHBoxLayout()
        self.layout().addLayout(self.button_box)
        self.init_camera_tab()
        self.init_general_tab()
        self.init_tracking_tab()
        self.add_interval_button = QPushButton("Add Interval")
        self.remove_interval_button = QPushButton("Remove Interval")
        self.button_box.addWidget(self.add_interval_button)
        self.button_box.addWidget(self.remove_interval_button)
        self.add_interval_button.clicked.connect(self.add_tracking_interval)
        self.remove_interval_button.clicked.connect(self.remove_tracking_interval)
        self.ok_button = QPushButton("OK")
        self.cancel_button = QPushButton("Cancel")
        self.button_box.addWidget(self.ok_button)
        self.button_box.addWidget(self.cancel_button)
        self.ok_button.clicked.connect(self.accept)
        self.cancel_button.clicked.connect(self.reject)
        load_user_settings()

    def accept(self):
        save_user_settings()
        super().accept()

    def add_tracking_interval(self):
        pass

    def get_available_cameras(self, max_index=10):
        pass

    def init_camera_tab(self):
        self.camera_tab = QVBoxLayout()
        self.camera_combo = QComboBox()
        self.fps_spinbox = QSpinBox()
        self.width_spinbox = QSpinBox()
        self.height_spinbox = QSpinBox()
        self.model_complexity_spinbox = QSpinBox()
        self.camera_tab.addWidget(self.camera_combo)
        self.camera_tab.addWidget(self.fps_spinbox)
        self.camera_tab.addWidget(self.width_spinbox)
        self.camera_tab.addWidget(self.height_spinbox)
        self.camera_tab.addWidget(self.model_complexity_spinbox)
        self.tabs.addTab(self.camera_tab, "Camera")

    def init_general_tab(self):
        self.general_tab = QVBoxLayout()
        self.cooldown_spinbox = QSpinBox()
        self.poor_posture_spinbox = QSpinBox()
        self.posture_message_lineedit = QLineEdit()
        self.db_logging_checkbox = QCheckBox()
        self.db_write_interval_spinbox = QSpinBox()
        self.general_tab.addWidget(self.cooldown_spinbox)
        self.general_tab.addWidget(self.poor_posture_spinbox)
        self.general_tab.addWidget(self.posture_message_lineedit)
        self.general_tab.addWidget(self.db_logging_checkbox)
        self.general_tab.addWidget(self.db_write_interval_spinbox)
        self.tabs.addTab(self.general_tab, "General")

    def init_tracking_tab(self):
        self.tracking_tab = QVBoxLayout()
        self.tracking_table = QTableWidget()
        self.new_interval_label_edit = QLineEdit()
        self.new_interval_spinbox = QSpinBox()
        self.tracking_duration_spinbox = QSpinBox()
        self.tracking_tab.addWidget(self.tracking_table)
        self.tracking_tab.addWidget(self.new_interval_label_edit)
        self.tracking_tab.addWidget(self.new_interval_spinbox)
        self.tracking_tab.addWidget(self.tracking_duration_spinbox)
        self.tabs.addTab(self.tracking_tab, "Tracking")

    def populate_tracking_table(self):
        pass

    def remove_tracking_interval(self):
        pass