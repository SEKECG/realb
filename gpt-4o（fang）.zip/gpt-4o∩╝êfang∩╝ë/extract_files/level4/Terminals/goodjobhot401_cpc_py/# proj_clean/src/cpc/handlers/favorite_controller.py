from cpc.services.favorite import FAVORITE_SERVICE

class FAVORITE:
    def add_favorite(self, favorite_list):
        service = FAVORITE_SERVICE()
        service.add_favorite(favorite_list)

    def remove_favorite(self, favorite_list):
        service = FAVORITE_SERVICE()
        service.remove_favorite(favorite_list)