import argparse
from cpc.handlers import (
    asset_controller,
    favorite_controller,
    kline_controller,
    price_controller,
    symbol_controller,
    user_controller,
)

def main():
    parser = argparse.ArgumentParser(description="Cryptocurrency Portfolio Tracker")
    subparsers = parser.add_subparsers(dest="command")

    # Define subcommands
    subparsers.add_parser("symbols")
    subparsers.add_parser("price")
    subparsers.add_parser("kline")
    subparsers.add_parser("user")
    subparsers.add_parser("favorite")
    subparsers.add_parser("asset")

    args = parser.parse_args()

    if args.command == "symbols":
        symbol_controller.SYMBOL().filter_symbols(args.query)
    elif args.command == "price":
        price_controller.PRICE().get_price_detail(args.symbols)
    elif args.command == "kline":
        kline_controller.KLINE().get_kline(args.symbol, args.interval, args.limit)
    elif args.command == "user":
        user_controller.USER().get_users()
    elif args.command == "favorite":
        favorite_controller.FAVORITE().add_favorite(args.favorite_list)
    elif args.command == "asset":
        asset_controller.ASSET().add_asset(args.asset_list)

if __name__ == "__main__":
    main()