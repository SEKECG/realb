class USER_REPOSITORIES:
    def __init__(self, conn):
        self.conn = conn
        self.cursor = conn.cursor()

    def create_default_user(self):
        self.cursor.execute("INSERT INTO User (name, target) VALUES (?, ?)", ("default", 1))
        return self.cursor.lastrowid

    def _auto_choose_user(self):
        self.cursor.execute("UPDATE User SET target = 1 WHERE id = (SELECT id FROM User LIMIT 1)")

    def _auto_switch_user(self):
        self._remove_all_target()
        self._auto_choose_user()

    def _is_user_target(self):
        self.cursor.execute("SELECT * FROM User WHERE target = 1")
        return len(self.cursor.fetchall()) == 1

    def _remove_all_target(self):
        self.cursor.execute("UPDATE User SET target = 0 WHERE target = 1")

    def create_user(self, name, target):
        self.cursor.execute("INSERT INTO User (name, target) VALUES (?, ?)", (name, target))
        self._auto_switch_user()
        return self.cursor.lastrowid

    def get_user(self):
        self.cursor.execute("SELECT * FROM User WHERE target = 1")
        return self.cursor.fetchone()

    def get_users(self):
        self.cursor.execute("SELECT * FROM User")
        return self.cursor.fetchall()

    def remove_user(self, user_id):
        self.cursor.execute("DELETE FROM User WHERE id = ?", (user_id,))
        self.cursor.execute("DELETE FROM Asset WHERE user_id = ?", (user_id,))
        self.cursor.execute("DELETE FROM Favorite WHERE user_id = ?", (user_id,))
        self._auto_switch_user()

    def switch_user(self, user_id):
        self._remove_all_target()
        self.cursor.execute("UPDATE User SET target = 1 WHERE id = ?", (user_id,))

    def update_user(self, user_id, name):
        self.cursor.execute("UPDATE User SET name = ? WHERE id = ?", (name, user_id))