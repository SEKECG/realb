from cpc.services.price import PRICE_SERVICE

class PRICE:
    def get_price_detail(self, symbols):
        service = PRICE_SERVICE()
        service.get_price_detail(symbols)