class ASSET_REPOSITORIES:
    def __init__(self, conn):
        self.conn = conn
        self.cursor = conn.cursor()

    def add_asset(self, user_id, symbol_list):
        for symbol, amount in symbol_list:
            self.cursor.execute("INSERT INTO Asset (user_id, symbol, amount) VALUES (?, ?, ?)", (user_id, symbol, amount))

    def remove_asset(self, user_id, symbol_list):
        for symbol in symbol_list:
            self.cursor.execute("DELETE FROM Asset WHERE user_id = ? AND symbol = ?", (user_id, symbol))

    def update_asset(self, user_id, symbol_list):
        for symbol, amount in symbol_list:
            self.cursor.execute("UPDATE Asset SET amount = ? WHERE user_id = ? AND symbol = ?", (amount, user_id, symbol))