from cpc.services.symbol import SYMBOL_SERVICE

class SYMBOL:
    def filter_symbols(self, query):
        service = SYMBOL_SERVICE()
        service.filter_symbols(query)