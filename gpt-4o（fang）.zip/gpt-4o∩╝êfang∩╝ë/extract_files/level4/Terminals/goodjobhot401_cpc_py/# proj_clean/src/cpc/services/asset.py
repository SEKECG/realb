from cpc.repositories.asset import ASSET_REPOSITORIES
from cpc.repositories.user import USER_REPOSITORIES
from cpc.middlewares.db_connect import db_connection

class ASSET_SERVICE:
    def __init__(self, conn):
        self.asset_repository = ASSET_REPOSITORIES(conn)
        self.user_repository = USER_REPOSITORIES(conn)

    @db_connection
    def add_asset(self, conn, asset_list):
        user = self.user_repository.get_user()
        if user:
            self.asset_repository.add_asset(user["id"], asset_list)

    @db_connection
    def remove_asset(self, conn, asset_list):
        user = self.user_repository.get_user()
        if user:
            self.asset_repository.remove_asset(user["id"], asset_list)

    @db_connection
    def update_asset(self, conn, asset_list):
        user = self.user_repository.get_user()
        if user:
            self.asset_repository.update_asset(user["id"], asset_list)