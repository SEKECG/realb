from cpc.services.user import USER_SERVICE

class USER:
    def get_user(self, print_table):
        service = USER_SERVICE()
        service.get_user(print_table)

    def get_users(self):
        service = USER_SERVICE()
        service.get_users()

    def create_user(self, name):
        service = USER_SERVICE()
        service.create_user(name)

    def switch_user(self, user_id):
        service = USER_SERVICE()
        service.switch_user(user_id)

    def update_user(self, user_id, name):
        service = USER_SERVICE()
        service.update_user(user_id, name)

    def remove_user(self, user_id):
        service = USER_SERVICE()
        service.remove_user(user_id)

    def get_position_ratio(self, sort, reverse):
        service = USER_SERVICE()
        service.get_position_ratio(sort, reverse)

    def create_default_user(self):
        service = USER_SERVICE()
        service.create_default_user()