INIT_USER_DATA = {
    "name": "default",
    "target": 1
}

PRICE_DETAIL_ROW_MAP = {
    "symbol": "Symbol",
    "priceChange": "Price Change",
    "priceChangePercent": "Price Change Percent",
    "weightedAvgPrice": "Weighted Avg Price",
    "prevClosePrice": "Prev Close Price",
    "lastPrice": "Last Price",
    "lastQty": "Last Qty",
    "bidPrice": "Bid Price",
    "askPrice": "Ask Price",
    "openPrice": "Open Price",
    "highPrice": "High Price",
    "lowPrice": "Low Price",
    "volume": "Volume",
    "quoteVolume": "Quote Volume",
    "openTime": "Open Time",
    "closeTime": "Close Time",
    "firstId": "First Id",
    "lastId": "Last Id",
    "count": "Count"
}

VALID_INTERVAL = ["1m", "5m", "15m", "30m", "1h", "4h", "8h", "1d", "1W", "1M"]