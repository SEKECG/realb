class ASSET_SQL:
    def add_asset_sql(self):
        return "INSERT INTO Asset (user_id, symbol, amount) VALUES (?, ?, ?)"

    def remove_asset_sql(self):
        return "DELETE FROM Asset WHERE user_id = ? AND symbol = ?"

    def update_asset_sql(self):
        return "UPDATE Asset SET amount = ? WHERE user_id = ? AND symbol = ?"