import hmac
import hashlib
import requests
from cpc.common.config import MEXC_HOST

class TOOL:
    def _get_server_time(self):
        url = f"{MEXC_HOST}/api/v3/time"
        response = requests.get(url)
        return response.json()

    def _sign_v3(self, req_time, sign_params):
        query_string = "&".join([f"{key}={value}" for key, value in sign_params.items()])
        signature = hmac.new(
            bytes("your_secret_key", "utf-8"),
            msg=bytes(f"{req_time}{query_string}", "utf-8"),
            digestmod=hashlib.sha256
        ).hexdigest()
        return signature

    def public_request(self, method, url, params=None):
        response = requests.request(method, url, params=params)
        return response.json()

    def sign_request(self, method, url, params=None):
        req_time = self._get_server_time()["serverTime"]
        signature = self._sign_v3(req_time, params)
        headers = {
            "X-MEXC-APIKEY": "your_api_key",
            "X-MEXC-SIGNATURE": signature,
            "X-MEXC-TIMESTAMP": str(req_time)
        }
        response = requests.request(method, url, params=params, headers=headers)
        return response.json()

class mexc_market:
    def __init__(self):
        self.api = TOOL()
        self.hosts = MEXC_HOST
        self.method = "GET"

    def get_24hr_ticker(self, params):
        url = f"{self.hosts}/api/v3/ticker/24hr"
        return self.api.public_request(self.method, url, params)

    def get_ETF_info(self, params):
        url = f"{self.hosts}/api/v3/etf/info"
        return self.api.public_request(self.method, url, params)

    def get_aggtrades(self, params):
        url = f"{self.hosts}/api/v3/aggTrades"
        return self.api.public_request(self.method, url, params)

    def get_avgprice(self, params):
        url = f"{self.hosts}/api/v3/avgPrice"
        return self.api.public_request(self.method, url, params)

    def get_bookticker(self, params):
        url = f"{self.hosts}/api/v3/ticker/bookTicker"
        return self.api.public_request(self.method, url, params)

    def get_deals(self, params):
        url = f"{self.hosts}/api/v3/trades"
        return self.api.public_request(self.method, url, params)

    def get_defaultSymbols(self):
        url = f"{self.hosts}/api/v3/exchangeInfo"
        return self.api.public_request(self.method, url)

    def get_depth(self, params):
        url = f"{self.hosts}/api/v3/depth"
        return self.api.public_request(self.method, url, params)

    def get_exchangeInfo(self, params):
        url = f"{self.hosts}/api/v3/exchangeInfo"
        return self.api.public_request(self.method, url, params)

    def get_kline(self, params):
        url = f"{self.hosts}/api/v3/klines"
        return self.api.public_request(self.method, url, params)

    def get_ping(self):
        url = f"{self.hosts}/api/v3/ping"
        return self.api.public_request(self.method, url)

    def get_price(self, params):
        url = f"{self.hosts}/api/v3/ticker/price"
        return self.api.public_request(self.method, url, params)

    def get_timestamp(self):
        url = f"{self.hosts}/api/v3/time"
        return self.api.public_request(self.method, url)