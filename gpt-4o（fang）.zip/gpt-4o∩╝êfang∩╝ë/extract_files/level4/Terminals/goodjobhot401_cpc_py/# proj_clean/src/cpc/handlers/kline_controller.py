from cpc.services.kline import KLINE_SERVICE

class KLINE:
    def get_kline(self, symbol, interval, limit):
        service = KLINE_SERVICE()
        service.get_kline(symbol, interval, limit)