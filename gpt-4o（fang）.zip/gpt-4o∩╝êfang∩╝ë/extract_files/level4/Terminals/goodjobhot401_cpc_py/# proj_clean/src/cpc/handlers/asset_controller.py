from cpc.services.asset import ASSET_SERVICE

class ASSET:
    def add_asset(self, asset_list):
        service = ASSET_SERVICE()
        service.add_asset(asset_list)

    def update_asset(self, asset_list):
        service = ASSET_SERVICE()
        service.update_asset(asset_list)

    def remove_asset(self, asset_list):
        service = ASSET_SERVICE()
        service.remove_asset(asset_list)