import sqlite3
from functools import wraps
from cpc.common.config import DB_PATH
from cpc.database.dml.init.init import ASSET_TABLE_SQL, FAVORITE_TABLE_SQL, USER_TABLE_SQL

def db_connection(func):
    @wraps(func)
    def with_connection_(*args, **kwargs):
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        try:
            rv = func(conn, *args, **kwargs)
            conn.commit()
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()
        return rv
    return with_connection_

@db_connection
def init_tables(conn):
    cursor = conn.cursor()
    cursor.execute(USER_TABLE_SQL)
    cursor.execute(ASSET_TABLE_SQL)
    cursor.execute(FAVORITE_TABLE_SQL)