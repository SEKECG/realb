class USER_SQL:
    def auto_choose_user(self):
        return "UPDATE User SET target = 1 WHERE id = (SELECT id FROM User LIMIT 1)"

    def create_user(self):
        return "INSERT INTO User (name, target) VALUES (?, ?)"

    def get_asset_sql(self):
        return "SELECT symbol, amount FROM Asset WHERE user_id = ?"

    def get_favorite_sql(self):
        return "SELECT symbol FROM Favorite WHERE user_id = ?"

    def get_user(self):
        return "SELECT * FROM User WHERE target = 1"

    def get_users(self):
        return "SELECT * FROM User"

    def is_taget_sql(self):
        return "SELECT * FROM User WHERE target = 1"

    def remove_all_target(self):
        return "UPDATE User SET target = 0 WHERE target = 1"

    def remove_asset_sql(self):
        return "DELETE FROM Asset WHERE user_id = ?"

    def remove_favorite_sql(self):
        return "DELETE FROM Favorite WHERE user_id = ?"

    def remove_user_sql(self):
        return "DELETE FROM User WHERE id = ?"

    def switch_target_user(self):
        return "UPDATE User SET target = 1 WHERE id = ?"

    def update_user(self):
        return "UPDATE User SET name = ? WHERE id = ?"