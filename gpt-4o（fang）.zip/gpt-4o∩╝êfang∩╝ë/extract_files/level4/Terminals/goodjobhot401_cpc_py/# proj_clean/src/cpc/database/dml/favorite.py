class FAVORITE_SQL:
    def add_favorite_sql(self):
        return "INSERT INTO Favorite (user_id, symbol) VALUES (?, ?)"

    def remove_favorite_sql(self):
        return "DELETE FROM Favorite WHERE user_id = ? AND symbol = ?"