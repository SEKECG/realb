from server.api import fetch_problem_list

def list_problems(difficulty=None, status=None, tag=None, category_slug=None):
    """
    List available LeetCode problems with optional filters.
    """
    problems = fetch_problem_list(difficulty, status, tag, category_slug)
    # Further implementation to display problems