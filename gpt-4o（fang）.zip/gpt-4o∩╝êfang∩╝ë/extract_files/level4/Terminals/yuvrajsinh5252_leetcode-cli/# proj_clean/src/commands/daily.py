from server.api import get_daily_question

def daily(lang=None, editor=None, full=None, no_editor=None):
    """
    Get and work on today's LeetCode daily challenge.
    """
    question = get_daily_question()
    # Further implementation to open the question in the editor