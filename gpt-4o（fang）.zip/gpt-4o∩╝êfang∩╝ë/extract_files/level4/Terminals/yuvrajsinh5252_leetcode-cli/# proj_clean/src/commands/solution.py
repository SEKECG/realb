from server.solution_manager import SolutionManager

def solutions(problem, best=None):
    """
    Fetch solution for a problem
    """
    manager = SolutionManager()
    solutions = manager.get_problem_solutions(problem, best)
    # Further implementation to display solutions