from server.solution_manager import SolutionManager

def test(problem, file):
    """
    Test a solution with LeetCode's test cases
    """
    manager = SolutionManager()
    result = manager.test_solution(problem, file)
    # Further implementation to display test result