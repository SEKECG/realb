from server.solution_manager import SolutionManager

def submit(problem, file, lang=None, force=None):
    """
    Submit a solution to LeetCode
    """
    manager = SolutionManager()
    result = manager.submit_solution(problem, file, lang)
    # Further implementation to display submission result