import typer
from commands.daily import daily
from commands.edit import edit
from commands.list_problems import list_problems
from commands.login import login, logout
from commands.profile import profile
from commands.show import show
from commands.solution import solutions
from commands.submit import submit
from commands.test import test
from lib.welcome import display_welcome

app = typer.Typer()

@app.callback()
def callback(ctx: typer.Context):
    """
    LeetCode CLI - A command-line tool for LeetCode problems.
    """
    display_welcome(app)

app.command()(daily)
app.command()(edit)
app.command()(list_problems)
app.command()(login)
app.command()(logout)
app.command()(profile)
app.command()(show)
app.command()(solutions)
app.command()(submit)
app.command()(test)

if __name__ == "__main__":
    app()