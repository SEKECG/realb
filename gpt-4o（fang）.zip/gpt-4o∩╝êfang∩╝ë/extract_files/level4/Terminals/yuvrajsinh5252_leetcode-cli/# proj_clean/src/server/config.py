LANGUAGE_MAP = {
    # Language map configuration
}

STATUS_CODES = {
    # Status codes configuration
}

BASE_URL = "https://leetcode.com"
LEETCODE_BASE_URL = "https://leetcode.com"
MEMORY_LIMIT_THRESHOLD = "450MB"
MEMORY_WARNING_THRESHOLD = "100MB"
SUBMISSION_RESULT_TIMEOUT = 30
TEST_RESULT_TIMEOUT = 30