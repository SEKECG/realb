from server.api import fetch_problem_list

def edit(problem, lang=None, editor=None):
    """
    Solves a problem by passing lang param and open it with your code editor.
    """
    # Implementation to fetch problem and open in editor