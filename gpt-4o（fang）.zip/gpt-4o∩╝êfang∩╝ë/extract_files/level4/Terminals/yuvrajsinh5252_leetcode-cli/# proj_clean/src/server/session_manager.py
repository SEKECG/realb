import os
import json

class SessionManager:
    config_dir = os.path.expanduser("~/.leetcode-cli")
    config_file = os.path.join(config_dir, "session.json")

    def __init__(self):
        self._ensure_config_dir()

    def _ensure_config_dir(self):
        """
        Ensure the config directory exists.
        """
        if not os.path.exists(self.config_dir):
            os.makedirs(self.config_dir)

    def load_session(self):
        """
        Load the session token and username from file.
        """
        if os.path.exists(self.config_file):
            with open(self.config_file, "r") as f:
                return json.load(f)
        return None

    def clear_session(self):
        """
        Clear the stored session.
        """
        if os.path.exists(self.config_file):
            os.remove(self.config_file)

    def save_session(self, csrftoken, session_token, user_name):
        """
        Save the session token and username to file.
        """
        with open(self.config_file, "w") as f:
            json.dump({
                "csrftoken": csrftoken,
                "session_token": session_token,
                "user_name": user_name
            }, f)