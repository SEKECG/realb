from server.api import fetch_problem_list

def show(problem, save=None, compact=None):
    """
    Show problem details including description and test cases
    """
    question_data = fetch_problem_list(problem)
    # Further implementation to display problem details

def _save_problem_to_file(question_data):
    """
    Save the problem statement to a markdown file
    """
    # Implementation to save problem to file