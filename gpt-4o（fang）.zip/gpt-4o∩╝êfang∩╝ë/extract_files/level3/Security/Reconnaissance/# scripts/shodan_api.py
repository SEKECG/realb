import shodan
import socket

def shodan_scan(domain, api_key):
    api = shodan.Shodan(api_key)
    results = api.search(domain)
    return results['matches']

def host_info(domain, api_key):
    api = shodan.Shodan(api_key)
    ip = get_ip_from_domain(domain)
    host = api.host(ip)
    return host

def get_api_key(api_key):
    return shodan.Shodan(api_key)

def get_ip_from_domain(domain):
    return socket.gethostbyname(domain)

def scan_single_ip(ip, api_key):
    api = shodan.Shodan(api_key)
    host = api.host(ip)
    return host