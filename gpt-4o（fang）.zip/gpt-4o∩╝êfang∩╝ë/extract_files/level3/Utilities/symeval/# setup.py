from setuptools import setup, find_packages

cfg = {
    'name': 'symeval',
    'version': '0.1.0',
    'description': 'Symbolic Math Expression Evaluator',
    'author': 'Your Name',
    'author_email': 'your.email@example.com',
    'packages': find_packages(),
    'install_requires': [
        'sympy',
        'pebble',
        'tqdm'
    ],
    'python_requires': '>=3.6',
}

setup(**cfg)