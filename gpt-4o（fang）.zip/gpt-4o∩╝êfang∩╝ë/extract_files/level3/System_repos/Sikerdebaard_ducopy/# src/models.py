from pydantic import BaseModel

class ConfigNodeRequest(BaseModel):
    Co2SetPoint: int | None = None
    FlowLvlAutoMax: int | None = None
    FlowLvlAutoMin: int | None = None
    FlowLvlMan1: int | None = None
    FlowLvlMan2: int | None = None
    FlowLvlMan3: int | None = None
    FlowLvlSwitch: int | None = None
    FlowMax: int | None = None
    Name: str | None = None
    RhDetMode: int | None = None
    RhSetPoint: int | None = None
    ShowSensorLvl: int | None = None
    SwitchMode: int | None = None
    TempDepEnable: int | None = None
    TimeMan: int | None = None

class ActionsResponse(BaseModel):
    pass

class NodeInfo(BaseModel):
    Sensor: dict | None = None

class NodesResponse(BaseModel):
    pass

class ConfigNodeResponse(BaseModel):
    Co2SetPoint: dict | None = None
    FlowLvlAutoMax: dict | None = None
    FlowLvlAutoMin: dict | None = None
    FlowLvlMan1: dict | None = None
    FlowLvlMan2: dict | None = None
    FlowLvlMan3: dict | None = None
    FlowLvlSwitch: dict | None = None
    FlowMax: dict | None = None
    Name: dict | None = None
    RhDetMode: dict | None = None
    RhSetPoint: dict | None = None
    SerialBoard: str
    SerialDuco: str
    ShowSensorLvl: dict | None = None
    SwitchMode: dict | None = None
    TempDepEnable: dict | None = None
    TimeMan: dict | None = None

class ParameterConfig(BaseModel):
    Id: int | None = None
    Inc: int | None = None
    Max: int | None = None
    Min: int | None = None

class NodesInfoResponse(BaseModel):
    Nodes: list[NodeInfo] | None = None

class ActionsChangeResponse(BaseModel):
    pass

class ActionInfo(BaseModel):
    pass

class FirmwareResponse(BaseModel):
    pass

class GeneralInfo(BaseModel):
    Id: int | None = None

class NetworkDucoInfo(BaseModel):
    CommErrorCtr: int

class NodeConfig(BaseModel):
    Co2SetPoint: dict | None = None
    FlowLvlAutoMax: dict | None = None
    FlowLvlAutoMin: dict | None = None
    FlowLvlMan1: dict | None = None
    FlowLvlMan2: dict | None = None
    FlowLvlMan3: dict | None = None
    FlowLvlSwitch: dict | None = None
    FlowMax: dict | None = None
    Name: dict | None = None
    RhDetMode: dict | None = None
    RhSetPoint: dict | None = None
    SerialBoard: str
    SerialDuco: str
    ShowSensorLvl: dict | None = None
    SwitchMode: dict | None = None
    TempDepEnable: dict | None = None
    TimeMan: dict | None = None

class NodeGeneralInfo(BaseModel):
    Addr: int

class SensorData(BaseModel):
    data: dict | None = None

class VentilationInfo(BaseModel):
    FlowLvlOvrl: int
    FlowLvlTgt: int | None = None
    Mode: str | None = None
    State: str | None = None
    TimeStateEnd: int | None = None
    TimeStateRemain: int | None = None

def extract_val(data):
    return data.get("Val", data)

def unified_validator(uargs, ukwargs):
    pass