import requests
from models import ConfigNodeRequest, ActionsResponse, ConfigNodeResponse, NodesResponse, NodeInfo, NodesInfoResponse, ActionsChangeResponse

class APIClient:
    def __init__(self, base_url, verify):
        self.base_url = base_url
        self.session = requests.Session()
        self.session.verify = verify

    def _duco_pem(self):
        return "path/to/certificate.pem"

    def close(self):
        self.session.close()

    def get_action(self, action):
        response = self.session.get(f"{self.base_url}/actions/{action}")
        return response.json()

    def get_actions_node(self, node_id, action):
        response = self.session.get(f"{self.base_url}/nodes/{node_id}/actions/{action}")
        return ActionsResponse(**response.json())

    def get_api_info(self):
        response = self.session.get(f"{self.base_url}/api/info")
        return response.json()

    def get_config_node(self, node_id):
        response = self.session.get(f"{self.base_url}/nodes/{node_id}/config")
        return ConfigNodeResponse(**response.json())

    def get_config_nodes(self):
        response = self.session.get(f"{self.base_url}/nodes/config")
        return NodesResponse(**response.json())

    def get_info(self, module, submodule, parameter):
        response = self.session.get(f"{self.base_url}/info/{module}/{submodule}/{parameter}")
        return response.json()

    def get_logs(self):
        response = self.session.get(f"{self.base_url}/logs")
        return response.json()

    def get_node_info(self, node_id):
        response = self.session.get(f"{self.base_url}/nodes/{node_id}")
        return NodeInfo(**response.json())

    def get_nodes(self):
        response = self.session.get(f"{self.base_url}/nodes")
        return NodesInfoResponse(**response.json())

    def patch_config_node(self, node_id, config):
        response = self.session.patch(f"{self.base_url}/nodes/{node_id}/config", json=config.dict())
        return ConfigNodeResponse(**response.json())

    def post_action_node(self, action, value, node_id):
        response = self.session.post(f"{self.base_url}/nodes/{node_id}/actions", json={"action": action, "value": value})
        return ActionsChangeResponse(**response.json())

    def raw_get(self, endpoint, params):
        response = self.session.get(f"{self.base_url}{endpoint}", params=params)
        return response.json()