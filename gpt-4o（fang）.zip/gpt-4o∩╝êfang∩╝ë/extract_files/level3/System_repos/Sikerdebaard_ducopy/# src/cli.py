import typer
from loguru import logger
from ducopy import DucoPy

app = typer.Typer()

@app.command()
def change_action_node(base_url, node_id, action, value, format):
    client = DucoPy(base_url)
    response = client.change_action_node(action, value, node_id)
    print_output(response, format)

@app.command()
def configure(logging_level):
    setup_logging(logging_level)

@app.command()
def entry_point():
    app()

@app.command()
def get_action(base_url, action, format):
    client = DucoPy(base_url)
    response = client.get_action(action)
    print_output(response, format)

@app.command()
def get_actions_node(base_url, node_id, action, format):
    client = DucoPy(base_url)
    response = client.get_actions_node(node_id, action)
    print_output(response, format)

@app.command()
def get_api_info(base_url, format):
    client = DucoPy(base_url)
    response = client.get_api_info()
    print_output(response, format)

@app.command()
def get_config_node(base_url, node_id, format):
    client = DucoPy(base_url)
    response = client.get_config_node(node_id)
    print_output(response, format)

@app.command()
def get_config_nodes(base_url, format):
    client = DucoPy(base_url)
    response = client.get_config_nodes()
    print_output(response, format)

@app.command()
def get_info(base_url, module, submodule, parameter, format):
    client = DucoPy(base_url)
    response = client.get_info(module, submodule, parameter)
    print_output(response, format)

@app.command()
def get_logs(base_url, format):
    client = DucoPy(base_url)
    response = client.get_logs()
    print_output(response, format)

@app.command()
def get_node_info(base_url, node_id, format):
    client = DucoPy(base_url)
    response = client.get_node_info(node_id)
    print_output(response, format)

@app.command()
def get_nodes(base_url, format):
    client = DucoPy(base_url)
    response = client.get_nodes()
    print_output(response, format)

@app.command()
def raw_get(url, params, format):
    client = DucoPy(url)
    response = client.raw_get(url, params)
    print_output(response, format)

def print_output(data, format):
    if format == "pretty":
        print(data)
    elif format == "json":
        import json
        print(json.dumps(data, indent=4))

def setup_logging(level):
    logger.remove()
    logger.add(lambda msg: print(msg, end=""), level=level)

def validate_url(url):
    from pydantic import HttpUrl
    return HttpUrl(url).rstrip('/')