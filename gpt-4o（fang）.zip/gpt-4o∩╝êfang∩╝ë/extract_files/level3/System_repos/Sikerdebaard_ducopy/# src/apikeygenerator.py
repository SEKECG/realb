class ApiKeyGenerator:
    def generate_api_key(self, board_serial, mac_address, time):
        # Generates a unique API key based on the MAC address, board serial, and time.
        key = f"{board_serial}{mac_address}{time}"
        transformed_key = ''.join([self.transform_char(c1, c2) for c1, c2 in zip(key[::2], key[1::2])])
        return transformed_key.ljust(64, '0')

    def transform_char(self, c1, c2):
        # Transforms two characters into a single character using XOR and ASCII adjustments.
        return chr((ord(c1) ^ ord(c2)) % 128)