class Options:
    def __init__(self, position_json):
        self.position_json = position_json
        self.option_symbol = position_json["option_symbol"]
        self.ticker = position_json["ticker"]
        self.expiration_date = position_json["expiration_date"]
        self.option_type = position_json["option_type"]
        self.strike_price = position_json["strike_price"]
        self.option_cost = position_json["option_cost"]
        self.option_market_price = position_json["option_market_price"]
        self.profit = position_json["profit"]
        self.short_quantity = position_json["short_quantity"]
        self.stock_price = position_json.get("stock_price", 0.0)
        self.delta = position_json.get("delta", 0.0)
        self.theta = position_json.get("theta", 0.0)
        self.theta_decay_percentage = position_json.get("theta_decay_percentage", 0.0)

    def create_a_rollout_order(self, new_expiration_date, new_strike_price, new_option_price):
        return {
            "option_symbol": self.option_symbol,
            "new_expiration_date": new_expiration_date,
            "new_strike_price": new_strike_price,
            "new_option_price": new_option_price,
            "instruction": OptionInstruction.BUY_TO_CLOSE
        }

    def create_an_option_order(self, ticker, expiration_date, strike_price, option_price, quantity, option_type, instruction):
        return {
            "ticker": ticker,
            "expiration_date": expiration_date,
            "strike_price": strike_price,
            "option_price": option_price,
            "quantity": quantity,
            "option_type": option_type,
            "instruction": instruction
        }

    def create_btc_order(self):
        return {
            "option_symbol": self.option_symbol,
            "instruction": OptionInstruction.BUY_TO_CLOSE,
            "profit": self.profit
        }

    def form_an_option_symbol(self, ticker, expiration_date, strike_price, option_type):
        return f"{ticker} {expiration_date}{option_type}{strike_price}"

    def is_gain_larger_than_50_percent(self):
        return self.option_market_price > 0.5 * self.option_cost

    def is_losing(self):
        return self.option_type == OptionType.PUT and self.theta_decay_percentage < 0.005 and (self.expiration_date - datetime.now()).days < 14

    def is_winning(self, max_delta_for_btc):
        return self.option_market_price < 0.5 * self.option_cost and abs(self.delta) <= max_delta_for_btc

    def set_delta(self, delta):
        self.delta = delta

    def set_stock_price(self, stock_price):
        self.stock_price = stock_price

    def set_theta(self, theta):
        self.theta = theta

    def sto_after_a_win(self, option_chains, min_expiration_weeks, min_delta, max_delta, min_premium_percentage, min_premium):
        return {
            "option_symbol": self.option_symbol,
            "instruction": OptionInstruction.SELL_TO_OPEN,
            "expiration_date": min_expiration_weeks,
            "strike_price": self.strike_price,
            "option_price": min_premium,
            "quantity": self.short_quantity,
            "option_type": self.option_type
        }

    def sto_after_btc_a_loss(self, option_chains):
        return {
            "option_symbol": self.option_symbol,
            "instruction": OptionInstruction.SELL_TO_OPEN,
            "expiration_date": self.expiration_date,
            "strike_price": self.strike_price * 0.98,
            "option_price": self.option_market_price + 0.3,
            "quantity": self.short_quantity,
            "option_type": self.option_type
        }

    def sto_an_option_order(self, ticker, option_chains, quantity, option_type, min_expiration_weeks, min_delta, max_delta, min_premium_percentage, min_premium, cost_basis):
        return {
            "ticker": ticker,
            "expiration_date": min_expiration_weeks,
            "strike_price": self.strike_price,
            "option_price": min_premium,
            "quantity": quantity,
            "option_type": option_type,
            "instruction": OptionInstruction.SELL_TO_OPEN
        }