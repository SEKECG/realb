import pandas as pd

EXISTING_OPTION_CHAINS_COLUMNS = ["symbol", "expiration_date", "strike_price", "option_type", "totalVolume", "openInterest", "bid", "ask"]
OPTION_CHAINS_COLUMNS = ["symbol", "expiration_date", "strike_price", "option_type", "totalVolume", "openInterest", "bid", "ask"]

class OptionChains:
    def __init__(self, option_chains_json):
        self.option_chains_json = option_chains_json
        self.call_option_chains_json = option_chains_json.get("calls", [])
        self.put_option_chains_json = option_chains_json.get("puts", [])
        self.option_chains_df = pd.DataFrame(option_chains_json, columns=OPTION_CHAINS_COLUMNS)

    def filter_option_candidates(self):
        filtered_df = self.option_chains_df.dropna(subset=["totalVolume", "openInterest", "bid", "ask"])
        filtered_df = filtered_df[(filtered_df["openInterest"] > 0) & (filtered_df["bid"] - filtered_df["ask"] <= BID_ASK_SPREAD_MAX)]
        return filtered_df

    def get_call_option_candidates_from_min_strike_price_and_min_premium_percentage(self, min_strike_price, min_premium, min_premium_percentage):
        candidates = self.option_chains_df[(self.option_chains_df["strike_price"] > min_strike_price) & (self.option_chains_df["bid"] > min_premium) & (self.option_chains_df["bid"] / self.option_chains_df["strike_price"] > min_premium_percentage)]
        return candidates.to_dict("records")

    def get_delta_from_option_symbol(self, option_symbol):
        return self.option_chains_df[self.option_chains_df["symbol"] == option_symbol]["delta"].values[0]

    def get_option_candidates_from_expiration_date_and_delta_range(self, min_expiration_date, min_delta, max_delta, min_premium_percentage, min_premium, option_type):
        candidates = self.option_chains_df[(self.option_chains_df["expiration_date"] > min_expiration_date) & (self.option_chains_df["delta"] >= min_delta) & (self.option_chains_df["delta"] <= max_delta) & (self.option_chains_df["bid"] / self.option_chains_df["strike_price"] > min_premium_percentage) & (self.option_chains_df["bid"] > min_premium) & (self.option_chains_df["option_type"] == option_type)]
        return candidates.to_dict("records")

    def get_put_option_candidates_from_max_strike_price_and_min_premium(self, max_strike_price, min_premium):
        candidates = self.option_chains_df[(self.option_chains_df["strike_price"] < max_strike_price) & (self.option_chains_df["bid"] > min_premium)]
        return candidates.to_dict("records")

    def get_theta_from_option_symbol(self, option_symbol):
        return self.option_chains_df[self.option_chains_df["symbol"] == option_symbol]["theta"].values[0]