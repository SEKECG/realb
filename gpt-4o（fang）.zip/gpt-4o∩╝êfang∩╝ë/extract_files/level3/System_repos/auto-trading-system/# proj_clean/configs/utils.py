import matplotlib.pyplot as plt

TOP_LEVEL_DIR = "proj_clean"

class OptionInstruction:
    BUY_TO_CLOSE = "BUY_TO_CLOSE"
    BUY_TO_OPEN = "BUY_TO_OPEN"
    SELL_TO_CLOSE = "SELL_TO_CLOSE"
    SELL_TO_OPEN = "SELL_TO_OPEN"

class OptionType:
    CALL = "CALL"
    PUT = "PUT"

class StockInstruction:
    BUY = "BUY"
    SELL = "SELL"

class TradeReason:
    BTC_FROM_LOSING = "BTC_FROM_LOSING"
    BTC_FROM_WINNING = "BTC_FROM_WINNING"
    ROLLOUT_FROM_LOSING = "ROLLOUT_FROM_LOSING"
    ROLLOUT_FROM_WINNING = "ROLLOUT_FROM_WINNING"
    STO_FROM_EARNINGS = "STO_FROM_EARNINGS"
    STO_FROM_LARGE_PRICE_CHANGE = "STO_FROM_LARGE_PRICE_CHANGE"
    STO_FROM_LOSING = "STO_FROM_LOSING"
    STO_FROM_THE_WHEEL = "STO_FROM_THE_WHEEL"
    STO_FROM_WINNING = "STO_FROM_WINNING"
    STO_FROM_other = "STO_FROM_other"

def sum_of_option_strike_prices(call_option_tickers, option_type):
    total_strike_price = 0.0
    for ticker in call_option_tickers:
        strike_price = float(ticker.split()[1][1:])
        total_strike_price += strike_price
    return total_strike_price

def theta_scatter_plot(ax, deltas, theta_decay_percentages, expiration_dates, strike_prices, tickers, subtitle):
    scatter = ax.scatter(deltas, theta_decay_percentages, s=strike_prices, c=expiration_dates, alpha=0.5)
    ax.set_xlabel('Delta')
    ax.set_ylabel('Theta Decay Percentage')
    ax.set_title('Theta Decay Scatter Plot')
    ax.legend(*scatter.legend_elements(), title="Expiration Dates")
    for i, ticker in enumerate(tickers):
        ax.annotate(ticker, (deltas[i], theta_decay_percentages[i]))
    plt.suptitle(subtitle)