from trading.theta_analyzer import ThetaAnalyzer
from trading.trade_options import TradeOptions

theta_analyzer = ThetaAnalyzer(client=None, options=[], ticker_to_stock_map={})
trade_options = TradeOptions(client=None, linked_accounts=[])

if __name__ == "__main__":
    theta_analyzer.scatter_plot()
    trade_options.trade_all_accounts()