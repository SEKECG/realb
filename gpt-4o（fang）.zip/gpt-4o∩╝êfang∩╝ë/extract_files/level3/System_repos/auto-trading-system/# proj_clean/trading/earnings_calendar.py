import json
import requests

class EarningsCalendar:
    def __init__(self):
        self.earning_tickers = []
        self.earnings_calendar_json = {}
        self.earnings_calendar_json_path = "earnings_calendar.json"
        self.earnings_json = {}
        self.headers = {"Content-Type": "application/json"}
        self.url = "https://api.example.com/earnings"

    def generate_earnings_calendar_from_yahoo_finance(self, symbol_list):
        for symbol in symbol_list:
            response = requests.get(f"https://finance.yahoo.com/quote/{symbol}/earnings")
            data = response.json()
            self.earnings_json[symbol] = data
        with open(self.earnings_calendar_json_path, 'w') as f:
            json.dump(self.earnings_json, f)

    def get_earning_tickers(self, date):
        date_str = date.strftime("%Y-%m-%d")
        if date_str in self.earnings_calendar_json:
            return self.earnings_calendar_json[date_str]
        else:
            response = requests.get(f"{self.url}?date={date_str}", headers=self.headers)
            data = response.json()
            self.earnings_calendar_json[date_str] = data
            return data