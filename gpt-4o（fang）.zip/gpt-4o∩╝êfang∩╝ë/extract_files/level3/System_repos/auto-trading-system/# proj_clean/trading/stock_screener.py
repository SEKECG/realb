class StockScreener:
    def __init__(self, client, tickers_to_scan):
        self.call_sell_candidates = []
        self.put_sell_candidates = []
        self.stocks = []
        self.tickers_to_scan = tickers_to_scan
        self.client = client

    def day_change_larger_than_x_percent(self, x_percent):
        candidates = {"put": [], "call": []}
        for stock in self.stocks:
            if stock.percent_day_change > x_percent:
                candidates["call"].append(stock.ticker)
            elif stock.percent_day_change < -x_percent:
                candidates["put"].append(stock.ticker)
        return candidates

    def month_change_larger_than_x_percent(self, x_percent):
        candidates = {"put": [], "call": []}
        for stock in self.stocks:
            if stock.percent_month_change > x_percent:
                candidates["call"].append(stock.ticker)
            elif stock.percent_month_change < -x_percent:
                candidates["put"].append(stock.ticker)
        return candidates

    def run(self, day_change, week_change, month_change):
        day_candidates = self.day_change_larger_than_x_percent(day_change)
        week_candidates = self.week_change_larger_than_x_percent(week_change)
        month_candidates = self.month_change_larger_than_x_percent(month_change)
        return {"day": day_candidates, "week": week_candidates, "month": month_candidates}

    def week_change_larger_than_x_percent(self, x_percent):
        candidates = {"put": [], "call": []}
        for stock in self.stocks:
            if stock.percent_week_change > x_percent:
                candidates["call"].append(stock.ticker)
            elif stock.percent_week_change < -x_percent:
                candidates["put"].append(stock.ticker)
        return candidates