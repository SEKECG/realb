import pandas as pd

ORDER_COLUMNS = ["account_number", "ticker", "quantity", "price", "instruction"]

class TradeOptions:
    def __init__(self, client, linked_accounts):
        self.client = client
        self.linked_accounts = linked_accounts
        self.account_number_to_hash = {}
        self.available_funds_by_account = {}
        self.options_by_account = {}
        self.order_dict_list = []
        self.order_ids = []
        self.position_tracker = {}
        self.ticker_to_stock_map_by_account = {}
        self.total_tickers = []

    def constrain_to_current_positions(self, account_number, ticker_list):
        return [ticker for ticker in ticker_list if ticker in self.position_tracker[account_number]]

    def display_all_orders(self):
        if self.order_dict_list:
            df = pd.DataFrame(self.order_dict_list, columns=ORDER_COLUMNS)
            print(df.sort_values(by="account_number"))
        else:
            print("No orders available")

    def get_existing_tickers(self):
        return set(self.total_tickers)

    def process_losing_trades(self, account_number, options, ticker_to_stock_map):
        for option in options:
            if option.is_losing():
                new_order = option.create_a_rollout_order(new_expiration_date, new_strike_price, new_option_price)
                self.order_dict_list.append(new_order)

    def process_positions(self, account_number, positions):
        for position in positions:
            self.position_tracker[account_number].append(position)
            self.ticker_to_stock_map_by_account[account_number][position.ticker] = position.stock_price
        return self.position_tracker, self.ticker_to_stock_map_by_account

    def process_winning_trades(self, account_number, options, ticker_to_stock_map):
        for option in options:
            if option.is_winning():
                new_order = option.sto_after_a_win(option_chains, min_expiration_weeks, min_delta, max_delta, min_premium_percentage, min_premium)
                self.order_dict_list.append(new_order)

    def selL_cc_and_csp(self, account_number, ticker_to_stock_map, trade_reason):
        for ticker in TICKERS_FOR_THE_WHEEL:
            if ticker in ticker_to_stock_map:
                new_order = self.sto_given_tickers(account_number, {ticker: ticker_to_stock_map[ticker]}, trade_reason)
                self.order_dict_list.append(new_order)

    def sto_given_tickers(self, account_number, tickers_to_sell_dict, trade_reason):
        for ticker, stock_price in tickers_to_sell_dict.items():
            new_order = self.sto_an_option_order(ticker, option_chains, quantity, option_type, min_expiration_weeks, min_delta, max_delta, min_premium_percentage, min_premium, cost_basis)
            self.order_dict_list.append(new_order)

    def trade_all_accounts(self):
        for account in self.linked_accounts:
            self.process_winning_trades(account, self.options_by_account[account], self.ticker_to_stock_map_by_account[account])
            self.process_losing_trades(account, self.options_by_account[account], self.ticker_to_stock_map_by_account[account])

    def trade_an_order(self, account_number, order, option_profit, trade_reason):
        order["price"] = round(order["price"], 2)
        self.order_dict_list.append(order)
        self.order_ids.append(order["order_id"])