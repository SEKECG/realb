import matplotlib.pyplot as plt

class ThetaAnalyzer:
    def __init__(self, client, options, ticker_to_stock_map):
        self.client = client
        self.options = options
        self.ticker_to_stock_map = ticker_to_stock_map
        self.total_theta = 0.0
        self.total_principal = 0.0
        self.total_put_principal = 0.0
        self.total_theta_decay_percentage = 0.0
        self.predicted_return_per_year = 0.0

    def scatter_plot(self):
        fig, ax = plt.subplots()
        deltas = [option.delta for option in self.options]
        theta_decay_percentages = [option.theta_decay_percentage for option in self.options]
        expiration_dates = [option.expiration_date for option in self.options]
        strike_prices = [option.strike_price for option in self.options]
        tickers = [option.ticker for option in self.options]
        subtitle = "Theta Decay Analysis"
        theta_scatter_plot(ax, deltas, theta_decay_percentages, expiration_dates, strike_prices, tickers, subtitle)
        plt.show()