from flask import Flask, render_template, request, redirect, session
from models import db, Students, Teachers, Admins, Exams, ExamQuestions, Questions, QuestionBanks, StudentAnswers, StudentGrades
from methods import local_date, logger
from check_questions.check_docx_questions import DocxQuestionImporter
from check_questions.check_excel_questions import ExcelQuestionImporter

app = Flask(__name__)
app.secret_key = 'supersecretkey'

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        admin = Admins.query.filter_by(admin_id=username, password=password).first()
        if admin:
            session['admin_id'] = admin.admin_id
            return redirect('/admin/dashboard')
        else:
            return 'Invalid credentials'
    return render_template('admin_login.html')

@app.route('/admin/logout')
def admin_logout():
    session.pop('admin_id', None)
    return redirect('/')

@app.route('/admin/dashboard')
def admin_dashboard():
    if 'admin_id' not in session:
        return redirect('/admin/login')
    return render_template('admin_dashboard.html')

@app.route('/admin/add_student', methods=['GET', 'POST'])
def add_student():
    if request.method == 'POST':
        student_id = request.form['student_id']
        name = request.form['name']
        student_class = request.form['student_class']
        gender = request.form['gender']
        phone_number = request.form['phone_number']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        if password == confirm_password:
            new_student = Students(student_id=student_id, name=name, student_class=student_class, gender=gender, phone_number=phone_number, password=password)
            db.session.add(new_student)
            db.session.commit()
            return redirect('/admin/manage_students')
        else:
            return 'Passwords do not match'
    return render_template('add_student.html')

@app.route('/admin/add_teacher', methods=['GET', 'POST'])
def add_teacher():
    if request.method == 'POST':
        teacher_id = request.form['teacher_id']
        name = request.form['name']
        gender = request.form['gender']
        phone_number = request.form['phone_number']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        if password == confirm_password:
            new_teacher = Teachers(teacher_id=teacher_id, name=name, gender=gender, phone_number=phone_number, password=password)
            db.session.add(new_teacher)
            db.session.commit()
            return redirect('/admin/manage_teachers')
        else:
            return 'Passwords do not match'
    return render_template('add_teacher.html')

@app.route('/admin/manage_students')
def manage_students():
    if 'admin_id' not in session:
        return redirect('/admin/login')
    students = Students.query.all()
    return render_template('manage_students.html', students=students)

@app.route('/admin/manage_teachers')
def manage_teachers():
    if 'admin_id' not in session:
        return redirect('/admin/login')
    teachers = Teachers.query.all()
    return render_template('manage_teachers.html', teachers=teachers)

@app.route('/admin/delete_student/<student_id>')
def delete_student(student_id):
    student = Students.query.filter_by(student_id=student_id).first()
    db.session.delete(student)
    db.session.commit()
    return redirect('/admin/manage_students')

@app.route('/admin/delete_teacher/<teacher_id>')
def delete_teacher(teacher_id):
    teacher = Teachers.query.filter_by(teacher_id=teacher_id).first()
    db.session.delete(teacher)
    db.session.commit()
    return redirect('/admin/manage_teachers')

@app.route('/admin/update_student/<student_id>', methods=['GET', 'POST'])
def update_student(student_id):
    student = Students.query.filter_by(student_id=student_id).first()
    if request.method == 'POST':
        student.name = request.form['name']
        student.gender = request.form['gender']
        student.phone_number = request.form['phone_number']
        student.password = request.form['password']
        db.session.commit()
        return redirect('/admin/manage_students')
    return render_template('update_student.html', student=student)

@app.route('/admin/update_teacher/<teacher_id>', methods=['GET', 'POST'])
def update_teacher(teacher_id):
    teacher = Teachers.query.filter_by(teacher_id=teacher_id).first()
    if request.method == 'POST':
        teacher.name = request.form['name']
        teacher.gender = request.form['gender']
        teacher.phone_number = request.form['phone_number']
        teacher.password = request.form['password']
        db.session.commit()
        return redirect('/admin/manage_teachers')
    return render_template('update_teacher.html', teacher=teacher)

@app.route('/admin/view_logs')
def view_logs():
    if 'admin_id' not in session:
        return redirect('/admin/login')
    try:
        with open(f'logs/{local_date}.log', 'r') as log_file:
            logs = log_file.read()
        return render_template('view_logs.html', logs=logs)
    except FileNotFoundError:
        return 'Log file not found'

@app.route('/student/register', methods=['GET', 'POST'])
def student_register():
    if request.method == 'POST':
        student_id = request.form['student_id']
        name = request.form['name']
        student_class = request.form['student_class']
        gender = request.form['gender']
        phone_number = request.form['phone_number']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        if password == confirm_password:
            new_student = Students(student_id=student_id, name=name, student_class=student_class, gender=gender, phone_number=phone_number, password=password)
            db.session.add(new_student)
            db.session.commit()
            return redirect('/student/login')
        else:
            return 'Passwords do not match'
    return render_template('student_register.html')

@app.route('/student/login', methods=['GET', 'POST'])
def student_login():
    if request.method == 'POST':
        student_id = request.form['student_id']
        password = request.form['password']
        student = Students.query.filter_by(student_id=student_id, password=password).first()
        if student:
            session['student_id'] = student.student_id
            return redirect('/student/exams')
        else:
            return 'Invalid credentials'
    return render_template('student_login.html')

@app.route('/student/logout')
def student_logout():
    session.pop('student_id', None)
    return redirect('/')

@app.route('/student/exams')
def exam_list():
    if 'student_id' not in session:
        return redirect('/student/login')
    exams = Exams.query.all()
    return render_template('exam_list.html', exams=exams)

@app.route('/student/take_exam/<exam_id>', methods=['GET', 'POST'])
def take_exam(exam_id):
    if 'student_id' not in session:
        return redirect('/student/login')
    exam = Exams.query.filter_by(id=exam_id).first()
    questions = ExamQuestions.query.filter_by(exam_id=exam_id).all()
    if request.method == 'POST':
        answers = request.form.getlist('answers')
        for question_id, answer in zip(request.form.getlist('question_ids'), answers):
            new_answer = StudentAnswers(exam_id=exam_id, question_id=question_id, student_id=session['student_id'], answer_text=answer)
            db.session.add(new_answer)
        db.session.commit()
        return redirect('/student/exams')
    return render_template('take_exam.html', exam=exam, questions=questions)

@app.route('/teacher/register', methods=['GET', 'POST'])
def teacher_register():
    if request.method == 'POST':
        teacher_id = request.form['teacher_id']
        name = request.form['name']
        gender = request.form['gender']
        phone_number = request.form['phone_number']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        if password == confirm_password:
            new_teacher = Teachers(teacher_id=teacher_id, name=name, gender=gender, phone_number=phone_number, password=password)
            db.session.add(new_teacher)
            db.session.commit()
            return redirect('/teacher/login')
        else:
            return 'Passwords do not match'
    return render_template('teacher_register.html')

@app.route('/teacher/login', methods=['GET', 'POST'])
def teacher_login():
    if request.method == 'POST':
        teacher_id = request.form['teacher_id']
        password = request.form['password']
        teacher = Teachers.query.filter_by(teacher_id=teacher_id, password=password).first()
        if teacher:
            session['teacher_id'] = teacher.teacher_id
            return redirect('/teacher/dashboard')
        else:
            return 'Invalid credentials'
    return render_template('teacher_login.html')

@app.route('/teacher/logout')
def teacher_logout():
    session.pop('teacher_id', None)
    return redirect('/')

@app.route('/teacher/dashboard')
def teacher_dashboard():
    if 'teacher_id' not in session:
        return redirect('/teacher/login')
    return render_template('teacher_dashboard.html')

@app.route('/teacher/create_exam', methods=['GET', 'POST'])
def create_exam():
    if 'teacher_id' not in session:
        return redirect('/teacher/login')
    if request.method == 'POST':
        name = request.form['name']
        start_time = request.form['start_time']
        end_time = request.form['end_time']
        question_bank_id = request.form['question_bank_id']
        new_exam = Exams(name=name, start_time=start_time, end_time=end_time, question_bank_id=question_bank_id)
        db.session.add(new_exam)
        db.session.commit()
        return redirect('/teacher/manage_exams')
    question_banks = QuestionBanks.query.all()
    return render_template('create_exam.html', question_banks=question_banks)

@app.route('/teacher/manage_exams')
def manage_exams():
    if 'teacher_id' not in session:
        return redirect('/teacher/login')
    exams = Exams.query.all()
    return render_template('manage_exams.html', exams=exams)

@app.route('/teacher/edit_exam/<exam_id>', methods=['GET', 'POST'])
def edit_exam(exam_id):
    if 'teacher_id' not in session:
        return redirect('/teacher/login')
    exam = Exams.query.filter_by(id=exam_id).first()
    if request.method == 'POST':
        exam.name = request.form['name']
        exam.start_time = request.form['start_time']
        exam.end_time = request.form['end_time']
        db.session.commit()
        return redirect('/teacher/manage_exams')
    return render_template('edit_exam.html', exam=exam)

@app.route('/teacher/delete_exam/<exam_id>')
def delete_exam(exam_id):
    if 'teacher_id' not in session:
        return redirect('/teacher/login')
    exam = Exams.query.filter_by(id=exam_id).first()
    db.session.delete(exam)
    db.session.commit()
    return redirect('/teacher/manage_exams')

@app.route('/teacher/grade_exam/<exam_id>', methods=['GET', 'POST'])
def grade_exam(exam_id):
    if 'teacher_id' not in session:
        return redirect('/teacher/login')
    exam = Exams.query.filter_by(id=exam_id).first()
    student_answers = StudentAnswers.query.filter_by(exam_id=exam_id).all()
    if request.method == 'POST':
        for answer in student_answers:
            answer.grade = request.form[f'grade_{answer.id}']
        db.session.commit()
        return redirect('/teacher/manage_exams')
    return render_template('grade_exam.html', exam=exam, student_answers=student_answers)

@app.route('/teacher/exam_report/<exam_id>')
def exam_report(exam_id):
    if 'teacher_id' not in session:
        return redirect('/teacher/login')
    exam = Exams.query.filter_by(id=exam_id).first()
    student_grades = StudentGrades.query.filter_by(exam_id=exam_id).all()
    return render_template('exam_report.html', exam=exam, student_grades=student_grades)

@app.route('/teacher/manage_question_banks', methods=['GET', 'POST'])
def manage_question_banks():
    if 'teacher_id' not in session:
        return redirect('/teacher/login')
    if request.method == 'POST':
        action = request.form['action']
        question_bank_id = request.form['question_bank_id']
        question_bank_name = request.form['question_bank_name']
        if action == 'add':
            new_question_bank = QuestionBanks(name=question_bank_name)
            db.session.add(new_question_bank)
            db.session.commit()
        elif action == 'delete':
            question_bank = QuestionBanks.query.filter_by(id=question_bank_id).first()
            db.session.delete(question_bank)
            db.session.commit()
    question_banks = QuestionBanks.query.all()
    return render_template('manage_question_banks.html', question_banks=question_banks)

@app.route('/teacher/question_bank_details/<question_bank_id>', methods=['GET', 'POST'])
def question_bank_details(question_bank_id):
    if 'teacher_id' not in session:
        return redirect('/teacher/login')
    question_bank = QuestionBanks.query.filter_by(id=question_bank_id).first()
    questions = Questions.query.filter_by(question_bank_id=question_bank_id).all()
    if request.method == 'POST':
        action = request.form['action']
        question_id = request.form['question_id']
        if action == 'delete':
            question = Questions.query.filter_by(id=question_id).first()
            db.session.delete(question)
            db.session.commit()
        elif action == 'edit':
            question = Questions.query.filter_by(id=question_id).first()
            question.content = request.form['content']
            question.answer = request.form['answer']
            question.question_type = request.form['question_type']
            db.session.commit()
    return render_template('question_bank_details.html', question_bank=question_bank, questions=questions)

@app.route('/teacher/import_question_bank', methods=['GET', 'POST'])
def import_question_bank():
    if 'teacher_id' not in session:
        return redirect('/teacher/login')
    if request.method == 'POST':
        file_path = request.form['file_path']
        question_bank_id = request.form['question_bank_id']
        if file_path.endswith('.docx'):
            importer = DocxQuestionImporter()
        else:
            importer = ExcelQuestionImporter()
        importer.import_question_bank(file_path, question_bank_id)
        return redirect('/teacher/manage_question_banks')
    question_banks = QuestionBanks.query.all()
    return render_template('import_question_bank.html', question_banks=question_banks)

@app.route('/teacher/view_grades/<exam_id>')
def view_grades(exam_id):
    if 'teacher_id' not in session:
        return redirect('/teacher/login')
    student_grades = StudentGrades.query.filter_by(exam_id=exam_id).all()
    return render_template('view_grades.html', student_grades=student_grades)

if __name__ == '__main__':
    app.run(debug=True)