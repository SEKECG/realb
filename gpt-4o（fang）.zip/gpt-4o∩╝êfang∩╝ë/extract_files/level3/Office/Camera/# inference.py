import torch

def embed_camera_settings(focal_length, aperture, iso_speed, exposure_time, prompt_embeds, 
                          negative_focal_length, negative_aperture, negative_iso_speed, 
                          negative_exposure_time, negative_prompt_embeds, cam_embed, device):
    focal_length = torch.tensor(focal_length, device=device)
    aperture = torch.tensor(aperture, device=device)
    iso_speed = torch.tensor(iso_speed, device=device)
    exposure_time = torch.tensor(exposure_time, device=device)

    negative_focal_length = torch.tensor(negative_focal_length, device=device)
    negative_aperture = torch.tensor(negative_aperture, device=device)
    negative_iso_speed = torch.tensor(negative_iso_speed, device=device)
    negative_exposure_time = torch.tensor(negative_exposure_time, device=device)

    cam_embeds = cam_embed(focal_length, aperture, iso_speed, exposure_time)
    negative_cam_embeds = cam_embed(negative_focal_length, negative_aperture, negative_iso_speed, negative_exposure_time)

    prompt_embeds = torch.cat([prompt_embeds, cam_embeds], dim=-1)
    negative_prompt_embeds = torch.cat([negative_prompt_embeds, negative_cam_embeds], dim=-1)

    return prompt_embeds, negative_prompt_embeds