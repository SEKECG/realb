import re
from typing import List, Optional
from node import ChainNode
from pattern import LevelPattern

class ChainParser:
    def __init__(self, patterns: List[LevelPattern]):
        self.patterns = patterns

    def _detect_level(self, line: str) -> Optional[ChainNode]:
        for pattern in self.patterns:
            match = re.match(pattern.regex, line)
            if match:
                level_seq = pattern.converter(match)
                return ChainNode(level_seq=level_seq, content=line, pattern_priority=pattern.priority)
        return None

    def parse_to_chain(self, text: str) -> List[ChainNode]:
        lines = text.split('\n')
        chain = []
        for line in lines:
            node = self._detect_level(line)
            if node:
                chain.append(node)
        return chain