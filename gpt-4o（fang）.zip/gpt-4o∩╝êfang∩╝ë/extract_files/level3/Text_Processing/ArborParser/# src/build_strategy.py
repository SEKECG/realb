from typing import List, Any
from node import ChainNode, TreeNode

def get_last_level(level_seq: Any) -> int:
    return level_seq[-1] if level_seq else 0

def get_prefix(level_seq: Any) -> List[int]:
    return level_seq[:-1]

def is_imm_next(front_seq: Any, back_seq: Any) -> bool:
    if len(front_seq) == len(back_seq):
        return front_seq[:-1] == back_seq[:-1] and front_seq[-1] + 1 == back_seq[-1]
    elif len(front_seq) + 1 == len(back_seq):
        return front_seq == back_seq[:-1]
    else:
        return front_seq[:len(back_seq)] == back_seq and front_seq[len(back_seq) - 1] + 1 == back_seq[-1]

def is_root(node: Any) -> bool:
    return node.level_seq == [1]

class TreeBuildingStrategy:
    def build_tree(self, chain: List[ChainNode]) -> TreeNode:
        raise NotImplementedError

class StrictStrategy(TreeBuildingStrategy):
    def build_tree(self, chain: List[ChainNode]) -> TreeNode:
        root = TreeNode()
        current_node = root
        for node in chain:
            while not is_imm_next(current_node.level_seq, node.level_seq):
                current_node = current_node.parent
            new_node = TreeNode.from_chain_node(node)
            current_node.add_child(new_node)
            current_node = new_node
        return root

class AutoPruneStrategy(TreeBuildingStrategy):
    def build_tree(self, chain: List[ChainNode]) -> TreeNode:
        root = TreeNode()
        current_node = root
        for node in chain:
            while not is_imm_next(current_node.level_seq, node.level_seq):
                current_node = current_node.parent
            new_node = TreeNode.from_chain_node(node)
            current_node.add_child(new_node)
            current_node = new_node
        return root