import re
from typing import Callable, List

class LevelPattern:
    def __init__(self, regex: re.Pattern, converter: Callable[[re.Match], List[int]], description: str):
        self.regex = regex
        self.converter = converter
        self.description = description

class NumberType:
    ARABIC = 'arabic'
    CHINESE = 'chinese'
    CIRCLED = 'circled'
    LETTER = 'letter'
    ROMAN = 'roman'

class NumberTypeInfo:
    def __init__(self, pattern: str, converter: Callable[[str], int], name: str):
        self.pattern = pattern
        self.converter = converter
        self.name = name

class PatternBuilder:
    def __init__(self, prefix_regex: str, number_type: NumberTypeInfo, suffix_regex: str, separator: str, min_level: int, max_level: int):
        self.prefix_regex = prefix_regex
        self.number_type = number_type
        self.suffix_regex = suffix_regex
        self.separator = separator
        self.min_level = min_level
        self.max_level = max_level
        self.__post_init__()

    def __post_init__(self) -> None:
        assert self.min_level <= self.max_level, "min_level must be less than or equal to max_level"

    def build(self) -> LevelPattern:
        regex = re.compile(f"{self.prefix_regex}{self.number_type.pattern}{self.suffix_regex}")
        return LevelPattern(regex, self.number_type.converter, f"{self.number_type.name} pattern")

    def modify(self, **kwargs) -> 'PatternBuilder':
        for key, value in kwargs.items():
            setattr(self, key, value)
        self.__post_init__()
        return self

CHINESE_CHAPTER_PATTERN_BUILDER = PatternBuilder(prefix_regex='', number_type=NumberTypeInfo(pattern='[一二三四五六七八九十百千万亿兆]', converter=lambda x: int(x), name='Chinese'), suffix_regex='', separator='', min_level=1, max_level=10)
CIRCLED_PATTERN_BUILDER = PatternBuilder(prefix_regex='', number_type=NumberTypeInfo(pattern='[①②③④⑤⑥⑦⑧⑨⑩]', converter=lambda x: int(x), name='Circled'), suffix_regex='', separator='', min_level=1, max_level=10)
ENGLISH_CHAPTER_PATTERN_BUILDER = PatternBuilder(prefix_regex='', number_type=NumberTypeInfo(pattern='[A-Za-z]', converter=lambda x: ord(x) - ord('A') + 1, name='English'), suffix_regex='', separator='', min_level=1, max_level=10)
NUMERIC_DASH_PATTERN_BUILDER = PatternBuilder(prefix_regex='', number_type=NumberTypeInfo(pattern='[0-9]+', converter=lambda x: int(x), name='Numeric'), suffix_regex='-', separator='-', min_level=1, max_level=10)
NUMERIC_DOT_PATTERN_BUILDER = PatternBuilder(prefix_regex='', number_type=NumberTypeInfo(pattern='[0-9]+', converter=lambda x: int(x), name='Numeric'), suffix_regex='.', separator='.', min_level=1, max_level=10)
ROMAN_PATTERN_BUILDER = PatternBuilder(prefix_regex='', number_type=NumberTypeInfo(pattern='[IVXLCDM]', converter=lambda x: roman_to_int(x), name='Roman'), suffix_regex='', separator='', min_level=1, max_level=10)