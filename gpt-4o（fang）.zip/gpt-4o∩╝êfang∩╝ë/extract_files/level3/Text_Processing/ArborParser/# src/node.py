from typing import List, Optional

class BaseNode:
    def __init__(self, level_seq: List[int], level_text: str, title: str, content: str):
        self.level_seq = level_seq
        self.level_text = level_text
        self.title = title
        self.content = content

    def concat_node(self, node: 'BaseNode') -> None:
        self.content += node.content

class ChainNode(BaseNode):
    def __init__(self, level_seq: List[int], content: str, pattern_priority: int):
        super().__init__(level_seq, '', '', content)
        self.pattern_priority = pattern_priority

class TreeNode(BaseNode):
    def __init__(self, level_seq: List[int] = None, level_text: str = '', title: str = '', content: str = ''):
        super().__init__(level_seq or [], level_text, title, content)
        self.parent: Optional['TreeNode'] = None
        self.children: List['TreeNode'] = []

    def add_child(self, child: 'TreeNode') -> None:
        child.parent = self
        self.children.append(child)

    @staticmethod
    def from_chain_node(chain_node: ChainNode) -> 'TreeNode':
        return TreeNode(level_seq=chain_node.level_seq, content=chain_node.content)

    def get_full_content(self) -> str:
        full_content = self.content
        for child in self.children:
            full_content += child.get_full_content()
        return full_content

    def merge_all_children(self) -> None:
        for child in self.children:
            self.concat_node(child)
        self.children = []