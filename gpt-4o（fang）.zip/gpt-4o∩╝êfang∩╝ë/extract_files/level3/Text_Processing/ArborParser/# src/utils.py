from typing import Optional

ALL_CHINESE_CHARS = "零一二三四五六七八九十百千万亿兆"
ALL_ROMAN_NUMERALS = "IVXLCDM"

def chinese_to_int(chinese_str: str) -> Optional[int]:
    try:
        return int(chinese_str)
    except ValueError:
        return None

def roman_to_int(roman_str: str) -> Optional[int]:
    roman_numerals = {
        'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000
    }
    result = 0
    prev_value = 0
    for char in reversed(roman_str):
        value = roman_numerals.get(char, 0)
        if value < prev_value:
            result -= value
        else:
            result += value
        prev_value = value
    return result if result > 0 else None

chinese_patterns_test = [chinese_to_int(ch) for ch in ALL_CHINESE_CHARS]
roman_patterns_test = [roman_to_int(roman) for roman in ALL_ROMAN_NUMERALS]