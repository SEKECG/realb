import os
import google.generativeai as gemini
from dotenv import load_dotenv

API_KEY_FILENAME = ".env"

def configure_ai(api_key):
    try:
        gemini.configure(api_key=api_key)
        return gemini.Model("gemini-1.5-flash-latest")
    except Exception as e:
        print(f"Error configuring AI: {e}")
        exit(1)

def load_api_key():
    load_dotenv()
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        print("Error: API key not found in .env file.")
        exit(1)
    return api_key

def parse_suggestions(ai_text):
    import re
    suggestions = re.findall(r"Command: (.*?)\nExplanation: (.*?)\n", ai_text, re.DOTALL)
    recommended = re.search(r"Recommended: (.*?)\nExplanation: (.*?)\n", ai_text, re.DOTALL)
    if not suggestions:
        return None, None, "Error parsing AI response."
    return suggestions, recommended, None

if __name__ == "__main__":
    api_key = load_api_key()
    model = configure_ai(api_key)
    user_task_description = input("Describe your task: ")
    suggester_prompt = f"Suggest multiple Linux commands for: {user_task_description}"
    response = model.chat(suggester_prompt)
    suggestions, recommended, parse_error_msg = parse_suggestions(response.text)
    if parse_error_msg:
        print(parse_error_msg)
    else:
        print("Suggestions:")
        for sug in suggestions:
            print(f"Command: {sug[0]}\nExplanation: {sug[1]}\n")
        if recommended:
            print(f"Recommended Command: {recommended[0]}\nExplanation: {recommended[1]}\n")