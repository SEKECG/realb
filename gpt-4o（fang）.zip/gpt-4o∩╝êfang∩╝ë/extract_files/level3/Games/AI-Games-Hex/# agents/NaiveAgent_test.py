import pytest
from agents.NaiveAgent import NaiveAgent
from src.Board import Board

@pytest.fixture
def mock_board():
    return Board(11)

@pytest.fixture
def naive_agent():
    return NaiveAgent("RED")

def test_naive_agent_initialization(naive_agent):
    assert naive_agent.colour == "RED"

def test_naive_agent_make_move_first_turn(naive_agent, mock_board):
    move = naive_agent.make_move(1, mock_board, None)
    assert move.x >= 0 and move.x < 11
    assert move.y >= 0 and move.y < 11

def test_naive_agent_make_move_swap_turn(naive_agent, mock_board):
    move = naive_agent.make_move(2, mock_board, None)
    assert move.x == -1 and move.y == -1

def test_naive_agent_make_move_with_opponent_move(naive_agent, mock_board):
    move = naive_agent.make_move(3, mock_board, Move(0, 0))
    assert move.x >= 0 and move.x < 11
    assert move.y >= 0 and move.y < 11