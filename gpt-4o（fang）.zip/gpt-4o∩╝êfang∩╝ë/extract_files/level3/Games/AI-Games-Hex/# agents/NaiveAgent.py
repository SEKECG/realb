import random
from src.AgentBase import AgentBase
from src.Move import Move

class NaiveAgent(AgentBase):
    def __init__(self, colour):
        super().__init__(colour)
        self._board_size = 11
        self.possible_moves = [(x, y) for x in range(self._board_size) for y in range(self._board_size)]

    def make_move(self, turn, board, opp_move):
        if turn == 2 and random.choice([True, False]):
            return Move(-1, -1)
        return Move(*random.choice(self.possible_moves))