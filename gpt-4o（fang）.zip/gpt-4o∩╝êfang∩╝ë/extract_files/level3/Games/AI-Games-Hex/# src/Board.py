from src.Tile import Tile
from src.Colour import Colour

class Board:
    def __init__(self, board_size):
        self.size = board_size
        self.tiles = [[Tile(x, y) for y in range(board_size)] for x in range(board_size)]

    def __str__(self):
        return self.print_board()

    def clear_tiles(self):
        for row in self.tiles:
            for tile in row:
                tile.clear_visit()

    @staticmethod
    def from_string(string_input, board_size):
        board = Board(board_size)
        # Implement string parsing logic here
        return board

    def get_winner(self):
        # Implement winner determination logic here
        pass

    def has_ended(self, colour):
        # Implement game end check logic here
        pass

    def print_board(self):
        # Implement board printing logic here
        pass

    def set_tile_colour(self, x, y, colour):
        self.tiles[x][y].colour = colour

    @property
    def size(self):
        return self._size

    @property
    def tiles(self):
        return self._tiles