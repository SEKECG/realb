import time
import logging
from src.Board import Board
from src.Colour import Colour
from src.Player import Player
from src.EndState import EndState

def format_result(player1_name, player2_name, winner, win_method, player_1_move_time, player_2_move_time, player_1_turn, player_2_turn, total_turns, total_time):
    return {
        "player1_name": player1_name,
        "player2_name": player2_name,
        "winner": winner,
        "win_method": win_method,
        "player_1_move_time": player_1_move_time,
        "player_2_move_time": player_2_move_time,
        "player_1_turn": player_1_turn,
        "player_2_turn": player_2_turn,
        "total_turns": total_turns,
        "total_time": total_time
    }

class Game:
    MAXIMUM_TIME = 60

    def __init__(self, player1, player2, board_size, logDest, verbose, silent):
        self._board = Board(board_size)
        self._start_time = time.time()
        self.board = self._board
        self.current_player = player1
        self.player1 = player1
        self.player2 = player2
        self.turn = 1
        self.logger = logging.getLogger("HexGame")
        if logDest:
            handler = logging.FileHandler(logDest)
            self.logger.addHandler(handler)
        if verbose:
            self.logger.setLevel(logging.DEBUG)
        elif silent:
            self.logger.setLevel(logging.ERROR)
        else:
            self.logger.setLevel(logging.INFO)

    def _end_game(self, status):
        total_time = time.time() - self._start_time
        result = format_result(
            self.player1.name, self.player2.name, status["winner"], status["win_method"],
            self.player1.move_time, self.player2.move_time, self.player1.turn, self.player2.turn,
            self.turn, total_time
        )
        self.logger.info(result)
        return result

    def _make_move(self, m):
        self.board.set_tile_colour(m.x, m.y, self.current_player.colour)
        self.logger.info(f"Move made: {m}")

    def _play(self):
        while not self.board.has_ended(self.current_player.colour):
            move = self.current_player.agent.make_move(self.turn, self.board, None)
            if self.is_valid_move(move, self.turn, self.board):
                self._make_move(move)
                self.turn += 1
                self.current_player = self.player2 if self.current_player == self.player1 else self.player1
            else:
                return self._end_game({"winner": self.current_player.name, "win_method": EndState.BAD_MOVE})
        return self._end_game({"winner": self.current_player.name, "win_method": EndState.WIN})

    @property
    def board(self):
        return self._board

    def is_valid_move(self, move, turn, board):
        # Implement move validation logic here
        pass

    @staticmethod
    def ns_to_s(t):
        return t / 1e9

    def run(self):
        self._play()

    @property
    def turn(self):
        return self._turn