class EndState:
    BAD_MOVE = "BAD_MOVE"
    FAILED_LOAD = "FAILED_LOAD"
    TIMEOUT = "TIMEOUT"
    WIN = "WIN"