class Colour:
    RED = "RED"
    BLUE = "BLUE"

    @staticmethod
    def from_char(c):
        if c == 'R':
            return Colour.RED
        elif c == 'B':
            return Colour.BLUE
        else:
            raise ValueError("Invalid colour character")

    @staticmethod
    def get_char(colour):
        return colour[0]

    @staticmethod
    def opposite(colour):
        return Colour.RED if colour == Colour.BLUE else Colour.BLUE