class Player:
    def __init__(self, agent):
        self.agent = agent
        self.move_time = 0
        self.turn = 0

    def __eq__(self, value):
        return self.agent.__hash__() == value.agent.__hash__() and self.name == value.name and self.move_time == value.move_time