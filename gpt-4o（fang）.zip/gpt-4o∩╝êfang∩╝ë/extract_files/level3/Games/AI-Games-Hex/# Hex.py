import argparse
from src.Game import Game
from src.Player import Player
from agents.NaiveAgent import NaiveAgent

parser = argparse.ArgumentParser(description="Hex Game")
parser.add_argument("--player1", type=str, default="NaiveAgent", help="Player 1 class")
parser.add_argument("--player2", type=str, default="NaiveAgent", help="Player 2 class")
parser.add_argument("--board_size", type=int, default=11, help="Board size")
parser.add_argument("--log", type=str, default=None, help="Log destination")
parser.add_argument("--verbose", action="store_true", help="Verbose mode")
parser.add_argument("--silent", action="store_true", help="Silent mode")
args = parser.parse_args()

p1_class = NaiveAgent if args.player1 == "NaiveAgent" else None
p2_class = NaiveAgent if args.player2 == "NaiveAgent" else None

p1 = Player(p1_class("RED"))
p2 = Player(p2_class("BLUE"))

g = Game(p1, p2, args.board_size, args.log, args.verbose, args.silent)
g.run()