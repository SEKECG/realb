import streamlit as st
import requests

def load_css():
    st.markdown(
        """
        <style>
        .main {
            background-color: #f0f0f5;
        }
        .stButton>button {
            background-color: #4CAF50;
            color: white;
        }
        </style>
        """,
        unsafe_allow_html=True
    )

def init_watsonx():
    api_key = st.secrets["WATSONX_API_KEY"]
    url = st.secrets["WATSONX_URL"]
    return {"api_key": api_key, "url": url}

def run_watson_granite(prompt, system_prompt):
    credentials = init_watsonx()
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {credentials['api_key']}"
    }
    data = {
        "prompt": prompt,
        "system_prompt": system_prompt
    }
    response = requests.post(credentials['url'], headers=headers, json=data)
    if response.status_code == 200:
        return response.json()["result"]
    else:
        raise Exception("Failed to get response from WatsonX")

def show_error(message):
    st.error(f"⚠️ {message}")

def show_info(message):
    st.info(f"ℹ️ {message}")

def show_success(message):
    st.success(f"✅ {message}")

def show_warning(message):
    st.warning(f"⚠️ {message}")