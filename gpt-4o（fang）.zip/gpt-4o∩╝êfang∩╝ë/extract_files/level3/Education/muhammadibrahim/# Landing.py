import streamlit as st
from utils import load_css, init_watsonx, run_watson_granite, show_error, show_info, show_success, show_warning

# Define columns for layout
col1, col2, col3, col4 = st.columns(4)
team_col1, team_col2, team_col3, team_col4, team_col5, team_col6 = st.columns(6)

# Inspirational quotes
quotes = [
    "The best way to predict the future is to create it.",
    "Education is the most powerful weapon which you can use to change the world.",
    "The beautiful thing about learning is that no one can take it away from you.",
    "The purpose of education is to replace an empty mind with an open one."
]

# Display random quote
import random
quote = random.choice(quotes)
st.write(f"**Inspirational Quote:** {quote}")

# Team information
team_info = [
    {"name": "M Ibrahim Qasmi", "role": "Team Leader, Data Science Specialist"},
    {"name": "TIJANI S. OLALEKAN", "role": "Software Engineer, Development Specialist"},
    {"name": "Maryam Sikander", "role": "ML Engineer, Machine Learning Specialist"},
    {"name": "Ahmad Fakhar", "role": "Data Analyst"},
    {"name": "M Jawad", "role": "Data Analyst"},
    {"name": "TAYYAB SAJJAD", "role": "Web Expert, Web Development Specialist"}
]

for i, col in enumerate([team_col1, team_col2, team_col3, team_col4, team_col5, team_col6]):
    col.write(f"**{team_info[i]['name']}**")
    col.write(team_info[i]['role'])

# Load custom CSS
load_css()

# Initialize WatsonX
watsonx_model = init_watsonx()

# Example usage of WatsonX model
try:
    result = run_watson_granite(prompt="Explain the concept of machine learning.", system_prompt="Educational")
    st.write(result)
except Exception as e:
    show_error(f"An error occurred: {e}")