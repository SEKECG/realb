import re
from typing import Callable, List

class LevelPattern:
    def __init__(self, regex, converter, description):
        self.regex = regex
        self.converter = converter
        self.description = description

class NumberType:
    ARABIC = "arabic"
    CHINESE = "chinese"
    CIRCLED = "circled"
    LETTER = "letter"
    ROMAN = "roman"

class NumberTypeInfo:
    def __init__(self, pattern, converter, name):
        self.pattern = pattern
        self.converter = converter
        self.name = name

class PatternBuilder:
    def __init__(self, prefix_regex, number_type, suffix_regex, separator, min_level, max_level):
        self.prefix_regex = prefix_regex
        self.number_type = number_type
        self.suffix_regex = suffix_regex
        self.separator = separator
        self.min_level = min_level
        self.max_level = max_level

    def __post_init__(self):
        # Validates the configuration of the PatternBuilder
        # Implementation goes here
        pass

    def build(self) -> LevelPattern:
        # Build a LevelPattern from the current configuration
        # Implementation goes here
        return LevelPattern(re.compile(""), lambda x: [], "")

    def modify(self, **kwargs) -> "PatternBuilder":
        # Create a new PatternBuilder with modified attributes
        # Implementation goes here
        return PatternBuilder("", NumberTypeInfo("", lambda x: 0, ""), "", "", 0, 0)

CHINESE_CHAPTER_PATTERN_BUILDER = PatternBuilder("", NumberTypeInfo("", lambda x: 0, ""), "", "", 0, 0)
CIRCLED_PATTERN_BUILDER = PatternBuilder("", NumberTypeInfo("", lambda x: 0, ""), "", "", 0, 0)
ENGLISH_CHAPTER_PATTERN_BUILDER = PatternBuilder("", NumberTypeInfo("", lambda x: 0, ""), "", "", 0, 0)
NUMERIC_DASH_PATTERN_BUILDER = PatternBuilder("", NumberTypeInfo("", lambda x: 0, ""), "", "", 0, 0)
NUMERIC_DOT_PATTERN_BUILDER = PatternBuilder("", NumberTypeInfo("", lambda x: 0, ""), "", "", 0, 0)
ROMAN_PATTERN_BUILDER = PatternBuilder("", NumberTypeInfo("", lambda x: 0, ""), "", "", 0, 0)