from typing import List, Dict, Any, Union
from pathlib import Path

class TreeBuilder:
    def __init__(self, strategy=None):
        self.strategy = strategy if strategy else StrictStrategy()

    def build_tree(self, chain) -> "TreeNode":
        # Build a tree from a list of ChainNodes using the specified strategy
        # Implementation goes here
        return TreeNode([], "", "", "")

class TreeExporter:
    def _export_tree_internal(self, node, prefix, is_last, is_root) -> str:
        # Recursively output the tree structure
        # Implementation goes here
        return ""

    def _node_to_dict(self, node) -> Dict[str, Any]:
        # Convert a node to dictionary format
        # Implementation goes here
        return {}

    def export_chain(self, chain) -> str:
        # Export the chain as a string
        # Implementation goes here
        return ""

    def export_to_json(self, tree) -> str:
        # Export the tree structure to a JSON string
        # Implementation goes here
        return ""

    def export_to_json_file(self, tree, file_path: Union[str, Path]):
        # Export the tree structure to a JSON file
        # Implementation goes here
        pass

    def export_tree(self, tree) -> str:
        # Export the tree as a formatted string
        # Implementation goes here
        return ""