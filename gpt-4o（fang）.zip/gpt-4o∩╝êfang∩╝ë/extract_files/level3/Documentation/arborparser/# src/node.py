from typing import List, Optional

class BaseNode:
    def __init__(self, level_seq, level_text, title, content):
        self.level_seq = level_seq
        self.level_text = level_text
        self.title = title
        self.content = content

    def concat_node(self, node):
        # Concatenate another node's content onto the current node
        # Implementation goes here
        pass

class ChainNode(BaseNode):
    def __init__(self, level_seq, level_text, title, content, pattern_priority):
        super().__init__(level_seq, level_text, title, content)
        self.pattern_priority = pattern_priority

class TreeNode(BaseNode):
    def __init__(self, level_seq, level_text, title, content, parent=None):
        super().__init__(level_seq, level_text, title, content)
        self.parent = parent
        self.children = []

    def add_child(self, child):
        # Add a child node to the current node
        # Implementation goes here
        pass

    @staticmethod
    def from_chain_node(chain_node) -> "TreeNode":
        # Convert a chain node to a tree node
        # Implementation goes here
        return TreeNode([], "", "", "")

    def get_full_content(self) -> str:
        # Get the full content of the current node and all its children
        # Implementation goes here
        return ""

    def merge_all_children(self):
        # Merge all children into the current node
        # Implementation goes here
        pass