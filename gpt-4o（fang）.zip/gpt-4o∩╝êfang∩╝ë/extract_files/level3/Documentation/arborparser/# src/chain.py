from typing import List, Optional

class ChainNode:
    def __init__(self, pattern_priority):
        self.pattern_priority = pattern_priority

class ChainParser:
    def __init__(self, patterns):
        self.patterns = patterns

    def _detect_level(self, line) -> Optional[ChainNode]:
        # Apply all patterns to detect the title hierarchy
        # Implementation goes here
        return None

    def parse_to_chain(self, text) -> List[ChainNode]:
        chain_nodes = []
        # Core parsing logic to convert text into a chain of nodes
        # Implementation goes here
        return chain_nodes