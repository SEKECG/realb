from typing import List

def get_last_level(level_seq):
    return level_seq[-1] if level_seq else 0

def get_prefix(level_seq) -> List[int]:
    return level_seq[:-1]

def is_imm_next(front_seq, back_seq) -> bool:
    # Determine if two nodes are immediate siblings based on their sequences
    # Implementation goes here
    return False

def is_root(node) -> bool:
    # Check if a node is the root of a tree
    # Implementation goes here
    return False

class TreeBuildingStrategy:
    def build_tree(self, chain):
        # Build a tree from a list of ChainNodes
        # Implementation goes here
        pass

class AutoPruneStrategy(TreeBuildingStrategy):
    def build_tree(self, chain):
        # Convert chain nodes to a tree structure using an auto-prune strategy
        # Implementation goes here
        pass

class StrictStrategy(TreeBuildingStrategy):
    def build_tree(self, chain):
        # Convert chain nodes to a tree structure using a strict strategy
        # Implementation goes here
        pass