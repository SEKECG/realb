from flask import Flask, request, jsonify
from methods import StudentModule, TeacherModule, AdminModule
from models import db, Exams, QuestionBanks, Questions, QuestionOptions, StudentAnswers, StudentGrades, Students, Admins, Teachers, BaseModel
from check_questions.check_docx_questions import DocxQuestionImporter
from check_questions.check_excel_questions import ExcelQuestionImporter
import datetime

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
db.init_app(app)

student_module = StudentModule()
teacher_module = TeacherModule()
admin_module = AdminModule()

@app.route('/api/student/login', methods=['POST'])
def student_login():
    student_id = request.form.get('student_id')
    password = request.form.get('password')
    return student_module.login(student_id, password)

@app.route('/api/student/logout', methods=['POST'])
def student_logout():
    return student_module.logout()

@app.route('/api/student/register', methods=['POST'])
def student_register():
    student_id = request.form.get('student_id')
    name = request.form.get('name')
    student_class = request.form.get('student_class')
    gender = request.form.get('gender')
    phone_number = request.form.get('phone_number')
    password = request.form.get('password')
    confirm_password = request.form.get('confirm_password')
    return student_module.register(student_id, name, student_class, gender, phone_number, password, confirm_password)

@app.route('/api/student/exams', methods=['GET'])
def list_exams():
    return student_module.list_exams()

@app.route('/api/student/exams/<int:exam_id>/submit', methods=['POST'])
def submit_exam_answers(exam_id):
    student_id = request.form.get('student_id')
    answers = request.form.get('answers')
    return student_module.submit_exam_answers(student_id, exam_id, answers)

@app.route('/api/teacher/login', methods=['POST'])
def teacher_login():
    teacher_id = request.form.get('teacher_id')
    password = request.form.get('password')
    return teacher_module.login(teacher_id, password)

@app.route('/api/teacher/logout', methods=['POST'])
def teacher_logout():
    return teacher_module.logout()

@app.route('/api/teacher/register', methods=['POST'])
def teacher_register():
    teacher_id = request.form.get('teacher_id')
    name = request.form.get('name')
    gender = request.form.get('gender')
    phone_number = request.form.get('phone_number')
    password = request.form.get('password')
    confirm_password = request.form.get('confirm_password')
    return teacher_module.register(teacher_id, name, gender, phone_number, password, confirm_password)

@app.route('/api/teacher/exams', methods=['GET'])
def manage_exams():
    return teacher_module.manage_exams()

@app.route('/api/teacher/exams/<int:exam_id>', methods=['PUT'])
def edit_exam(exam_id):
    name = request.form.get('name')
    start_time = request.form.get('start_time')
    end_time = request.form.get('end_time')
    return teacher_module.edit_exam(exam_id, name, start_time, end_time)

@app.route('/api/teacher/exams/<int:exam_id>/questions', methods=['PUT'])
def assign_questions_to_exam(exam_id):
    question_ids_with_scores = request.form.get('question_ids_with_scores')
    return teacher_module.assign_questions_to_exam(exam_id, question_ids_with_scores)

@app.route('/api/teacher/exams/<int:exam_id>/auto-grade', methods=['POST'])
def auto_grade_exam(exam_id):
    return teacher_module.auto_grade_exam(exam_id)

@app.route('/api/teacher/exams/<int:exam_id>/report', methods=['GET'])
def exam_report(exam_id):
    return teacher_module.generate_exam_report(exam_id)

@app.route('/api/teacher/question-banks', methods=['GET'])
def manage_question_banks():
    return teacher_module.manage_question_banks()

@app.route('/api/teacher/question-banks/<int:question_bank_id>', methods=['PUT'])
def edit_question_bank(question_bank_id):
    question_bank_name = request.form.get('question_bank_name')
    return teacher_module.edit_question_bank(question_bank_id, question_bank_name)

@app.route('/api/teacher/question-banks/<int:question_bank_id>/questions', methods=['POST'])
def add_question(question_bank_id):
    question_type = request.form.get('question_type')
    content = request.form.get('content')
    answer = request.form.get('answer')
    options = request.form.get('options')
    return teacher_module.add_question(question_bank_id, question_type, content, answer, options)

@app.route('/api/teacher/question-banks/<int:question_bank_id>/questions/<int:question_id>', methods=['PUT'])
def edit_question(question_bank_id, question_id):
    question_type = request.form.get('question_type')
    content = request.form.get('content')
    answer = request.form.get('answer')
    options = request.form.get('options')
    return teacher_module.edit_question(question_bank_id, question_id, question_type, content, answer, options)

@app.route('/api/teacher/question-banks/<int:question_bank_id>/questions/<int:question_id>', methods=['DELETE'])
def delete_question(question_bank_id, question_id):
    return teacher_module.delete_question(question_bank_id, question_id)

@app.route('/api/teacher/question-banks/<int:question_bank_id>/import', methods=['POST'])
def import_question_bank(question_bank_id):
    file_path = request.form.get('file_path')
    return teacher_module.import_question_bank(file_path, question_bank_id)

@app.route('/api/admin/login', methods=['POST'])
def admin_login():
    username = request.form.get('username')
    password = request.form.get('password')
    return admin_module.login(username, password)

@app.route('/api/admin/logout', methods=['POST'])
def admin_logout():
    return admin_module.logout()

@app.route('/api/admin/teachers', methods=['GET'])
def manage_teachers():
    return admin_module.manage_teacher_accounts()

@app.route('/api/admin/teachers/<int:teacher_id>', methods=['PUT'])
def update_teacher(teacher_id):
    name = request.form.get('name')
    gender = request.form.get('gender')
    phone_number = request.form.get('phone_number')
    password = request.form.get('password')
    return admin_module.update_teacher(teacher_id, name, gender, phone_number, password)

@app.route('/api/admin/teachers/<int:teacher_id>', methods=['DELETE'])
def delete_teacher(teacher_id):
    return admin_module.delete_teacher(teacher_id)

@app.route('/api/admin/students', methods=['GET'])
def manage_students():
    return admin_module.manage_student_accounts()

@app.route('/api/admin/students/<int:student_id>', methods=['PUT'])
def update_student(student_id):
    name = request.form.get('name')
    gender = request.form.get('gender')
    phone_number = request.form.get('phone_number')
    password = request.form.get('password')
    return admin_module.update_student(student_id, name, gender, phone_number, password)

@app.route('/api/admin/students/<int:student_id>', methods=['DELETE'])
def delete_student(student_id):
    return admin_module.delete_student(student_id)

@app.route('/api/admin/logs', methods=['GET'])
def view_logs():
    return admin_module.view_logs()

@app.route('/api/admin/teachers/search', methods=['GET'])
def search_teacher():
    teacher_id = request.args.get('teacher_id')
    name = request.args.get('name')
    return admin_module.search_teacher(teacher_id, name)

@app.route('/api/admin/students/search', methods=['GET'])
def search_student():
    student_id = request.args.get('student_id')
    name = request.args.get('name')
    return admin_module.search_student(student_id, name)

@app.route('/api/admin/grades', methods=['GET'])
def view_grades():
    exam_id = request.args.get('exam_id')
    student_id = request.args.get('student_id')
    student_name = request.args.get('student_name')
    return admin_module.view_grades(exam_id, student_id, student_name)

if __name__ == '__main__':
    app.run(debug=True)