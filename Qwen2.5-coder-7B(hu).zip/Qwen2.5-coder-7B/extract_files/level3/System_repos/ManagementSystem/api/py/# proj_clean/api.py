from flask import Flask, render_template, request, redirect, url_for, session
from methods import StudentModule, TeacherModule, AdminModule
from models import db, Exams, QuestionBanks, Questions, QuestionOptions, StudentAnswers, StudentGrades, Students, Admins, Teachers, BaseModel
from check_questions.check_docx_questions import DocxQuestionImporter
from check_questions.check_excel_questions import ExcelQuestionImporter
import datetime

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'

student_module = StudentModule()
teacher_module = TeacherModule()
admin_module = AdminModule()

# ... (other functions and methods)

if __name__ == '__main__':
    app.run(debug=True)