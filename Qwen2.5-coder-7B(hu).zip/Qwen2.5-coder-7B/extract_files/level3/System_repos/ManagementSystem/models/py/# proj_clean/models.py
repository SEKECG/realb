from datetime import datetime
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class BaseModel(db.Model):
    __abstract__ = True
    reserved1 = db.Column(db.String(255))
    reserved2 = db.Column(db.String(255))

class ExamQuestions(db.Model):
    __tablename__ = 'exam_questions'
    id = db.Column(db.Integer, primary_key=True)
    exam_id = db.Column(db.Integer, db.ForeignKey('exams.id'))
    question_id = db.Column(db.Integer, db.ForeignKey('questions.id'))
    score = db.Column(db.Float)

    exam = db.relationship('Exams', backref=db.backref('exam_questions', lazy=True))
    question = db.relationship('Questions', backref=db.backref('exam_questions', lazy=True))

class Exams(db.Model):
    __tablename__ = 'exams'
    id = db.Column(db.Integer, primary_key=True)
    start_time = db.Column(db.DateTime)
    end_time = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    name = db.Column(db.String(255))
    question_bank_id = db.Column(db.Integer, db.ForeignKey('question_banks.id'))

    question_bank = db.relationship('QuestionBanks', backref=db.backref('exams', lazy=True))

class QuestionBanks(db.Model):
    __tablename__ = 'question_banks'
    id = db.Column(db.Integer, primary_key=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    name = db.Column(db.String(255))

    questions = db.relationship('Questions', backref=db.backref('question_bank', lazy=True))

class QuestionOptions(db.Model):
    __tablename__ = 'question_options'
    id = db.Column(db.Integer, primary_key=True)
    question_id = db.Column(db.Integer, db.ForeignKey('questions.id'))
    is_correct = db.Column(db.Boolean)
    option_text = db.Column(db.String(255))

    question = db.relationship('Questions', backref=db.backref('question_options', lazy=True))

class Questions(db.Model):
    __tablename__ = 'questions'
    id = db.Column(db.Integer, primary_key=True)
    question_bank_id = db.Column(db.Integer, db.ForeignKey('question_banks.id'))
    answer = db.Column(db.String(255))
    content = db.Column(db.String(255))
    question_type = db.Column(db.String(255))

    question_bank = db.relationship('QuestionBanks', backref=db.backref('questions', lazy=True))

class StudentAnswers(db.Model):
    __tablename__ = 'student_answers'
    id = db.Column(db.Integer, primary_key=True)
    exam_id = db.Column(db.Integer, db.ForeignKey('exams.id'))
    question_id = db.Column(db.Integer, db.ForeignKey('questions.id'))
    student_id = db.Column(db.Integer, db.ForeignKey('students.id'))
    answer_text = db.Column(db.String(255))
    selected_option_id = db.Column(db.Integer, db.ForeignKey('question_options.id'))

    exam = db.relationship('Exams', backref=db.backref('student_answers', lazy=True))
    question = db.relationship('Questions', backref=db.backref('student_answers', lazy=True))
    student = db.relationship('Students', backref=db.backref('student_answers', lazy=True))
    selected_option = db.relationship('QuestionOptions', backref=db.backref('student_answers', lazy=True))

class StudentGrades(db.Model):
    __tablename__ = 'student_grades'
    id = db.Column(db.Integer, primary_key=True)
    exam_id = db.Column(db.Integer, db.ForeignKey('exams.id'))
    grade = db.Column(db.Float)
    student_id = db.Column(db.Integer, db.ForeignKey('students.id'))

    exam = db.relationship('Exams', backref=db.backref('student_grades', lazy=True))
    student = db.relationship('Students', backref=db.backref('student_grades', lazy=True))

class Students(db.Model):
    __tablename__ = 'students'
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.String(255))
    name = db.Column(db.String(255))
    password = db.Column(db.String(255))
    gender = db.Column(db.String(255))
    phone_number = db.Column(db.String(255))
    student_class = db.Column(db.String(255))

class Admins(db.Model):
    __tablename__ = 'admins'
    id = db.Column(db.Integer, primary_key=True)
    admin_id = db.Column(db.String(255))
    password = db.Column(db.String(255))
    name = db.Column(db.String(255))
    phone_number = db.Column(db.String(255))

class Teachers(db.Model):
    __tablename__ = 'teachers'
    id = db.Column(db.Integer, primary_key=True)
    teacher_id = db.Column(db.String(255))
    name = db.Column(db.String(255))
    password = db.Column(db.String(255))
    gender = db.Column(db.String(255))
    phone_number = db.Column(db.String(255))