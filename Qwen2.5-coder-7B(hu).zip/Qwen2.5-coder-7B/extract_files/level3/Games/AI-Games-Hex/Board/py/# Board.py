from Colour import Colour
from Tile import Tile

class Board:
    def __init__(self, board_size):
        self.size = board_size
        self.tiles = [[Tile(i, j) for j in range(board_size)] for i in range(board_size)]

    def set_tile_colour(self, x, y, colour):
        self.tiles[x][y].colour = colour

    def get_winner(self):
        for i in range(self.size):
            if self.DFS_colour(0, i, Colour.RED):
                return Colour.RED
            if self.DFS_colour(i, 0, Colour.BLUE):
                return Colour.BLUE
        return None

    def DFS_colour(self, x, y, colour):
        if x < 0 or x >= self.size or y < 0 or y >= self.size:
            return False
        if self.tiles[x][y].colour != colour:
            return False
        if self.tiles[x][y].is_visited():
            return False
        self.tiles[x][y].visit()
        if x == self.size - 1 and colour == Colour.RED:
            return True
        if y == self.size - 1 and colour == Colour.BLUE:
            return True
        for i in range(6):
            if self.DFS_colour(x + Tile.I_DISPLACEMENTS[i], y + Tile.J_DISPLACEMENTS[i], colour):
                return True
        return False

    def clear_tiles(self):
        for i in range(self.size):
            for j in range(self.size):
                self.tiles[i][j].clear_visit()

    def __str__(self):
        return self.print_board()

    def print_board(self):
        board_str = ""
        for i in range(self.size):
            for j in range(self.size):
                board_str += str(self.tiles[i][j].colour)
            board_str += "\n"
        return board_str

    def from_string(self, string_input, board_size):
        self.size = board_size
        self.tiles = [[Tile(i, j) for j in range(board_size)] for i in range(board_size)]
        for i in range(board_size):
            for j in range(board_size):
                self.tiles[i][j].colour = Colour.from_char(string_input[i * board_size + j])

    def has_ended(self, colour):
        return self.get_winner() == colour

    def __eq__(self, value):
        if not isinstance(value, Board):
            return False
        if self.size != value.size:
            return False
        for i in range(self.size):
            for j in range(self.size):
                if self.tiles[i][j].colour != value.tiles[i][j].colour:
                    return False
        return True

    def size_getter(self):
        return self.size

    def tiles_getter(self):
        return self.tiles