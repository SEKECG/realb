import os
from azure.kusto.data import KustoClient, KustoConnectionStringBuilder
from azure.identity import WorkloadIdentityCredential, DefaultAzureCredential
from azure.core.exceptions import ClientAuthenticationError
from typing import List, Dict, Any

class ADXConfig:
    def __init__(self, cluster_url: str, database_name: str):
        self.cluster_url = cluster_url
        self.database_name = database_name

def execute_query(query: Any) -> List[Dict[str, Any]]:
    # Execute Kusto Query Language (KQL) queries against the configured database
    # ...

def format_query_results(result_set: Any) -> List[Dict[str, Any]]:
    # Convert a query result set into a list of dictionaries where each dictionary represents a row with column names as keys and corresponding row values as values.
    # ...

def get_kusto_client() -> KustoClient:
    # Create and return a KustoClient instance configured with Azure authentication credentials
    # using either WorkloadIdentityCredential (preferred) or DefaultAzureCredential as a fallback.
    # Get tenant and client IDs from environment variables
    # ...

def get_table_details(table_name: Any) -> List[Dict[str, Any]]:
    # Retrieve detailed table information including row counts and extent sizes
    # ...

def get_table_schema(table_name: Any) -> List[Dict[str, Any]]:
    # Retrieve schema information for specified tables including column names and data types
    # ...

def list_tables() -> List[Dict[str, Any]]:
    # List all available tables in the database with their names, folders, and database associations
    # ...

def sample_table_data(table_name: Any, sample_size: Any) -> List[Dict[str, Any]]:
    # Sample random rows from specified tables with configurable sample size
    # ...

config = ADXConfig(
    cluster_url=os.getenv("ADX_CLUSTER_URL"),
    database_name=os.getenv("ADX_DATABASE_NAME")
)