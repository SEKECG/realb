import os
from dotenv import load_dotenv
from adx_mcp_server.server import run_server

def run_server():
    setup_environment()
    run_server()

def setup_environment():
    load_dotenv()
    # Load and validate environment variables for Azure Data Explorer configuration
    # including cluster URL, database name, and authentication credentials
    # with support for both workload identity and default Azure authentication methods.
    # Get tenant and client IDs from environment variables
    # ...

if __name__ == "__main__":
    run_server()