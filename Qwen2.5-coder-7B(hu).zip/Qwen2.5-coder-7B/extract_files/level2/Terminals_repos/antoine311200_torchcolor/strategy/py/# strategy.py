from typing import Any, Union, Dict, List, Tuple, Optional
from dataclasses import dataclass, field
from .color import Color, Gradient, Palette
from .style import TextStyle, FunctionalStyle, ModuleStyle
from .printer import Printer

@dataclass
class ColorStrategy:
    _registry: Dict[str, "ColorStrategy"] = field(default_factory=dict, init=False)
    disable_registry: bool = False

    @classmethod
    def get_strategy(cls, key: str, *args: Any, **kwargs: Any) -> "ColorStrategy":
        if key not in cls._registry:
            raise ValueError(f"Strategy '{key}' is not registered.")
        return cls._registry[key](*args, **kwargs)

    @classmethod
    def available_strategies(cls) -> List[str]:
        return list(cls._registry.keys())

    @classmethod
    def create(cls, key: str, *args: Any, **kwargs: Any) -> "ColorStrategy":
        return cls.get_strategy(key, *args, **kwargs)

    @classmethod
    def register(cls, key: str) -> Any:
        def decorator(strategy_cls: Any) -> Any:
            if not cls.disable_registry:
                cls._registry[key] = strategy_cls
            return strategy_cls
        return decorator

    def get_style(self, module: Any, params: Dict[str, Any]) -> ModuleStyle:
        raise NotImplementedError

@dataclass
class ModuleStyle:
    name_style: Union[TextStyle, FunctionalStyle]
    layer_style: Union[TextStyle, FunctionalStyle]
    extra_style: Union[TextStyle, FunctionalStyle]

@dataclass
class ConstantColorStrategy(ColorStrategy):
    color: Union[str, Tuple[int, int, int]] = ""

    def __init__(self, color: Union[str, Tuple[int, int, int]] = "") -> None:
        self.color = color

    def get_style(self, module: Any, config: Dict[str, Any]) -> ModuleStyle:
        return ModuleStyle(
            name_style=TextStyle(fg_style=self.color),
            layer_style=TextStyle(fg_style=self.color),
            extra_style=TextStyle(fg_style=self.color)
        )

@dataclass
class LayerColorStrategy(ColorStrategy):
    def get_style(self, module: Any, config: Dict[str, Any]) -> ModuleStyle:
        raise NotImplementedError

@dataclass
class TrainableStrategy(ColorStrategy):
    def get_style(self, module: Any, config: Dict[str, Any]) -> ModuleStyle:
        if all(param.requires_grad for param in module.parameters()):
            return ModuleStyle(
                name_style=TextStyle(fg_style="green"),
                layer_style=TextStyle(fg_style="green"),
                extra_style=TextStyle(fg_style="green")
            )
        elif any(param.requires_grad for param in module.parameters()):
            return ModuleStyle(
                name_style=TextStyle(fg_style="yellow"),
                layer_style=TextStyle(fg_style="yellow"),
                extra_style=TextStyle(fg_style="yellow")
            )
        else:
            return ModuleStyle(
                name_style=TextStyle(fg_style="red"),
                layer_style=TextStyle(fg_style="red"),
                extra_style=TextStyle(fg_style="red")
            )