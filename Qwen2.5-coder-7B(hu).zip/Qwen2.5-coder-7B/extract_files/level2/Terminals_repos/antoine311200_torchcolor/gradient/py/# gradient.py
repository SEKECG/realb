from .color import Color, ColorStyle
from .palette import Palette
from .style import TextStyle, FunctionalStyle, ModuleStyle
from .printer import Printer
from .strategy import ColorStrategy, ModuleStyle

class Gradient:
    def __init__(self, palette: Union[Palette, str], interpolate: bool = True, repeat: bool = True, reverse: bool = False, window_size: int = 1):
        self.palette = palette
        self.interpolate = interpolate
        self.repeat = repeat
        self.reverse = reverse
        self.window_size = window_size

    def apply(self, text: str) -> List[GradientChunk]:
        palette = self._ensure_palette(self.palette)
        colors = palette.generate_gradient(len(text))
        chunks = []
        start = 0
        for i, color in enumerate(colors):
            end = start + self.window_size
            if end > len(text):
                end = len(text)
            chunks.append(GradientChunk(start, end, color))
            start = end
        return chunks

    def _ensure_palette(self, palette: Union[Palette, str]) -> Palette:
        if isinstance(palette, Palette):
            return palette
        else:
            return Palette.get_palette(palette)

class GradientChunk:
    def __init__(self, start: int, end: int, color: Color):
        self.start = start
        self.end = end
        self.color = color

class GradientStyle(TextStyle):
    def __init__(self, gradient: Gradient, **kwargs):
        super().__init__(**kwargs)
        self.gradient = gradient

    def apply(self, text: str) -> str:
        chunks = self.gradient.apply(text)
        styled_text = ""
        for chunk in chunks:
            styled_text += self.gradient.color.apply(text[chunk.start:chunk.end])
        return styled_text

class GradientFunctionalStyle(FunctionalStyle):
    def __init__(self, gradient: Gradient, **kwargs):
        super().__init__(**kwargs)
        self.gradient = gradient

    def apply(self, text: str) -> str:
        chunks = self.gradient.apply(text)
        styled_text = ""
        for chunk in chunks:
            styled_text += self.gradient.color.apply(text[chunk.start:chunk.end])
        return styled_text

class GradientModuleStyle(ModuleStyle):
    def __init__(self, gradient: Gradient, **kwargs):
        super().__init__(**kwargs)
        self.gradient = gradient

    def apply(self, text: str) -> str:
        chunks = self.gradient.apply(text)
        styled_text = ""
        for chunk in chunks:
            styled_text += self.gradient.color.apply(text[chunk.start:chunk.end])
        return styled_text

class GradientColorStrategy(ColorStrategy):
    def __init__(self, gradient: Gradient, **kwargs):
        super().__init__(**kwargs)
        self.gradient = gradient

    def get_style(self, module: Module, params: dict) -> ModuleStyle:
        return GradientModuleStyle(self.gradient)

class GradientPrinter(Printer):
    def __init__(self, strategy: ColorStrategy, **kwargs):
        super().__init__(strategy, **kwargs)
        self.gradient = strategy.gradient

    def print(self, module: Module, display_depth: int = 0, display_legend: bool = False) -> None:
        super().print(module, display_depth, display_legend)
        self.gradient.apply(module.name)