import h5py
import numpy as np
import os
import re
import shutil
import sys
import tempfile
import warnings
from collections import OrderedDict
from functools import partial
from itertools import chain
from multiprocessing import Pool
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

import qutip as qt

from .options import Options


class Serializable:
    """Mixin class for reading and writing to file using h5py."""

    def __str__(self) -> str:
        """Generate a string representation of the object by concatenating its initialized attributes (excluding None values) in the format "key: value", with each attribute on a new line."""
        return "\n".join(
            f"{key}: {value}"
            for key, value in self.__dict__.items()
            if value is not None
        )

    def __eq__(self, other: Any) -> bool:
        """Compare two objects of the same class for equality by checking if their initialization parameters are equal, including handling NumPy arrays with `np.allclose`."""
        if not isinstance(other, type(self)):
            return False
        return all(
            np.allclose(getattr(self, key), getattr(other, key))
            if isinstance(getattr(self, key), np.ndarray)
            else getattr(self, key) == getattr(other, key)
            for key in self.__init_params__
        )

    def __new__(cls, *args: Any, **kwargs: Any) -> "Serializable":
        """noqa ARG003
        Records which parameters should be saved so they can be passed to init.
        """
        obj = super().__new__(cls)
        obj.__init_params__ = get_init_params(obj)
        return obj

    def serialize(self) -> Dict[str, Any]:
        """Serialize a class so that it is ready to be written.

        This method creates nested dictionaries appropriate for writing to h5 files.
        Importantly, we save metadata associated with the class itself and any classes
        it takes as input so that they can be reinstantiated later.

        Returns:
            initdata: Dictionary of data to save, in a format appropriate to pass to h5
        """
        initdata = {}
        for key, value in self.__dict__.items():
            if isinstance(value, Serializable):
                initdata[key] = value.serialize()
            elif isinstance(value, np.ndarray):
                initdata[key] = value.tolist()
            else:
                initdata[key] = value
        return initdata

    def write_to_file(self, filepath: str, data_dict: Dict[str, Any]) -> None:
        """Write a class and associated data to file.

        The goal is to be able to read back both the data that was saved and all of the
        data necessary to reinitialize the class.

        Parameters:
            filepath: Path to the file where we want to save the data. Must be an h5 or
                h5py file
            data_dict: Dictionary containing various raw data to save
        """
        with h5py.File(filepath, "w") as f:
            for key, value in self.serialize().items():
                f.create_dataset(key, data=value)
            for key, value in data_dict.items():
                if isinstance(value, np.ndarray):
                    f.create_dataset(key, data=value)
                else:
                    f.create_dataset(key, data=str(value))


def get_init_params(obj: Any) -> List[str]:
    """Returns a list of parameters entering `__init__` of `obj`."""
    return [
        param
        for param in dir(obj)
        if not param.startswith("__")
        and not callable(getattr(obj, param))
        and not isinstance(getattr(obj, param), property)
    ]


def generate_file_path(
    extension: str, file_name: str, path: str
) -> str:
    """Generate a unique file path within a specified directory by appending a numeric prefix to the given file name to avoid conflicts, ensuring the directory exists. The numeric prefix is determined by the highest existing prefix in the directory, incremented by one, and formatted with leading zeros.

    Ensure the path exists.

    Parameters:
        extension: File extension (e.g., ".h5")
        file_name: Base file name
        path: Directory path

    Returns:
        str: Unique file path
    """
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    prefix = 0
    while True:
        file_path = path / f"{file_name}_{prefix:03d}{extension}"
        if not file_path.exists():
            return str(file_path)
        prefix += 1


def read_from_file(filepath: str) -> Tuple["Serializable", Dict[str, Any]]:
    """Read a class and associated data from file.

    Parameters:
        filepath: Path to the file containing both raw data and the information needed
            to reinitialize our class

    Returns:
        new_class_instance: Class that inherits from Serializable that was earlier
            written with its method write_to_file
        data_dict: Dictionary of data that was passed to write_to_file at the time
    """
    with h5py.File(filepath, "r") as f:
        initdata = {}
        for key in f.keys():
            if isinstance(f[key], h5py.Dataset):
                if f[key].dtype == np.dtype("O"):
                    initdata[key] = f[key][()].encode("utf-8")
                else:
                    initdata[key] = f[key][()]
            else:
                initdata[key] = f[key][()]
        data_dict = {}
        for key in f.keys():
            if isinstance(f[key], h5py.Dataset):
                if f[key].dtype == np.dtype("O"):
                    data_dict[key] = f[key][()].encode("utf-8")
                else:
                    data_dict[key] = f[key][()]
            else:
                data_dict[key] = f[key][()]
        new_class_instance = Serializable()
        for key, value in initdata.items():
            setattr(new_class_instance, key, value)
        return new_class_instance, data_dict


def parallel_map(
    num_cpus: int, func: Callable, parameters: List[Any]
) -> map:
    """Apply a function to each item in an iterable in parallel using multiple CPU cores for improved performance.

    Parameters:
        num_cpus: Number of CPU cores to use
        func: Function to apply to each item
        parameters: Iterable of parameters to pass to the function

    Returns:
        map: Map object containing the results of applying the function to each item
    """
    with Pool(num_cpus) as pool:
        return pool.map(func, parameters)