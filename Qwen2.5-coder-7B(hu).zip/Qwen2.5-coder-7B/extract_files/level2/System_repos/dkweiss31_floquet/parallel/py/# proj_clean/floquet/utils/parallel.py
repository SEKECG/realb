from multiprocessing import Pool
from typing import Any, Callable, Iterable, List, Tuple

def parallel_map(num_cpus: int, func: Callable, parameters: Iterable) -> map:
    """
    Apply a function to each item in an iterable in parallel using multiple CPU cores for improved performance.

    Parameters:
        num_cpus: Number of CPU cores to use for parallel processing.
        func: Function to apply to each item in the iterable.
        parameters: Iterable containing the parameters to pass to the function.

    Returns:
        map: A map object containing the results of applying the function to each item in the iterable.
    """
    with Pool(processes=num_cpus) as pool:
        return pool.map(func, parameters)