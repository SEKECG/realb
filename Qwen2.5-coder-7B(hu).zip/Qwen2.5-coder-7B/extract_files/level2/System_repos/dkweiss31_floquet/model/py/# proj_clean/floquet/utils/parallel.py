from multiprocessing import Pool
from typing import Any, Callable, Iterable, List, Optional, Tuple, Union

import numpy as np
import qutip as qt

from .file_io import Serializable


def parallel_map(
    num_cpus: int, func: Any, parameters: Any
) -> map:
    """
    Apply a function to each item in an iterable in parallel using multiple CPU cores for improved performance.

    Parameters:
        num_cpus (int): Number of CPU cores to use.
        func (Any): The function to apply.
        parameters (Any): The iterable of parameters to apply the function to.

    Returns:
        map: The result of applying the function in parallel.
    """
    with Pool(num_cpus) as pool:
        return pool.map(func, parameters)