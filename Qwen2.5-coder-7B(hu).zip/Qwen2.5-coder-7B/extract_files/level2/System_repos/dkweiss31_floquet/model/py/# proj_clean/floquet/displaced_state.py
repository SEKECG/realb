import numpy as np
import qutip as qt

from .model import Model


class DisplacedState(Serializable):
    """
    Class providing methods for computing displaced states.

    Parameters:
        hilbert_dim (int): Hilbert space dimension
        model (Model): Model including the Hamiltonian, drive amplitudes, frequencies,
            state indices
        state_indices (List[int]): States of interest
        options (Options): Options used
    """

    def __init__(
        self,
        hilbert_dim: int,
        model: Model,
        state_indices: List[int],
        options: Options,
    ) -> None:
        """
        Initialize an instance of the class with the specified Hilbert dimension, model, state indices, and options, and create a mapping for exponent pairs.

        Parameters:
            hilbert_dim (int): Hilbert space dimension
            model (Model): Model including the Hamiltonian, drive amplitudes, frequencies,
                state indices
            state_indices (List[int]): States of interest
            options (Options): Options used
        """
        self.hilbert_dim = hilbert_dim
        self.model = model
        self.state_indices = state_indices
        self.options = options
        self.exponent_pair_idx_map = self._create_exponent_pair_idx_map()

    def _coefficient_for_state(
        self,
        xydata: np.ndarray,
        state_idx_coefficients: np.ndarray,
        bare_same: bool,
    ) -> np.ndarray | float:
        """
        Fit function to pass to curve fit, assume a 2D polynomial.

        Parameters:
            xydata (np.ndarray): Data for x and y coordinates.
            state_idx_coefficients (np.ndarray): Coefficients for the state.
            bare_same (bool): Whether the bare state is the same.

        Returns:
            np.ndarray | float: Coefficients for the state.
        """
        if bare_same:
            return state_idx_coefficients[0]
        else:
            return np.polyval(state_idx_coefficients, xydata)

    def _create_exponent_pair_idx_map(self) -> dict:
        """
        Create dictionary of terms in polynomial that we fit.

        We truncate the fit if e.g. there is only a single frequency value to scan over
        but the fit is nominally set to order four. We additionally eliminate the
        constant term that should always be either zero or one.

        Returns:
            dict: Dictionary of exponent pairs.
        """
        exponent_pair_idx_map = {}
        for i in range(self.options.fit_cutoff + 1):
            for j in range(self.options.fit_cutoff + 1 - i):
                exponent_pair_idx_map[(i, j)] = len(exponent_pair_idx_map)
        return exponent_pair_idx_map

    def _fit_coefficients_factory(
        self,
        XYdata: np.ndarray,
        Zdata: np.ndarray,
        p0: np.ndarray,
        bare_same: bool,
    ) -> np.ndarray:
        """
        Fit polynomial coefficients to given XY and Z data using curve fitting, with fallback to zero coefficients if fitting fails.

        Parameters:
            XYdata (np.ndarray): Data for x and y coordinates.
            Zdata (np.ndarray): Data for z coordinates.
            p0 (np.ndarray): Initial guess for coefficients.
            bare_same (bool): Whether the bare state is the same.

        Returns:
            np.ndarray: Fitted coefficients.
        """
        try:
            popt, _ = np.polyfit(XYdata, Zdata, len(p0) - 1, full=True)
            return popt
        except np.linalg.LinAlgError:
            return np.zeros_like(p0)

    def _fit_coefficients_for_component(
        self,
        omega_d_amp_filtered: np.ndarray,
        floquet_component_filtered: np.ndarray,
        bare_same: bool,
    ) -> np.ndarray:
        """
        Fit the floquet modes to an "ideal" displaced state based on a polynomial.

        This is done here over the grid specified by omega_d_amp_slice. We ignore
        floquet mode data indicated by mask, where we suspect by looking at overlaps
        with the bare state that we have hit a resonance.

        Parameters:
            omega_d_amp_filtered (np.ndarray): Filtered data for omega_d and amplitude.
            floquet_component_filtered (np.ndarray): Filtered floquet component data.
            bare_same (bool): Whether the bare state is the same.

        Returns:
            np.ndarray: Fitted coefficients.
        """
        XYdata = omega_d_amp_filtered
        Zdata = floquet_component_filtered
        p0 = np.zeros(len(self.exponent_pair_idx_map) + 1)
        return self._fit_coefficients_factory(XYdata, Zdata, p0, bare_same)

    def bare_state_coefficients(self, state_idx: int) -> np.ndarray:
        """
        rFor bare state only component is itself.

        Parameters:
            state_idx (int): Coefficients for the state $|state_idx\\rangle$ that when
                evaluated at any amplitude or frequency simply return the bare state.
                Note that this should be the actual state index, and not the array index
                (for instance if we have state_indices=[0, 1, 3] because we're not
                interested in the second excited state, for the 3rd excited state we
                should pass 3 here and not 2).

        Returns:
            np.ndarray: Coefficients for the bare state.
        """
        return np.array([1 if i == state_idx else 0 for i in range(self.hilbert_dim)])

    def displaced_state(
        self,
        omega_d: float,
        amp: float,
        state_idx: int,
        coefficients: np.ndarray,
    ) -> qt.Qobj:
        """
        Construct the ideal displaced state based on a polynomial expansion.

        Parameters:
            omega_d (float): Drive frequency.
            amp (float): Amplitude.
            state_idx (int): State index.
            coefficients (np.ndarray): Coefficients for the state.

        Returns:
            qt.Qobj: Displaced state.
        """
        return qt.Qobj(
            np.polyval(coefficients, np.array([omega_d, amp])),
            dims=[[self.hilbert_dim], [1]],
        )

    def displaced_states_fit(
        self,
        omega_d_amp_slice: np.ndarray,
        ovlp_with_bare_states: np.ndarray,
        floquet_modes: np.ndarray,
    ) -> np.ndarray:
        """
        Perform a fit for the indicated range, ignoring specified modes.

        We loop over all states in state_indices and perform the fit for a given
        amplitude range. We ignore floquet modes (not included in the fit) where
        the corresponding value in ovlp_with_bare_states is below the threshold
        specified in options.

        Parameters:
            omega_d_amp_slice (np.ndarray): Pairs of omega_d, amplitude values at which the
                floquet modes have been computed and which we will use as the
                independent variables to fit the Floquet modes
            ovlp_with_bare_states (np.ndarray): Bare state overlaps that has shape (w, a, s) where w
                is drive frequency, a is drive amplitude and s is state_indices
            floquet_modes (np.ndarray): Floquet mode array with the same shape as
                ovlp_with_bare_states except with an additional trailing dimension h,
                the Hilbert-space dimension.

        Returns:
            np.ndarray: Optimized fit coefficients
        """
        coefficients = np.zeros((len(self.state_indices), len(self.exponent_pair_idx_map) + 1))
        for state_idx in self.state_indices:
            bare_same = np.allclose(ovlp_with_bare_states[:, :, state_idx], 1)
            coefficients[state_idx] = self._fit_coefficients_for_component(
                omega_d_amp_slice,
                floquet_modes[:, :, state_idx],
                bare_same,
            )
        return coefficients

    def overlap_with_bare_states(
        self,
        amp_idx_0: int,
        coefficients: np.ndarray,
        floquet_modes: np.ndarray,
    ) -> np.ndarray:
        """
        Calculate overlap of floquet modes with 'bare' states.

        'Bare' here is defined loosely. For the first range of amplitudes, the bare
        states are truly the bare states (the coefficients are obtained from
        bare_state_coefficients, which give the bare states). For later ranges, we
        define the bare state as the state obtained from the fit from previous range,
        with amplitude evaluated at the lower edge of amplitudes for the new region.
        This is, in a sense, the most natural choice, since it is most analogous to what
        is done in the first window when the overlap is computed against bare
        eigenstates (that obviously don't have amplitude dependence). Moreover, the fit
        coefficients for the previous window by definition were obtained in a window
        that does not include the one we are currently investigating. Asking for the
        state with amplitude values outside of the fit window should be done at your
        own peril.

        Parameters:
            amp_idx_0 (int): Index specifying the lower bound of the amplitude range.
            coefficients (np.ndarray): coefficients that specify the bare state that we calculate
                overlaps of Floquet modes against
            floquet_modes (np.ndarray): Floquet modes to be compared to the bare states given by
                coefficients

        Returns:
            np.ndarray: Overlaps with shape (w,a,s) where w is the number of drive frequencies,
                a is the number of drive amplitudes (specified by amp_idxs) and s is the
                number of states we are investigating
        """
        overlaps = np.zeros((len(self.model.omega_d_values), len(self.model.drive_amplitudes), len(self.state_indices)))
        for state_idx in self.state_indices:
            bare_same = np.allclose(coefficients[state_idx], 1)
            for amp_idx in range(amp_idx_0, len(self.model.drive_amplitudes)):
                overlaps[:, amp_idx, state_idx] = np.abs(
                    np.dot(
                        floquet_modes[:, amp_idx, state_idx],
                        self.bare_state_coefficients(state_idx)
                        if bare_same
                        else self.displaced_state(
                            self.model.omega_d_values[amp_idx_0],
                            self.model.drive_amplitudes[amp_idx_0],
                            state_idx,
                            coefficients[state_idx],
                        ),
                    )
                )
        return overlaps

    def overlap_with_displaced_states(
        self,
        amp_idxs: np.ndarray,
        coefficients: np.ndarray,
        floquet_modes: np.ndarray,
    ) -> np.ndarray:
        """
        Calculate overlap of floquet modes with 'ideal' displaced states.

        This is done here for a specific amplitude range.

        Parameters:
            amp_idxs (np.ndarray): list of lower and upper amplitude indices specifying the range of
                drive amplitudes this calculation should be done for
            coefficients (np.ndarray): coefficients that specify the displaced state that we
                calculate overlaps of Floquet modes against
            floquet_modes (np.ndarray): Floquet modes to be compared to the displaced states given by
                coefficients

        Returns:
            np.ndarray: Overlaps with shape (w,a,s) where w is the number of drive frequencies,
                a is the number of drive amplitudes (specified by amp_idxs) and s is the
                number of states we are investigating
        """
        overlaps = np.zeros((len(self.model.omega_d_values), len(amp_idxs), len(self.state_indices)))
        for state_idx in self.state_indices:
            for amp_idx in range(amp_idxs[0], amp_idxs[1]):
                overlaps[:, amp_idx - amp_idxs[0], state_idx] = np.abs(
                    np.dot(
                        floquet_modes[:, amp_idx, state_idx],
                        self.displaced_state(
                            self.model.omega_d_values[amp_idx],
                            self.model.drive_amplitudes[amp_idx],
                            state_idx,
                            coefficients[state_idx],
                        ),
                    )
                )
        return overlaps