import numpy as np
import qutip as qt

from .model import Model


class ChiacToAmp:
    """
    rConvert given induced ac-stark shift values to drive amplitudes.

    Consider a qubit coupled to an oscillator with the interaction Hamiltonian
    $H_I = g(a + a^{\\dagger})(b + b^{\\dagger})$. If the oscillator is driven to
    an average occupation number of $\\bar{n}$, then the effective drive strength
    seen by the qubit is $\\Omega_d = 2 g \\sqrt{\\bar{n}}$. On the other hand based
    on a Schrieffer-Wolff transformation, the interaction hamiltonian is
    $H^{(2)} = \\chi a^{\\dagger}ab^{\\dagger}b$. The average induced
    ac-stark shift is then $\\chi_{ac} = \\chi \\bar{n}$. Thus $\\Omega_d = 2g\\sqrt{\\chi_{\\rm ac}/\\chi}$.
    Observe that since $\\chi \\sim g^2$, $g$ effectively cancels out and can be set to 1.

    noqa E501
    """

    def __init__(
        self,
        H0: qt.Qobj,
        H1: qt.Qobj,
        state_indices: List[int],
        omega_d_values: np.ndarray,
    ) -> None:
        """
        Initialize the object with Hamiltonian operators H0 and H1, a list of state indices, and an array of driving frequency values.

        Parameters:
            H0 (qt.Qobj): Drift Hamiltonian.
            H1 (qt.Qobj): Drive operator.
            state_indices (List[int]): List of state indices.
            omega_d_values (np.ndarray): Array of driving frequency values.
        """
        self.H0 = H0
        self.H1 = H1
        self.state_indices = state_indices
        self.omega_d_linspace = omega_d_values

    def amplitudes_for_omega_d(self, chi_ac_linspace: np.ndarray) -> np.ndarray:
        """
        rReturn drive amplitudes corresponding to $\\chi_{\\rm ac}$ values.

        Parameters:
            chi_ac_linspace (np.ndarray): Array of $\\chi_{\\rm ac}$ values.

        Returns:
            np.ndarray: Array of drive amplitudes.
        """
        return 2 * np.sqrt(chi_ac_linspace)

    def chi_ell(self, energies: np.ndarray, H1: qt.Qobj, E_osc: float, ell: int) -> np.ndarray:
        """
        Compute the difference between the sum of chi_ell_ellp values for all ellp and the sum of chi_ellp_ell values for all ellp, given energies, H1 matrix, E_osc, and ell.

        Parameters:
            energies (np.ndarray): Array of energies.
            H1 (qt.Qobj): Drive operator.
            E_osc (float): Oscillator energy.
            ell (int): Index.

        Returns:
            np.ndarray: Array of chi values.
        """
        return np.sum(self.chi_ell_ellp(energies, H1, E_osc, ell, ellp) for ellp in range(len(energies))) - np.sum(
            self.chi_ell_ellp(energies, H1, E_osc, ellp, ell) for ellp in range(len(energies))
        )

    def chi_ell_ellp(
        self, energies: np.ndarray, H1: qt.Qobj, E_osc: float, ell: int, ellp: int
    ) -> np.ndarray:
        """
        Calculate the transition matrix element between energy states ell and ellp for a given oscillator energy E_osc, using the provided Hamiltonian matrix H1 and energy levels.

        Parameters:
            energies (np.ndarray): Array of energies.
            H1 (qt.Qobj): Drive operator.
            E_osc (float): Oscillator energy.
            ell (int): Index.
            ellp (int): Index.

        Returns:
            np.ndarray: Array of chi values.
        """
        return np.abs(H1.matrix_element(energies[ell], energies[ellp])) ** 2 * np.exp(
            -1j * (E_osc - energies[ell] - energies[ellp]) * self.omega_d_linspace
        )

    def compute_chis_for_omega_d(self) -> np.ndarray:
        """
        Compute chi difference for the first two states in state_indices.

        Based on the analysis in Zhu et al PRB (2013)

        Returns:
            np.ndarray: Array of chi values.
        """
        energies = np.array([self.H0.eigenenergies()[i] for i in self.state_indices])
        H1 = self.H1.matrix_element(energies[0], energies[1])
        E_osc = np.mean(energies)
        return self.chi_ell(energies, H1, E_osc, 0) - self.chi_ell(energies, H1, E_osc, 1)


class XiSqToAmp:
    """
    rConvert given $|\\xi|^2$ value into a drive amplitude.

    This is based on the equivalence $\\xi = 2 \\Omega_d \\omega_d / (\\omega_d^2-\\omega^2)$,
    where in this definition $|\\xi|^2= 2 \\chi_{\\rm ac} / \\alpha$ where $\\chi_{\\rm ac}$ is
    the induced ac stark shift, $\\alpha$ is the anharmonicity and $\\Omega_d$ is the
    drive amplitude.

    noqa E501
    """

    def __init__(
        self,
        H0: qt.Qobj,
        H1: qt.Qobj,
        state_indices: List[int],
        omega_d_values: np.ndarray,
    ) -> None:
        """
        Initialize an instance of the class with the given Hamiltonian operators (H0 and H1), state indices, and a linear space of driving frequencies (omega_d_linspace).

        Parameters:
            H0 (qt.Qobj): Drift Hamiltonian.
            H1 (qt.Qobj): Drive operator.
            state_indices (List[int]): List of state indices.
            omega_d_values (np.ndarray): Array of driving frequency values.
        """
        self.H0 = H0
        self.H1 = H1
        self.state_indices = state_indices
        self.omega_d_linspace = omega_d_values

    def amplitudes_for_omega_d(self, xi_sq_linspace: np.ndarray) -> np.ndarray:
        """
        rReturn drive amplitudes corresponding to $|\\xi|^2$ values.

        Parameters:
            xi_sq_linspace (np.ndarray): Array of $|\\xi|^2$ values.

        Returns:
            np.ndarray: Array of drive amplitudes.
        """
        return np.sqrt(xi_sq_linspace)