import h5py
import numpy as np
import os
import re
import sys
import time
from typing import Any, Dict, List, Optional, Tuple, Union

import qutip as qt

from .parallel import parallel_map

__all__ = ["Serializable", "generate_file_path", "read_from_file", "get_init_params"]

__version__ = "0.1.0"


def generate_file_path(
    extension: str, file_name: str, path: str = "./"
) -> str:
    """
    Generate a unique file path within a specified directory by appending a numeric prefix to the given file name to avoid conflicts, ensuring the directory exists. The numeric prefix is determined by the highest existing prefix in the directory, incremented by one, and formatted with leading zeros.

    Parameters:
        extension (str): The file extension (e.g., ".h5").
        file_name (str): The base file name without the extension.
        path (str, optional): The directory path where the file will be saved. Defaults to "./".

    Returns:
        str: The generated file path.
    """
    if not os.path.exists(path):
        os.makedirs(path)

    file_pattern = re.compile(rf"{file_name}_(\d+){extension}$")
    existing_files = [f for f in os.listdir(path) if file_pattern.match(f)]
    if not existing_files:
        prefix = 0
    else:
        prefix = max(int(file_pattern.match(f).group(1)) for f in existing_files) + 1
    file_path = os.path.join(path, f"{file_name}_{prefix:03d}{extension}")
    return file_path


def read_from_file(filepath: str) -> Tuple[Any, Dict[str, Any]]:
    """
    Read a class and associated data from file.

    Parameters:
        filepath (str): Path to the file containing both raw data and the information needed
            to reinitialize our class

    Returns:
        Tuple[Any, Dict[str, Any]]: A tuple containing the new class instance and the data dictionary.
    """
    with h5py.File(filepath, "r") as f:
        data_dict = {}
        for key in f.keys():
            if isinstance(f[key], h5py.Dataset):
                data_dict[key] = f[key][()]
            elif isinstance(f[key], h5py.Group):
                data_dict[key] = {}
                for subkey in f[key].keys():
                    if isinstance(f[key][subkey], h5py.Dataset):
                        data_dict[key][subkey] = f[key][subkey][()]
                    else:
                        raise ValueError(
                            f"Unsupported data type for key {subkey} in group {key}"
                        )
        new_class_instance = Serializable.from_file(filepath)
    return new_class_instance, data_dict


def get_init_params(obj: Any) -> List[str]:
    """
    Returns a list of parameters entering `__init__` of `obj`.

    Parameters:
        obj (Any): The object for which to retrieve initialization parameters.

    Returns:
        List[str]: A list of parameter names.
    """
    init_params = []
    for attr_name in dir(obj):
        if not attr_name.startswith("__"):
            attr_value = getattr(obj, attr_name)
            if callable(attr_value):
                continue
            init_params.append(attr_name)
    return init_params


class Serializable:
    """
    Mixin class for reading and writing to file using h5py.
    """

    def __str__(self) -> str:
        """
        Generate a string representation of the object by concatenating its initialized attributes (excluding None values) in the format "key: value", with each attribute on a new line.

        Returns:
            str: The string representation of the object.
        """
        return "\n".join(
            f"{key}: {value}"
            for key, value in self.__dict__.items()
            if value is not None
        )

    def __eq__(self, other: Any) -> bool:
        """
        Compare two objects of the same class for equality by checking if their initialization parameters are equal, including handling NumPy arrays with `np.allclose`.

        Parameters:
            other (Any): The other object to compare.

        Returns:
            bool: True if the objects are equal, False otherwise.
        """
        if not isinstance(other, self.__class__):
            return False
        for key in get_init_params(self):
            if key not in other.__dict__:
                return False
            if isinstance(self.__dict__[key], np.ndarray):
                if not np.allclose(self.__dict__[key], other.__dict__[key]):
                    return False
            elif self.__dict__[key] != other.__dict__[key]:
                return False
        return True

    def __new__(cls, *args, **kwargs):
        """
        noqa ARG003

        Records which parameters should be saved so they can be passed to init.

        Parameters:
            cls (Any): The class.
            args (Any): Positional arguments.
            kwargs (Any): Keyword arguments.

        Returns:
            Serializable: The new instance of the class.
        """
        obj = super().__new__(cls)
        obj._init_params = get_init_params(obj)
        return obj

    def serialize(self) -> Dict[str, Any]:
        """
        Serialize a class so that it is ready to be written.

        This method creates nested dictionaries appropriate for writing to h5 files.
        Importantly, we save metadata associated with the class itself and any classes
        it takes as input so that they can be reinstantiated later.

        Returns:
            Dict[str, Any]: A dictionary of data to save, in a format appropriate to pass to h5.
        """
        initdata = {}
        for key in self._init_params:
            value = getattr(self, key)
            if isinstance(value, Serializable):
                initdata[key] = value.serialize()
            elif isinstance(value, np.ndarray):
                initdata[key] = value.tolist()
            else:
                initdata[key] = value
        return initdata

    def write_to_file(self, filepath: str, data_dict: Dict[str, Any]) -> None:
        """
        Write a class and associated data to file.

        The goal is to be able to read back both the data that was saved and all of the
        data necessary to reinitialize the class.

        Parameters:
            filepath (str): Path to the file where we want to save the data. Must be an h5 or
                h5py file
            data_dict (Dict[str, Any]): Dictionary containing various raw data to save
        """
        with h5py.File(filepath, "w") as f:
            for key, value in data_dict.items():
                if isinstance(value, np.ndarray):
                    f.create_dataset(key, data=value)
                elif isinstance(value, dict):
                    group = f.create_group(key)
                    for subkey, subvalue in value.items():
                        if isinstance(subvalue, np.ndarray):
                            group.create_dataset(subkey, data=subvalue)
                        else:
                            group.create_dataset(subkey, data=subvalue)
                else:
                    f.create_dataset(key, data=value)
            for key, value in self.serialize().items():
                if isinstance(value, dict):
                    group = f.create_group(key)
                    for subkey, subvalue in value.items():
                        if isinstance(subvalue, np.ndarray):
                            group.create_dataset(subkey, data=subvalue)
                        else:
                            group.create_dataset(subkey, data=subvalue)
                else:
                    f.create_dataset(key, data=value)

    @classmethod
    def from_file(cls, filepath: str) -> Any:
        """
        Reinitialize a class from a file.

        Parameters:
            filepath (str): Path to the file containing the serialized data.

        Returns:
            Any: The reinitialized class instance.
        """
        with h5py.File(filepath, "r") as f:
            initdata = {}
            for key in f.keys():
                if isinstance(f[key], h5py.Dataset):
                    initdata[key] = f[key][()]
                elif isinstance(f[key], h5py.Group):
                    initdata[key] = {}
                    for subkey in f[key].keys():
                        if isinstance(f[key][subkey], h5py.Dataset):
                            initdata[key][subkey] = f[key][subkey][()]
                        else:
                            raise ValueError(
                                f"Unsupported data type for key {subkey} in group {key}"
                            )
            return cls(**initdata)


def parallel_map(
    num_cpus: int, func: Any, parameters: Any
) -> map:
    """
    Apply a function to each item in an iterable in parallel using multiple CPU cores for improved performance.

    Parameters:
        num_cpus (int): Number of CPU cores to use.
        func (Any): The function to apply.
        parameters (Any): The iterable of parameters to apply the function to.

    Returns:
        map: The result of applying the function in parallel.
    """
    return parallel_map(num_cpus, func, parameters)