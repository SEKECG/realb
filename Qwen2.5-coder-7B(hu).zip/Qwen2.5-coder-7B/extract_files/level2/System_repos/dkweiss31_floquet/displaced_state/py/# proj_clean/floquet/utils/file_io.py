import h5py
import numpy as np
import os
from typing import Any, Dict, List, Tuple

class Serializable:
    def __str__(self) -> str:
        return "\n".join(
            f"{key}: {value}"
            for key, value in self.__dict__.items()
            if value is not None
        )

    def __eq__(self, other: Any) -> bool:
        if not isinstance(other, type(self)):
            return False
        return all(
            np.allclose(getattr(self, key), getattr(other, key))
            for key in self.__init_params__
        )

    def __new__(cls, *args: Any, **kwargs: Any) -> "Serializable":
        self = super().__new__(cls)
        self.__init_params__ = get_init_params(self)
        return self

    def serialize(self) -> Dict[str, Any]:
        initdata = {}
        for key in self.__init_params__:
            value = getattr(self, key)
            if isinstance(value, np.ndarray):
                initdata[key] = value.tolist()
            else:
                initdata[key] = value
        return initdata

    def write_to_file(self, filepath: str, data_dict: Dict[str, Any]) -> None:
        with h5py.File(filepath, "w") as f:
            for key, value in data_dict.items():
                if isinstance(value, np.ndarray):
                    f.create_dataset(key, data=value)
                else:
                    f.create_dataset(key, data=np.array([value]))

def generate_file_path(extension: str, file_name: str, path: str) -> str:
    if not os.path.exists(path):
        os.makedirs(path)
    file_path = os.path.join(path, file_name)
    if os.path.exists(file_path):
        file_path = os.path.join(path, f"{file_name}_{get_highest_prefix(file_path)}{extension}")
    return file_path

def read_from_file(filepath: str) -> Tuple["Serializable", Dict[str, Any]]:
    with h5py.File(filepath, "r") as f:
        data_dict = {key: f[key][()] for key in f.keys()}
        new_class_instance = data_dict.pop("class_instance")
        return new_class_instance, data_dict

def get_init_params(obj: Any) -> List[str]:
    return [
        param
        for param in dir(obj)
        if not param.startswith("__")
        and not callable(getattr(obj, param))
        and not param.startswith("_")
    ]

def get_highest_prefix(file_path: str) -> int:
    prefix = 0
    while os.path.exists(file_path):
        prefix += 1
        file_path = os.path.join(os.path.dirname(file_path), f"{os.path.basename(file_path).split('.')[0]}_{prefix}.h5")
    return prefix