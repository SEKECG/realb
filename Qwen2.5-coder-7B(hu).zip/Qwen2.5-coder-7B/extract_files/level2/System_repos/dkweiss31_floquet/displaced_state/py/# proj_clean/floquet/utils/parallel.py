from multiprocessing import Pool
from typing import Any, Callable, Iterable

def parallel_map(num_cpus: int, func: Callable, parameters: Iterable) -> map:
    with Pool(num_cpus) as pool:
        return pool.map(func, parameters)