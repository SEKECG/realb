import numpy as np
import qutip as qt
from typing import Any, Dict, List, Tuple

class DisplacedState:
    def __init__(self, hilbert_dim: int, model: Any, state_indices: List[int], options: Any) -> None:
        self.hilbert_dim = hilbert_dim
        self.model = model
        self.state_indices = state_indices
        self.options = options
        self.exponent_pair_idx_map = self._create_exponent_pair_idx_map()

    def _coefficient_for_state(self, xydata: np.ndarray, state_idx_coefficients: np.ndarray, bare_same: bool) -> np.ndarray:
        return np.polyval(state_idx_coefficients, xydata)

    def _create_exponent_pair_idx_map(self) -> Dict[Tuple[int, int], int]:
        exponent_pair_idx_map = {}
        for i in range(self.options.fit_cutoff + 1):
            for j in range(self.options.fit_cutoff + 1 - i):
                exponent_pair_idx_map[(i, j)] = len(exponent_pair_idx_map)
        return exponent_pair_idx_map

    def _fit_coefficients_factory(self, XYdata: np.ndarray, Zdata: np.ndarray, p0: np.ndarray, bare_same: bool) -> np.ndarray:
        try:
            return np.polyfit(XYdata, Zdata, self.options.fit_cutoff)
        except Exception:
            return np.zeros_like(p0)

    def _fit_coefficients_for_component(self, omega_d_amp_filtered: np.ndarray, floquet_component_filtered: np.ndarray, bare_same: bool) -> np.ndarray:
        p0 = np.zeros(self.options.fit_cutoff + 1)
        return self._fit_coefficients_factory(omega_d_amp_filtered, floquet_component_filtered, p0, bare_same)

    def bare_state_coefficients(self, state_idx: int) -> np.ndarray:
        return np.zeros(self.options.fit_cutoff + 1)

    def displaced_state(self, omega_d: float, amp: float, state_idx: int, coefficients: np.ndarray) -> qt.Qobj:
        return qt.Qobj(coefficients)

    def displaced_states_fit(self, omega_d_amp_slice: np.ndarray, ovlp_with_bare_states: np.ndarray, floquet_modes: np.ndarray) -> np.ndarray:
        coefficients = np.zeros((len(omega_d_amp_slice), self.options.fit_cutoff + 1))
        for i, (omega_d, amp) in enumerate(omega_d_amp_slice):
            coefficients[i] = self._fit_coefficients_for_component(
                omega_d_amp_slice[:, 0], ovlp_with_bare_states[i], True
            )
        return coefficients

    def overlap_with_bare_states(self, amp_idx_0: int, coefficients: np.ndarray, floquet_modes: np.ndarray) -> np.ndarray:
        overlaps = np.zeros((len(self.model.omega_d_values), len(self.model.drive_amplitudes), len(self.state_indices)))
        for i, omega_d in enumerate(self.model.omega_d_values):
            for j, amp in enumerate(self.model.drive_amplitudes):
                overlaps[i, j] = np.abs(
                    np.dot(coefficients[amp_idx_0], floquet_modes[i, j, self.state_indices])
                )
        return overlaps

    def overlap_with_displaced_states(self, amp_idxs: List[int], coefficients: np.ndarray, floquet_modes: np.ndarray) -> np.ndarray:
        overlaps = np.zeros((len(self.model.omega_d_values), len(amp_idxs), len(self.state_indices)))
        for i, omega_d in enumerate(self.model.omega_d_values):
            for j, amp_idx in enumerate(amp_idxs):
                overlaps[i, j] = np.abs(
                    np.dot(coefficients[amp_idx], floquet_modes[i, amp_idx, self.state_indices])
                )
        return overlaps