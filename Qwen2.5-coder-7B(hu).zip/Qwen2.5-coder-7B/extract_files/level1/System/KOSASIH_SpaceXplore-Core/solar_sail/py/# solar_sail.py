import logging

class SolarSail:
    def __init__(self, area, reflectivity):
        self.area = area
        self.reflectivity = reflectivity
        self.is_deployed = False
        self.thrust = 0
        logging.basicConfig(level=logging.INFO)

    def calculate_thrust(self, solar_constant):
        if self.is_deployed:
            self.thrust = solar_constant * self.area * self.reflectivity
        else:
            self.thrust = 0
        return self.thrust

    def deploy(self):
        self.is_deployed = True
        logging.info("Solar sail deployed.")

    def retract(self):
        self.is_deployed = False
        logging.info("Solar sail retracted.")

    def simulate(self, duration):
        if self.is_deployed:
            logging.info(f"Simulating solar sail operation for {duration} seconds.")
            logging.info(f"Thrust: {self.thrust} N")
        else:
            logging.info("Solar sail is not deployed.")

    def status(self):
        return self.is_deployed, self.thrust