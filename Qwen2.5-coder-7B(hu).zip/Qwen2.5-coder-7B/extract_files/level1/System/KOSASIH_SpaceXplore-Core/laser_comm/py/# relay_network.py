import logging

class RelayNetwork:
    def __init__(self):
        self.relays = []
        logging.basicConfig(level=logging.INFO)

    def add_relay(self, relay_id):
        """
        Add a relay ID to the network and log the addition.
        :param relay_id: Relay ID to be added
        """
        self.relays.append(relay_id)
        logging.info(f"Added relay: {relay_id}")

    def transmit_via_relays(self, data):
        """
        Transmit data through all available relays in the network and log the transmission process.
        Returns True if successful, False if no relays are available.
        :param data: Data to be transmitted
        :return: True if successful, False if no relays are available
        """
        if not self.relays:
            logging.warning("No relays available for transmission")
            return False

        for relay in self.relays:
            logging.info(f"Transmitting data through relay {relay}: {data}")

        return True