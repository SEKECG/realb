import logging

class LaserCommunication:
    def __init__(self, power, distance):
        self.power = power
        self.distance = distance
        self.efficiency = 0.8  # Default efficiency
        logging.basicConfig(level=logging.INFO)

    def calculate_signal_strength(self):
        """
        Calculate the signal strength based on power, efficiency, and distance, then log and return the result.
        Signal strength decreases with distance
        :return: Signal strength
        """
        signal_strength = self.power * self.efficiency / self.distance
        logging.info(f"Signal strength: {signal_strength}")
        return signal_strength

    def transmit_data(self, data):
        """
        Transmit the given data if the signal strength is above the minimum threshold for successful transmission.
        :param data: Data to be transmitted
        """
        signal_strength = self.calculate_signal_strength()
        if signal_strength > 0.5:  # Minimum threshold for successful transmission
            logging.info(f"Transmitting data: {data}")
        else:
            logging.warning("Signal strength too low for transmission")