import logging

class RelayNetwork:
    def __init__(self):
        self.relays = []
        logging.basicConfig(level=logging.INFO)

    def add_relay(self, relay_id):
        self.relays.append(relay_id)
        logging.info(f"Added relay {relay_id} to the network.")

    def transmit_via_relays(self, data):
        if not self.relays:
            logging.warning("No relays available for transmission.")
            return False
        logging.info(f"Transmitting data via relays: {data}")
        return True