import logging

class LaserCommunication:
    def __init__(self, power, distance):
        """
        Simulate and manage laser-based communication, including signal strength calculation and data transmission over specified distances.
        Initialize an instance of a laser communication system with specified power, distance, and default efficiency, and set up logging configuration.
        """
        self.power = power
        self.distance = distance
        self.efficiency = 0.8  # Default efficiency
        logging.basicConfig(level=logging.INFO)

    def calculate_signal_strength(self):
        """
        Calculate the signal strength based on power, efficiency, and distance, then log and return the result.
        Signal strength decreases with distance
        """
        # Calculate the signal strength based on power, efficiency, and distance, then log and return the result.
        pass

    def transmit_data(self, data):
        """
        Transmit the given data if the signal strength is above the minimum threshold for successful transmission.
        """
        # Transmit the given data if the signal strength is above the minimum threshold for successful transmission.
        pass