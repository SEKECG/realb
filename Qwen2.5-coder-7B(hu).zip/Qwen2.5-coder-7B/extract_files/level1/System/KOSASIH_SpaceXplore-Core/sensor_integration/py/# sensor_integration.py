import logging

class SensorIntegration:
    def __init__(self):
        self.sensors = {
            "temperature": self.read_temperature,
            "humidity": self.read_humidity,
            "pressure": self.read_pressure,
            "biosensor": self.read_biosensor
        }
        logging.basicConfig(level=logging.INFO)

    def collect_data(self):
        sensor_data = {}
        for sensor_name, sensor_function in self.sensors.items():
            sensor_data[sensor_name] = sensor_function()
        return sensor_data

    def read_biosensor(self):
        biosignal = bool(random.getrandbits(1))
        logging.info(f"Biosignal detected: {biosignal}")
        return biosignal

    def read_humidity(self):
        humidity = random.randint(0, 100)
        logging.info(f"Humidity: {humidity}%")
        return humidity

    def read_pressure(self):
        pressure = random.randint(900, 1100)
        logging.info(f"Pressure: {pressure} hPa")
        return pressure

    def read_temperature(self):
        temperature = random.randint(-50, 50)
        logging.info(f"Temperature: {temperature}°C")
        return temperature