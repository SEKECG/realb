import logging

class AutonomousNavigation:
    def __init__(self, initial_position, destination):
        self.position = initial_position
        self.destination = destination
        self.speed = 1.0
        logging.basicConfig(level=logging.INFO)

    def calculate_direction(self):
        direction = self.destination - self.position
        return direction / np.linalg.norm(direction)

    def has_reached_destination(self):
        return np.linalg.norm(self.position - self.destination) < 1e-6

    def move(self):
        direction = self.calculate_direction()
        self.position += self.speed * direction
        logging.info(f"New position: {self.position}")

    def navigate(self):
        while not self.has_reached_destination():
            self.move()
        logging.info("Destination reached!")