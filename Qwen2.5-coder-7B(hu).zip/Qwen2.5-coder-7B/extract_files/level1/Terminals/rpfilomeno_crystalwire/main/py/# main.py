import threading
import time
import psutil
import pandas as pd
import plotille
from scapy.all import sniff, IP, TCP, UDP

all_macs = {}
connection2pid = {}
global_df = pd.DataFrame()
global_graph_data = {}
is_program_running = True

def get_connections():
    while is_program_running:
        for conn in psutil.net_connections():
            if conn.status == 'ESTABLISHED':
                src_ip = conn.laddr.ip
                dst_ip = conn.raddr.ip
                src_port = conn.laddr.port
                dst_port = conn.raddr.port
                pid = conn.pid
                if (src_ip, src_port, dst_ip, dst_port) not in all_macs:
                    all_macs[(src_ip, src_port, dst_ip, dst_port)] = pid
                if pid not in connection2pid:
                    connection2pid[pid] = [0, 0]  # [upload, download]

def get_size(bytes):
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if bytes < 1024:
            return f"{bytes:.2f} {unit}"
        bytes /= 1024

def plot(df):
    fig = plotille.Figure()
    fig.width = 80
    fig.height = 20
    fig.x_label = 'Time (s)'
    fig.y_label = 'Bandwidth (Kb/s)'
    fig.color_mode = 'byte'
    fig.plot(df.index, df['upload'], label='Upload')
    fig.plot(df.index, df['download'], label='Download')
    print(fig.show())

def print_pid2traffic():
    while is_program_running:
        time.sleep(1)
        df = pd.DataFrame(connection2pid.values(), index=connection2pid.keys(), columns=['upload', 'download'])
        df['upload'] = df['upload'].apply(lambda x: get_size(x))
        df['download'] = df['download'].apply(lambda x: get_size(x))
        df['upload_speed'] = df['upload'].diff() / 1024
        df['download_speed'] = df['download'].diff() / 1024
        df['upload_speed'] = df['upload_speed'].apply(lambda x: get_size(x))
        df['download_speed'] = df['download_speed'].apply(lambda x: get_size(x))
        df = df.sort_values(by=['upload', 'download'], ascending=False)
        df = df.head(10)
        df = df.reset_index()
        df.columns = ['PID', 'Upload', 'Download', 'Upload Speed', 'Download Speed']
        df = df.set_index('PID')
        df = df.style.highlight_max(subset=['Upload', 'Download', 'Upload Speed', 'Download Speed'], color='lightgreen')
        print(df)

def print_stats():
    while is_program_running:
        time.sleep(1)
        df = pd.DataFrame(connection2pid.values(), index=connection2pid.keys(), columns=['upload', 'download'])
        df['upload'] = df['upload'].apply(lambda x: get_size(x))
        df['download'] = df['download'].apply(lambda x: get_size(x))
        df['upload_speed'] = df['upload'].diff() / 1024
        df['download_speed'] = df['download'].diff() / 1024
        df['upload_speed'] = df['upload_speed'].apply(lambda x: get_size(x))
        df['download_speed'] = df['download_speed'].apply(lambda x: get_size(x))
        df = df.sort_values(by=['upload', 'download'], ascending=False)
        df = df.head(10)
        df = df.reset_index()
        df.columns = ['PID', 'Upload', 'Download', 'Upload Speed', 'Download Speed']
        df = df.set_index('PID')
        df = df.style.highlight_max(subset=['Upload', 'Download', 'Upload Speed', 'Download Speed'], color='lightgreen')
        print(df)

def process_packet(packet):
    if IP in packet and (packet[IP].src, packet[IP].dst) in all_macs:
        pid = all_macs[(packet[IP].src, packet[IP].dst)]
        if TCP in packet:
            if packet[TCP].flags == 'S':
                connection2pid[pid][0] += packet[TCP].payload.len
            elif packet[TCP].flags == 'A':
                connection2pid[pid][1] += packet[TCP].payload.len
        elif UDP in packet:
            connection2pid[pid][1] += packet[UDP].payload.len

def stat(df):
    print(df.head())

if __name__ == '__main__':
    connections_thread = threading.Thread(target=get_connections)
    connections_thread.start()
    printing_thread = threading.Thread(target=print_pid2traffic)
    printing_thread.start()
    sniff(prn=process_packet, store=0)
    connections_thread.join()
    printing_thread.join()
    is_program_running = False