import os
import time
import random

def banner():
    print("InfiNet - Network Penetration Testing Tool")

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def show_menu():
    print("1. Network Scan")
    print("2. MITM Attack")
    print("3. DNS Spoofing")
    print("4. Automatic Attack Type Selection")
    print("5. Performance Monitoring")
    print("6. Dynamic Reporting")
    print("7. Advanced Logging")
    print("8. Help and Instructions")
    print("9. Exit")

def show_instructions():
    print("Network Scan: Enter a target IP address to scan the network for connected devices.")
    print("MITM Attack: Enter the victim's IP address and the gateway IP address to initiate a Man-in-the-Middle attack.")
    print("DNS Spoofing: Enter the target IP address and the IP address to redirect DNS requests to.")
    print("Automatic Attack Type Selection: The tool will automatically select an attack type based on random selection.")
    print("Performance Monitoring: The tool will track the duration of the attack processes.")
    print("Dynamic Reporting: After each attack, the tool will generate a dynamic report.")
    print("Advanced Logging: The tool will log user interactions and attack initiations.")
    print("Help and Instructions: This menu provides instructions on how to use the tool.")

def network_scan():
    target_ip = input("Enter target IP address: ")
    print(f"Scanning network for devices connected to {target_ip}...")
    time.sleep(2)
    print("Scan complete. Devices found:")
    print("- Device 1")
    print("- Device 2")
    print("- Device 3")

def mitm_attack():
    victim_ip = input("Enter victim's IP address: ")
    gateway_ip = input("Enter gateway IP address: ")
    print(f"Starting MITM attack on {victim_ip} with gateway {gateway_ip}...")
    time.sleep(2)
    print("MITM attack initiated.")

def dns_spoofing():
    target_ip = input("Enter target IP address: ")
    redirect_ip = input("Enter IP address to redirect DNS requests to: ")
    print(f"Redirecting DNS requests from {target_ip} to {redirect_ip}...")
    time.sleep(2)
    print("DNS spoofing initiated.")

def advanced_attack_choice():
    attack_types = ["ARP Spoofing", "MITM", "DNS Spoofing"]
    selected_attack = random.choice(attack_types)
    print(f"Selected attack type: {selected_attack}")
    if selected_attack == "ARP Spoofing":
        network_scan()
    elif selected_attack == "MITM":
        mitm_attack()
    elif selected_attack == "DNS Spoofing":
        dns_spoofing()

def performance_monitor():
    start_time = time.time()
    print("Starting performance monitoring...")
    time.sleep(2)
    end_time = time.time()
    duration = end_time - start_time
    print(f"Performance monitoring complete. Duration: {duration} seconds")

def dynamic_report():
    attack_type = input("Enter attack type: ")
    status = input("Enter attack status (successful/failed): ")
    duration = input("Enter attack duration: ")
    print(f"Attack type: {attack_type}")
    print(f"Status: {status}")
    print(f"Duration: {duration} seconds")

def advanced_logging():
    user_interaction = input("Enter user interaction: ")
    attack_initiation = input("Enter attack initiation: ")
    print(f"User interaction: {user_interaction}")
    print(f"Attack initiation: {attack_initiation}")

def main():
    while True:
        clear_screen()
        banner()
        show_menu()
        choice = input("Enter your choice: ")
        if choice == "1":
            network_scan()
        elif choice == "2":
            mitm_attack()
        elif choice == "3":
            dns_spoofing()
        elif choice == "4":
            advanced_attack_choice()
        elif choice == "5":
            performance_monitor()
        elif choice == "6":
            dynamic_report()
        elif choice == "7":
            advanced_logging()
        elif choice == "8":
            show_instructions()
        elif choice == "9":
            print("Exiting InfiNet...")
            break
        else:
            print("Invalid choice. Please try again.")
        input("Press Enter to continue...")

if __name__ == "__main__":
    main()