import os
import sys
import time
import random
import string
import hashlib
import base64
from cryptography.fernet import Fernet

# Constants
AUTHOR_NAME = "Mahmud Nibir"
AUTHOR_GITHUB = "https://github.com/mahmudnibir"
AUTHOR_PROJECT = "HiddenMessage"

# Variables
IMAGE_PATH = "path/to/image.png"
OUTPUT_IMAGE_PATH = "path/to/output_image.png"
PASSWORD = "your_password"

# Functions
def animated_logo(text):
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(0.1)
    print()

def text_to_bin(text):
    return ''.join(format(ord(char), '08b') for char in text)

def bin_to_text(binary_data):
    return ''.join(chr(int(binary_data[i:i+8], 2)) for i in range(0, len(binary_data), 8))

def generate_key(password):
    return base64.urlsafe_b64encode(hashlib.sha256(password.encode()).digest())

def encrypt_text(text, password):
    key = generate_key(password)
    fernet = Fernet(key)
    return fernet.encrypt(text.encode()).decode()

def decrypt_text(encrypted_text, password):
    key = generate_key(password)
    fernet = Fernet(key)
    return fernet.decrypt(encrypted_text.encode()).decode()

def hide_text_in_image(IMAGE_PATH, text, OUTPUT_IMAGE_PATH, password):
    encrypted_text = encrypt_text(text, password)
    binary_data = text_to_bin(encrypted_text)

    image = Image.open(IMAGE_PATH)
    width, height = image.size

    index = 0
    for y in range(height):
        for x in range(width):
            r, g, b = image.getpixel((x, y))
            if index < len(binary_data):
                r = (r & 0xFE) | int(binary_data[index])
                index += 1
            if index < len(binary_data):
                g = (g & 0xFE) | int(binary_data[index])
                index += 1
            if index < len(binary_data):
                b = (b & 0xFE) | int(binary_data[index])
                index += 1
            image.putpixel((x, y), (r, g, b))

    image.save(OUTPUT_IMAGE_PATH)

def extract_text_from_image(IMAGE_PATH, password):
    image = Image.open(IMAGE_PATH)
    width, height = image.size

    binary_data = ""
    for y in range(height):
        for x in range(width):
            r, g, b = image.getpixel((x, y))
            binary_data += str(r & 1)
            binary_data += str(g & 1)
            binary_data += str(b & 1)

    encrypted_text = bin_to_text(binary_data)
    return decrypt_text(encrypted_text, password)

def print_AUTHOR_info():
    print(f"Author: {AUTHOR_NAME}")
    print(f"GitHub: {AUTHOR_GITHUB}")
    print(f"Project: {AUTHOR_PROJECT}")

# Main
if __name__ == "__main__":
    print_AUTHOR_info()
    animated_logo("Welcome to HiddenMessage!")

    choice = input("Choose an option:\n1. Hide text in image\n2. Extract text from image\n")

    if choice == "1":
        text = input("Enter the text to hide: ")
        hide_text_in_image(IMAGE_PATH, text, OUTPUT_IMAGE_PATH, PASSWORD)
        print("Text hidden successfully!")
    elif choice == "2":
        extracted_text = extract_text_from_image(IMAGE_PATH, PASSWORD)
        print("Extracted text:", extracted_text)
    else:
        print("Invalid choice!")