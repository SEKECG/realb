import os
import json
from pathlib import Path

class SessionManager:
    def __init__(self):
        self.config_dir = Path.home() / ".leetcode-cli"
        self.config_file = self.config_dir / "session.json"
        self._ensure_config_dir()

    def _ensure_config_dir(self):
        if not self.config_dir.exists():
            self.config_dir.mkdir(parents=True)

    def save_session(self, csrftoken, session_token, user_name):
        session_data = {
            "csrftoken": csrftoken,
            "session_token": session_token,
            "user_name": user_name
        }
        with open(self.config_file, "w") as f:
            json.dump(session_data, f)

    def load_session(self):
        if self.config_file.exists():
            with open(self.config_file, "r") as f:
                return json.load(f)
        return None

    def clear_session(self):
        if self.config_file.exists():
            os.remove(self.config_file)