from src.lib.problem_ui import ProblemDetails
from src.server.api import get_daily_question
from src.server.config import BASE_URL
from src.server.session_manager import SessionManager

def show(problem, save=False, compact=False):
    """Show problem details including description and test cases."""
    session_manager = SessionManager()
    session = session_manager.get_session()
    csrf_token = session.cookies.get('csrftoken')
    leetcode_session = session.cookies.get('LEETCODE_SESSION')
    if not csrf_token or not leetcode_session:
        print("Please login first.")
        return

    if problem == 'daily':
        daily_question = get_daily_question(csrf_token, leetcode_session)
        if not daily_question:
            print("No daily question available.")
            return

        problem_number = daily_question['question']['questionFrontendId']
        title_slug = daily_question['question']['titleSlug']
    else:
        problem_number = problem
        title_slug = problem

    problem_data = SolutionManager(session).get_question_data(title_slug)
    problem_details = ProblemDetails(problem_data)
    if save:
        _save_problem_to_file(problem_details)
    else:
        if compact:
            problem_details.display_header()
        else:
            problem_details.display_probelm()