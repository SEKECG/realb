from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich.style import Style
from src.server.config import BASE_URL

console = Console()

class ProblemDetails:
    def __init__(self, problem_data):
        self.content = problem_data['content']
        self.difficulty = problem_data['difficulty']['level']
        self.problem_number = problem_data['question']['questionFrontendId']
        self.similar_questions = problem_data['question']['similarQuestions']
        self.stats = problem_data['question']['stats']
        self.title = problem_data['question']['title']
        self.topics = problem_data['question']['topicTags']

    def _create_header(self):
        header = f"[bold]{self.problem_number}. {self.title}[/bold]"
        if self.difficulty == 1:
            header += " [green]Easy[/green]"
        elif self.difficulty == 2:
            header += " [yellow]Medium[/yellow]"
        elif self.difficulty == 3:
            header += " [red]Hard[/red]"
        return header

    def _format_markdown(self, content):
        # Convert HTML to Markdown
        # Adjust headings, code blocks, and key sections (Input, Output, Explanation)
        # Normalize line breaks
        return content

    def _format_similar_questions(self):
        similar_questions = []
        for question in self.similar_questions:
            title = question['title']
            difficulty = question['difficulty']['level']
            url = f"{BASE_URL}/problems/{question['titleSlug']}"
            similar_questions.append(f"[link={url}]{title}[/link] ({difficulty})")
        return ", ".join(similar_questions)

    def _format_stats(self):
        stats = f"Acceptance Rate: {self.stats['acRate']}%\nTotal Accepted: {self.stats['totalAccepted']}\nTotal Submissions: {self.stats['totalSubmissions']}"
        return stats

    def _format_topics(self):
        topics = [topic['name'] for topic in self.topics]
        return ", ".join(topics)

    def display_additional_info(self):
        table = Table(show_header=False, show_lines=True)
        table.add_column("Topics", style="bold")
        table.add_column("Similar Questions", style="bold")
        table.add_row(self._format_topics(), self._format_similar_questions())
        console.print(table)

    def display_probelm(self):
        formatted_content = self._format_markdown(self.content)
        panel = Panel(formatted_content, title=self._create_header(), style="bold")
        console.print(panel)

    def display_stats(self):
        stats = self._format_stats()
        panel = Panel(stats, title="Statistics", style="bold")
        console.print(panel)