import click
from src.commands.daily import daily
from src.commands.edit import edit
from src.commands.list_problems import list_problems
from src.commands.login import login, logout
from src.commands.profile import profile
from src.commands.show import show
from src.commands.solution import solutions
from src.commands.submit import submit
from src.commands.test import test
from src.lib.welcome import display_welcome

@click.group()
@click.pass_context
def app(ctx):
    """LeetCode CLI - A command-line tool for LeetCode problems."""
    ctx.ensure_object(dict)

@app.command()
@click.pass_context
def daily(ctx):
    """Get and work on today's LeetCode daily challenge."""
    daily()

@app.command()
@click.argument('problem')
@click.option('--lang', default='python3', help='Language to use for the solution')
@click.option('--editor', default='vim', help='Code editor to use')
@click.option('--full', is_flag=True, help='Open the problem in full mode')
@click.option('--no-editor', is_flag=True, help='Do not open the problem in an editor')
def edit(ctx, problem, lang, editor, full, no_editor):
    """Solves a problem by passing lang param and open it with your code editor."""
    edit(problem, lang, editor, full, no_editor)

@app.command()
@click.option('--difficulty', default=None, help='Filter problems by difficulty')
@click.option('--status', default=None, help='Filter problems by status')
@click.option('--tag', default=None, help='Filter problems by tag')
@click.option('--category-slug', default=None, help='Filter problems by category slug')
def list_problems(difficulty, status, tag, category_slug):
    """List available LeetCode problems with optional filters."""
    list_problems(difficulty, status, tag, category_slug)

@app.command()
@click.option('--username', prompt=True, help='LeetCode username')
@click.option('--password', prompt=True, hide_input=True, help='LeetCode password')
def login(username, password):
    """Login to LeetCode."""
    login(username, password)

@app.command()
def logout():
    """Logout from LeetCode."""
    logout()

@app.command()
@click.argument('problem')
def profile(problem):
    """View user profile statistics."""
    profile(problem)

@app.command()
@click.argument('problem')
@click.option('--save', is_flag=True, help='Save problem to a file')
@click.option('--compact', is_flag=True, help='Show a condensed view')
def show(problem, save, compact):
    """Show problem details including description and test cases."""
    show(problem, save, compact)

@app.command()
@click.argument('problem')
@click.option('--best', is_flag=True, help='Show the best solution')
def solutions(problem, best):
    """Fetch solution for a problem."""
    solutions(problem, best)

@app.command()
@click.argument('problem')
@click.argument('file')
@click.option('--lang', default=None, help='Language of the solution file')
@click.option('--force', is_flag=True, help='Force submission even if the solution is not valid')
def submit(problem, file, lang, force):
    """Submit a solution to LeetCode."""
    submit(problem, file, lang, force)

@app.command()
@click.argument('problem')
@click.argument('file')
def test(problem, file):
    """Test a solution with LeetCode's test cases."""
    test(problem, file)

@app.command()
def welcome():
    """Display welcome screen with ASCII art and command list."""
    display_welcome(app)

if __name__ == '__main__':
    app()