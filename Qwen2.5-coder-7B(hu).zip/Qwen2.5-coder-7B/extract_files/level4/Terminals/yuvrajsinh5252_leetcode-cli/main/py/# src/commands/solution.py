from src.server.api import fetch_problem_list
from src.server.config import BASE_URL
from src.server.session_manager import SessionManager
from src.lib.solution_ui import SolutionUI

def solutions(problem, best=False):
    """Fetch solution for a problem."""
    session_manager = SessionManager()
    session = session_manager.get_session()
    csrf_token = session.cookies.get('csrftoken')
    leetcode_session = session.cookies.get('LEETCODE_SESSION')
    if not csrf_token or not leetcode_session:
        print("Please login first.")
        return

    if problem == 'daily':
        daily_question = get_daily_question(csrf_token, leetcode_session)
        if not daily_question:
            print("No daily question available.")
            return

        problem_number = daily_question['question']['questionFrontendId']
        title_slug = daily_question['question']['titleSlug']
    else:
        problem_number = problem
        title_slug = problem

    problem_data = SolutionManager(session).get_question_data(title_slug)
    problem_details = ProblemDetails(problem_data)
    solutions = SolutionUI(problem_details).solutions
    SolutionUI(problem_details).show_solution()