from src.server.api import fetch_user_profile
from src.server.config import BASE_URL
from src.server.session_manager import SessionManager
from src.lib.profile_ui import display_user_stats

def profile(problem):
    """View user profile statistics."""
    session_manager = SessionManager()
    session = session_manager.get_session()
    csrf_token = session.cookies.get('csrftoken')
    leetcode_session = session.cookies.get('LEETCODE_SESSION')
    if not csrf_token or not leetcode_session:
        print("Please login first.")
        return

    user_profile = fetch_user_profile(csrf_token, leetcode_session)
    display_user_stats(user_profile)