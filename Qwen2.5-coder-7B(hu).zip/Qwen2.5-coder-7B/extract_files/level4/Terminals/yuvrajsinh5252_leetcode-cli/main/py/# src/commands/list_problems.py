from src.server.api import fetch_problem_list
from src.server.config import BASE_URL
from src.server.session_manager import SessionManager

def list_problems(difficulty=None, status=None, tag=None, category_slug=None):
    """List available LeetCode problems with optional filters."""
    session_manager = SessionManager()
    session = session_manager.get_session()
    csrf_token = session.cookies.get('csrftoken')
    leetcode_session = session.cookies.get('LEETCODE_SESSION')
    if not csrf_token or not leetcode_session:
        print("Please login first.")
        return

    problems = fetch_problem_list(csrf_token, leetcode_session, category_slug, limit=1000, skip=0, filters={})
    if difficulty:
        problems = [p for p in problems if p['difficulty']['level'] == difficulty]
    if status:
        problems = [p for p in problems if p['status'] == status]
    if tag:
        problems = [p for p in problems if tag in p['topicTags']]

    display_problem_list(problems)