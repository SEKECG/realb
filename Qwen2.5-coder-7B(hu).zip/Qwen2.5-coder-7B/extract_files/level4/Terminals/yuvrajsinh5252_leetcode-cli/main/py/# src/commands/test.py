from src.lib.solution_manager import SolutionManager
from src.server.api import get_daily_question
from src.server.auth import Auth
from src.server.config import BASE_URL
from src.server.session_manager import SessionManager
from src.lib.submission_ui import create_submission_progress, display_submission_details, display_submission_results

def test(problem, file):
    """Test a solution with LeetCode's test cases."""
    auth = Auth()
    session_manager = SessionManager()
    session = session_manager.get_session()
    csrf_token = auth._get_csrf_token(session)
    leetcode_session = session.cookies.get('LEETCODE_SESSION')
    if not leetcode_session:
        print("Please login first.")
        return

    if problem == 'daily':
        daily_question = get_daily_question(csrf_token, leetcode_session)
        if not daily_question:
            print("No daily question available.")
            return

        problem_number = daily_question['question']['questionFrontendId']
        title_slug = daily_question['question']['titleSlug']
    else:
        problem_number = problem
        title_slug = problem

    with open(file, 'r') as f:
        code = f.read()

    submission_progress = create_submission_progress()
    submission_progress.start()
    result = SolutionManager(session).test_solution(title_slug, code, 'python3', full=True)
    submission_progress.stop()

    display_submission_details(problem_number, title_slug, 'python3', file)
    display_submission_results(result, True)