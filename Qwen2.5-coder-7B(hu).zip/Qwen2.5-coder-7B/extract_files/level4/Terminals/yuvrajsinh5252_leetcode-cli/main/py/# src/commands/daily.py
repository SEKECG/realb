from src.lib.problem_ui import ProblemDetails
from src.lib.solution_manager import SolutionManager
from src.lib.submission_ui import create_submission_progress, display_submission_details, display_submission_results
from src.server.api import get_daily_question
from src.server.auth import Auth
from src.server.config import BASE_URL
from src.server.session_manager import SessionManager

def daily(lang='python3', editor='vim', full=False, no_editor=False):
    """Get and work on today's LeetCode daily challenge."""
    auth = Auth()
    session_manager = SessionManager()
    session = session_manager.get_session()
    csrf_token = auth._get_csrf_token(session)
    leetcode_session = session.cookies.get('LEETCODE_SESSION')
    if not leetcode_session:
        print("Please login first.")
        return

    daily_question = get_daily_question(csrf_token, leetcode_session)
    if not daily_question:
        print("No daily question available.")
        return

    problem_number = daily_question['question']['questionFrontendId']
    title_slug = daily_question['question']['titleSlug']
    problem_data = SolutionManager(session).get_question_data(title_slug)
    problem_details = ProblemDetails(problem_data)
    if full:
        problem_details.display_probelm()
    else:
        problem_details.display_header()

    if not no_editor:
        solution_file = f"{problem_number}_{title_slug}.py"
        with open(solution_file, 'w') as f:
            f.write(problem_details.content)
        print(f"Solution file created: {solution_file}")
        print(f"Opening solution file in {editor}...")
        os.system(f"{editor} {solution_file}")