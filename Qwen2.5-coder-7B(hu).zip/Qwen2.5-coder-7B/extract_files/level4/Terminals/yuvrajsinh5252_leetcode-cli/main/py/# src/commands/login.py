from src.server.auth import Auth
from src.server.session_manager import SessionManager

def login(username, password):
    """Login to LeetCode."""
    auth = Auth()
    session_manager = SessionManager()
    session = session_manager.get_session()
    csrf_token = auth._get_csrf_token(session)
    leetcode_session = auth.login_with_session(csrf_token, password)
    if leetcode_session:
        session_manager.save_session(csrf_token, leetcode_session, username)
        print("Login successful.")
    else:
        print("Login failed.")

def logout():
    """Logout from LeetCode."""
    session_manager = SessionManager()
    session_manager.clear_session()
    print("Logout successful.")