from src.server.auth import Auth

def login():
    auth = Auth()
    auth.login_with_session()

def logout():
    auth = Auth()
    auth.logout()