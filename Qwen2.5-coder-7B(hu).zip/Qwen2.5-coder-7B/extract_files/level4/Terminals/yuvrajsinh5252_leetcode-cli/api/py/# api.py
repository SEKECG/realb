import requests
from config import BASE_URL, LEETCODE_BASE_URL
from auth import Auth
from solution_manager import SolutionManager

class LeetCodeAPI:
    def __init__(self):
        self.session = requests.Session()
        self.auth = Auth(self.session)
        self.solution_manager = SolutionManager(self.session)

    def get_daily_question(self):
        return self.solution_manager.get_daily_question()

    def fetch_problem_list(self, categorySlug=None, limit=10, skip=0, filters=None):
        return self.solution_manager.fetch_problem_list(categorySlug, limit, skip, filters)

    def fetch_user_profile(self):
        return self.solution_manager.fetch_user_profile()

    def create_leetcode_client(self):
        return self.solution_manager.create_leetcode_client()