from .test import test

def test(problem, file):
    # Test a solution with LeetCode's test cases
    pass