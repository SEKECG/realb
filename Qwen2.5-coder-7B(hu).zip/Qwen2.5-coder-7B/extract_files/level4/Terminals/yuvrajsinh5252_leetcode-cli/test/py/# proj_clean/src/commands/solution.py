from .solution import solutions

def solutions(problem, best=None):
    # Fetch solution for a problem
    pass