from .show import show

def show(problem, save=None, compact=None):
    # Show problem details including description and test cases
    # Fetches and displays the problem statement, examples, and metadata.
    # Use --compact for a condensed view or --save to export to a file.
    pass