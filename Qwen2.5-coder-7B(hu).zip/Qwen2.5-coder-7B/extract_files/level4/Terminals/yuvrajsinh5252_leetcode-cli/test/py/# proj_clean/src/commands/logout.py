from .logout import logout

def logout():
    # Logout from LeetCode
    pass