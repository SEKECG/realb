from .config import LANGUAGE_MAP, STATUS_CODES, BASE_URL, LEETCODE_BASE_URL, MEMORY_LIMIT_THRESHOLD, MEMORY_WARNING_THRESHOLD, SUBMISSION_RESULT_TIMEOUT, TEST_RESULT_TIMEOUT

LANGUAGE_MAP = {
    # Language map for LeetCode problem solutions.
}

STATUS_CODES = {
    # Status codes for LeetCode problem solutions.
}

BASE_URL = "https://leetcode.com/graphql"
LEETCODE_BASE_URL = "https://leetcode.com"
MEMORY_LIMIT_THRESHOLD = 450 * 1024 * 1024  # 450MB
MEMORY_WARNING_THRESHOLD = 100 * 1024 * 1024  # 100MB
SUBMISSION_RESULT_TIMEOUT = 10  # seconds
TEST_RESULT_TIMEOUT = 5  # seconds