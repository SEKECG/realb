from .submit import submit

def submit(problem, file, lang=None, force=False):
    # Submit a solution to LeetCode
    # Uploads your solution file to LeetCode and returns the verdict.
    # Language is auto-detected from file extension if not specified.
    pass