from .list_problems import list_problems

def list_problems(difficulty=None, status=None, tag=None, category_slug=None):
    # List available LeetCode problems with optional filters.
    pass