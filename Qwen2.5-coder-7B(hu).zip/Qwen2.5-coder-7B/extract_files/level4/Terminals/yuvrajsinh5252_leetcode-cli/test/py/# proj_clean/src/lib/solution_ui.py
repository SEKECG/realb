from .solution_ui import SolutionUI

class SolutionUI:
    # Display and manage LeetCode solutions in a formatted table with interactive features like opening solution URLs in a browser.
    pass