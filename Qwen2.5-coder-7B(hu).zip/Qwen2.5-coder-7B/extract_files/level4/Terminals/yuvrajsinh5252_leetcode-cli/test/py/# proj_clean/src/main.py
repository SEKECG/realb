from .main import callback, main

def callback(ctx):
    # LeetCode CLI - A command-line tool for LeetCode problems.
    pass

def main():
    # Execute the function `app()` when the script is run as the main program.
    pass