from .login import login

def login():
    # Login to LeetCode
    pass