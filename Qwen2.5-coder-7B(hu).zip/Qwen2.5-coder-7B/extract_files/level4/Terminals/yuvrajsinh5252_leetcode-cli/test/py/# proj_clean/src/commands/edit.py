from .edit import edit

def edit(problem, lang, editor):
    # Solves a problem by passing lang param and open it with your code editor.
    pass