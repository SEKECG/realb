from typing import Any, Dict, List, Optional, Union

class PromptBuilder:
    BASE_SYSTEM_PROMPT = "You are a helpful assistant."
    EXPLANATION_SYSTEM_PROMPT = "You are a helpful assistant that explains commands."
    FIXING_SYSTEM_PROMPT = "You are a helpful assistant that fixes commands."
    GIT_COMMIT_SYSTEM_PROMPT = "You are a helpful assistant that generates git commit messages."

    def __init__(self, config: Any):
        self.config = config
        self.shell = config.get_shell()

    def _gather_tools_context(self, tools: List[Any]) -> str:
        context = ""
        for tool in tools:
            try:
                context += tool.get_context()
            except Exception as e:
                print(f"Error gathering context for tool {tool.name}: {e}")
        return context

    def build_explanation_system_prompt(self, tools: List[Any]) -> str:
        context = self._gather_tools_context(tools)
        return f"{self.EXPLANATION_SYSTEM_PROMPT}\n\n{context}"

    def build_fixing_system_prompt(self, tools: List[Any]) -> str:
        context = self._gather_tools_context(tools)
        return f"{self.FIXING_SYSTEM_PROMPT}\n\n{context}"

    def build_fixing_user_prompt(self, prompt: str, failed_command: str, failed_command_exit_code: int, failed_command_output: str) -> str:
        return f"Command: {failed_command}\nExit Code: {failed_command_exit_code}\nOutput: {failed_command_output}\n\n{prompt}"

    def build_git_commit_system_prompt(self, declined_messages: List[str]) -> str:
        return f"{self.GIT_COMMIT_SYSTEM_PROMPT}\n\nDeclined Messages: {', '.join(declined_messages)}"

    def build_git_commit_user_prompt(self, git_diff: str, changed_files_content: Dict[str, str]) -> str:
        return f"Git Diff:\n{git_diff}\n\nChanged Files:\n{', '.join(changed_files_content.keys())}"

    def build_system_prompt(self, tools: List[Any], declined_commands: List[str]) -> str:
        context = self._gather_tools_context(tools)
        return f"{self.BASE_SYSTEM_PROMPT}\n\n{context}\n\nDeclined Commands: {', '.join(declined_commands)}"

    def load_prompt_from_file(self, file_path: str) -> str:
        try:
            with open(file_path, "r") as file:
                return file.read()
        except FileNotFoundError:
            print(f"Prompt file not found: {file_path}")
            return ""
        except Exception as e:
            print(f"Error loading prompt from file: {e}")
            return ""