from pyquist.audio import Audio
from pyquist.realtime import AudioProcessorStream

def play(audio: Audio, safe: bool = True, normalize: bool = True) -> None:
    """Plays the audio."""
    stream = AudioProcessorStream(audio.processor, audio.block_size, audio.sample_rate, audio.peak_gain)
    stream.start()
    stream.sleep(audio.duration)
    stream.stop()
    stream.close()
    stream.abort()